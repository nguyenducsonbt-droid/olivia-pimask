"use client"

import { useEffect, useState, useRef } from "react"
import { WalletDashboard } from "@/components/wallet-dashboard"
import { WalletSetup } from "@/components/wallet-setup"
import { WelcomeSplash } from "@/components/welcome-splash"
import { FaceIDConfirmationDialog } from "@/components/face-id-confirmation-dialog"
import { useWallet } from "@/hooks/use-wallet"
import { getWalletData, simpleDecrypt, testStorageIntegrity, saveWalletData, getAutoLockTime } from "@/lib/storage"
import { getWalletFromMnemonic } from "@/lib/wallet"
import { useAppUpdate } from "@/hooks/use-app-update"
import { Lock } from "lucide-react"

export default function HomePage() {
  const { wallet, setWallet } = useWallet()
  const [hasWallet, setHasWallet] = useState(false)
  const [loading, setLoading] = useState(true)
  const [showWalletSetup, setShowWalletSetup] = useState(false)
  const [setupMode, setSetupMode] = useState<"create" | "restore">("create")
  const [showFaceIDConfirmation, setShowFaceIDConfirmation] = useState(false)
  const [isLocked, setIsLocked] = useState(false)
  const [pendingWalletData, setPendingWalletData] = useState<{ address: string; encryptedMnemonic: string } | null>(
    null,
  )
  const [hasImportedPiWallet, setHasImportedPiWallet] = useState(false)

  const isMountedRef = useRef(true)
  const refreshTimeoutRef = useRef<NodeJS.Timeout>()
  const backgroundTimeRef = useRef<number>(0)
  const lastResumeTimeRef = useRef<number>(0)
  const forceRefreshTimeoutRef = useRef<NodeJS.Timeout>()
  const isInitialLoadRef = useRef(true)

  useAppUpdate()

  useEffect(() => {
    isMountedRef.current = true

    const initializePiSDK = async () => {
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi
        const savedNetwork = localStorage.getItem("olivia_network") || "mainnet"
        const isMainnet = savedNetwork === "mainnet"

        try {
          if (!Pi.initialized) {
            Pi.init({
              version: "2.0",
              sandbox: !isMainnet,
            })
            Pi.initialized = true
          }

          const isResuming = sessionStorage.getItem("olivia_app_resumed") === "true"

          if (!isResuming) {
            const { loadPiSession, savePiSession } = await import("@/lib/persistent-storage")
            const existingSession = loadPiSession()

            if (!existingSession) {
              try {
                const authResult = await Pi.authenticate(["username", "payments", "wallet_address"], (payment: any) => {
                  console.log("Incomplete payment:", payment)
                })

                if (authResult && authResult.user) {
                  await savePiSession({
                    user: authResult.user,
                    accessToken: authResult.accessToken,
                    scopes: ["username", "payments", "wallet_address"],
                  })

                  window.dispatchEvent(
                    new CustomEvent("olivia-pi-session-changed", {
                      detail: {
                        user: authResult.user,
                        accessToken: authResult.accessToken,
                        scopes: ["username", "payments", "wallet_address"],
                      },
                    }),
                  )
                }
              } catch (error: any) {
                if (!error.message?.includes("user_cancelled")) {
                  console.error("Auto Pi authentication failed:", error)
                }
              }
            } else {
              window.dispatchEvent(
                new CustomEvent("olivia-pi-session-changed", {
                  detail: {
                    user: existingSession.user,
                    accessToken: existingSession.accessToken,
                    scopes: existingSession.scopes || ["username", "payments", "wallet_address"],
                  },
                }),
              )
            }
          }
        } catch (error) {
          console.error("Error initializing Pi SDK:", error)
        }
      }
    }

    initializePiSDK()

    const visibilityTimeout: NodeJS.Timeout | null = null

    const handleVisibilityChange = () => {
      // Clear previous timeout
      if (visibilityTimeout) {
        clearTimeout(visibilityTimeout)
      }
      if (forceRefreshTimeoutRef.current) {
        clearTimeout(forceRefreshTimeoutRef.current)
      }

      if (!document.hidden && isMountedRef.current) {
        const now = Date.now()
        const timeSinceLastResume = now - lastResumeTimeRef.current

        // Prevent rapid-fire resume events
        if (timeSinceLastResume < 500 && !isInitialLoadRef.current) {
          console.log("[v0] Debouncing resume event")
          return
        }

        lastResumeTimeRef.current = now
        isInitialLoadRef.current = false

        console.log("[v0] App resumed - forcing UI refresh")

        // Immediately clear any loading states
        sessionStorage.removeItem("olivia_navigating_away")

        const autoLockTime = getAutoLockTime()
        const backgroundTime = sessionStorage.getItem("olivia_app_backgrounded")

        if (autoLockTime && autoLockTime !== "never" && backgroundTime) {
          const timeInBackground = now - Number.parseInt(backgroundTime, 10)
          const autoLockMs = Number.parseInt(autoLockTime, 10) * 60 * 1000

          console.log("[v0] Time in background:", timeInBackground, "ms")
          console.log("[v0] Auto-lock timeout:", autoLockMs, "ms")

          if (timeInBackground >= autoLockMs) {
            console.log("[v0] Auto-lock triggered - locking wallet")
            setIsLocked(true)
            setWallet(null)
            setHasWallet(false)
          }
        }

        // Mark app as resumed
        sessionStorage.setItem("olivia_app_resumed", "true")

        window.dispatchEvent(new Event("olivia-refresh-ui"))
        window.dispatchEvent(new Event("olivia-force-refresh"))

        // Clear any stale cache that might cause UI freeze
        if (typeof window !== "undefined") {
          try {
            // Clear performance entries to free memory
            if (performance.clearResourceTimings) {
              performance.clearResourceTimings()
            }
            if (performance.clearMarks) {
              performance.clearMarks()
            }
          } catch (e) {
            // Silent fail
          }
        }

        // Schedule a secondary refresh for any async components
        forceRefreshTimeoutRef.current = setTimeout(() => {
          if (isMountedRef.current) {
            window.dispatchEvent(new Event("olivia-refresh-ui"))
          }
        }, 100)
      } else {
        // App going to background - preserve state
        sessionStorage.setItem("olivia_app_backgrounded", Date.now().toString())
        console.log("[v0] App backgrounded at:", Date.now())
      }
    }

    const handleFocus = () => {
      if (!document.hidden && isMountedRef.current) {
        console.log("[v0] Window focused - refreshing UI")
        sessionStorage.removeItem("olivia_navigating_away")
        window.dispatchEvent(new Event("olivia-refresh-ui"))
        window.dispatchEvent(new Event("olivia-force-refresh"))
      }
    }

    const handlePageShow = (event: PageTransitionEvent) => {
      console.log("[v0] Page show event, persisted:", event.persisted)
      if (event.persisted && isMountedRef.current) {
        // Page restored from cache - force full refresh
        sessionStorage.removeItem("olivia_navigating_away")
        window.location.reload()
      }
    }

    const handleBeforeUnload = () => {
      if (sessionStorage.getItem("olivia_navigating_away") !== "true") {
        sessionStorage.setItem("olivia_app_backgrounded", Date.now().toString())
      }
    }

    const checkAndLoadWallet = async () => {
      if (!isMountedRef.current) return

      const storageWorks = testStorageIntegrity()
      if (!storageWorks) {
        alert("CRITICAL ERROR: localStorage không hoạt động. Vui lòng kiểm tra trình duyệt.")
        setLoading(false)
        return
      }

      try {
        const sessionWallet = sessionStorage.getItem("olivia_pi_wallet_session")
        const piWalletString = localStorage.getItem("olivia_pi_wallet")
        const walletEncrypted = localStorage.getItem("olivia_wallet_encrypted")

        if (sessionWallet || piWalletString || walletEncrypted) {
          console.log("[v0] Found imported Pi wallet in storage")
          if (isMountedRef.current) {
            setHasImportedPiWallet(true)
            setHasWallet(true)
          }
        }
      } catch (error) {
        console.error("[v0] Error checking Pi wallet:", error)
      }

      const walletData = getWalletData()

      if (walletData) {
        try {
          const mnemonic = simpleDecrypt(walletData.encryptedMnemonic, walletData.address)
          const walletInstance = getWalletFromMnemonic(mnemonic)

          if (isMountedRef.current) {
            setWallet(walletInstance)
            setHasWallet(true)
          }
        } catch (err) {
          console.error("Error loading wallet:", err)
          if (isMountedRef.current) {
            setHasWallet(false)
          }
        }
      } else {
        if (isMountedRef.current) {
          if (!hasImportedPiWallet) {
            setHasWallet(false)
          }
        }
      }

      if (isMountedRef.current) {
        setLoading(false)
      }
    }

    checkAndLoadWallet()

    document.addEventListener("visibilitychange", handleVisibilityChange)
    window.addEventListener("focus", handleFocus)
    window.addEventListener("pageshow", handlePageShow)
    window.addEventListener("beforeunload", handleBeforeUnload)

    return () => {
      isMountedRef.current = false
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current)
      }
      if (visibilityTimeout) {
        clearTimeout(visibilityTimeout)
      }
      if (forceRefreshTimeoutRef.current) {
        clearTimeout(forceRefreshTimeoutRef.current)
      }
      document.removeEventListener("visibilitychange", handleVisibilityChange)
      window.removeEventListener("focus", handleFocus)
      window.removeEventListener("pageshow", handlePageShow)
      window.removeEventListener("beforeunload", handleBeforeUnload)
    }
  }, [setWallet, hasImportedPiWallet])

  const handleCreateWallet = () => {
    setSetupMode("create")
    setShowWalletSetup(true)
  }

  const handleRestoreWallet = () => {
    setSetupMode("restore")
    setShowWalletSetup(true)
  }

  const handleWalletSetupComplete = async (address: string, encryptedMnemonic: string) => {
    const saveSuccess = saveWalletData(address, encryptedMnemonic)

    if (!saveSuccess) {
      alert("Lỗi lưu ví. Vui lòng thử lại.")
      return
    }

    setPendingWalletData({ address, encryptedMnemonic })
    setShowFaceIDConfirmation(true)
  }

  const handleFaceIDSuccess = async () => {
    if (!pendingWalletData) return

    try {
      const mnemonic = simpleDecrypt(pendingWalletData.encryptedMnemonic, pendingWalletData.address)
      const walletInstance = getWalletFromMnemonic(mnemonic)

      setWallet(walletInstance)
      setHasWallet(true)
      setShowWalletSetup(false)
      setShowFaceIDConfirmation(false)
      setPendingWalletData(null)
    } catch (err) {
      console.error("Error loading wallet after setup:", err)
      alert("Lỗi tải ví. Vui lòng thử lại.")
    }
  }

  const handleFaceIDSkip = async () => {
    if (!pendingWalletData) return

    try {
      const mnemonic = simpleDecrypt(pendingWalletData.encryptedMnemonic, pendingWalletData.address)
      const walletInstance = getWalletFromMnemonic(mnemonic)

      setWallet(walletInstance)
      setHasWallet(true)
      setShowWalletSetup(false)
      setShowFaceIDConfirmation(false)
      setPendingWalletData(null)
    } catch (err) {
      console.error("Error loading wallet after setup:", err)
      alert("Lỗi tải ví. Vui lòng thử lại.")
    }
  }

  const handleUnlock = async () => {
    const walletData = getWalletData()

    if (walletData) {
      try {
        const mnemonic = simpleDecrypt(walletData.encryptedMnemonic, walletData.address)
        const walletInstance = getWalletFromMnemonic(mnemonic)

        setWallet(walletInstance)
        setHasWallet(true)
        setIsLocked(false)
      } catch (err) {
        console.error("Error unlocking wallet:", err)
        alert("Lỗi mở khóa ví. Vui lòng thử lại.")
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="mt-4 text-gray-600 font-medium">Đang tải...</p>
        </div>
      </div>
    )
  }

  if (isLocked) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-10 h-10 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Ví đã bị khóa</h2>
          <p className="text-gray-600 mb-6">Ví của bạn đã tự động khóa do không hoạt động</p>
          <button
            onClick={handleUnlock}
            className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
          >
            Mở khóa ví
          </button>
        </div>
      </div>
    )
  }

  if (!hasWallet && !showWalletSetup) {
    return <WelcomeSplash onCreateWallet={handleCreateWallet} onRestoreWallet={handleRestoreWallet} />
  }

  if (showWalletSetup) {
    return (
      <>
        <WalletSetup onComplete={handleWalletSetupComplete} initialMode={setupMode} />
        <FaceIDConfirmationDialog
          open={showFaceIDConfirmation}
          onSuccess={handleFaceIDSuccess}
          onSkip={handleFaceIDSkip}
        />
      </>
    )
  }

  if (hasWallet || hasImportedPiWallet) {
    return <WalletDashboard />
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="mt-4 text-gray-600 font-medium">Đang tải...</p>
      </div>
    </div>
  )
}
