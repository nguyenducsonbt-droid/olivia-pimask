import { NextResponse } from "next/server"

export async function GET() {
  const verificationKey =
    process.env.NEXT_PUBLIC_PI_VALIDATION_KEY ||
    "8e50bead8c4165b42a031a1bac9db62294d4c254fbfc81f7aba0b719a49ecd836b17b95f55127d86037f034f76d6a4d9a4d14aa4cdc42c1fed6806c9c88b9942"

  return new NextResponse(verificationKey, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET",
      "Cache-Control": "public, max-age=0, must-revalidate",
    },
  })
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
