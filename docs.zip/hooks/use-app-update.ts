"use client"

import { useState, useEffect, useCallback } from "react"
import { useToast } from "@/hooks/use-toast"

const CURRENT_VERSION = "1.0.0"
const VERSION_CHECK_URL = "https://api.github.com/repos/olivia-pimask/app/releases/latest" // Placeholder URL
const APP_URL = "https://minepi.com/oliviapimask" // Deep link to app on Ecosystem Directory
const UPDATE_CHECKED_KEY = "olivia_update_checked"
const UPDATE_DISMISSED_KEY = "olivia_update_dismissed_version"
const UPDATE_SUCCESS_SHOWN_KEY = "olivia_update_success_shown"

interface VersionInfo {
  version: string
  releaseNotes: string
  downloadUrl: string
}

export function useAppUpdate() {
  const [checking, setChecking] = useState(false)
  const [updateAvailable, setUpdateAvailable] = useState(false)
  const [latestVersion, setLatestVersion] = useState<VersionInfo | null>(null)
  const { toast } = useToast()

  const compareVersions = useCallback((v1: string, v2: string): number => {
    const parts1 = v1.split(".").map(Number)
    const parts2 = v2.split(".").map(Number)

    for (let i = 0; i < 3; i++) {
      if (parts1[i] > parts2[i]) return 1
      if (parts1[i] < parts2[i]) return -1
    }
    return 0
  }, [])

  const checkForUpdates = useCallback(
    async (silent = false) => {
      setChecking(true)

      try {
        // Simulate API call - In production, this would call a real API
        // For now, we'll simulate no update available
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Simulated response - replace with real API call
        const mockVersion = "1.0.0" // Change this to test update flow
        const hasUpdate = compareVersions(mockVersion, CURRENT_VERSION) > 0

        if (hasUpdate) {
          const versionInfo: VersionInfo = {
            version: mockVersion,
            releaseNotes: "Swap mượt hơn, staking ngon hơn",
            downloadUrl: APP_URL,
          }

          setLatestVersion(versionInfo)
          setUpdateAvailable(true)

          // Check if user dismissed this version
          const dismissedVersion = localStorage.getItem(UPDATE_DISMISSED_KEY)
          if (dismissedVersion !== mockVersion && !silent) {
            toast({
              title: "Có update mới! Swap mượt hơn, staking ngon hơn 💜",
              description: `Phiên bản ${mockVersion} sẵn sàng`,
              action: {
                label: "Update ngay",
                onClick: () => {
                  window.location.href = APP_URL
                },
              },
              duration: 8000,
            })
          }
        } else {
          setUpdateAvailable(false)
          if (!silent) {
            toast({
              title: "Bạn đang dùng phiên bản mới nhất",
              description: `Phiên bản ${CURRENT_VERSION}`,
              duration: 3000,
            })
          }
        }

        localStorage.setItem(UPDATE_CHECKED_KEY, Date.now().toString())
      } catch (error) {
        console.error("Error checking for updates:", error)
        if (!silent) {
          toast({
            title: "Không thể kiểm tra cập nhật",
            description: "Vui lòng thử lại sau",
            variant: "destructive",
            duration: 3000,
          })
        }
      } finally {
        setChecking(false)
      }
    },
    [compareVersions, toast],
  )

  const dismissUpdate = useCallback(() => {
    if (latestVersion) {
      localStorage.setItem(UPDATE_DISMISSED_KEY, latestVersion.version)
      setUpdateAvailable(false)
    }
  }, [latestVersion])

  const openUpdatePage = useCallback(() => {
    window.location.href = APP_URL
  }, [])

  // Auto-check on mount (background, only once per session)
  useEffect(() => {
    const lastChecked = localStorage.getItem(UPDATE_CHECKED_KEY)
    const now = Date.now()
    const oneHour = 60 * 60 * 1000

    // Only auto-check if not checked in the last hour
    if (!lastChecked || now - Number.parseInt(lastChecked) > oneHour) {
      // Delay to not block app startup
      setTimeout(() => {
        checkForUpdates(true)
      }, 3000)
    }

    // Check if this is first launch after update
    const updateSuccessShown = sessionStorage.getItem(UPDATE_SUCCESS_SHOWN_KEY)
    const lastDismissedVersion = localStorage.getItem(UPDATE_DISMISSED_KEY)

    if (!updateSuccessShown && lastDismissedVersion && lastDismissedVersion !== CURRENT_VERSION) {
      // User updated the app!
      setTimeout(() => {
        toast({
          title: "Update thành công! Cảm ơn bạn đã giữ Olivia mới nhất 🚀",
          description: `Phiên bản ${CURRENT_VERSION}`,
          duration: 5000,
        })
        sessionStorage.setItem(UPDATE_SUCCESS_SHOWN_KEY, "true")
        // Clear dismissed version since user updated
        localStorage.removeItem(UPDATE_DISMISSED_KEY)
      }, 2000)
    }
  }, [checkForUpdates, toast])

  return {
    currentVersion: CURRENT_VERSION,
    checking,
    updateAvailable,
    latestVersion,
    checkForUpdates,
    dismissUpdate,
    openUpdatePage,
  }
}
