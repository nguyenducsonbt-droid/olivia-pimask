"use client"

import { create } from "zustand"
import type { ethers } from "ethers"
import type { Network, Transaction, Token } from "@/lib/wallet"
import { DEFAULT_NETWORKS, getTokenBalance } from "@/lib/wallet"
import {
  saveCustomTokens,
  getCustomTokens,
  saveCustomNetworks,
  getCustomNetworks,
  savePiConnection,
  getPiConnection,
  clearPiConnection,
} from "@/lib/storage"

interface WalletState {
  wallet: ethers.HDNodeWallet | null
  address: string
  isUnlocked: boolean
  networks: Network[]
  currentNetwork: Network
  tokens: Token[]
  transactions: Transaction[]
  balance: string
  setWallet: (wallet: ethers.HDNodeWallet) => void
  clearWallet: () => void
  setNetworks: (networks: Network[]) => void
  setCurrentNetwork: (network: Network) => void
  addTransaction: (transaction: Transaction) => void
  setBalance: (balance: string) => void
  addToken: (token: Token) => void
  removeToken: (address: string) => void
  refreshTokenBalances: () => Promise<void>
  loadCustomTokens: () => void
  piConnected: boolean
  piBalance: string
  piUsername: string
  piKycStatus: string
  piMainnetMigrated: boolean
  connectPiWallet: () => Promise<void>
  disconnectPiWallet: () => void
  syncPiBalance: () => Promise<void>
}

export const useWallet = create<WalletState>((set, get) => ({
  wallet: null,
  address: "",
  isUnlocked: false,
  networks: [...DEFAULT_NETWORKS, ...getCustomNetworks()],
  currentNetwork: DEFAULT_NETWORKS[0],
  tokens: [],
  transactions: [],
  balance: "0",
  piConnected: false,
  piBalance: "0",
  piUsername: "",
  piKycStatus: "",
  piMainnetMigrated: false,
  setWallet: (wallet) => set({ wallet, address: wallet.address, isUnlocked: true }),
  clearWallet: () => set({ wallet: null, address: "", isUnlocked: false }),
  setNetworks: (networks) => {
    set({ networks })
    const customNetworks = networks.filter((n) => n.id.startsWith("custom-"))
    saveCustomNetworks(customNetworks)
  },
  setCurrentNetwork: (network) => set({ currentNetwork: network }),
  addTransaction: (transaction) => set((state) => ({ transactions: [transaction, ...state.transactions] })),
  setBalance: (balance) => set({ balance }),
  addToken: (token) => {
    const state = get()
    const newToken = { ...token, isCustom: true }
    const updatedTokens = [...state.tokens, newToken]
    set({ tokens: updatedTokens })
    saveCustomTokens(updatedTokens.filter((t) => t.isCustom))
  },
  removeToken: (address) => {
    const state = get()
    const updatedTokens = state.tokens.filter((t) => t.address !== address)
    set({ tokens: updatedTokens })
    saveCustomTokens(updatedTokens.filter((t) => t.isCustom))
  },
  refreshTokenBalances: async () => {
    const state = get()
    if (!state.address || !state.currentNetwork) return

    const updatedTokens = await Promise.all(
      state.tokens.map(async (token) => {
        try {
          const rawBalance = await getTokenBalance(state.address, token.address, state.currentNetwork.rpcUrl)
          const formattedBalance = (Number(rawBalance) / 10 ** token.decimals).toFixed(4)
          return { ...token, balance: formattedBalance }
        } catch (error) {
          console.error(`[v0] Error fetching balance for ${token.symbol}:`, error)
          return token
        }
      }),
    )

    set({ tokens: updatedTokens })
    saveCustomTokens(updatedTokens.filter((t) => t.isCustom))
  },
  loadCustomTokens: () => {
    const customTokens = getCustomTokens()
    if (customTokens.length > 0) {
      set({ tokens: customTokens })
    }
  },
  connectPiWallet: async () => {
    try {
      console.log("[v0] Starting Pi Wallet connection with session...")

      // Check if Pi SDK is available
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi

        // Initialize Pi SDK
        await Pi.init({ version: "2.0", sandbox: false })

        if (Pi.session && Pi.session.persist) {
          await Pi.session.persist({ inApp: true, browser: "pi" })
          console.log("[v0] Pi session persisted - will return to Olivia PiMask")
        }

        // Authenticate with Pi Browser
        const scopes = ["username", "payments", "wallet_address"]
        const authResult = await Pi.authenticate(scopes, (payment: any) => {
          console.log("[v0] Pi payment initiated:", payment)
        })

        console.log("[v0] Pi authentication result:", authResult)

        // Fetch user info and balance
        const userInfo = await Pi.User.getInfo()
        const balance = await Pi.User.getBalance()

        // Check KYC status
        const kycStatus = userInfo.kyc_status || "pending"

        // Check Mainnet migration
        const mainnetMigrated = userInfo.mainnet_migrated || false

        // Save connection data
        const connectionData = {
          accessToken: authResult.accessToken,
          userId: authResult.user.uid,
          username: authResult.user.username,
          balance: balance.toString(),
          kycStatus,
          mainnetMigrated,
        }

        savePiConnection(connectionData)

        localStorage.setItem("pi_session_active", "true")

        set({
          piConnected: true,
          piBalance: balance.toString(),
          piUsername: authResult.user.username,
          piKycStatus: kycStatus,
          piMainnetMigrated: mainnetMigrated,
        })

        console.log("[v0] Pi Wallet connected successfully with persistent session")
        return
      }

      // Fallback: Open Pi Browser for authentication
      const url = "pi://browser/wallet"
      window.location.href = url

      // Simulate connection for development
      setTimeout(() => {
        const mockData = {
          accessToken: "mock_token_" + Date.now(),
          userId: "mock_user_id",
          username: "pi_user",
          balance: "0.0000",
          kycStatus: "pending",
          mainnetMigrated: false,
        }

        savePiConnection(mockData)

        set({
          piConnected: true,
          piBalance: mockData.balance,
          piUsername: mockData.username,
          piKycStatus: mockData.kycStatus,
          piMainnetMigrated: mockData.mainnetMigrated,
        })
      }, 2000)
    } catch (error) {
      console.error("[v0] Pi Wallet connection failed:", error)
      throw error
    }
  },
  disconnectPiWallet: () => {
    clearPiConnection()
    set({
      piConnected: false,
      piBalance: "0",
      piUsername: "",
      piKycStatus: "",
      piMainnetMigrated: false,
    })
  },
  syncPiBalance: async () => {
    try {
      const connection = getPiConnection()
      if (!connection) return

      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi
        const balance = await Pi.User.getBalance()
        const userInfo = await Pi.User.getInfo()

        const updatedData = {
          ...connection,
          balance: balance.toString(),
          kycStatus: userInfo.kyc_status || connection.kycStatus,
          mainnetMigrated: userInfo.mainnet_migrated || connection.mainnetMigrated,
        }

        savePiConnection(updatedData)

        set({
          piBalance: balance.toString(),
          piKycStatus: updatedData.kycStatus,
          piMainnetMigrated: updatedData.mainnetMigrated,
        })
      }
    } catch (error) {
      console.error("[v0] Failed to sync Pi balance:", error)
    }
  },
}))
