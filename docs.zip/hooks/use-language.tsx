"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { translations, detectLanguage, saveLanguage, type Language } from "@/lib/i18n"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: typeof translations.vi
  changeLanguage: (lang: Language) => void
}

const LanguageContext = createContext<LanguageContextType>({
  language: "vi",
  setLanguage: () => {},
  changeLanguage: () => {},
  t: translations.vi,
})

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("vi")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const detectedLang = detectLanguage()
    setLanguageState(detectedLang)
  }, [])

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    saveLanguage(lang)
  }

  const value = {
    language: mounted ? language : "vi",
    setLanguage,
    changeLanguage: setLanguage,
    t: translations[mounted ? language : "vi"],
  }

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider")
  }
  return context
}
