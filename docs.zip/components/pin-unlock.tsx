"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Shield, Fingerprint, Eye, EyeOff } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { getPinHash, getBiometricEnabled, setBiometricEnabled, getPinMemoryEnabled } from "@/lib/storage"

interface PinUnlockProps {
  onUnlock: () => void
}

export function PinUnlock({ onUnlock }: PinUnlockProps) {
  const [pin, setPin] = useState<string[]>(["", "", "", "", "", ""])
  const [error, setError] = useState("")
  const [attempts, setAttempts] = useState(0)
  const [biometricEnabled, setBiometricEnabledState] = useState(false)
  const [pinMemoryEnabled, setPinMemoryEnabledState] = useState(false)
  const [showPreviewNotice, setShowPreviewNotice] = useState(false)
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const [biometricAttempts, setBiometricAttempts] = useState(0)
  const [showPin, setShowPin] = useState(false)

  useEffect(() => {
    const checkEnvironment = () => {
      const isDev = process.env.NODE_ENV === "development"
      const isPreview = window.location.hostname === "localhost" || window.location.hostname.includes("preview")
      setIsPreviewMode(isDev || isPreview)
    }

    checkEnvironment()

    const checkBiometric = async () => {
      const enabled = getBiometricEnabled()
      setBiometricEnabledState(enabled)

      const pinMemory = getPinMemoryEnabled()
      setPinMemoryEnabledState(pinMemory)

      const isDev = process.env.NODE_ENV === "development"
      const isPreview = window.location.hostname === "localhost" || window.location.hostname.includes("preview")

      if ((isDev || isPreview) && pinMemory && enabled) {
        console.log("[v0] Preview mode: Auto-unlocking with PIN memory enabled")
        setTimeout(() => {
          onUnlock()
        }, 800)
        return
      }

      if (enabled && pinMemory) {
        setTimeout(() => {
          handleBiometricUnlock()
        }, 500)
      }
    }

    checkBiometric()
  }, [])

  const handleBiometricUnlock = async () => {
    try {
      if (biometricAttempts >= 3) {
        setError("Đã thất bại 3 lần. Vui lòng nhập PIN.")
        return
      }

      if (typeof window !== "undefined" && (window as any).Pi && (window as any).Pi.biometric) {
        const Pi = (window as any).Pi
        const result = await Pi.biometric.authenticate({
          reason: "Mở khóa ví Olivia PiMask",
          fallbackEnabled: true,
        })

        if (result.success) {
          console.log("[v0] Face ID authentication successful")
          onUnlock()
        } else {
          setBiometricAttempts(biometricAttempts + 1)
          if (biometricAttempts + 1 >= 3) {
            setError("Đã thất bại 3 lần. Vui lòng nhập PIN.")
          } else {
            setError(`Face ID thất bại. Còn ${3 - biometricAttempts - 1} lần thử.`)
          }
        }
      } else {
        const result = confirm("Sử dụng Face ID để mở ví?")

        if (result) {
          console.log("[v0] Face ID authentication successful (preview)")
          onUnlock()
        } else {
          setBiometricAttempts(biometricAttempts + 1)
          if (biometricAttempts + 1 >= 3) {
            setError("Đã thất bại 3 lần. Vui lòng nhập PIN.")
          }
        }
      }
    } catch (err) {
      console.error("[v0] Biometric error:", err)
      setBiometricAttempts(biometricAttempts + 1)
      if (biometricAttempts + 1 >= 3) {
        setError("Đã thất bại 3 lần. Vui lòng nhập PIN.")
      } else {
        setError("Face ID không khả dụng. Vui lòng nhập PIN hoặc thử lại.")
      }
    }
  }

  const handleToggleFaceID = () => {
    if (isPreviewMode && !biometricEnabled) {
      setShowPreviewNotice(true)
    } else {
      const newState = !biometricEnabled
      setBiometricEnabled(newState)
      setBiometricEnabledState(newState)

      if (newState && pinMemoryEnabled) {
        setTimeout(() => handleBiometricUnlock(), 300)
      }
    }
  }

  const handlePreviewNoticeClose = () => {
    setShowPreviewNotice(false)
    setBiometricEnabled(true)
    setBiometricEnabledState(true)
    setTimeout(() => handleBiometricUnlock(), 300)
  }

  const handlePinInput = async (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return

    const newPin = [...pin]
    newPin[index] = value
    setPin(newPin)

    if (value && index < 5) {
      const nextInput = document.getElementById(`unlock-pin-${index + 1}`)
      nextInput?.focus()
    }

    if (newPin.every((digit) => digit) && index === 5) {
      verifyPin(newPin)
    }
  }

  const verifyPin = async (pinArray: string[]) => {
    const pinString = pinArray.join("")

    console.log("[v0] ====================================")
    console.log("[v0] VERIFYING PIN FOR UNLOCK")
    console.log("[v0] Entered PIN length:", pinString.length)
    console.log("[v0] Timestamp:", new Date().toLocaleString())

    const encoder = new TextEncoder()
    const data = encoder.encode(pinString)
    const hashBuffer = await crypto.subtle.digest("SHA-256", data)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

    console.log("[v0] Computed hash from entered PIN:", hashHex.substring(0, 10) + "...")

    const storedPinData = await getPinHash()

    if (!storedPinData) {
      console.error("[v0] ✗✗✗ CRITICAL: No PIN hash found in storage")
      console.log("[v0] ====================================")
      setError("Không tìm thấy PIN. Vui lòng thiết lập lại ví.")
      setPin(["", "", "", "", "", ""])
      return
    }

    console.log("[v0] Retrieved stored PIN hash:", storedPinData.pinHash.substring(0, 10) + "...")
    console.log("[v0] PIN version:", storedPinData.version)
    console.log("[v0] PIN nonce:", storedPinData.nonce)
    console.log("[v0] PIN saved at:", new Date(storedPinData.createdAt).toLocaleString())
    console.log("[v0] Hash comparison:")
    console.log("[v0]   Entered:", hashHex.substring(0, 20) + "...")
    console.log("[v0]   Stored:", storedPinData.pinHash.substring(0, 20) + "...")
    console.log("[v0]   Match:", hashHex === storedPinData.pinHash)

    if (hashHex === storedPinData.pinHash) {
      console.log("[v0] ✓✓✓ PIN VERIFICATION SUCCESSFUL")
      console.log("[v0] ✓ Correct PIN entered")
      console.log("[v0] ✓ Unlocking wallet...")
      console.log("[v0] ====================================")
      onUnlock()
    } else {
      console.error("[v0] ✗✗✗ PIN VERIFICATION FAILED")
      console.error("[v0] ✗ WRONG PIN - Hash does NOT match")
      console.error("[v0] ✗ This is NOT the correct PIN")
      console.log("[v0] ====================================")

      setAttempts(attempts + 1)
      setError(`PIN SAI - Không đúng! ${attempts >= 4 ? "Quá nhiều lần thử." : `Thử lại (${attempts + 1}/5).`}`)
      setPin(["", "", "", "", "", ""])

      setTimeout(() => {
        document.getElementById("unlock-pin-0")?.focus()
      }, 100)

      if (attempts >= 4) {
        setError("Quá nhiều lần thử sai. Vui lòng khởi động lại ứng dụng.")
      }
    }
  }

  return (
    <>
      <div className="min-h-screen flex items-center justify-center p-4 sm:p-12 bg-gradient-to-br from-purple-600 via-purple-500 to-pink-400">
        <Card className="w-full max-w-md mx-4 sm:mx-8 shadow-2xl border-purple-200 bg-white/95 backdrop-blur-sm rounded-3xl">
          <CardHeader className="text-center space-y-4 pt-8 pb-6">
            <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-700 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-purple-900 px-4">Mở khóa ví</CardTitle>
            <CardDescription className="text-base text-purple-700 px-4">
              {pinMemoryEnabled && biometricEnabled && biometricAttempts < 3
                ? "Sử dụng Face ID để mở khóa nhanh"
                : "Nhập mã PIN để tiếp tục"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 px-6 pb-8">
            <div className="relative flex justify-center items-center gap-2 sm:gap-3 px-2">
              {pin.map((digit, index) => (
                <input
                  key={index}
                  id={`unlock-pin-${index}`}
                  type={showPin ? "text" : "password"}
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handlePinInput(index, e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Backspace" && !digit && index > 0) {
                      const prevInput = document.getElementById(`unlock-pin-${index - 1}`)
                      prevInput?.focus()
                    }
                  }}
                  className="w-12 h-12 sm:w-14 sm:h-14 text-center text-2xl font-bold border-2 border-purple-300 rounded-xl focus:border-purple-600 focus:ring-2 focus:ring-purple-200 bg-purple-50 text-purple-900 transition-all duration-200"
                  autoFocus={index === 0}
                />
              ))}
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute -top-2 right-0 p-1 rounded-full bg-purple-100 hover:bg-purple-200 text-purple-700 transition-all duration-200 z-10"
                aria-label={showPin ? "Ẩn PIN" : "Hiện PIN"}
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {error && (
              <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-2 duration-300">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {biometricAttempts < 3 && (
              <div className="mt-6">
                <Button
                  onClick={handleToggleFaceID}
                  variant="outline"
                  className="w-full h-12 text-base border-2 border-purple-300 bg-purple-50/50 text-purple-700 hover:bg-purple-100 hover:border-purple-400 transition-all duration-200"
                  size="lg"
                >
                  <Fingerprint className="mr-2 h-5 w-5 text-purple-600" />
                  Sử dụng Face ID
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showPreviewNotice} onOpenChange={setShowPreviewNotice}>
        <DialogContent className="sm:max-w-md border-2 border-purple-200 bg-white/95 backdrop-blur-sm">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-purple-900 flex items-center gap-2">
              <Fingerprint className="w-6 h-6 text-purple-600" />
              Thông báo Face ID
            </DialogTitle>
            <DialogDescription className="text-base text-purple-700 leading-relaxed pt-2">
              Face ID sẽ hoạt động đầy đủ khi publish app thật.
              <br />
              <br />
              Trong preview bị hạn chế bởi Pi App Studio để bảo mật.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              onClick={handlePreviewNoticeClose}
              className="w-full bg-gradient-to-r from-purple-700 to-pink-500 hover:from-purple-800 hover:to-pink-600 text-white"
            >
              Đã hiểu
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
