"use client"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface BugReportDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function BugReportDialog({ open, onOpenChange }: BugReportDialogProps) {
  const [bugDescription, setBugDescription] = useState("")
  const { toast } = useToast()

  const handleSubmit = () => {
    if (!bugDescription.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng mô tả lỗi bạn gặp phải",
        variant: "destructive",
      })
      return
    }

    // Collect system info
    const systemInfo = {
      version: "1.0.0",
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString(),
      description: bugDescription,
    }

    // In a real app, send to backend API
    console.log("[v0] Bug report:", systemInfo)

    toast({
      title: "Đã gửi báo cáo",
      description: "Cảm ơn bạn đã báo lỗi. Chúng tôi sẽ xem xét và khắc phục sớm nhất.",
    })

    setBugDescription("")
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader>
          <DialogTitle className="text-purple-900">Báo lỗi</DialogTitle>
          <DialogDescription className="text-purple-700">
            Mô tả lỗi bạn gặp phải. Chúng tôi sẽ xem xét và khắc phục sớm nhất.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="bug-description" className="text-purple-900 font-medium">
              Mô tả lỗi
            </Label>
            <Textarea
              id="bug-description"
              placeholder="Ví dụ: Không thể gửi Pi, nút Gửi không hoạt động..."
              value={bugDescription}
              onChange={(e) => setBugDescription(e.target.value)}
              className="min-h-32 bg-white border-purple-200 text-purple-900 placeholder:text-purple-400"
            />
          </div>
          <div className="text-xs text-purple-600 space-y-1">
            <p>Thông tin thiết bị sẽ được gửi kèm:</p>
            <p>• Version: 1.0.0</p>
            <p>• Thiết bị: {navigator.userAgent.includes("Mobile") ? "Mobile" : "Desktop"}</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50"
            >
              Hủy
            </Button>
            <Button
              onClick={handleSubmit}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            >
              Gửi báo cáo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
