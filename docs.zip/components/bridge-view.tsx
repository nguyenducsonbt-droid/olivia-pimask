"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowRightLeft, Info, Loader2 } from "lucide-react"
import { triggerHaptic } from "@/lib/haptic"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"

const SUPPORTED_CHAINS = [
  { id: "ethereum", name: "Ethereum", symbol: "ETH", logo: "⟠", color: "text-gray-600" },
  { id: "bsc", name: "Binance Smart Chain", symbol: "BNB", logo: "🔶", color: "text-yellow-600" },
  { id: "polygon", name: "Polygon", symbol: "MATIC", logo: "🟣", color: "text-purple-600" },
  { id: "arbitrum", name: "Arbitrum", symbol: "ETH", logo: "🔵", color: "text-blue-600" },
  { id: "solana", name: "Solana", symbol: "SOL", logo: "◎", color: "text-purple-500" },
  { id: "avalanche", name: "Avalanche", symbol: "AVAX", logo: "🔺", color: "text-red-600" },
  { id: "optimism", name: "Optimism", symbol: "ETH", logo: "🔴", color: "text-orange-600" },
  { id: "base", name: "Base", symbol: "ETH", logo: "🔵", color: "text-blue-500" },
]

export function BridgeView() {
  const { balance } = useWallet()
  const { toast } = useToast()
  const [amount, setAmount] = useState("")
  const [fromChain, setFromChain] = useState("pi")
  const [toChain, setToChain] = useState("ethereum")
  const [isBridging, setIsBridging] = useState(false)

  const estimatedFee = amount ? (Number.parseFloat(amount) * 0.001).toFixed(6) : "0.000000"
  const estimatedGas = amount ? (Number.parseFloat(amount) * 0.0005).toFixed(6) : "0.000000"
  const totalCost = amount
    ? (Number.parseFloat(amount) + Number.parseFloat(estimatedFee) + Number.parseFloat(estimatedGas)).toFixed(6)
    : "0.000000"
  const estimatedReceive = amount
    ? (Number.parseFloat(amount) - Number.parseFloat(estimatedFee) - Number.parseFloat(estimatedGas)).toFixed(6)
    : "0.000000"

  const handleMaxClick = () => {
    const maxAmount = Number.parseFloat(balance) * 0.95 // Leave 5% for gas
    setAmount(maxAmount.toFixed(6))
    triggerHaptic("light")
  }

  const handleBridge = async () => {
    if (!amount || Number.parseFloat(amount) <= 0) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập số lượng Pi hợp lệ",
        variant: "destructive",
        duration: 2000,
      })
      return
    }

    if (Number.parseFloat(amount) > Number.parseFloat(balance)) {
      toast({
        title: "Số dư không đủ",
        description: `Bạn chỉ có ${balance} π`,
        variant: "destructive",
        duration: 2000,
      })
      return
    }

    setIsBridging(true)
    triggerHaptic("medium")

    // Demo mode - simulate bridge transaction
    setTimeout(() => {
      setIsBridging(false)
      toast({
        title: "🌉 Bridge demo",
        description: "Swap thật sẽ khả dụng khi Pi bridge & DeFi 2026 launch. Vui lòng chờ đợi!",
        duration: 4000,
      })
      setAmount("")
      triggerHaptic("success")
    }, 2000)
  }

  return (
    <div className="space-y-4 pb-24">
      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-purple-600" />
            Cross-Chain Bridge
          </CardTitle>
          <CardDescription>Chuyển Pi giữa các blockchain</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* From Chain */}
          <div className="space-y-2">
            <Label>Từ mạng</Label>
            <Select value={fromChain} onValueChange={setFromChain}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pi">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">π</span>
                    <span>Pi Network</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Amount Input */}
          <div className="space-y-2">
            <Label>Số lượng</Label>
            <div className="relative">
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pr-20"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={handleMaxClick}
                className="absolute right-2 top-1/2 -translate-y-1/2 h-7 px-2 text-xs font-semibold text-purple-600 hover:text-purple-700 hover:bg-purple-50"
              >
                MAX
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Số dư: {balance} π</p>
          </div>

          {/* Swap Direction Icon */}
          <div className="flex justify-center py-2">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <ArrowRightLeft className="w-5 h-5 text-purple-600 rotate-90" />
            </div>
          </div>

          {/* To Chain */}
          <div className="space-y-2">
            <Label>Đến mạng</Label>
            <Select value={toChain} onValueChange={setToChain}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SUPPORTED_CHAINS.map((chain) => (
                  <SelectItem key={chain.id} value={chain.id}>
                    <div className="flex items-center gap-2">
                      <span className={`text-lg ${chain.color}`}>{chain.logo}</span>
                      <span>{chain.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Fee Breakdown */}
          {amount && Number.parseFloat(amount) > 0 && (
            <Card className="bg-purple-50 border-purple-200">
              <CardContent className="pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Bridge Fee (0.1%)</span>
                  <span className="font-medium">{estimatedFee} π</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Gas Fee</span>
                  <span className="font-medium">~{estimatedGas} π</span>
                </div>
                <div className="border-t border-purple-200 pt-2 flex justify-between">
                  <span className="font-semibold">Bạn sẽ nhận</span>
                  <span className="font-semibold text-purple-600">{estimatedReceive} π</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Bridge Button */}
          <Button
            onClick={handleBridge}
            disabled={isBridging || !amount || Number.parseFloat(amount) <= 0}
            className="w-full text-white font-semibold"
            style={{
              background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
            }}
          >
            {isBridging ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Đang bridge...
              </>
            ) : (
              <>
                <ArrowRightLeft className="w-4 h-4 mr-2" />
                Bridge ngay
              </>
            )}
          </Button>

          {/* Demo Disclaimer */}
          <Alert className="bg-blue-50 border-blue-200">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-xs text-blue-800">
              <strong>Bridge & Portfolio là demo/mock.</strong> Tính năng bridge thực tế sẽ khả dụng khi Pi Network
              launch cross-chain bridge và DeFi 2026. Hỗ trợ bridge sang nhiều chain EVM + non-EVM khi Pi mở rộng. Hiện
              tại chưa hỗ trợ giao dịch thật.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Bridge Info */}
      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="text-base">Thông tin Bridge</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Thời gian ước tính</span>
            <span className="font-medium">5-15 phút</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Số tiền tối thiểu</span>
            <span className="font-medium">1 π</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Số tiền tối đa</span>
            <span className="font-medium">10,000 π</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Trạng thái</span>
            <span className="px-2 py-0.5 rounded-full text-xs bg-yellow-100 text-yellow-800 font-medium">
              Coming Soon 2026
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
