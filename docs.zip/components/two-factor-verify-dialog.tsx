"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Shield, Clock } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { verifyTOTP, getTwoFactorData, verifyBackupCode } from "@/lib/two-factor"

interface TwoFactorVerifyDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onVerified: () => void
  title?: string
  description?: string
}

export function TwoFactorVerifyDialog({
  open,
  onOpenChange,
  onVerified,
  title = "Xác thực 2FA",
  description = "Nhập mã từ Google Authenticator",
}: TwoFactorVerifyDialogProps) {
  const [code, setCode] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const [showBackupCodeInput, setShowBackupCodeInput] = useState(false)
  const [countdown, setCountdown] = useState(30)
  const { toast } = useToast()

  // Countdown timer for visual feedback
  useState(() => {
    if (!open) return

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) return 30
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(interval)
  })

  const handleVerify = async () => {
    if (code.length !== 6) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ 6 số",
        variant: "destructive",
      })
      return
    }

    setIsVerifying(true)

    try {
      const twoFactorData = getTwoFactorData()
      if (!twoFactorData) {
        throw new Error("2FA data not found")
      }

      let isValid = false

      if (showBackupCodeInput) {
        // Verify backup code
        isValid = verifyBackupCode(code)
      } else {
        // Verify TOTP code
        isValid = await verifyTOTP(code, twoFactorData.secret)
      }

      if (isValid) {
        toast({
          title: "Xác thực thành công",
          description: "Bạn có thể tiếp tục thao tác",
        })
        onVerified()
        onOpenChange(false)
        setCode("")
        setShowBackupCodeInput(false)
      } else {
        toast({
          title: "Mã không đúng",
          description: showBackupCodeInput ? "Mã dự phòng không hợp lệ" : "Vui lòng kiểm tra lại mã từ Authenticator",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Lỗi xác thực",
        description: "Không thể xác minh mã. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsVerifying(false)
    }
  }

  const handleClose = () => {
    setCode("")
    setShowBackupCodeInput(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-purple-900">
            <Shield className="w-5 h-5 text-purple-600" />
            {title}
          </DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Card className="bg-purple-50 border-purple-200 p-4">
            <p className="text-sm text-purple-900 text-center font-medium">
              {showBackupCodeInput ? "Nhập mã dự phòng 8 ký tự" : "Nhập mã 6 số từ Google Authenticator"}
            </p>
          </Card>

          <div className="space-y-3">
            <div className="relative">
              <Input
                type="text"
                inputMode={showBackupCodeInput ? "text" : "numeric"}
                maxLength={showBackupCodeInput ? 8 : 6}
                value={code}
                onChange={(e) =>
                  setCode(showBackupCodeInput ? e.target.value.toUpperCase() : e.target.value.replace(/\D/g, ""))
                }
                placeholder={showBackupCodeInput ? "ABCD1234" : "000000"}
                className="text-center text-2xl tracking-widest font-mono"
                autoFocus
              />
              {!showBackupCodeInput && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-mono">{countdown}s</span>
                </div>
              )}
            </div>

            {!showBackupCodeInput && (
              <button
                onClick={() => setShowBackupCodeInput(true)}
                className="text-sm text-purple-600 hover:text-purple-700 underline w-full text-center"
              >
                Sử dụng mã dự phòng
              </button>
            )}

            {showBackupCodeInput && (
              <button
                onClick={() => setShowBackupCodeInput(false)}
                className="text-sm text-purple-600 hover:text-purple-700 underline w-full text-center"
              >
                Quay lại nhập mã Authenticator
              </button>
            )}

            <Button
              onClick={handleVerify}
              disabled={(showBackupCodeInput ? code.length !== 8 : code.length !== 6) || isVerifying}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
            >
              {isVerifying ? "Đang xác minh..." : "Xác nhận"}
            </Button>

            <Button onClick={handleClose} variant="outline" className="w-full bg-transparent">
              Hủy
            </Button>
          </div>

          <Card className="bg-blue-50 border-blue-200 p-3">
            <p className="text-xs text-blue-800 text-center">
              💡 Mã mới mỗi 30 giây. Nếu mất thiết bị Authenticator, dùng mã dự phòng.
            </p>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  )
}
