"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Sparkles, ExternalLink } from "lucide-react"
import { memo, useState, useEffect } from "react"

interface MarketplaceNFT {
  id: string
  name: string
  image: string
  collection: string
  floorPrice: number
  rarity: "Common" | "Rare" | "Epic" | "Legendary"
  gradient: string
  contractAddress?: string
}

const marketplaceNFTs: MarketplaceNFT[] = [
  {
    id: "legendary-1",
    name: "Pi Pioneer Legendary #1",
    image: "/nft-images/pi-pioneer-legendary.jpg",
    collection: "Pi Pioneers",
    floorPrice: 500,
    rarity: "Legendary",
    gradient: "linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FF6B00 100%)",
    contractAddress: "0x1234...5678",
  },
]

const otherCollections: MarketplaceNFT[] = [
  {
    id: "olivia-pi",
    name: "olivia.pi",
    image: "/nft-images/olivia-pi-domain.jpg",
    collection: ".pi Domains",
    floorPrice: 100,
    rarity: "Epic",
    gradient: "linear-gradient(135deg, #9C27B0 0%, #E91E63 100%)",
    contractAddress: "0xabcd...ef01",
  },
  {
    id: "ecosystem-builder",
    name: "Pi Ecosystem Builder #101",
    image: "/nft-images/pi-ecosystem-builder.jpg",
    collection: "Ecosystem Builders",
    floorPrice: 50,
    rarity: "Rare",
    gradient: "linear-gradient(135deg, #00BCD4 0%, #4CAF50 100%)",
    contractAddress: "0x2345...6789",
  },
  {
    id: "pi-ape",
    name: "PiApe #777",
    image: "/nft-images/pi-ape.jpg",
    collection: "PiApes",
    floorPrice: 75,
    rarity: "Epic",
    gradient: "linear-gradient(135deg, #FF5722 0%, #FF9800 100%)",
    contractAddress: "0x3456...789a",
  },
  {
    id: "pi-digits",
    name: "PiDigits #314159",
    image: "/nft-images/pi-digits.jpg",
    collection: "PiDigits",
    floorPrice: 25,
    rarity: "Rare",
    gradient: "linear-gradient(135deg, #3F51B5 0%, #2196F3 100%)",
    contractAddress: "0x4567...89ab",
  },
]

const rarityBadgeStyles = {
  Legendary: "bg-gradient-to-r from-yellow-400 via-orange-400 to-orange-600 text-white shadow-lg shadow-orange-500/50",
  Epic: "bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg shadow-purple-500/50",
  Rare: "bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg shadow-blue-500/50",
  Common: "bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg shadow-green-500/50",
}

const MarketplaceNFTCard = memo(({ nft, isLegendary }: { nft: MarketplaceNFT; isLegendary?: boolean }) => {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [imageError, setImageError] = useState(false)

  useEffect(() => {
    const img = new Image()
    img.src = nft.image
    img.loading = "eager"
    img.onload = () => setImageLoaded(true)
    img.onerror = () => setImageError(true)
  }, [nft.image])

  return (
    <div
      className={`relative rounded-xl overflow-hidden group transition-all duration-300 ${
        isLegendary ? "col-span-full" : ""
      }`}
    >
      <div className="relative">
        <div className={`w-full ${isLegendary ? "h-48" : "h-40"} relative`} style={{ background: nft.gradient }}>
          {!imageLoaded && !imageError && (
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer opacity-50" />
          )}

          <img
            src={nft.image || "/placeholder.svg"}
            alt={nft.name}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
              imageLoaded ? "opacity-100" : "opacity-0"
            }`}
            loading="eager"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
          />

          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20">
            <div className={`${isLegendary ? "text-3xl" : "text-2xl"} animate-pulse drop-shadow-lg`}>✨</div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black/80 via-black/50 to-transparent py-3 px-3">
            <h3 className={`text-white font-bold text-center drop-shadow-lg ${isLegendary ? "text-lg" : "text-sm"}`}>
              {nft.name}
            </h3>
          </div>
        </div>

        <div className="absolute top-2 right-2 z-20">
          <span
            className={`px-2 py-1 rounded-full text-xs font-bold ${rarityBadgeStyles[nft.rarity]} transform rotate-3`}
            style={{ textShadow: "0 2px 4px rgba(0,0,0,0.3)" }}
          >
            {nft.rarity}
          </span>
        </div>

        <div className="absolute inset-0 z-10 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
      </div>

      <div className="p-3 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground truncate">{nft.collection}</p>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Floor Price</p>
            <p className="font-bold text-sm">{nft.floorPrice} π</p>
          </div>
          <Button
            size="sm"
            disabled
            className="text-white font-semibold h-8 px-4 opacity-50 cursor-not-allowed"
            style={{
              background: isLegendary ? nft.gradient : "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
            }}
          >
            Mua{isLegendary ? " ngay" : ""}
          </Button>
        </div>
      </div>
    </div>
  )
})

MarketplaceNFTCard.displayName = "MarketplaceNFTCard"

export function NFTMarketplaceMini() {
  return (
    <Card className="mt-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            NFT Marketplace
          </CardTitle>
          <Button disabled variant="ghost" size="sm" className="h-8 text-xs opacity-50 cursor-not-allowed">
            <ExternalLink className="h-3 w-3 mr-1" />
            Xem thêm
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-yellow-500" />
            Legendary Collection
          </h3>
          <div className="grid grid-cols-1 gap-3">
            {marketplaceNFTs.map((nft) => (
              <MarketplaceNFTCard key={nft.id} nft={nft} isLegendary />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold mb-3">Other Collections</h3>
          <div className="grid grid-cols-2 gap-3">
            {otherCollections.map((nft) => (
              <MarketplaceNFTCard key={nft.id} nft={nft} />
            ))}
          </div>
        </div>

        <Button
          disabled
          className="w-full text-white font-semibold opacity-50 cursor-not-allowed"
          style={{
            background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
          }}
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          Khám phá tất cả NFT
        </Button>
      </CardContent>
    </Card>
  )
}
