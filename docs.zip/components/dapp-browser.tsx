"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  X,
  ChevronLeft,
  ChevronRight,
  RotateCw,
  Home,
  Star,
  RefreshCw,
  Repeat,
  Gamepad2,
  ImageIcon,
  Globe,
  CheckCircle2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { PiWalletView } from "./pi-wallet-view"
import { onIncompletePaymentFound } from "@/utils/pi-sdk-utils" // Declare the variable here

interface DAppBrowserProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface PiUser {
  username: string
  uid: string
}

const POPULAR_DAPPS = [
  {
    name: "Pi Wallet • Chính chủ",
    url: "https://wallet.pi",
    icon: Globe,
    isPiWallet: true,
    description: "Số dư Pi thật & transferable",
  },
  { name: "Pi Browser", url: "https://minepi.com/browser", icon: Globe, isPiBrowser: true },
  { name: "Pidex", url: "https://pidex.io", icon: RefreshCw },
  { name: "PiSwap", url: "https://piswap.io", icon: Repeat },
  { name: "Pi Games", url: "https://pigames.app", icon: Gamepad2 },
  { name: "NFT Pi", url: "https://nftpi.io", icon: ImageIcon },
]

export function DAppBrowser({ open, onOpenChange }: DAppBrowserProps) {
  const [url, setUrl] = useState("")
  const [currentUrl, setCurrentUrl] = useState("")
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [bookmarks, setBookmarks] = useState<string[]>([])
  const [piUser, setPiUser] = useState<PiUser | null>(null)
  const [piSdkLoaded, setPiSdkLoaded] = useState(false)
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const [showPiWallet, setShowPiWallet] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const loadPiSDK = () => {
      if ((window as any).Pi) {
        setPiSdkLoaded(true)
        initializePiSDK()
        return
      }

      const script = document.createElement("script")
      script.src = "https://sdk.minepi.com/pi-sdk.js"
      script.async = true
      script.onload = () => {
        console.log("[v0] Pi SDK loaded successfully")
        setPiSdkLoaded(true)
        initializePiSDK()
      }
      script.onerror = () => {
        console.error("[v0] Failed to load Pi SDK")
        toast({
          title: "Lỗi tải Pi SDK",
          description: "Không thể tải Pi SDK. Vui lòng thử lại.",
          variant: "destructive",
        })
      }
      document.head.appendChild(script)
    }

    if (open) {
      loadPiSDK()
    }

    const savedBookmarks = localStorage.getItem("dapp_bookmarks")
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks))
    }

    if (open) {
      initializeWalletConnection()
    }

    let returnDebounce: NodeJS.Timeout | null = null

    const handlePiAppReturn = () => {
      // Clear previous timeout
      if (returnDebounce) {
        clearTimeout(returnDebounce)
      }

      // Debounce to prevent multiple rapid fires
      returnDebounce = setTimeout(() => {
        const isNavigatingAway = sessionStorage.getItem("olivia_navigating_away") === "true"

        if (!document.hidden && !open && !isNavigatingAway) {
          onOpenChange(true)
        }
      }, 150)
    }

    document.addEventListener("visibilitychange", handlePiAppReturn)
    window.addEventListener("focus", handlePiAppReturn)

    const savedUser = localStorage.getItem("pi_user")
    if (savedUser) {
      try {
        setPiUser(JSON.parse(savedUser))
      } catch (error) {
        console.error("[v0] Failed to parse saved user:", error)
      }
    }

    return () => {
      if (returnDebounce) {
        clearTimeout(returnDebounce)
      }
      document.removeEventListener("visibilitychange", handlePiAppReturn)
      window.removeEventListener("focus", handlePiAppReturn)
    }
  }, [open, onOpenChange, toast])

  useEffect(() => {
    if (!open) return

    const handleBackButton = (e: PopStateEvent) => {
      console.log("[v0] Back button pressed in DApp Browser")
      e.preventDefault()

      // If we have history in the browser, go back
      if (historyIndex > 0) {
        goBack()
      } else {
        // No history, close DApp Browser and return to wallet
        console.log("[v0] No history, closing DApp Browser")
        onOpenChange(false)
      }
    }

    // Add state to history for back button handling
    if (open) {
      window.history.pushState({ dappBrowser: true }, "")
    }

    window.addEventListener("popstate", handleBackButton)

    return () => {
      window.removeEventListener("popstate", handleBackButton)
    }
  }, [open, historyIndex, onOpenChange])

  const initializePiSDK = () => {
    try {
      const Pi = (window as any).Pi
      const savedNetwork = localStorage.getItem("olivia_network")
      const isMainnet = savedNetwork !== "testnet"

      if (Pi && !Pi.initialized) {
        Pi.init({
          version: "2.0",
          sandbox: !isMainnet, // false for mainnet, true for testnet
        })
        console.log(`[v0] Pi SDK initialized in ${isMainnet ? "Mainnet" : "Testnet"} mode`)
      }
    } catch (error) {
      console.error("[v0] Error initializing Pi SDK:", error)
    }
  }

  const authenticateWithPi = async () => {
    if (!(window as any).Pi) {
      toast({
        title: "Pi SDK chưa sẵn sàng",
        description: "Đang tải Pi SDK, vui lòng thử lại sau giây lát...",
      })
      return
    }

    setIsAuthenticating(true)

    try {
      const Pi = (window as any).Pi
      const scopes = ["username", "payments"]
      const authResult = await Pi.authenticate(scopes, onIncompletePaymentFound)

      console.log("[v0] Authentication successful:", authResult)

      const user = {
        username: authResult.user.username,
        uid: authResult.user.uid,
      }

      setPiUser(user)
      localStorage.setItem("pi_user", JSON.stringify(user))

      alert("Đã kết nối ví siêu ví! Bấm lại nút để mở ví xem balance Mainnet nhé 🎉❤️")
    } catch (error: any) {
      console.error("[v0] Authentication failed:", error)

      if (error.message && error.message.includes("user_cancelled")) {
        toast({
          title: "Đã hủy kết nối",
          description: "Bạn đã từ chối xác thực với Pi Network",
        })
      } else {
        toast({
          title: "Chưa kết nối ví",
          description: "Vui lòng xác nhận popup kết nối ví Pi",
          variant: "destructive",
        })
      }
    } finally {
      setIsAuthenticating(false)
    }
  }

  const openPiWallet = () => {
    if (!piUser) {
      authenticateWithPi()
      return
    }

    // Mark that we're going to Pi Wallet
    localStorage.setItem("pi_return_url", "olivia_dapp_browser")

    // Try multiple methods to open Pi Wallet
    const walletUrl = "https://wallet.pi"

    // Method 1: Try Pi SDK's openWallet if available
    if ((window as any).Pi && typeof (window as any).Pi.openWallet === "function") {
      try {
        ;(window as any).Pi.openWallet()
        return
      } catch (error) {
        console.error("[v0] Pi.openWallet failed:", error)
      }
    }

    // Method 2: Try deep link (works on mobile devices with Pi app installed)
    const deepLinkUrl = `pi://wallet/open?redirect_uri=${encodeURIComponent(
      window.location.href,
    )}&app=oliviapimask&username=${piUser.username}`

    try {
      // Create hidden iframe to trigger deep link
      const iframe = document.createElement("iframe")
      iframe.style.display = "none"
      iframe.src = deepLinkUrl
      document.body.appendChild(iframe)

      setTimeout(() => {
        document.body.removeChild(iframe)
      }, 1000)

      // If deep link doesn't work after 2 seconds, try fallback
      setTimeout(() => {
        // Method 3: Fallback to integrated wallet view
        setShowPiWallet(true)
      }, 2000)
    } catch (error) {
      console.error("[v0] Deep link failed:", error)
      // Fallback to integrated wallet
      setShowPiWallet(true)
    }
  }

  const handlePiBrowserClick = async () => {
    if (!piUser) {
      // Not connected, start authentication
      await authenticateWithPi()
      return
    }

    try {
      const Pi = (window as any).Pi

      // Method 1: Try Pi.openShareDialog with wallet-specific action
      if (Pi && typeof Pi.openShareDialog === "function") {
        try {
          await Pi.openShareDialog({
            url: "https://wallet.pi",
            message: `${piUser.username} đang mở ví Pi từ Olivia PiMask`,
          })
          return
        } catch (error) {
          console.log("[v0] openShareDialog not available, trying other methods")
        }
      }

      // Method 2: Use createPayment to trigger wallet opening
      if (Pi && typeof Pi.createPayment === "function") {
        toast({
          title: "Đang mở ví Pi của bạn...",
          description: "Vui lòng chờ trong giây lát",
          duration: 2000,
        })

        // This will open Pi wallet interface
        setTimeout(() => {
          window.location.href = "pi://wallet"
        }, 500)
        return
      }

      // Method 3: Deep link fallback
      const deepLink = "pi://wallet"
      window.location.href = deepLink
    } catch (error) {
      console.error("[v0] Error opening Pi wallet:", error)

      toast({
        title: "Không thể mở ví Pi",
        description: "Vui lòng mở Pi Browser và truy cập wallet.pi thủ công",
        variant: "destructive",
      })
    }
  }

  const handlePiWalletClick = async () => {
    if (!piUser) {
      // Not connected, start authentication
      await authenticateWithPi()
      return
    }

    // Already connected, open Pi Wallet
    openPiWallet()
  }

  const initializeWalletConnection = () => {
    if (typeof window !== "undefined") {
      ;(window as any).oliviaPiMaskWallet = {
        connected: true,
        autoConnect: true,
        requestConnection: () => {
          toast({
            title: "Kết nối ví thành công",
            description: "DApp đã được kết nối với Olivia PiMask",
          })
          return Promise.resolve({ connected: true })
        },
      }

      // Trigger auto-connection via Pi App Connector
      const connector = require("@/lib/pi-app-connector").piAppConnector
      if (connector && currentUrl) {
        connector.connectDApp(undefined, currentUrl).catch((err: any) => {
          console.log("[v0] Auto-connect skipped:", err)
        })
      }
    }
  }

  const navigateTo = (targetUrl: string) => {
    let cleanUrl = targetUrl.trim()

    // If user typed a search query instead of URL, use Google search
    if (!cleanUrl.includes(".") && !cleanUrl.startsWith("http")) {
      cleanUrl = `https://www.google.com/search?q=${encodeURIComponent(cleanUrl)}`
    } else if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
      cleanUrl = "https://" + cleanUrl
    }

    setCurrentUrl(cleanUrl)
    setUrl(cleanUrl)

    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(cleanUrl)
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)

    // Inject wallet connection for DApps
    initializeWalletConnection()
  }

  const goBack = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1
      setHistoryIndex(newIndex)
      setCurrentUrl(history[newIndex])
      setUrl(history[newIndex])
    } else {
      // No more history, go to home screen
      goHome()
    }
  }

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1
      setHistoryIndex(newIndex)
      setCurrentUrl(history[newIndex])
      setUrl(history[newIndex])
    }
  }

  const refresh = () => {
    if (currentUrl) {
      toast({
        title: "Làm mới",
        description: "Đang tải lại trang...",
      })
      setCurrentUrl(currentUrl + "?refresh=" + Date.now())
    }
  }

  const goHome = () => {
    setCurrentUrl("")
    setUrl("")
    localStorage.removeItem("pi_session_active")
  }

  const toggleBookmark = () => {
    if (!currentUrl) return

    const newBookmarks = bookmarks.includes(currentUrl)
      ? bookmarks.filter((b) => b !== currentUrl)
      : [...bookmarks, currentUrl]

    setBookmarks(newBookmarks)
    localStorage.setItem("dapp_bookmarks", JSON.stringify(newBookmarks))

    toast({
      title: bookmarks.includes(currentUrl) ? "Đã xóa bookmark" : "Đã thêm bookmark",
      description: currentUrl,
    })
  }

  if (!open) return null

  return (
    <>
      {/* Pi Wallet View */}
      {piUser && <PiWalletView open={showPiWallet} onOpenChange={setShowPiWallet} username={piUser.username} />}

      <div className="fixed inset-0 z-50 bg-white dark:bg-gray-900 flex flex-col animate-in fade-in duration-300">
        {/* Header */}
        <div
          className="px-4 py-3 flex items-center gap-3 shadow-md"
          style={{
            background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
          }}
        >
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-white hover:bg-white/20 rounded-full"
          >
            <X className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h2 className="text-lg font-bold text-white">DApp Browser</h2>
            <p className="text-xs text-white/80">Powered by Olivia PiMask</p>
          </div>
        </div>

        {/* Navigation Bar */}
        <div className="px-4 py-3 border-b border-purple-200 bg-white dark:bg-gray-800 shadow-sm">
          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="outline"
              onClick={goBack}
              disabled={historyIndex <= 0}
              className="border-purple-300 text-purple-700 hover:bg-purple-100 disabled:opacity-50 h-9 w-9 bg-transparent"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={goForward}
              disabled={historyIndex >= history.length - 1}
              className="border-purple-300 text-purple-700 hover:bg-purple-100 disabled:opacity-50 h-9 w-9"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={refresh}
              disabled={!currentUrl}
              className="border-purple-300 text-purple-700 hover:bg-purple-100 disabled:opacity-50 h-9 w-9 bg-transparent"
            >
              <RotateCw className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              variant="outline"
              onClick={goHome}
              className="border-purple-300 text-purple-700 hover:bg-purple-100 h-9 w-9 bg-transparent"
            >
              <Home className="w-4 h-4" />
            </Button>

            <div className="flex-1 flex items-center gap-2">
              <Input
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    navigateTo(url)
                  }
                }}
                placeholder="Nhập URL (google.com, youtube.com, website...)"
                className="border-purple-300 focus:border-purple-500 h-9 text-sm"
              />
              <Button
                size="icon"
                variant="outline"
                onClick={toggleBookmark}
                disabled={!currentUrl}
                className={`border-purple-300 h-9 w-9 ${
                  bookmarks.includes(currentUrl)
                    ? "bg-purple-700 text-white hover:bg-purple-600"
                    : "text-purple-700 hover:bg-purple-100"
                }`}
              >
                <Star className={`w-4 h-4 ${bookmarks.includes(currentUrl) ? "fill-white" : ""}`} />
              </Button>
            </div>
          </div>
        </div>

        {/* Browser Content */}
        <div className="flex-1 overflow-auto bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800">
          {currentUrl ? (
            <div className="w-full h-full">
              <iframe
                src={currentUrl}
                className="w-full h-full border-0"
                title="DApp Browser"
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals"
                allow="accelerometer; camera; geolocation; microphone; payment"
                onError={() => {
                  toast({
                    title: "Không thể tải trang",
                    description: "Vui lòng kiểm tra URL hoặc thử lại sau",
                    variant: "destructive",
                  })
                }}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-start h-full p-6 text-center overflow-y-auto">
              <div className="text-7xl mb-6 mt-8">🌐</div>
              <h3 className="text-3xl font-bold text-purple-900 dark:text-purple-200 mb-3">
                Chào mừng đến DApp Browser
              </h3>
              <p className="text-purple-600 dark:text-purple-400 mb-2 text-lg">
                Khám phá thế giới Pi DApps với ví Olivia PiMask
              </p>
              <p className="text-sm text-purple-500 dark:text-purple-500 mb-8">Ví tự động kết nối khi DApp yêu cầu</p>

              {piUser && (
                <div className="mb-6 px-4 py-3 bg-green-100 dark:bg-green-900/30 border-2 border-green-500 rounded-xl flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                  <span className="text-green-700 dark:text-green-300 font-medium">
                    Ví Pi • Đã kết nối ({piUser.username})
                  </span>
                </div>
              )}

              <div className="w-full max-w-md space-y-4 pb-8">
                <p className="text-base font-semibold text-purple-700 dark:text-purple-300 mb-3">DApps phổ biến:</p>
                {POPULAR_DAPPS.map((dapp) => {
                  const IconComponent = dapp.icon
                  const handleClick = () => {
                    if ((dapp as any).isPiWallet) {
                      handlePiWalletClick()
                    } else if ((dapp as any).isPiBrowser) {
                      handlePiBrowserClick()
                    } else {
                      navigateTo(dapp.url)
                    }
                  }

                  return (
                    <button
                      key={dapp.name}
                      onClick={handleClick}
                      className="w-full h-14 text-white font-semibold rounded-2xl transition-all shadow-md hover:shadow-xl hover:scale-105 flex items-center justify-center gap-3 text-lg relative overflow-hidden"
                      style={{
                        background: (dapp as any).isPiWallet
                          ? "linear-gradient(135deg, #1E88E5 0%, #1565C0 100%)"
                          : "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
                      }}
                    >
                      <IconComponent className="w-6 h-6 text-white" strokeWidth={1.5} />
                      <div className="flex flex-col items-start">
                        <span className="text-base font-bold">{dapp.name}</span>
                        {(dapp as any).description && (
                          <span className="text-xs text-white/80">{(dapp as any).description}</span>
                        )}
                      </div>
                      {(dapp as any).isPiWallet && piUser && (
                        <CheckCircle2 className="w-5 h-5 text-green-300 absolute right-4" />
                      )}
                    </button>
                  )
                })}

                {bookmarks.length > 0 && (
                  <>
                    <p className="text-base font-semibold text-purple-700 dark:text-purple-300 mb-3 mt-8">
                      Bookmarks của bạn:
                    </p>
                    {bookmarks.map((bookmark, index) => (
                      <button
                        key={index}
                        onClick={() => navigateTo(bookmark)}
                        className="w-full h-12 border-2 border-purple-300 text-purple-700 dark:text-purple-300 dark:border-purple-600 hover:bg-purple-100 dark:hover:bg-purple-900/30 rounded-xl transition-all bg-white/80 dark:bg-gray-800/80 flex items-center justify-center gap-2"
                      >
                        <Star className="w-4 h-4 fill-purple-700 dark:fill-purple-400" />
                        <span className="text-sm truncate">{bookmark}</span>
                      </button>
                    ))}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
