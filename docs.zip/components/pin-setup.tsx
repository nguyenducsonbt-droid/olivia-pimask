"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle2, Shield, Eye, EyeOff } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { savePinHash, saveBiometricEnabled, savePinMemoryEnabled } from "@/lib/storage"

interface PinSetupProps {
  address: string
  encryptedMnemonic: string
  onComplete: () => void
}

export function PinSetup({ address, encryptedMnemonic, onComplete }: PinSetupProps) {
  const [pin, setPin] = useState<string[]>(["", "", "", "", "", ""])
  const [confirmPin, setConfirmPin] = useState<string[]>(["", "", "", "", "", ""])
  const [step, setStep] = useState<"create" | "confirm" | "biometric">("create")
  const [error, setError] = useState("")
  const [showBiometricPrompt, setShowBiometricPrompt] = useState(false)
  const [showPin, setShowPin] = useState(false)

  const handlePinInput = (index: number, value: string, isConfirm = false) => {
    if (!/^\d*$/.test(value)) return

    const currentPin = isConfirm ? [...confirmPin] : [...pin]
    currentPin[index] = value

    if (isConfirm) {
      setConfirmPin(currentPin)
    } else {
      setPin(currentPin)
    }

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(isConfirm ? `confirm-pin-${index + 1}` : `pin-${index + 1}`)
      nextInput?.focus()
    }

    if (currentPin.every((digit) => digit) && index === 5) {
      if (!isConfirm) {
        setStep("confirm")
        // Auto-reset PIN inputs and focus first input for confirmation
        setTimeout(() => {
          document.getElementById("confirm-pin-0")?.focus()
        }, 100)
      } else {
        handleConfirmPin(currentPin)
      }
    }
  }

  const handleConfirmPin = async (confirmPinArray: string[]) => {
    const pinString = pin.join("")
    const confirmPinString = confirmPinArray.join("")

    if (pinString !== confirmPinString) {
      setError("Mã PIN không khớp. Vui lòng thử lại.")
      setConfirmPin(["", "", "", "", "", ""])
      setTimeout(() => {
        document.getElementById("confirm-pin-0")?.focus()
      }, 100)
      return
    }

    setError("")

    // Hash the PIN (simple SHA-256)
    const encoder = new TextEncoder()
    const data = encoder.encode(pinString)
    const hashBuffer = await crypto.subtle.digest("SHA-256", data)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

    // Save PIN hash
    await savePinHash(hashHex, address, encryptedMnemonic)

    // Check if biometric is available
    if (typeof window !== "undefined" && (window as any).PublicKeyCredential) {
      setShowBiometricPrompt(true)
      setStep("biometric")
    } else {
      onComplete()
    }
  }

  const handleEnableBiometric = async () => {
    saveBiometricEnabled(true)
    savePinMemoryEnabled(true)
    onComplete()
  }

  const handleSkipBiometric = () => {
    saveBiometricEnabled(false)
    savePinMemoryEnabled(false)
    onComplete()
  }

  if (step === "biometric") {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 sm:p-12 bg-gradient-to-br from-purple-600 via-purple-500 to-pink-400">
        <Card className="w-full max-w-md mx-4 sm:mx-8 shadow-2xl border-purple-200 bg-white/95 backdrop-blur-sm rounded-3xl">
          <CardHeader className="text-center space-y-4 pt-8 pb-6">
            <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-700 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-purple-900 px-4">Face ID / Touch ID</CardTitle>
            <CardDescription className="text-base text-purple-700 px-4">
              Sử dụng Face ID để mở ví nhanh hơn?
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 px-6 pb-8">
            <Alert className="border-purple-300 bg-purple-50">
              <AlertCircle className="h-4 w-4 text-purple-600" />
              <AlertDescription className="text-sm text-purple-900">
                Face ID giúp bạn truy cập ví nhanh chóng. PIN được lưu an toàn trong phần cứng thiết bị, chỉ mở khóa khi
                Face ID thành công.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <Button
                onClick={handleEnableBiometric}
                className="w-full h-12 text-base bg-gradient-to-r from-purple-800 to-purple-700 hover:from-purple-900 hover:to-purple-800 text-white shadow-lg transition-all duration-200"
                size="lg"
              >
                <CheckCircle2 className="mr-2 h-5 w-5" />
                Bật Face ID
              </Button>

              <Button
                onClick={handleSkipBiometric}
                variant="outline"
                className="w-full h-12 text-base border-2 border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent transition-all duration-200"
                size="lg"
              >
                Bỏ qua
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-12 bg-gradient-to-br from-purple-600 via-purple-500 to-pink-400">
      <Card className="w-full max-w-md mx-4 sm:mx-8 shadow-2xl border-purple-200 bg-white/95 backdrop-blur-sm rounded-3xl">
        <CardHeader className="text-center space-y-4 pt-8 pb-6">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-700 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-purple-900 px-4">
            {step === "create" ? "Thiết lập mã PIN" : "Xác nhận mã PIN"}
          </CardTitle>
          <CardDescription className="text-base text-purple-700 px-4">
            {step === "create" ? "Nhập 6 số để bảo vệ ví của bạn" : "Nhập lại mã PIN để xác nhận"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 px-6 pb-8">
          <div className="relative flex justify-center items-center gap-2 sm:gap-3 px-2">
            {(step === "create" ? pin : confirmPin).map((digit, index) => (
              <input
                key={index}
                id={step === "create" ? `pin-${index}` : `confirm-pin-${index}`}
                type={showPin ? "text" : "password"}
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handlePinInput(index, e.target.value, step === "confirm")}
                onKeyDown={(e) => {
                  if (e.key === "Backspace" && !digit && index > 0) {
                    const prevInput = document.getElementById(
                      step === "create" ? `pin-${index - 1}` : `confirm-pin-${index - 1}`,
                    )
                    prevInput?.focus()
                  }
                }}
                className="w-12 h-12 sm:w-14 sm:h-14 text-center text-2xl font-bold border-2 border-purple-300 rounded-xl focus:border-purple-600 focus:ring-2 focus:ring-purple-200 bg-purple-50 text-purple-900 transition-all duration-200"
                autoFocus={index === 0}
              />
            ))}

            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="absolute -top-2 right-0 p-1 rounded-full bg-purple-100 hover:bg-purple-200 text-purple-700 transition-all duration-200 z-10"
              aria-label={showPin ? "Ẩn PIN" : "Hiện PIN"}
            >
              {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {error && (
            <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-2 duration-300">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {step === "confirm" && (
            <Button
              onClick={() => {
                setStep("create")
                setPin(["", "", "", "", "", ""])
                setConfirmPin(["", "", "", "", "", ""])
                setError("")
                setTimeout(() => {
                  document.getElementById("pin-0")?.focus()
                }, 100)
              }}
              variant="ghost"
              className="w-full text-purple-700 hover:text-purple-900 hover:bg-purple-100 transition-all duration-200"
            >
              Nhập lại mã PIN
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
