"use client"

import { useEffect, useState, useCallback, useRef, memo } from "react"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/use-wallet"
import { getBalance } from "@/lib/wallet"
import { Copy, Wallet, Bell, Shield, ArrowLeftRight, Key } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Toaster } from "@/components/ui/toaster"
import dynamic from "next/dynamic"
import { useLanguage } from "@/hooks/use-language"
import { BottomNav } from "./bottom-nav"
import { loadAvatar } from "@/lib/persistent-storage"
import { triggerHaptic } from "@/lib/haptic"
import ImportPiScreen from "./import-pi-screen"
import PiEcosystemModal from "./pi-ecosystem-modal"
import SecurityView from "./security-view"
import { QuickTransactionSheet } from "./quick-transaction-sheet"
import { CrossBorderTransferDialog } from "./cross-border-transfer-dialog"
import { BridgeView } from "./bridge-view"
import { PortfolioTrackerView } from "./portfolio-tracker-view"

const SendDialog = dynamic(() => import("./send-dialog").then((mod) => ({ default: mod.SendDialog })), {
  loading: () => null,
  ssr: false,
})
const ReceiveDialog = dynamic(() => import("./receive-dialog").then((mod) => ({ default: mod.ReceiveDialog })), {
  loading: () => null,
  ssr: false,
})
const NotificationsDialog = dynamic(
  () => import("./notifications-dialog").then((mod) => ({ default: mod.NotificationsDialog })),
  {
    loading: () => null,
    ssr: false,
  },
)
const HomeView = dynamic(() => import("./home-view").then((mod) => ({ default: mod.HomeView })), {
  loading: () => <LoadingView />,
  ssr: false,
})
const SwapView = dynamic(() => import("./swap-view").then((mod) => ({ default: mod.SwapView })), {
  loading: () => <LoadingView />,
  ssr: false,
})
const HistoryView = dynamic(() => import("./history-view").then((mod) => ({ default: mod.HistoryView })), {
  loading: () => <LoadingView />,
  ssr: false,
})
const AssetsView = dynamic(() => import("./assets-view").then((mod) => ({ default: mod.AssetsView })), {
  loading: () => <LoadingView />,
  ssr: false,
})
const ProfileView = dynamic(() => import("./profile-view").then((mod) => ({ default: mod.ProfileView })), {
  loading: () => <LoadingView />,
  ssr: false,
})
const SettingsView = dynamic(() => import("./settings-view").then((mod) => ({ default: mod.SettingsView })), {
  loading: () => <LoadingView />,
  ssr: false,
})

function LoadingView() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-8 h-8 border-3 border-purple-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )
}

const MemoizedAvatar = memo(({ customAvatar, onClick }: { customAvatar: string | null; onClick: () => void }) => {
  return (
    <div
      className="w-10 h-10 rounded-xl overflow-hidden shadow-md cursor-pointer hover:opacity-80 transition-opacity"
      onClick={onClick}
    >
      {customAvatar ? (
        <img
          src={customAvatar || "/placeholder.svg"}
          alt="User avatar"
          className="w-full h-full object-cover"
          loading="lazy"
        />
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-purple-700 to-pink-500 flex items-center justify-center">
          <Wallet className="w-5 h-5 text-white" />
        </div>
      )}
    </div>
  )
})

MemoizedAvatar.displayName = "MemoizedAvatar"

export default function WalletDashboard() {
  const { address, balance, setBalance, currentNetwork, setCurrentNetwork } = useWallet()
  const [showSend, setShowSend] = useState(false)
  const [showReceive, setShowReceive] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<
    "home" | "swap" | "history" | "assets" | "bridge" | "portfolio" | "settings" | "security"
  >("home")
  const [visitedTabs, setVisitedTabs] = useState(new Set(["home"]))
  const [unreadCount, setUnreadCount] = useState(0)
  const [showProfile, setShowProfile] = useState(false)
  const [isConnected, setIsConnected] = useState(true)
  const [isRefreshingBalance, setIsRefreshingBalance] = useState(false)
  const [walletName, setWalletName] = useState("Olivia PiMask")
  const [importedPiAddress, setImportedPiAddress] = useState<string | null>(null)
  const [showPiEcosystem, setShowPiEcosystem] = useState(false)
  const [oliviaAddress, setOliviaAddress] = useState<string>("")
  const [activeWalletType, setActiveWalletType] = useState<"olivia" | "pi">("olivia")
  const [customAvatar, setCustomAvatar] = useState<string | null>(null)
  const [showImportScreen, setShowImportScreen] = useState(false)
  const [showQuickTransaction, setShowQuickTransaction] = useState(false)
  const [showImportPiDialog, setShowImportPiDialog] = useState(false)
  const [showCrossBorder, setShowCrossBorder] = useState(false)

  const { toast } = useToast()
  const { t } = useLanguage()

  const isMountedRef = useRef(true)
  const updateTimeoutRef = useRef<NodeJS.Timeout>()
  const activeTabRef = useRef(activeTab)
  const isResumingRef = useRef(false)
  const visibilityDebounceRef = useRef<NodeJS.Timeout>()
  const isNavigatingAwayRef = useRef(false)
  const lastUpdateRef = useRef<number>(0)
  const refreshIntervalRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    activeTabRef.current = activeTab
  }, [activeTab])

  const handleTabChange = useCallback(
    (tab: "home" | "swap" | "history" | "assets" | "bridge" | "portfolio" | "settings" | "security") => {
      console.log("[v0] Tab change requested:", tab)
      setActiveTab(tab)
      setVisitedTabs((prev) => new Set([...prev, tab]))
      triggerHaptic("light")
    },
    [],
  )

  const updateDashboard = useCallback(async () => {
    if (!isMountedRef.current) return

    const now = Date.now()
    if (now - lastUpdateRef.current < 300) {
      console.log("[v0] Skipping update - too soon")
      return
    }
    lastUpdateRef.current = now

    try {
      const avatar = await loadAvatar()
      if (avatar !== customAvatar && isMountedRef.current) {
        setCustomAvatar(avatar)
      }

      if (address && currentNetwork && isMountedRef.current) {
        const bal = await getBalance(address, currentNetwork.rpcUrl)
        setBalance(bal)
      }

      try {
        const notifications = JSON.parse(localStorage.getItem("olivia_notifications") || "[]")
        const unread = notifications.filter((n: any) => !n.read).length
        if (isMountedRef.current) {
          setUnreadCount(unread)
        }
      } catch (error) {
        // Silent fail
      }
    } catch (error) {
      // Silent fail
    }
  }, [address, currentNetwork, customAvatar, setBalance])

  const fetchBalance = useCallback(async () => {
    if (address && currentNetwork) {
      setIsLoading(true)
      const bal = await getBalance(address, currentNetwork.rpcUrl)
      setBalance(bal)
      setIsLoading(false)
    }
  }, [address, currentNetwork, setBalance])

  useEffect(() => {
    let cancelled = false

    fetchBalance()

    return () => {
      cancelled = true
    }
  }, [address, currentNetwork, setBalance])

  useEffect(() => {
    const loadInitialAvatar = async () => {
      const avatar = await loadAvatar()
      setCustomAvatar(avatar)
    }

    loadInitialAvatar()

    const handleSecurityBack = () => {
      setActiveTab("home")
      triggerHaptic("light")
    }

    window.addEventListener("security-back-to-home", handleSecurityBack)

    return () => {
      window.removeEventListener("security-back-to-home", handleSecurityBack)
    }
  }, [])

  useEffect(() => {
    const switchWalletBasedOnNetwork = async () => {
      if (currentNetwork.id === "pi-mainnet" || currentNetwork.id === "pi-testnet") {
        if (importedPiAddress && activeWalletType !== "pi") {
          setActiveWalletType("pi")
          setIsRefreshingBalance(true)
          try {
            const horizonUrl =
              currentNetwork.id === "pi-mainnet" ? "https://api.mainnet.minepi.com" : "https://api.testnet.minepi.com"
            const response = await fetch(`${horizonUrl}/accounts/${importedPiAddress}`)
            if (response.ok) {
              const data = await response.json()
              const piBalance = data.balances?.find((b: any) => b.asset_type === "native")?.balance || "0"
              setBalance(piBalance)
              toast({
                title: "Đã chuyển sang Pi Mainnet",
                description: `Số dư: ${piBalance} π`,
                duration: 2000,
              })
            } else {
              setBalance("0")
              toast({
                title: "Đã chuyển sang Pi Mainnet",
                description: "Số dư: 0 π",
                duration: 2000,
              })
            }
          } catch (error) {
            console.log("[v0] Failed to fetch Pi balance:", error)
            setBalance("0")
          } finally {
            setIsRefreshingBalance(false)
          }
        }
      } else {
        if (activeWalletType !== "olivia") {
          setActiveWalletType("olivia")
          setIsRefreshingBalance(true)
          try {
            const evmAddress = oliviaAddress || address
            if (evmAddress) {
              const bal = await getBalance(evmAddress, currentNetwork.rpcUrl)
              setBalance(bal)
              toast({
                title: "Đã chuyển về ví Olivia (EVM)",
                description: `Mạng: ${currentNetwork.name}`,
                duration: 2000,
              })
            }
          } catch (error) {
            console.log("[v0] Failed to fetch EVM balance:", error)
            setBalance("0")
          } finally {
            setIsRefreshingBalance(false)
          }
        }
      }
    }

    switchWalletBasedOnNetwork()
  }, [
    currentNetwork.id,
    currentNetwork.name,
    currentNetwork.rpcUrl,
    importedPiAddress,
    oliviaAddress,
    address,
    activeWalletType,
    setBalance,
    toast,
  ])

  const handleLogoClick = useCallback(() => {
    triggerHaptic("medium")
    setShowProfile(true)
  }, [])

  const handleHeaderPiConnectFunc = useCallback(() => {
    setShowPiEcosystem(true)
    triggerHaptic("light")

    toast({
      title: "Đang mở Pi Ecosystem",
      description: "Vui lòng chờ trong giây lát...",
      duration: 2000,
    })
  }, [toast])

  const handleCopyAddress = useCallback(() => {
    const currentAddr = activeWalletType === "olivia" ? oliviaAddress : importedPiAddress
    if (currentAddr) {
      navigator.clipboard
        .writeText(currentAddr)
        .then(() => {
          triggerHaptic("light")
          toast({
            title: "✓ Đã copy địa chỉ ví!",
            description: `Địa chỉ ${currentAddr.slice(0, 10)}...${currentAddr.slice(-8)} đã được copy`,
            duration: 2000,
          })
        })
        .catch(() => {
          const textarea = document.createElement("textarea")
          textarea.value = currentAddr
          textarea.style.position = "fixed"
          textarea.style.opacity = "0"
          document.body.appendChild(textarea)
          textarea.select()
          document.execCommand("copy")
          document.body.removeChild(textarea)

          triggerHaptic("light")
          toast({
            title: "✓ Đã copy địa chỉ ví!",
            description: `Địa chỉ ${currentAddr.slice(0, 10)}...${currentAddr.slice(-8)} đã được copy`,
            duration: 2000,
          })
        })
    } else {
      toast({
        title: "Không có địa chỉ",
        description: "Vui lòng import ví trước",
        variant: "destructive",
        duration: 2000,
      })
    }
  }, [oliviaAddress, importedPiAddress, activeWalletType, toast])

  const formattedAddress = useCallback(() => {
    const currentAddr = activeWalletType === "olivia" ? oliviaAddress : importedPiAddress
    return currentAddr ? currentAddr.substring(0, 6) + "..." + currentAddr.substring(currentAddr.length - 4) : ""
  }, [oliviaAddress, importedPiAddress, activeWalletType])

  const handleSwitchWallet = useCallback(() => {
    triggerHaptic("medium")

    const newWalletType = activeWalletType === "olivia" ? "pi" : "olivia"

    if (newWalletType === "pi" && !importedPiAddress) {
      toast({
        title: "Chưa import ví Pi",
        description: "Vui lòng import ví Pi trước khi chuyển sang Pi Mainnet",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    setActiveWalletType(newWalletType)

    if (newWalletType === "pi") {
      const piMainnetNetwork = {
        id: "pi-mainnet",
        name: "Pi Mainnet",
        rpcUrl: "https://api.mainnet.minepi.com",
        chainId: 314159,
        symbol: "PI",
        explorer: "https://explorer.minepi.com",
      }
      setCurrentNetwork(piMainnetNetwork)
    } else {
      const ethereumNetwork = {
        id: "ethereum",
        name: "Ethereum",
        rpcUrl: "https://eth.llamarpc.com",
        chainId: 1,
        symbol: "ETH",
        explorer: "https://etherscan.io",
      }
      setCurrentNetwork(ethereumNetwork)
    }

    toast({
      title: "Đã chuyển ví",
      description: newWalletType === "olivia" ? "Đang sử dụng ví Olivia (EVM)" : "Đang sử dụng ví Pi Mainnet",
      duration: 2000,
    })
  }, [activeWalletType, importedPiAddress, setCurrentNetwork, toast])

  const getCurrentAddress = useCallback(() => {
    if (activeWalletType === "pi" && importedPiAddress) {
      return importedPiAddress
    }
    return oliviaAddress || address
  }, [activeWalletType, address, importedPiAddress, oliviaAddress])

  const handleAppSelect = useCallback(
    (url: string) => {
      try {
        console.log("[v0] App clicked:", url)

        if (url === "https://ecosystem.pinet.com") {
          setShowPiEcosystem(false)
          isNavigatingAwayRef.current = true
          const newWindow = window.open(url, "_blank")

          if (!newWindow || newWindow.closed || typeof newWindow.closed === "undefined") {
            console.log("[v0] Popup blocked, using same window")
            window.location.href = url
          } else {
            setTimeout(() => {
              isNavigatingAwayRef.current = false
            }, 1000)
          }
        } else {
          setShowPiEcosystem(false)
          toast({
            title: "Tính năng đang phát triển",
            description: "Chức năng này sẽ sớm được kích hoạt!",
            duration: 2000,
          })
        }
      } catch (error) {
        console.error("[v0] Error:", error)
        toast({
          title: "Lỗi",
          description: "Không thể mở ứng dụng",
          variant: "destructive",
          duration: 2000,
        })
      }
    },
    [toast],
  )

  useEffect(() => {
    const loadWallets = async () => {
      if (address) {
        setOliviaAddress(address)
      }

      const sessionPiWallet = sessionStorage.getItem("olivia_pi_wallet_session")
      const piWalletString = localStorage.getItem("olivia_pi_wallet")
      const encryptedWallet = localStorage.getItem("olivia_wallet_encrypted")

      let hasPiWallet = false

      if (sessionPiWallet) {
        const piWallet = JSON.parse(sessionPiWallet)
        setImportedPiAddress(piWallet.address)
        hasPiWallet = true
      } else if (piWalletString) {
        const piWallet = JSON.parse(piWalletString)
        setImportedPiAddress(piWallet.address || piWallet.publicAddress)
        hasPiWallet = true
      } else if (encryptedWallet) {
        const wallet = JSON.parse(encryptedWallet)
        setImportedPiAddress(wallet.address || wallet.publicAddress)
        hasPiWallet = true
      }
    }

    loadWallets()

    const handleLogout = () => {
      console.log("[v0] Logout detected, reloading wallet addresses")
      loadWallets()
    }

    window.addEventListener("olivia-wallet-logout", handleLogout)

    return () => {
      window.removeEventListener("olivia-wallet-logout", handleLogout)
    }
  }, [address])

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (visibilityDebounceRef.current) {
        clearTimeout(visibilityDebounceRef.current)
      }

      if (document.visibilityState === "visible" && !isNavigatingAwayRef.current) {
        console.log("[v0] Dashboard visible - refreshing state")
        setIsLoading(false)
        visibilityDebounceRef.current = setTimeout(() => {
          if (!isResumingRef.current && isMountedRef.current) {
            isResumingRef.current = true
            setActiveTab((prev) => prev)
            updateDashboard().finally(() => {
              setTimeout(() => {
                isResumingRef.current = false
              }, 200)
            })
          }
        }, 150)
      } else if (document.visibilityState === "hidden") {
        console.log("[v0] Dashboard hidden")
        if (refreshIntervalRef.current) {
          clearTimeout(refreshIntervalRef.current)
        }
      }
    }

    const handleFocus = () => {
      console.log("[v0] Dashboard window focused")
      if (!isNavigatingAwayRef.current && !isResumingRef.current && isMountedRef.current) {
        if (visibilityDebounceRef.current) {
          clearTimeout(visibilityDebounceRef.current)
        }
        visibilityDebounceRef.current = setTimeout(() => {
          setIsLoading(false)
          updateDashboard()
        }, 100)
      }
    }

    const handlePageShow = (event: PageTransitionEvent) => {
      console.log("[v0] Dashboard page show event, persisted:", event.persisted)
      if (event.persisted && !isNavigatingAwayRef.current) {
        setIsLoading(false)
        isNavigatingAwayRef.current = false
        updateDashboard()
      }
    }

    const handleForceRefresh = () => {
      console.log("[v0] Force refresh triggered")
      setIsLoading(false)
      isNavigatingAwayRef.current = false
      if (isMountedRef.current) {
        updateDashboard()
      }
    }

    const handleRefreshUI = () => {
      console.log("[v0] UI refresh triggered")
      if (isMountedRef.current) {
        setIsLoading(false)
        setActiveTab((prev) => prev)
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    window.addEventListener("focus", handleFocus)
    window.addEventListener("pageshow", handlePageShow)
    window.addEventListener("olivia-force-refresh", handleForceRefresh)
    window.addEventListener("olivia-refresh-ui", handleRefreshUI)

    return () => {
      if (visibilityDebounceRef.current) {
        clearTimeout(visibilityDebounceRef.current)
      }
      if (refreshIntervalRef.current) {
        clearTimeout(refreshIntervalRef.current)
      }
      document.removeEventListener("visibilitychange", handleVisibilityChange)
      window.removeEventListener("focus", handleFocus)
      window.removeEventListener("pageshow", handlePageShow)
      window.removeEventListener("olivia-force-refresh", handleForceRefresh)
      window.removeEventListener("olivia-refresh-ui", handleRefreshUI)
    }
  }, [updateDashboard])

  useEffect(() => {
    isMountedRef.current = true

    return () => {
      isMountedRef.current = false
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current)
      }
      if (visibilityDebounceRef.current) {
        clearTimeout(visibilityDebounceRef.current)
      }
      if (refreshIntervalRef.current) {
        clearTimeout(refreshIntervalRef.current)
      }
    }
  }, [])

  return (
    <>
      {showImportScreen && (
        <ImportPiScreen
          onClose={() => setShowImportScreen(false)}
          onImportSuccess={() => {
            const loadPiWallet = async () => {
              const sessionPiWallet = sessionStorage.getItem("olivia_pi_wallet_session")
              const piWalletString = localStorage.getItem("olivia_pi_wallet")

              if (sessionPiWallet) {
                const piWallet = JSON.parse(sessionPiWallet)
                setImportedPiAddress(piWallet.address)
                setActiveWalletType("pi")

                const piMainnetNetwork = {
                  id: "pi-mainnet",
                  name: "Pi Mainnet",
                  rpcUrl: "https://api.mainnet.minepi.com",
                  chainId: 314159,
                  symbol: "PI",
                  explorer: "https://explorer.minepi.com",
                }
                setCurrentNetwork(piMainnetNetwork)

                toast({
                  title: "Đã chuyển sang Pi Mainnet",
                  description: "Ví Pi đã được import và kích hoạt",
                  duration: 3000,
                })
              } else if (piWalletString) {
                const piWallet = JSON.parse(piWalletString)
                setImportedPiAddress(piWallet.address || piWallet.publicAddress)
                setActiveWalletType("pi")

                const piMainnetNetwork = {
                  id: "pi-mainnet",
                  name: "Pi Mainnet",
                  rpcUrl: "https://api.mainnet.minepi.com",
                  chainId: 314159,
                  symbol: "PI",
                  explorer: "https://explorer.minepi.com",
                }
                setCurrentNetwork(piMainnetNetwork)

                toast({
                  title: "Đã chuyển sang Pi Mainnet",
                  description: "Ví Pi đã được import và kích hoạt",
                  duration: 3000,
                })
              }
            }
            loadPiWallet()
          }}
        />
      )}

      {showPiEcosystem && <PiEcosystemModal onClose={() => setShowPiEcosystem(false)} onSelectApp={handleAppSelect} />}

      <Toaster />

      <div className="flex flex-col h-screen w-full bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
        <header
          className="sticky top-0 z-40 shadow-lg"
          style={{
            background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
          }}
        >
          <div className="max-w-2xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <button onClick={handleLogoClick} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
                <MemoizedAvatar customAvatar={customAvatar} onClick={handleLogoClick} />
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-lg font-bold text-white">{walletName}</h1>
                    {isRefreshingBalance && (
                      <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    )}
                  </div>
                  <button
                    onClick={handleCopyAddress}
                    className="text-xs text-purple-100 hover:text-white transition-colors flex items-center gap-1"
                    title={
                      activeWalletType === "olivia"
                        ? "Ví Olivia (EVM) - Click để copy"
                        : "Ví Pi Mainnet - Click để copy"
                    }
                  >
                    {formattedAddress()}
                    <Copy className="w-3 h-3" />
                  </button>
                  <div className="text-[10px] text-purple-200 mt-0.5">
                    {activeWalletType === "olivia" ? "Ví Olivia (EVM)" : "Ví Pi Mainnet"}
                  </div>
                </div>
              </button>
              <div className="flex items-center gap-1.5 flex-wrap justify-end">
                <div
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border backdrop-blur-sm cursor-help
                    transition-all duration-300 ease-in-out
                    ${
                      currentNetwork.id === "pi-mainnet"
                        ? "bg-green-500/20 border-green-400/50"
                        : currentNetwork.id === "pi-testnet"
                          ? "bg-orange-500/20 border-orange-400/50"
                          : "bg-purple-500/20 border-purple-400/50"
                    }`}
                  title="Chuyển mạng trong Cài đặt → Network"
                  onClick={(e) => {
                    e.stopPropagation()
                    toast({
                      title: "💡 Thông tin",
                      description: "Để chuyển mạng, vui lòng vào Cài đặt → Network",
                      duration: 3000,
                    })
                  }}
                >
                  <span
                    className={`text-[11px] font-semibold whitespace-nowrap transition-all duration-300 ease-in-out transform hover:scale-105 ${
                      currentNetwork.id === "pi-mainnet"
                        ? "text-green-300"
                        : currentNetwork.id === "pi-testnet"
                          ? "text-orange-300"
                          : "text-purple-300"
                    }`}
                  >
                    {currentNetwork.id === "pi-mainnet"
                      ? "Mainnet"
                      : currentNetwork.id === "pi-testnet"
                        ? "Testnet"
                        : currentNetwork.name.length > 10
                          ? currentNetwork.name.substring(0, 10) + "..."
                          : currentNetwork.name}
                  </span>
                </div>
                {oliviaAddress && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handleSwitchWallet}
                    disabled={activeWalletType === "olivia" && !importedPiAddress}
                    className="text-white hover:bg-purple-700/50 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                    title={
                      activeWalletType === "olivia" && !importedPiAddress
                        ? "Import ví Pi trước khi chuyển"
                        : activeWalletType === "olivia"
                          ? "Chuyển sang ví Pi Mainnet"
                          : "Chuyển sang ví Olivia (EVM)"
                    }
                  >
                    <ArrowLeftRight className="w-4 h-4" />
                  </Button>
                )}
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={handleHeaderPiConnectFunc}
                  className="relative text-white hover:bg-purple-700/50 transition-all overflow-hidden group"
                  title="Mở Pi Ecosystem – Khám phá dApps"
                >
                  <span className="absolute inset-0 bg-white/20 rounded-full scale-0 group-active:scale-100 transition-transform duration-500 ease-out" />

                  <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 transition-all group-hover:scale-110">
                    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" fill="none" />
                    <path d="M12 7 L12 17 M7 12 L17 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    setShowImportScreen(true)
                    triggerHaptic("medium")
                    toast({
                      title: "Đang mở import ví Pi...",
                      description: "Chuẩn bị màn hình import passphrase",
                      duration: 1500,
                    })
                  }}
                  className="text-white hover:bg-purple-700/50 transition-all active:scale-95"
                  title="Import ví Pi (passphrase/private key)"
                >
                  <Key className="w-5 h-5" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    setShowNotifications(true)
                    triggerHaptic("light")
                  }}
                  className="relative text-white hover:bg-purple-700/50"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <div
                      className="absolute -top-1 -right-1 rounded-full flex items-center justify-center text-white text-[10px] font-bold shadow-lg"
                      style={{
                        width: "20px",
                        height: "20px",
                        background: "linear-gradient(135deg, #9333EA 0%, #EC4899 100%)",
                        boxShadow: "0 2px 8px rgba(147, 51, 234, 0.5), 0 0 12px rgba(236, 72, 153, 0.3)",
                      }}
                    >
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </div>
                  )}
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    setActiveTab("security")
                    setVisitedTabs((prev) => new Set([...prev, "security"]))
                    triggerHaptic("light")
                  }}
                  className="text-white hover:bg-purple-700/50 transition-all active:scale-95 ring-2 ring-purple-400/30"
                  title="An toàn - Quét bảo mật ví"
                >
                  <Shield className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="max-w-2xl mx-auto px-4 pb-24">
            {activeTab === "home" && <HomeView />}

            <div style={{ display: activeTab === "swap" ? "block" : "none" }}>
              {visitedTabs.has("swap") && <SwapView />}
            </div>

            <div style={{ display: activeTab === "history" ? "block" : "none" }}>
              {visitedTabs.has("history") && <HistoryView />}
            </div>

            <div style={{ display: activeTab === "assets" ? "block" : "none" }}>
              {visitedTabs.has("assets") && <AssetsView />}
            </div>

            <div style={{ display: activeTab === "bridge" ? "block" : "none" }}>
              {visitedTabs.has("bridge") && <BridgeView />}
            </div>

            <div style={{ display: activeTab === "portfolio" ? "block" : "none" }}>
              {visitedTabs.has("portfolio") && <PortfolioTrackerView />}
            </div>

            <div style={{ display: activeTab === "settings" ? "block" : "none" }}>
              {visitedTabs.has("settings") && <SettingsView />}
            </div>

            <div style={{ display: activeTab === "security" ? "block" : "none" }}>
              {visitedTabs.has("security") && <SecurityView />}
            </div>
          </div>
        </div>

        <div className="flex-shrink-0">
          <BottomNav
            activeTab={activeTab}
            onTabChange={handleTabChange}
            unreadCount={unreadCount}
            onFabClick={() => setShowQuickTransaction(true)}
          />
        </div>

        {showSend && <SendDialog open={showSend} onOpenChange={setShowSend} />}
        {showReceive && <ReceiveDialog open={showReceive} onOpenChange={setShowReceive} />}
        {showNotifications && (
          <NotificationsDialog
            open={showNotifications}
            onOpenChange={setShowNotifications}
            onTransactionClick={() => {}}
          />
        )}
        {showQuickTransaction && (
          <QuickTransactionSheet
            open={showQuickTransaction}
            onOpenChange={setShowQuickTransaction}
            activeWalletType={activeWalletType}
            activeAddress={getCurrentAddress()}
            currentNetwork={currentNetwork}
          />
        )}
        {showCrossBorder && <CrossBorderTransferDialog open={showCrossBorder} onOpenChange={setShowCrossBorder} />}
        {showProfile && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 overflow-y-auto">
            <div className="min-h-screen px-4 py-6">
              <button
                onClick={() => {
                  setShowProfile(false)
                  triggerHaptic("light")
                }}
                className="fixed top-4 left-4 z-50 px-4 py-2 rounded-full bg-purple-600 text-white hover:bg-purple-700 transition-all active:scale-95 font-medium shadow-lg"
              >
                ← Quay lại
              </button>
              <div className="max-w-2xl mx-auto pt-16">
                <ProfileView />
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  )
}

export { WalletDashboard }
