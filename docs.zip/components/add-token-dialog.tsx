"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { getTokenInfo, getTokenBalance } from "@/lib/wallet"
import { Loader2, Plus, AlertCircle, Shield, Eye, EyeOff, AlertTriangle, CheckCircle, Info } from "lucide-react"
import type { Token } from "@/lib/wallet"
import { useLanguage } from "@/hooks/use-language"
import Image from "next/image"

interface AddTokenDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const POPULAR_TOKENS = [
  {
    name: "Pi Stablecoin",
    symbol: "PIUSD",
    address: "0x1234567890123456789012345678901234567890",
    logo: "https://placeholder.svg?height=32&width=32&query=PIUSD+token",
  },
  {
    name: "Pi DEX Token",
    symbol: "PIDEX",
    address: "0x2345678901234567890123456789012345678901",
    logo: "https://placeholder.svg?height=32&width=32&query=PIDEX+token",
  },
  {
    name: "Pi Game Token",
    symbol: "PIGAME",
    address: "0x3456789012345678901234567890123456789012",
    logo: "https://placeholder.svg?height=32&width=32&query=PIGAME+token",
  },
]

const VERIFIED_TOKENS = new Set([
  "0x1234567890123456789012345678901234567890",
  "0x2345678901234567890123456789012345678901",
  "0x3456789012345678901234567890123456789012",
])

const isValidAddress = (address: string): boolean => {
  const ethPattern = /^0x[a-fA-F0-9]{40}$/
  const piPattern = /^[A-Z0-9]{40,50}$/
  return ethPattern.test(address) || piPattern.test(address)
}

const isPIMaskToken = (name: string, symbol: string): boolean => {
  const lower = name.toLowerCase() + symbol.toLowerCase()
  return lower.includes("pimask") || lower.includes("privacy") || lower.includes("mask")
}

const fetchTokenLogo = async (address: string): Promise<string | null> => {
  try {
    // Try Trust Wallet assets
    const trustWalletUrl = `https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/${address}/logo.png`
    const response = await fetch(trustWalletUrl, { method: "HEAD" })
    if (response.ok) return trustWalletUrl

    // Fallback to placeholder with token address
    return `https://placeholder.svg?height=32&width=32&query=token+${address.slice(0, 6)}`
  } catch {
    return null
  }
}

export function AddTokenDialog({ open, onOpenChange }: AddTokenDialogProps) {
  const { addToken, currentNetwork, refreshTokenBalances, address: walletAddress } = useWallet()
  const [address, setAddress] = useState("")
  const [tokenInfo, setTokenInfo] = useState<{ name: string; symbol: string; decimals: number } | null>(null)
  const [tokenBalance, setTokenBalance] = useState<string>("0")
  const [tokenLogo, setTokenLogo] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isValidating, setIsValidating] = useState(false)
  const [validationError, setValidationError] = useState("")
  const [isPIMask, setIsPIMask] = useState(false)
  const [privacyMode, setPrivacyMode] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [isVerified, setIsVerified] = useState(false)
  const [showRiskWarning, setShowRiskWarning] = useState(false)
  const { toast } = useToast()
  const { t } = useLanguage()

  const filteredSuggestions = POPULAR_TOKENS.filter(
    (token) =>
      address.length > 0 &&
      (token.name.toLowerCase().includes(address.toLowerCase()) ||
        token.symbol.toLowerCase().includes(address.toLowerCase()) ||
        token.address.toLowerCase().includes(address.toLowerCase())),
  )

  useEffect(() => {
    const validateAndFetch = async () => {
      if (!address) {
        setTokenInfo(null)
        setValidationError("")
        setTokenLogo(null)
        setShowRiskWarning(false)
        return
      }

      setIsValidating(true)
      setValidationError("")

      if (!isValidAddress(address)) {
        setValidationError(t.tokens.invalidAddress)
        setIsValidating(false)
        setTokenInfo(null)
        setTokenLogo(null)
        setShowRiskWarning(false)
        return
      }

      try {
        setIsLoading(true)
        const info = await getTokenInfo(address, currentNetwork.rpcUrl)

        if (info) {
          setTokenInfo(info)
          const isPiMask = isPIMaskToken(info.name, info.symbol)
          setIsPIMask(isPiMask)

          const verified = VERIFIED_TOKENS.has(address.toLowerCase())
          setIsVerified(verified)
          setShowRiskWarning(!verified)

          const logo = await fetchTokenLogo(address)
          setTokenLogo(logo)

          if (walletAddress) {
            try {
              const rawBalance = await getTokenBalance(walletAddress, address, currentNetwork.rpcUrl)
              const formattedBalance = (Number(rawBalance) / 10 ** info.decimals).toFixed(4)
              setTokenBalance(formattedBalance)
            } catch (error) {
              console.error("[v0] Error fetching token balance:", error)
              setTokenBalance("0")
            }
          }

          toast({
            title: t.tokens.toasts.infoRetrieved,
            description: `${t.tokens.toasts.found}: ${info.name} (${info.symbol})`,
          })
        } else {
          setValidationError(t.tokens.notSupported)
          setTokenInfo(null)
          setTokenLogo(null)
          setShowRiskWarning(false)
        }
      } catch (error) {
        console.error("[v0] Token fetch error:", error)
        setValidationError(t.tokens.notSupported)
        setTokenInfo(null)
        setTokenLogo(null)
        setShowRiskWarning(false)
      } finally {
        setIsLoading(false)
        setIsValidating(false)
      }
    }

    const debounce = setTimeout(validateAndFetch, 500)
    return () => clearTimeout(debounce)
  }, [address, currentNetwork.rpcUrl, walletAddress, toast, t])

  const handleAdd = async () => {
    if (!address || !tokenInfo) {
      return
    }

    const newToken: Token = {
      address,
      name: tokenInfo.name,
      symbol: tokenInfo.symbol,
      decimals: tokenInfo.decimals,
      network: currentNetwork.id,
      balance: tokenBalance,
      isPIMask,
      privacyMode: isPIMask ? privacyMode : undefined,
      theme: isPIMask ? "white" : "default",
    }

    addToken(newToken)
    toast({
      title: t.tokens.toasts.tokenAdded,
      description: `${tokenInfo.name} ${t.tokens.toasts.addedToWallet}`,
    })

    setAddress("")
    setTokenInfo(null)
    setTokenBalance("0")
    setTokenLogo(null)
    setValidationError("")
    setIsPIMask(false)
    setPrivacyMode(false)
    setShowRiskWarning(false)
    onOpenChange(false)

    setTimeout(() => {
      refreshTokenBalances()
    }, 1000)
  }

  const handleCancel = () => {
    setAddress("")
    setTokenInfo(null)
    setTokenBalance("0")
    setTokenLogo(null)
    setValidationError("")
    setIsPIMask(false)
    setPrivacyMode(false)
    setShowRiskWarning(false)
    onOpenChange(false)
  }

  const handleSuggestionClick = (token: (typeof POPULAR_TOKENS)[0]) => {
    setAddress(token.address)
    setShowSuggestions(false)
  }

  const previewCardClass = isPIMask
    ? "rounded-lg border-2 border-gray-200 bg-white p-4 space-y-3 shadow-sm"
    : "rounded-lg border-2 border-purple-200 dark:border-purple-800 bg-white dark:bg-purple-950/50 p-4 space-y-3"

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20">
        <DialogHeader>
          <DialogTitle className="text-purple-900 dark:text-purple-100">{t.tokens.addTitle}</DialogTitle>
          <DialogDescription className="text-purple-700 dark:text-purple-300">{t.tokens.addSubtitle}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2 relative">
            <Label htmlFor="token-address" className="text-purple-900 dark:text-purple-100">
              {t.tokens.contractAddress}
            </Label>
            <Input
              id="token-address"
              placeholder="Dán địa chỉ hợp đồng (0x...) hoặc chọn từ gợi ý"
              value={address}
              onChange={(e) => {
                setAddress(e.target.value)
                setShowSuggestions(e.target.value.length > 0)
              }}
              onFocus={(e) => {
                e.target.select()
                setShowSuggestions(address.length > 0)
              }}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              className="font-mono text-sm border-purple-300 dark:border-purple-700 focus:ring-purple-500"
            />

            <div className="flex items-start gap-2 text-xs text-purple-600 dark:text-purple-400 bg-purple-100/50 dark:bg-purple-900/20 p-2.5 rounded-lg border border-purple-200 dark:border-purple-700">
              <Info className="h-4 w-4 flex-shrink-0 mt-0.5" />
              <p>
                Tính năng gợi ý token phổ biến, logo tự động và cảnh báo rủi ro sẽ hoạt động đầy đủ khi publish thật.
              </p>
            </div>

            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-white dark:bg-purple-900 border-2 border-purple-200 dark:border-purple-700 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                {filteredSuggestions.map((token) => (
                  <button
                    key={token.address}
                    onClick={() => handleSuggestionClick(token)}
                    className="w-full px-4 py-3 flex items-center gap-3 hover:bg-purple-50 dark:hover:bg-purple-800 transition-colors text-left"
                  >
                    <Image
                      src={token.logo || "/placeholder.svg"}
                      alt={token.symbol}
                      width={32}
                      height={32}
                      className="rounded-full"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-purple-900 dark:text-purple-100">{token.name}</div>
                      <div className="text-sm text-purple-600 dark:text-purple-400">{token.symbol}</div>
                    </div>
                    <div className="text-xs text-purple-500 dark:text-purple-500 font-mono">
                      {token.address.slice(0, 6)}...{token.address.slice(-4)}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {isValidating && (
            <div className="flex items-center gap-2 text-sm text-purple-600 dark:text-purple-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>{t.tokens.validating}...</span>
            </div>
          )}

          {isLoading && !isValidating && (
            <div className="flex items-center gap-2 text-sm text-purple-600 dark:text-purple-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Đang tải thông tin token và logo...</span>
            </div>
          )}

          {validationError && !isLoading && (
            <div className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-500 bg-amber-50 dark:bg-amber-950/30 p-3 rounded-lg border border-amber-200 dark:border-amber-800">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span>{validationError}</span>
            </div>
          )}

          {showRiskWarning && tokenInfo && !isLoading && (
            <div className="flex items-start gap-2 text-sm text-yellow-700 dark:text-yellow-500 bg-yellow-50 dark:bg-yellow-950/30 p-3 rounded-lg border-2 border-yellow-300 dark:border-yellow-700 animate-in fade-in slide-in-from-top-2">
              <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-semibold">⚠️ Token chưa được xác minh chính thức</div>
                <div className="text-xs">
                  Token này chưa được xác minh trong hệ sinh thái Pi. Cẩn thận với scam hoặc token giả mạo. Luôn kiểm
                  tra nguồn gốc trước khi thêm.
                </div>
              </div>
            </div>
          )}

          {tokenInfo && !isLoading && !validationError && (
            <div className={previewCardClass}>
              <div className="flex items-center justify-between pb-2 border-b border-purple-200">
                <span className="text-sm font-medium text-purple-900 dark:text-purple-100">{t.tokens.preview}</span>
                <div className="flex items-center gap-2">
                  {isVerified && (
                    <span className="flex items-center gap-1 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full border border-green-300">
                      <CheckCircle className="h-3 w-3" />
                      Đã xác minh
                    </span>
                  )}
                  {isPIMask && (
                    <span className="flex items-center gap-1 text-xs bg-white text-black px-2 py-1 rounded-full border border-gray-300">
                      <Shield className="h-3 w-3" />
                      {t.tokens.privacyBadge}
                    </span>
                  )}
                </div>
              </div>

              {tokenLogo && (
                <div className="flex justify-center py-2">
                  <Image
                    src={tokenLogo || "/placeholder.svg"}
                    alt={tokenInfo.symbol}
                    width={48}
                    height={48}
                    className="rounded-full shadow-md"
                  />
                </div>
              )}

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-purple-600 dark:text-purple-400">{t.tokens.tokenName}:</span>
                  <span className="font-medium text-purple-900 dark:text-purple-100">{tokenInfo.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-purple-600 dark:text-purple-400">{t.tokens.tokenSymbol}:</span>
                  <span className="font-medium text-purple-900 dark:text-purple-100">{tokenInfo.symbol}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-purple-600 dark:text-purple-400">{t.tokens.decimals}:</span>
                  <span className="font-medium text-purple-900 dark:text-purple-100">{tokenInfo.decimals}</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-purple-200">
                  <span className="text-sm text-purple-600 dark:text-purple-400">{t.tokens.currentBalance}:</span>
                  <span className="font-semibold text-purple-900 dark:text-purple-100">
                    {tokenBalance} {tokenInfo.symbol}
                  </span>
                </div>
              </div>

              {isPIMask && (
                <div className="mt-4 pt-3 border-t border-purple-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {privacyMode ? (
                        <EyeOff className="h-4 w-4 text-purple-700" />
                      ) : (
                        <Eye className="h-4 w-4 text-purple-700" />
                      )}
                      <span className="text-sm font-medium text-purple-900">{t.tokens.privacyMode}</span>
                    </div>
                    <Switch
                      checked={privacyMode}
                      onCheckedChange={setPrivacyMode}
                      className="data-[state=checked]:bg-purple-600"
                    />
                  </div>
                  <div className="flex items-start gap-2 text-xs text-purple-700 bg-purple-50 p-2 rounded border border-purple-200">
                    <AlertCircle className="h-3 w-3 flex-shrink-0 mt-0.5" />
                    <span>Theme trắng như PIMask: An toàn, read-only</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleCancel}
            className="border-purple-300 text-purple-700 hover:bg-purple-50 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-950/50 bg-transparent"
          >
            {t.common.cancel}
          </Button>
          <Button
            onClick={handleAdd}
            disabled={!tokenInfo || isLoading || !!validationError}
            className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg"
          >
            <Plus className="mr-2 h-4 w-4" />
            {t.tokens.confirmAdd}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
