"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"

type Theme = "light" | "dark" | "system"

interface ThemeContextType {
  theme: Theme
  toggleTheme: () => void
  setTheme: (theme: Theme) => void
  actualTheme: "light" | "dark"
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("system")
  const [actualTheme, setActualTheme] = useState<"light" | "dark">("light")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem("olivia-theme") as Theme | null
    if (savedTheme) {
      setThemeState(savedTheme)
    }

    // Listen to system theme changes
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)")

    const updateActualTheme = () => {
      const currentTheme = savedTheme || theme
      if (currentTheme === "system") {
        const systemIsDark = mediaQuery.matches
        setActualTheme(systemIsDark ? "dark" : "light")
        document.documentElement.classList.toggle("dark", systemIsDark)
      } else {
        setActualTheme(currentTheme === "dark" ? "dark" : "light")
        document.documentElement.classList.toggle("dark", currentTheme === "dark")
      }
    }

    updateActualTheme()

    mediaQuery.addEventListener("change", updateActualTheme)
    return () => mediaQuery.removeEventListener("change", updateActualTheme)
  }, [theme])

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    localStorage.setItem("olivia-theme", newTheme)

    if (newTheme === "system") {
      const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches
      setActualTheme(systemIsDark ? "dark" : "light")
      document.documentElement.classList.toggle("dark", systemIsDark)
    } else {
      setActualTheme(newTheme === "dark" ? "dark" : "light")
      document.documentElement.classList.toggle("dark", newTheme === "dark")
    }
  }

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : theme === "dark" ? "system" : "light"
    setTheme(newTheme)
  }

  // Prevent flash of wrong theme
  if (!mounted) {
    return <>{children}</>
  }

  return <ThemeContext.Provider value={{ theme, toggleTheme, setTheme, actualTheme }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error("useTheme must be used within ThemeProvider")
  }
  return context
}
