"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, Droplet, AlertTriangle, Plus, Minus, Info } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface LiquidityPool {
  id: string
  name: string
  token0: string
  token1: string
  token0Symbol: string
  token1Symbol: string
  apy: number
  tvl: number
  myLiquidity: number
  myLPTokens: number
  earnedFees: number
  status: "active" | "inactive"
  isPiDEX: boolean
}

interface TokenBalance {
  symbol: string
  balance: number
}

export function LiquidityProvidingTab() {
  const { address, currentNetwork } = useWallet()
  const { toast } = useToast()

  const [pools] = useState<LiquidityPool[]>([
    {
      id: "pidex-pi-usdt",
      name: "PI/USDT",
      token0: "PI",
      token1: "USDT",
      token0Symbol: "PI",
      token1Symbol: "USDT",
      apy: 45.5,
      tvl: 0, // $0 TVL - demo mode
      myLiquidity: 0,
      myLPTokens: 0,
      earnedFees: 0,
      status: "active",
      isPiDEX: true,
    },
    {
      id: "pidex-pi-usdc",
      name: "PI/USDC",
      token0: "PI",
      token1: "USDC",
      token0Symbol: "PI",
      token1Symbol: "USDC",
      apy: 42.8,
      tvl: 0, // $0 TVL - demo mode
      myLiquidity: 0,
      myLPTokens: 0,
      earnedFees: 0,
      status: "active",
      isPiDEX: true,
    },
    {
      id: "pidex-usdt-usdc",
      name: "USDT/USDC",
      token0: "USDT",
      token1: "USDC",
      token0Symbol: "USDT",
      token1Symbol: "USDC",
      apy: 12.3,
      tvl: 0, // $0 TVL - demo mode
      myLiquidity: 0,
      myLPTokens: 0,
      earnedFees: 0,
      status: "active",
      isPiDEX: true,
    },
  ])

  const [selectedPool, setSelectedPool] = useState<LiquidityPool | null>(null)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showRemoveDialog, setShowRemoveDialog] = useState(false)
  const [amount0, setAmount0] = useState("")
  const [amount1, setAmount1] = useState("")
  const [removeAmount, setRemoveAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const [tokenBalances] = useState<TokenBalance[]>([
    { symbol: "PI", balance: 100 },
    { symbol: "USDT", balance: 500 },
    { symbol: "USDC", balance: 500 },
  ])

  const calculateImpermanentLoss = (change: number) => {
    // Simple IL calculation for demonstration
    // IL = 2 * sqrt(price_ratio) / (1 + price_ratio) - 1
    const ratio = 1 + change / 100
    const il = (2 * Math.sqrt(ratio)) / (1 + ratio) - 1
    return (Math.abs(il) * 100).toFixed(2)
  }

  const getTokenBalance = (symbol: string): number => {
    const token = tokenBalances.find((t) => t.symbol === symbol)
    return token?.balance || 0
  }

  const hasEnoughBalance = (): boolean => {
    if (!selectedPool || !amount0 || !amount1) return false
    const amt0 = Number.parseFloat(amount0)
    const amt1 = Number.parseFloat(amount1)
    const balance0 = getTokenBalance(selectedPool.token0Symbol)
    const balance1 = getTokenBalance(selectedPool.token1Symbol)
    return amt0 <= balance0 && amt1 <= balance1
  }

  const handleAddLiquidity = async () => {
    toast({
      title: "Demo Mode",
      description:
        "Tính năng demo - chưa kết nối pool PiDEX thật. Chờ Pi Mainnet open DeFi 2026 để add liquidity thực tế.",
    })
  }

  const handleRemoveLiquidity = async () => {
    toast({
      title: "Demo Mode",
      description: "Tính năng demo - chưa có LP tokens thật. Chờ PiDEX launch 2026.",
    })
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-blue-300 dark:border-blue-700">
        <CardContent className="pt-6 pb-6">
          <div className="flex items-start gap-3">
            <Info className="w-6 h-6 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-2">
              <p className="text-lg font-bold text-blue-900 dark:text-blue-100">
                🚀 Tính năng Liquidity Providing đang demo
              </p>
              <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
                Chờ PiDEX launch full pools trên Pi Mainnet 2026 để add liquidity thật (kiếm phí swap + reward). Hiện
                tại <strong>chưa hỗ trợ giao dịch thực tế</strong>. Bạn có thể xem trước giao diện và các pool sẽ khả
                dụng.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warning Card */}
      <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 border-orange-200 dark:border-orange-800">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-2">
              <p className="text-sm font-semibold text-orange-900 dark:text-orange-100">
                Cung cấp thanh khoản để kiếm phí swap + farming reward
              </p>
              <p className="text-xs text-orange-700 dark:text-orange-300">
                <strong>Rủi ro:</strong> Impermanent loss và smart contract risk. Chỉ dùng pool official PiDEX khi
                launch. Không đảm bảo lợi nhuận. DYOR trước khi tham gia.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Liquidity Pools */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplet className="w-5 h-5 text-purple-600" />
            Liquidity Providing (Demo)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pools.map((pool) => (
              <div
                key={pool.id}
                className="bg-white dark:bg-gray-900 rounded-2xl border border-purple-200 dark:border-purple-800 p-4 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between gap-4">
                  {/* Left side: Pool info */}
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="relative w-12 h-8 flex-shrink-0">
                      <div className="absolute left-0 top-0 w-8 h-8 rounded-full bg-gradient-to-br from-yellow-400 to-purple-600 flex items-center justify-center text-white font-bold text-xs border-2 border-white dark:border-gray-900 z-10">
                        {pool.token0Symbol.charAt(0)}
                      </div>
                      <div className="absolute left-4 top-0 w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center text-white font-bold text-xs border-2 border-white dark:border-gray-900">
                        {pool.token1Symbol.charAt(0)}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-base text-purple-900 dark:text-purple-100">{pool.name}</h3>
                        {pool.isPiDEX && (
                          <Badge className="bg-purple-600 text-white text-[10px] px-1.5 py-0">PiDEX</Badge>
                        )}
                      </div>
                      <p className="text-xs text-purple-600 dark:text-purple-400">TVL: ${pool.tvl.toFixed(2)} (Demo)</p>
                    </div>
                  </div>

                  {/* Right side: APY prominently displayed */}
                  <div className="flex flex-col items-end justify-center">
                    <div className="flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-400 flex-shrink-0" />
                      <span className="text-xl font-bold text-green-600 dark:text-green-400 whitespace-nowrap">
                        {pool.apy}%
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground text-right whitespace-nowrap mt-0.5">
                      APY ước tính
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-2">
                    <p className="text-xs text-purple-600 dark:text-purple-400">My Liquidity</p>
                    <p className="text-lg font-bold text-purple-900 dark:text-purple-100">
                      {pool.myLiquidity > 0 ? `$${pool.myLiquidity.toFixed(2)}` : "$0.00"}
                    </p>
                  </div>
                  <div className="bg-green-50 dark:bg-green-950/30 rounded-lg p-2">
                    <p className="text-xs text-green-600 dark:text-green-400">Earned Fees</p>
                    <p className="text-lg font-bold text-green-900 dark:text-green-100">
                      {pool.earnedFees > 0 ? `$${pool.earnedFees.toFixed(2)}` : "$0.00"}
                    </p>
                  </div>
                </div>

                {pool.myLPTokens > 0 && (
                  <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-xs text-purple-600 dark:text-purple-400">Your LP Tokens</p>
                      <p className="text-sm font-bold text-purple-900 dark:text-purple-100">
                        {pool.myLPTokens.toFixed(4)}
                      </p>
                    </div>
                    <Progress value={65} className="h-2" />
                    <p className="text-xs text-purple-600 dark:text-purple-400">65% of pool share</p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      setSelectedPool(pool)
                      setShowAddDialog(true)
                    }}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                    style={{
                      background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Liquidity (Demo)
                  </Button>
                  {pool.myLPTokens > 0 && (
                    <Button
                      onClick={() => {
                        setSelectedPool(pool)
                        setShowRemoveDialog(true)
                      }}
                      variant="outline"
                      className="flex-1 border-purple-600 text-purple-600 hover:bg-purple-50"
                    >
                      <Minus className="w-4 h-4 mr-2" />
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add Liquidity Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedPool && (
                <div className="relative w-10 h-8">
                  <div className="absolute left-0 top-0 w-7 h-7 rounded-full bg-gradient-to-br from-yellow-400 to-purple-600 flex items-center justify-center text-white font-bold text-xs border-2 border-white z-10">
                    {selectedPool.token0Symbol.charAt(0)}
                  </div>
                  <div className="absolute left-3 top-0 w-7 h-7 rounded-full bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center text-white font-bold text-xs border-2 border-white">
                    {selectedPool.token1Symbol.charAt(0)}
                  </div>
                </div>
              )}
              Add Liquidity (Demo)
            </DialogTitle>
            <DialogDescription>
              {selectedPool && `Xem trước giao diện add liquidity vào pool ${selectedPool.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="amount-0">Số lượng {selectedPool?.token0Symbol}</Label>
                <span className="text-xs text-muted-foreground">
                  Khả dụng: {getTokenBalance(selectedPool?.token0Symbol || "")}
                </span>
              </div>
              <Input
                id="amount-0"
                type="number"
                placeholder={`0.0 ${selectedPool?.token0Symbol}`}
                value={amount0}
                onChange={(e) => setAmount0(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="amount-1">Số lượng {selectedPool?.token1Symbol}</Label>
                <span className="text-xs text-muted-foreground">
                  Khả dụng: {getTokenBalance(selectedPool?.token1Symbol || "")}
                </span>
              </div>
              <Input
                id="amount-1"
                type="number"
                placeholder={`0.0 ${selectedPool?.token1Symbol}`}
                value={amount1}
                onChange={(e) => setAmount1(e.target.value)}
              />
            </div>
            <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 text-sm space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-purple-600 dark:text-purple-400">Estimated APY:</span>
                <span className="font-semibold text-purple-900 dark:text-purple-100">{selectedPool?.apy}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-purple-600 dark:text-purple-400 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  Impermanent Loss (50% change):
                </span>
                <span className="font-semibold text-orange-600">~{calculateImpermanentLoss(50)}%</span>
              </div>
              <p className="text-xs text-purple-600 dark:text-purple-400 pt-1">
                LP tokens sẽ được mint và gửi về ví của bạn
              </p>
            </div>

            <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-300 dark:border-yellow-700">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-yellow-900 dark:text-yellow-100">Demo/Mock Mode</p>
                    <p className="text-xs text-yellow-800 dark:text-yellow-200 leading-relaxed">
                      Chưa kết nối pool PiDEX thật. Rủi ro impermanent loss và smart contract. DYOR và chờ Pi Mainnet
                      open DeFi 2026 để add liquidity thực tế. <strong>Không confirm giao dịch thật lúc này.</strong>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Đóng
            </Button>
            <Button
              onClick={handleAddLiquidity}
              disabled={true}
              className="bg-gray-400 text-white cursor-not-allowed opacity-60"
            >
              Xác nhận Add Liquidity (Disabled - Demo)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remove Liquidity Dialog */}
      <Dialog open={showRemoveDialog} onOpenChange={setShowRemoveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Remove Liquidity (Demo)</DialogTitle>
            <DialogDescription>
              {selectedPool && `Xem trước giao diện remove thanh khoản từ pool ${selectedPool.name}`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="remove-amount">Số lượng LP tokens</Label>
              <Input
                id="remove-amount"
                type="number"
                placeholder={`Tối đa ${selectedPool?.myLPTokens.toFixed(4) || "0.0000"}`}
                value={removeAmount}
                onChange={(e) => setRemoveAmount(e.target.value)}
                disabled
              />
            </div>
            {selectedPool && selectedPool.myLPTokens > 0 && (
              <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-purple-600 dark:text-purple-400">Your LP Tokens:</span>
                  <span className="font-semibold text-purple-900 dark:text-purple-100">
                    {selectedPool.myLPTokens.toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-600 dark:text-purple-400">Earned Fees:</span>
                  <span className="font-semibold text-green-600">${selectedPool.earnedFees.toFixed(2)}</span>
                </div>
                <p className="text-xs text-purple-600 dark:text-purple-400 pt-2">
                  Bạn sẽ nhận lại {selectedPool.token0Symbol} + {selectedPool.token1Symbol} + earned fees
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRemoveDialog(false)}>
              Đóng
            </Button>
            <Button
              onClick={handleRemoveLiquidity}
              disabled={true}
              className="bg-gray-400 text-white cursor-not-allowed opacity-60"
            >
              Xác nhận Remove Liquidity (Disabled - Demo)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
