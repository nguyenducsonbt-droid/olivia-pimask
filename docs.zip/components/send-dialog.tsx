"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useWallet } from "@/hooks/use-wallet"
import { sendTransaction } from "@/lib/wallet"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Send, Star } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddressBookDialog } from "./address-book-dialog"
import { getRecentRecipients, addRecentRecipient, findContactByAddress } from "@/lib/address-book"
import { Users, Clock, Keyboard } from "lucide-react"
import { triggerHaptic } from "@/lib/haptic"
import { isTwoFactorEnabled } from "@/lib/two-factor"
import { TwoFactorVerifyDialog } from "./two-factor-verify-dialog"

interface SendDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  initialAddress?: string
  activeWalletType?: "olivia" | "pi"
  senderAddress?: string
}

export function SendDialog({
  open,
  onOpenChange,
  initialAddress = "",
  activeWalletType = "olivia",
  senderAddress,
}: SendDialogProps) {
  const { wallet, currentNetwork, balance, addTransaction } = useWallet()
  const [to, setTo] = useState("")
  const [amount, setAmount] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()
  const { t } = useLanguage()
  const [showAddressBook, setShowAddressBook] = useState(false)
  const [recentRecipients, setRecentRecipients] = useState<Array<{ address: string; timestamp: number }>>([])
  const [selectedTab, setSelectedTab] = useState("manual")
  const [show2FAVerify, setShow2FAVerify] = useState(false)
  const [pending2FAAction, setPending2FAAction] = useState<(() => void) | null>(null)

  const estimatedGasFee = 0.0005 // ETH
  const amountNumber = amount ? Number.parseFloat(amount) : 0
  const fromAddress = senderAddress || wallet?.address || ""

  useEffect(() => {
    if (open && initialAddress) {
      setTo(initialAddress)
    }

    if (open) {
      const recent = getRecentRecipients(10)
      setRecentRecipients(recent)
    }
  }, [open, initialAddress])

  const handleSend = async () => {
    if (!wallet) return
    if (!to || !amount) {
      setError(t.send.errors.fillFields)
      return
    }
    if (amountNumber > Number.parseFloat(balance)) {
      setError(t.send.errors.insufficient)
      return
    }

    const requires2FA = isTwoFactorEnabled() && amountNumber > 50

    if (requires2FA) {
      setPending2FAAction(() => executeTransaction)
      setShow2FAVerify(true)
      return
    }

    await executeTransaction()
  }

  const executeTransaction = async () => {
    setIsLoading(true)
    setError("")

    try {
      console.log("[v0] Sending transaction on Mainnet with balance:", balance)

      const hash = await sendTransaction(wallet!, to, amount, currentNetwork.rpcUrl)
      addTransaction({
        hash,
        from: fromAddress,
        to,
        value: amount,
        timestamp: Date.now(),
        status: "pending",
        network: currentNetwork.name,
      })

      addRecentRecipient(to)

      toast({
        title: t.send.toasts.sent,
        description: `${t.send.toasts.submitted}. Balance: ${balance} ${currentNetwork.symbol}`,
      })
      onOpenChange(false)
      setTo("")
      setAmount("")
    } catch (err: any) {
      console.error("[v0] Send transaction failed:", err)
      setError(err.message || t.send.errors.failed)
    } finally {
      setIsLoading(false)
    }
  }

  const handle2FAVerified = () => {
    if (pending2FAAction) {
      pending2FAAction()
      setPending2FAAction(null)
    }
  }

  const handleSelectContact = (address: string) => {
    setTo(address)
    triggerHaptic("light")
    toast({
      title: "✓ Đã chọn địa chỉ",
      description: "Địa chỉ đã được điền vào",
      duration: 2000,
    })
  }

  const handleSelectRecent = (address: string) => {
    setTo(address)
    setSelectedTab("manual")
    triggerHaptic("light")
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle
              className="text-lg font-bold"
              style={{
                background: "linear-gradient(135deg, #8A2BE2 0%, #DA70D6 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Gửi {activeWalletType === "pi" ? "Pi" : "Token"}
            </DialogTitle>
            <DialogDescription style={{ color: "#DA70D6" }}>
              {activeWalletType === "pi" ? "Gửi Pi từ ví Pi Mainnet của bạn" : "Gửi token từ ví Olivia EVM"}
            </DialogDescription>
          </DialogHeader>

          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 p-1 bg-gray-100 rounded-lg">
              <TabsTrigger
                value="manual"
                className="text-xs data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#8A2BE2] data-[state=active]:to-[#6A1B9A] data-[state=active]:text-white data-[state=inactive]:bg-gray-200 data-[state=inactive]:text-gray-600 rounded-md transition-all"
              >
                <Keyboard className="w-3 h-3 mr-1" />
                Nhập tay
              </TabsTrigger>
              <TabsTrigger
                value="contacts"
                className="text-xs data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#8A2BE2] data-[state=active]:to-[#6A1B9A] data-[state=active]:text-white data-[state=inactive]:bg-gray-200 data-[state=inactive]:text-gray-600 rounded-md transition-all"
              >
                <Users className="w-3 h-3 mr-1" />
                Danh bạ
              </TabsTrigger>
              <TabsTrigger
                value="recent"
                className="text-xs data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#8A2BE2] data-[state=active]:to-[#6A1B9A] data-[state=active]:text-white data-[state=inactive]:bg-gray-200 data-[state=inactive]:text-gray-600 rounded-md transition-all"
              >
                <Clock className="w-3 h-3 mr-1" />
                Gần đây
              </TabsTrigger>
            </TabsList>

            <TabsContent value="manual" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="to-address" style={{ color: "#6A1B9A" }} className="font-medium">
                  {t.send.recipientLabel}
                </Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      id="to-address"
                      placeholder="0x..."
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      className="bg-white rounded-lg pr-8"
                      style={{
                        border: "1.5px solid #E6E6FA",
                        color: "#6A1B9A",
                      }}
                    />
                    <Star className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "#DA70D6" }} />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => setShowAddressBook(true)}
                    className="rounded-lg"
                    style={{
                      border: "1.5px solid #E6E6FA",
                      color: "#8A2BE2",
                    }}
                  >
                    <Users className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount" style={{ color: "#6A1B9A" }} className="font-medium">
                  {t.send.amountLabel}
                </Label>
                <div className="relative">
                  <Input
                    id="amount"
                    type="number"
                    step="0.0001"
                    placeholder="0.0"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="bg-white rounded-lg pr-20"
                    style={{
                      border: "1.5px solid #E6E6FA",
                      color: "#6A1B9A",
                    }}
                  />
                  <button
                    onClick={() => setAmount(balance)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-semibold px-3 py-1 rounded-md transition-colors"
                    style={{
                      color: "#8A2BE2",
                      backgroundColor: "#E6E6FA",
                    }}
                  >
                    TỐI ĐA
                  </button>
                </div>
                <div
                  className="text-center py-3 px-3 rounded-lg"
                  style={{
                    background: "linear-gradient(135deg, #E6E6FA 0%, #D8BFD8 100%)",
                  }}
                >
                  <p className="text-sm" style={{ color: "#6A1B9A" }}>
                    Phí gas hiện tại:{" "}
                    <span className="font-semibold" style={{ color: "#8A2BE2" }}>
                      ~{estimatedGasFee.toFixed(4)} ETH
                    </span>
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="contacts" className="space-y-3 mt-4 max-h-[300px] overflow-y-auto">
              <Button
                onClick={() => setShowAddressBook(true)}
                variant="outline"
                className="w-full rounded-lg"
                style={{
                  border: "1.5px solid #E6E6FA",
                  color: "#8A2BE2",
                }}
              >
                <Users className="w-4 h-4 mr-2" />
                Quản lý danh bạ
              </Button>
              <p className="text-xs text-center text-muted-foreground">Chọn người nhận từ danh bạ của bạn</p>
            </TabsContent>

            <TabsContent value="recent" className="space-y-2 mt-4 max-h-[300px] overflow-y-auto">
              {recentRecipients.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Clock className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Chưa có giao dịch gần đây</p>
                </div>
              ) : (
                recentRecipients.map((recipient, index) => {
                  const contact = findContactByAddress(recipient.address)
                  return (
                    <button
                      key={index}
                      onClick={() => handleSelectRecent(recipient.address)}
                      className="w-full text-left p-3 rounded-lg transition-all hover:shadow-md"
                      style={{
                        border: "1.5px solid #E6E6FA",
                        background: "linear-gradient(135deg, #E6E6FA 0%, #D8BFD8 100%)",
                      }}
                    >
                      <p className="font-medium text-sm" style={{ color: "#6A1B9A" }}>
                        {contact?.name || "Không rõ tên"}
                      </p>
                      <p className="text-xs truncate" style={{ color: "#8A2BE2" }}>
                        {recipient.address}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(recipient.timestamp).toLocaleDateString("vi-VN")}
                      </p>
                    </button>
                  )
                })
              )}
            </TabsContent>
          </Tabs>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
              className="rounded-full px-6"
              style={{
                backgroundColor: "white",
                border: "1.5px solid #D8BFD8",
                color: "#DA70D6",
              }}
            >
              {t.common.cancel}
            </Button>
            <Button
              onClick={handleSend}
              disabled={isLoading || selectedTab !== "manual"}
              className="rounded-full px-6 text-white font-semibold shadow-lg"
              style={{
                background: "linear-gradient(135deg, #8A2BE2 0%, #DA70D6 50%, #FF69B4 100%)",
                border: "none",
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t.send.sending}
                </>
              ) : (
                <>
                  {t.send.sendButton}
                  <Send className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>

        <AddressBookDialog
          open={showAddressBook}
          onOpenChange={setShowAddressBook}
          onSelectContact={handleSelectContact}
        />
      </Dialog>

      <TwoFactorVerifyDialog
        open={show2FAVerify}
        onOpenChange={setShow2FAVerify}
        onVerified={handle2FAVerified}
        title="Xác thực giao dịch lớn"
        description={`Giao dịch ${amount} Pi yêu cầu xác thực 2FA`}
      />
    </>
  )
}
