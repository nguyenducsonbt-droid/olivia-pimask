"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, ArrowDownLeft, Copy } from "lucide-react"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic, triggerSuccessFeedback } from "@/lib/haptic"

interface ReceivedTransactionsDetailProps {
  onBack: () => void
}

export function ReceivedTransactionsDetail({ onBack }: ReceivedTransactionsDetailProps) {
  const { transactions, address } = useWallet()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [filterDate, setFilterDate] = useState("all")

  const receivedTransactions = transactions
    .filter((tx) => tx.to.toLowerCase() === address.toLowerCase())
    .filter((tx) => {
      const matchesSearch =
        searchQuery === "" ||
        tx.hash.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.from.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesDate = filterDate === "all" || true // Add date filtering logic if needed

      return matchesSearch && matchesDate
    })
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

  const handleBack = () => {
    triggerHaptic("light")
    onBack()
  }

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash)
    triggerSuccessFeedback()
    toast({
      title: "Đã sao chép hash",
      description: "Hash giao dịch đã được sao chép",
    })
  }

  const handleCopyAddress = (addr: string) => {
    navigator.clipboard.writeText(addr)
    triggerSuccessFeedback()
    toast({
      title: "Đã sao chép địa chỉ",
      description: "Địa chỉ đã được sao chép",
    })
  }

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center gap-3 mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="text-purple-700 hover:bg-purple-50 transition-all active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-xl font-bold text-purple-900">Giao dịch đã nhận</h2>
      </div>

      <Card className="border-purple-200">
        <CardContent className="pt-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
            <Input
              placeholder="Tìm hash hoặc địa chỉ gửi..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 border-purple-200 focus:border-purple-400"
            />
          </div>

          <Select value={filterDate} onValueChange={setFilterDate}>
            <SelectTrigger className="border-purple-200">
              <SelectValue placeholder="Lọc theo thời gian" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tất cả</SelectItem>
              <SelectItem value="today">Hôm nay</SelectItem>
              <SelectItem value="week">Tuần này</SelectItem>
              <SelectItem value="month">Tháng này</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {receivedTransactions.length === 0 ? (
        <Card className="border-purple-200">
          <CardContent className="pt-6 pb-6 text-center">
            <ArrowDownLeft className="w-12 h-12 text-purple-300 mx-auto mb-3" />
            <p className="text-purple-600 font-medium">Chưa có giao dịch nhận nào</p>
            <p className="text-sm text-purple-400 mt-1">Các giao dịch nhận sẽ xuất hiện ở đây</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {receivedTransactions.map((tx) => (
            <Card key={tx.hash} className="border-purple-200 hover:shadow-md transition-shadow">
              <CardContent className="pt-4 pb-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                      <ArrowDownLeft className="w-4 h-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-purple-900">Nhận Pi</p>
                      <p className="text-xs text-purple-500">{new Date(tx.timestamp).toLocaleString("vi-VN")}</p>
                    </div>
                  </div>
                  <p className="text-base font-bold text-purple-600">+{tx.value} π</p>
                </div>

                <div className="space-y-2 mt-3 pt-3 border-t border-purple-100">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-purple-500">Từ:</p>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-mono text-purple-700">
                        {tx.from.slice(0, 8)}...{tx.from.slice(-6)}
                      </p>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6"
                        onClick={() => handleCopyAddress(tx.from)}
                      >
                        <Copy className="w-3 h-3 text-purple-500" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-xs text-purple-500">Hash:</p>
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-mono text-purple-700">
                        {tx.hash.slice(0, 8)}...{tx.hash.slice(-6)}
                      </p>
                      <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => handleCopyHash(tx.hash)}>
                        <Copy className="w-3 h-3 text-purple-500" />
                      </Button>
                    </div>
                  </div>

                  {tx.fee && (
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-purple-500">Phí:</p>
                      <p className="text-xs text-purple-700">{tx.fee} π</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
