"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertTriangle, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { getPinHash } from "@/lib/storage"
import { useTheme } from "./theme-context"

interface DeleteWalletDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onConfirmDelete: () => void
}

export function DeleteWalletDialog({ open, onOpenChange, onConfirmDelete }: DeleteWalletDialogProps) {
  const [pin, setPin] = useState<string[]>(["", "", "", "", "", ""])
  const [isVerifying, setIsVerifying] = useState(false)
  const { toast } = useToast()
  const { theme } = useTheme()

  const handlePinChange = (index: number, value: string) => {
    if (value.length > 1) {
      value = value[0]
    }

    if (!/^\d*$/.test(value)) return

    const newPin = [...pin]
    newPin[index] = value
    setPin(newPin)

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`delete-pin-${index + 1}`)
      nextInput?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !pin[index] && index > 0) {
      const prevInput = document.getElementById(`delete-pin-${index - 1}`)
      prevInput?.focus()
    }
  }

  const handleVerifyAndDelete = async () => {
    const pinString = pin.join("")
    if (pinString.length !== 6) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ 6 số PIN",
        variant: "destructive",
      })
      return
    }

    setIsVerifying(true)

    try {
      // Verify PIN
      const pinData = await getPinHash()
      if (!pinData) {
        toast({
          title: "Lỗi",
          description: "Không tìm thấy mã PIN",
          variant: "destructive",
        })
        setIsVerifying(false)
        return
      }

      // Hash the entered PIN
      const encoder = new TextEncoder()
      const data = encoder.encode(pinString)
      const hashBuffer = await crypto.subtle.digest("SHA-256", data)
      const hashArray = Array.from(new Uint8Array(hashBuffer))
      const enteredPinHash = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

      if (enteredPinHash !== pinData.pinHash) {
        toast({
          title: "Mã PIN không đúng",
          description: "Vui lòng thử lại",
          variant: "destructive",
        })
        setPin(["", "", "", "", "", ""])
        document.getElementById("delete-pin-0")?.focus()
        setIsVerifying(false)
        return
      }

      // PIN verified, proceed with deletion
      onConfirmDelete()
    } catch (error) {
      console.error("[v0] PIN verification error:", error)
      toast({
        title: "Lỗi",
        description: "Không thể xác thực mã PIN",
        variant: "destructive",
      })
    } finally {
      setIsVerifying(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-gradient-to-br from-red-50 to-orange-50 dark:from-[#330011] dark:to-[#1A0000] border-red-300 dark:border-red-600">
        <DialogHeader>
          <DialogTitle className="text-red-700 dark:text-red-400 flex items-center gap-2 text-lg">
            <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
            Xóa ví vĩnh viễn?
          </DialogTitle>
          <DialogDescription className="text-red-600 dark:text-red-300 space-y-3 pt-2">
            <p className="font-semibold text-red-700 dark:text-red-400">
              ⚠️ Cảnh báo: Hành động này không thể hoàn tác!
            </p>
            <p>Tất cả dữ liệu ví sẽ bị xóa khỏi thiết bị này, bao gồm:</p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Địa chỉ ví và private key</li>
              <li>Danh sách token và giao dịch</li>
              <li>Cài đặt và dữ liệu đã lưu</li>
            </ul>
            <p className="font-semibold text-red-700 dark:text-red-400">
              Bạn chỉ có thể khôi phục ví bằng 12 từ seed phrase.
            </p>
            <p className="text-sm">Đảm bảo bạn đã sao lưu seed phrase trước khi xóa!</p>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="text-red-700 dark:text-red-300">Nhập mã PIN để xác nhận:</Label>
            <div className="flex gap-2 justify-center">
              {pin.map((digit, index) => (
                <Input
                  key={index}
                  id={`delete-pin-${index}`}
                  type="password"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handlePinChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-12 h-14 text-center text-2xl font-bold border-2 border-red-300 dark:border-red-600 focus:border-red-500 dark:focus:border-red-400 bg-white dark:bg-[#220011] text-red-900 dark:text-red-200"
                />
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              Hủy
            </Button>
            <Button
              onClick={handleVerifyAndDelete}
              disabled={isVerifying || pin.join("").length !== 6}
              className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {isVerifying ? "Đang xóa..." : "Xóa ví"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
