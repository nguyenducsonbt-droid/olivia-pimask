"use client"

import { Plus } from "lucide-react"
import { triggerHaptic } from "@/lib/haptic"

interface FloatingActionButtonProps {
  onClick: () => void
}

export function FloatingActionButton({ onClick }: FloatingActionButtonProps) {
  const handleClick = () => {
    triggerHaptic("medium")
    onClick()
  }

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40 w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-purple-800 text-white shadow-2xl hover:shadow-purple-500/50 hover:scale-110 active:scale-95 transition-all duration-200 flex items-center justify-center group"
      style={{
        boxShadow: "0 8px 32px rgba(156, 39, 176, 0.4), 0 0 0 0 rgba(156, 39, 176, 0.7)",
        animation: "pulse-glow 2s ease-in-out infinite",
      }}
      aria-label="Giao dịch nhanh"
    >
      {/* Ripple effect on click */}
      <div className="absolute inset-0 rounded-full bg-white/20 scale-0 group-active:scale-150 group-active:opacity-0 transition-all duration-500" />

      {/* Icon */}
      <Plus className="w-8 h-8 group-hover:rotate-90 transition-transform duration-300" strokeWidth={3} />

      {/* Outer glow ring */}
      <div
        className="absolute inset-0 rounded-full border-4 border-purple-400/30 scale-110"
        style={{
          animation: "ping-slow 2s ease-in-out infinite",
        }}
      />

      <style jsx>{`
        @keyframes pulse-glow {
          0%, 100% {
            box-shadow: 0 8px 32px rgba(156, 39, 176, 0.4), 0 0 0 0 rgba(156, 39, 176, 0.7);
          }
          50% {
            box-shadow: 0 12px 40px rgba(156, 39, 176, 0.6), 0 0 20px 8px rgba(156, 39, 176, 0.5);
          }
        }
        
        @keyframes ping-slow {
          0% {
            transform: scale(1.1);
            opacity: 0.5;
          }
          50% {
            transform: scale(1.3);
            opacity: 0;
          }
          100% {
            transform: scale(1.1);
            opacity: 0;
          }
        }
      `}</style>
    </button>
  )
}
