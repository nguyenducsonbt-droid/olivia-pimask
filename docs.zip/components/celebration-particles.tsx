"use client"

import { useEffect, useState, useRef } from "react"

interface Particle {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  color: string
  size: number
}

export function CelebrationParticles() {
  const [particles, setParticles] = useState<Particle[]>([])
  const [show, setShow] = useState(false)

  const animationFrameRef = useRef<number | null>(null)
  const lastFrameTimeRef = useRef<number>(0)
  const isMountedRef = useRef(true)

  useEffect(() => {
    const visualEffects = localStorage.getItem("visual_effects") !== "false"
    const isDarkMode = document.documentElement.classList.contains("dark")

    // Don't show particles in dark mode or if effects are disabled
    if (!visualEffects || isDarkMode) {
      return
    }

    const lastCelebration = localStorage.getItem("last_celebration")
    const today = new Date().toDateString()

    if (lastCelebration !== today) {
      setShow(true)
      localStorage.setItem("last_celebration", today)

      // Create particles
      const newParticles: Particle[] = []
      const colors = ["#9C27B0", "#E91E63", "#BA68C8", "#F06292", "#CE93D8"]

      for (let i = 0; i < 30; i++) {
        newParticles.push({
          id: i,
          x: Math.random() * window.innerWidth,
          y: window.innerHeight + 20,
          vx: (Math.random() - 0.5) * 2,
          vy: -(Math.random() * 3 + 2),
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 8 + 4,
        })
      }

      setParticles(newParticles)

      // Hide after animation
      setTimeout(() => setShow(false), 2000)
    }
  }, [])

  useEffect(() => {
    if (!show || particles.length === 0) return

    isMountedRef.current = true

    const animate = (currentTime: number) => {
      if (!isMountedRef.current) return

      // Throttle to ~60fps
      if (currentTime - lastFrameTimeRef.current < 16) {
        animationFrameRef.current = requestAnimationFrame(animate)
        return
      }

      lastFrameTimeRef.current = currentTime

      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.1, // Gravity
          }))
          .filter((p) => p.y < window.innerHeight + 50),
      )

      animationFrameRef.current = requestAnimationFrame(animate)
    }

    animationFrameRef.current = requestAnimationFrame(animate)

    return () => {
      isMountedRef.current = false
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
        animationFrameRef.current = null
      }
    }
  }, [show, particles.length])

  if (!show) return null

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            opacity: 0.8,
            transform: "translate(-50%, -50%)",
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`,
          }}
        />
      ))}
    </div>
  )
}
