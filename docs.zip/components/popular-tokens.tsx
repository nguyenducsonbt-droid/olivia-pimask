"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy, AlertTriangle, ChevronDown, ChevronUp, ExternalLink, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PopularToken {
  name: string
  symbol: string
  contractAddress: string
  description: string
  isOfficial?: boolean
  icon?: string
}

const POPULAR_TOKENS: PopularToken[] = [
  {
    name: "Pi Network",
    symbol: "PI",
    contractAddress: "0x...",
    description: "Native Pi token, EVM-compatible mainnet 2026",
    isOfficial: true,
    icon: "π", // Pi symbol as icon
  },
  {
    name: "Tether USD",
    symbol: "USDT",
    contractAddress: "0x...",
    description: "Stablecoin phổ biến, pair PI/USDT, bridge quốc tế",
    isOfficial: true,
  },
  {
    name: "USD Coin",
    symbol: "USDC",
    contractAddress: "0x...",
    description: "Stablecoin được quy định, bridge fiat-crypto",
    isOfficial: true,
  },
  {
    name: "Pi Ecosystem",
    symbol: "PIEC",
    contractAddress: "0x...",
    description: "Verified ecosystem token, DApps governance",
    isOfficial: true,
  },
  {
    name: "PiSwap",
    symbol: "PISWAP",
    contractAddress: "0x...",
    description: "Community DEX, liquidity provider rewards",
    isOfficial: false,
  },
  {
    name: "PiDEX Token",
    symbol: "PIDEX",
    contractAddress: "0x...",
    description: "Native DEX Pi 2026, AMM liquidity, token swap",
    isOfficial: true,
  },
]

export function PopularTokens() {
  const { toast } = useToast()
  const [isExpanded, setIsExpanded] = useState(true)
  const [expandedToken, setExpandedToken] = useState<string>("PI")

  const handleCopyContract = (token: PopularToken) => {
    navigator.clipboard.writeText(token.contractAddress)
    toast({
      title: "Đã copy!",
      description: `Dán vào ví Olivia PiMask > Tokens > + để thêm ${token.symbol}`,
      duration: 3000,
    })
  }

  const handleOpenExplorer = (url: string, name: string) => {
    try {
      window.open(url, "_blank", "noopener,noreferrer")
    } catch (error) {
      toast({
        title: "Lỗi",
        description: `Không mở được ${name}`,
        variant: "destructive",
        duration: 3000,
      })
    }
  }

  return (
    <Card
      className="border-purple-200 cursor-pointer hover:shadow-md transition-shadow"
      onClick={() => !isExpanded && setIsExpanded(true)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-base font-semibold text-purple-700">Token Phổ Biến</h3>
            {!isExpanded && (
              <div className="flex items-start gap-2 mt-2">
                <AlertTriangle className="h-3 w-3 text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-amber-800">Verify contract trên piscan.io hoặc minepi explorer</p>
              </div>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation()
              setIsExpanded(!isExpanded)
            }}
            className="h-8 w-8 p-0 ml-2"
          >
            {isExpanded ? (
              <ChevronUp className="h-5 w-5 text-purple-600" />
            ) : (
              <ChevronDown className="h-5 w-5 text-purple-600" />
            )}
          </Button>
        </div>
        {!isExpanded && <p className="text-xs text-muted-foreground mt-1">Copy contract để thêm nhanh</p>}
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-4 pt-0">
          <p className="text-sm text-muted-foreground">Add token nhanh mà không cần nhập tay.</p>

          <div className="flex flex-col gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-amber-800 font-medium">
                  Danh sách phổ biến Pi ecosystem 2026. Verify contract để tránh scam. Chỉ add contract chính thức.
                </p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleOpenExplorer("https://piscan.io", "piscan.io")
                    }}
                    className="inline-flex items-center gap-1 text-xs text-purple-700 hover:text-purple-900 hover:underline font-medium"
                  >
                    <ExternalLink className="h-3 w-3" />
                    Verify on piscan.io
                  </button>
                  <span className="text-xs text-gray-400">|</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleOpenExplorer("https://blockexplorer.minepi.com", "MinePi Explorer")
                    }}
                    className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 hover:underline font-medium"
                  >
                    <Search className="h-3 w-3" />
                    MinePi Explorer
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {POPULAR_TOKENS.map((token) => (
              <div
                key={token.symbol}
                className="p-3 rounded-lg border border-purple-100 bg-gradient-to-br from-purple-50 to-white hover:shadow-md transition-shadow"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          token.symbol === "PI"
                            ? "bg-gradient-to-br from-yellow-400 via-yellow-500 to-purple-600"
                            : "bg-gradient-to-br from-purple-500 to-purple-700"
                        }`}
                      >
                        <span className="text-sm font-bold text-white">{token.icon || token.symbol[0]}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-1">
                          <p className={`text-sm text-gray-900 ${token.isOfficial ? "font-bold" : "font-semibold"}`}>
                            {token.symbol}
                          </p>
                          {token.isOfficial && (
                            <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-medium">
                              Official
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-gray-600">{token.name}</p>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">{token.description}</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleCopyContract(token)}
                  className="w-full h-8 mt-2 text-xs bg-white border-purple-300 text-purple-700 hover:bg-purple-50 hover:text-purple-800"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy Contract
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  )
}
