"use client"
import { Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { HolographicGlobe } from "@/components/holographic-globe"

interface WelcomeSplashProps {
  onCreateWallet: () => void
  onRestoreWallet: () => void
}

export function WelcomeSplash({ onCreateWallet, onRestoreWallet }: WelcomeSplashProps) {
  const [sparkles, setSparkles] = useState<Array<{ id: number; delay: number; x: number; y: number }>>([])
  const [showRocketAnimation, setShowRocketAnimation] = useState(true)

  useEffect(() => {
    const sparkleArray = Array.from({ length: 8 }, (_, i) => ({
      id: i,
      delay: i * 0.3,
      x: Math.cos((i * Math.PI * 2) / 8) * 80,
      y: Math.sin((i * Math.PI * 2) / 8) * 80,
    }))
    setSparkles(sparkleArray)

    const initialTimeout = setTimeout(() => {
      setShowRocketAnimation(false)
      setTimeout(() => {
        setShowRocketAnimation(true)
      }, 100)
    }, 5000)

    const loopInterval = setInterval(() => {
      setShowRocketAnimation(false)
      setTimeout(() => {
        setShowRocketAnimation(true)
      }, 100)
    }, 8000)

    return () => {
      clearTimeout(initialTimeout)
      clearInterval(loopInterval)
    }
  }, [])

  return (
    <div className="min-h-screen flex flex-col items-center justify-between p-6 bg-gradient-to-br from-purple-600 via-purple-500 to-pink-400 relative overflow-hidden">
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-400 rounded-full blur-3xl animate-pulse" />
        <div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-400 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        />
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/20 to-transparent">
        <svg
          viewBox="0 0 1200 200"
          className="absolute bottom-0 w-full h-full"
          preserveAspectRatio="none"
          fill="rgba(0,0,0,0.15)"
        >
          <rect x="50" y="120" width="60" height="80" />
          <rect x="120" y="80" width="80" height="120" />
          <rect x="210" y="100" width="50" height="100" />
          <rect x="270" y="60" width="90" height="140" />
          <rect x="370" y="90" width="70" height="110" />
          <rect x="450" y="70" width="60" height="130" />
          <rect x="520" y="100" width="80" height="100" />
          <rect x="610" y="80" width="70" height="120" />
          <rect x="690" y="110" width="50" height="90" />
          <rect x="750" y="90" width="90" height="110" />
          <rect x="850" y="70" width="70" height="130" />
          <rect x="930" y="100" width="60" height="100" />
          <rect x="1000" y="80" width="80" height="120" />
          <rect x="1090" y="110" width="60" height="90" />
        </svg>
      </div>

      <div className="flex-1 flex items-center justify-center w-full relative z-10 pt-20">
        <div className="w-full max-w-md flex flex-col items-center space-y-8">
          <div className="space-y-3 animate-fade-in-glow text-center mt-4">
            <h1 className="text-5xl font-bold text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.5)] animate-text-glow">
              Olivia PiMask
            </h1>
          </div>

          <div className="flex justify-center relative mt-10">
            {sparkles.map((sparkle) => (
              <div
                key={sparkle.id}
                className="absolute w-2 h-2 bg-white rounded-full animate-sparkle"
                style={{
                  left: `calc(50% + ${sparkle.x}px)`,
                  top: `calc(50% + ${sparkle.y}px)`,
                  animationDelay: `${sparkle.delay}s`,
                }}
              />
            ))}

            <div className="relative">
              <div className="absolute inset-0 rounded-3xl bg-purple-500/50 blur-2xl animate-breathing-glow" />
              <div
                className="absolute inset-0 rounded-3xl bg-[#C300FF]/60 blur-xl animate-breathing-glow"
                style={{ animationDelay: "0.5s" }}
              />

              <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-purple-700 to-pink-500 flex items-center justify-center shadow-2xl ring-4 ring-white/30 animate-glow-build">
                <Wallet
                  className="w-12 h-12 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.8)]"
                  strokeWidth={2.5}
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center animate-fade-in-glow relative space-y-6">
            <div className="space-y-1 text-center">
              <p className="text-xl font-bold text-white drop-shadow-md">The Premium Pi Wallet</p>
              <p className="text-sm italic text-white drop-shadow-md">Đẹp như Olivia</p>
            </div>

            <div className="relative z-0">
              <HolographicGlobe />
            </div>

            {showRocketAnimation && (
              <div className="absolute left-1/2 -translate-x-1/2 -top-4 pointer-events-none z-10">
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                  <div className="absolute inset-0 w-32 h-32 rounded-full border-2 border-yellow-300/40 animate-ripple-1" />
                  <div className="absolute inset-0 w-32 h-32 rounded-full border-2 border-pink-300/40 animate-ripple-2" />
                  <div className="absolute inset-0 w-32 h-32 rounded-full border-2 border-purple-300/40 animate-ripple-3" />
                  <div className="absolute inset-0 w-32 h-32 rounded-full bg-gradient-to-r from-yellow-200/20 via-pink-200/20 to-purple-200/20 animate-ripple-glow" />
                </div>

                <div className="relative animate-rocket-launch">
                  <svg
                    width="48"
                    height="48"
                    viewBox="0 0 48 48"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]"
                  >
                    <path
                      d="M24 4 L28 14 L28 32 L24 38 L20 32 L20 14 Z"
                      fill="url(#rocketGradient)"
                      stroke="white"
                      strokeWidth="1.5"
                    />
                    <path d="M20 24 L14 30 L20 30 Z" fill="url(#finGradient)" stroke="white" strokeWidth="1" />
                    <path d="M28 24 L34 30 L28 30 Z" fill="url(#finGradient)" stroke="white" strokeWidth="1" />
                    <circle cx="24" cy="16" r="3" fill="white" opacity="0.9" />
                    <text
                      x="24"
                      y="18.5"
                      fontSize="5"
                      fontWeight="bold"
                      fill="url(#rocketGradient)"
                      textAnchor="middle"
                    >
                      π
                    </text>
                    <path d="M24 4 L26 8 L24 6 L22 8 Z" fill="white" className="animate-sparkle-tip" />

                    <defs>
                      <linearGradient id="rocketGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#E879F9" />
                        <stop offset="50%" stopColor="#C084FC" />
                        <stop offset="100%" stopColor="#A78BFA" />
                      </linearGradient>
                      <linearGradient id="finGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#F0ABFC" />
                        <stop offset="100%" stopColor="#E879F9" />
                      </linearGradient>
                    </defs>
                  </svg>

                  <div className="absolute left-1/2 -translate-x-1/2 top-8">
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <div
                        key={i}
                        className="absolute w-1.5 h-1.5 bg-white rounded-full animate-trail-sparkle"
                        style={{
                          left: `${Math.sin(i) * 8}px`,
                          top: `${i * 6}px`,
                          animationDelay: `${i * 0.15}s`,
                        }}
                      />
                    ))}
                  </div>
                </div>

                {[...Array(12)].map((_, i) => {
                  const angle = (i * Math.PI * 2) / 12
                  const radius = 40 + (i % 3) * 8
                  return (
                    <div
                      key={`spark-${i}`}
                      className="absolute w-1 h-1 bg-white rounded-full animate-path-sparkle"
                      style={{
                        left: `calc(50% + ${Math.cos(angle) * radius}px)`,
                        top: `calc(50% + ${Math.sin(angle) * radius}px)`,
                        animationDelay: `${i * 0.2}s`,
                      }}
                    />
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="w-full max-w-md space-y-4 pb-16 relative z-20">
        <Button
          onClick={onCreateWallet}
          className="w-full h-16 bg-gradient-to-r from-purple-800 to-purple-700 hover:from-purple-900 hover:to-purple-800 text-white font-bold text-lg rounded-2xl shadow-xl hover:shadow-2xl transition-all hover:scale-[1.02]"
        >
          Tạo ví mới
        </Button>

        <Button
          onClick={onRestoreWallet}
          className="w-full h-16 bg-purple-100/90 hover:bg-purple-200/90 text-purple-800 font-bold text-lg rounded-2xl shadow-xl hover:shadow-2xl transition-all hover:scale-[1.02] border-2 border-purple-400"
        >
          Khôi phục ví
        </Button>
      </div>

      <style jsx>{`
        @keyframes breathing-glow {
          0%, 100% {
            opacity: 0.8;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.1);
          }
        }

        @keyframes glow-build {
          0% {
            box-shadow: 0 0 0px rgba(195, 0, 255, 0);
          }
          50% {
            box-shadow: 0 0 40px rgba(195, 0, 255, 0.8), 0 0 60px rgba(195, 0, 255, 0.6), 0 0 80px rgba(195, 0, 255, 0.4);
          }
          100% {
            box-shadow: 0 0 30px rgba(195, 0, 255, 0.8), 0 0 50px rgba(195, 0, 255, 0.6), 0 0 70px rgba(195, 0, 255, 0.4);
          }
        }

        @keyframes sparkle {
          0%, 100% {
            opacity: 0;
            transform: scale(0);
          }
          10%, 30% {
            opacity: 1;
            transform: scale(1);
          }
          40% {
            opacity: 0;
            transform: scale(0);
          }
        }

        @keyframes fade-in-glow {
          0% {
            opacity: 0;
            transform: translateY(10px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes text-glow {
          0%, 100% {
            text-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
          }
          50% {
            text-shadow: 0 0 30px rgba(255, 255, 255, 0.8), 0 0 40px rgba(195, 0, 255, 0.6);
          }
        }

        @keyframes rocket-launch {
          0% {
            transform: translateY(60px) scale(0.8);
            opacity: 0;
          }
          15% {
            opacity: 1;
          }
          85% {
            opacity: 1;
          }
          100% {
            transform: translateY(-120px) scale(1);
            opacity: 0;
          }
        }

        @keyframes ripple-1 {
          0% {
            transform: scale(0.3);
            opacity: 0.8;
          }
          100% {
            transform: scale(2.5);
            opacity: 0;
          }
        }

        @keyframes ripple-2 {
          0% {
            transform: scale(0.3);
            opacity: 0.7;
          }
          100% {
            transform: scale(2.8);
            opacity: 0;
          }
        }

        @keyframes ripple-3 {
          0% {
            transform: scale(0.3);
            opacity: 0.6;
          }
          100% {
            transform: scale(3.2);
            opacity: 0;
          }
        }

        @keyframes ripple-glow {
          0% {
            transform: scale(0.5);
            opacity: 0.4;
          }
          100% {
            transform: scale(3);
            opacity: 0;
          }
        }

        @keyframes sparkle-tip {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.3;
            transform: scale(1.3);
          }
        }

        @keyframes trail-sparkle {
          0% {
            opacity: 1;
            transform: scale(1);
          }
          100% {
            opacity: 0;
            transform: scale(0.3) translateY(20px);
          }
        }

        @keyframes path-sparkle {
          0%, 20% {
            opacity: 0;
            transform: scale(0);
          }
          40% {
            opacity: 1;
            transform: scale(1.5);
          }
          60% {
            opacity: 0.8;
            transform: scale(1);
          }
          100% {
            opacity: 0;
            transform: scale(0);
          }
        }

        .animate-breathing-glow {
          animation: breathing-glow 2s ease-in-out infinite;
        }

        .animate-glow-build {
          animation: glow-build 1.5s ease-out forwards, breathing-glow 2s ease-in-out infinite 1.5s;
        }

        .animate-sparkle {
          animation: sparkle 3s ease-in-out infinite;
        }

        .animate-fade-in-glow {
          animation: fade-in-glow 1s ease-out 0.5s forwards;
          opacity: 0;
        }

        .animate-text-glow {
          animation: text-glow 3s ease-in-out infinite;
        }

        .animate-rocket-launch {
          animation: rocket-launch 5s ease-out forwards;
        }

        .animate-ripple-1 {
          animation: ripple-1 4s ease-out forwards;
        }

        .animate-ripple-2 {
          animation: ripple-2 4.5s ease-out 0.2s forwards;
        }

        .animate-ripple-3 {
          animation: ripple-3 5s ease-out 0.4s forwards;
        }

        .animate-ripple-glow {
          animation: ripple-glow 5s ease-out forwards;
        }

        .animate-sparkle-tip {
          animation: sparkle-tip 1s ease-in-out infinite;
        }

        .animate-trail-sparkle {
          animation: trail-sparkle 1.2s ease-out forwards;
        }

        .animate-path-sparkle {
          animation: path-sparkle 3s ease-in-out forwards;
        }
      `}</style>
    </div>
  )
}
