"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { QRCodeSVG } from "qrcode.react"

interface ChainQRDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  network: {
    name: string
    chainId: number
    rpcUrl: string
  }
}

export function ChainQRDialog({ open, onOpenChange, network }: ChainQRDialogProps) {
  const chainInfo = JSON.stringify({
    chainId: network.chainId,
    name: network.name,
    rpcUrl: network.rpcUrl,
  })

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-md"
        style={{
          background: "linear-gradient(135deg, rgba(156, 39, 176, 0.05) 0%, rgba(233, 30, 99, 0.05) 100%)",
          border: "1px solid rgba(156, 39, 176, 0.2)",
        }}
      >
        <DialogHeader>
          <DialogTitle className="text-center" style={{ color: "#7B1FA2" }}>
            Chain ID QR Code
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 p-4">
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <QRCodeSVG value={chainInfo} size={200} level="H" includeMargin fgColor="#7B1FA2" />
          </div>
          <div className="text-center space-y-1">
            <p className="font-semibold" style={{ color: "#7B1FA2" }}>
              {network.name}
            </p>
            <p className="text-sm text-muted-foreground">Chain ID: {network.chainId}</p>
            <p className="text-xs text-muted-foreground break-all px-4">{network.rpcUrl}</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
