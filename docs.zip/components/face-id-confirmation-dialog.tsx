"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Fingerprint, Shield } from "lucide-react"
import { saveBiometricEnabled } from "@/lib/storage"
import { useToast } from "@/hooks/use-toast"

interface FaceIDConfirmationDialogProps {
  open: boolean
  onSuccess: () => void
  onSkip: () => void
}

export function FaceIDConfirmationDialog({ open, onSuccess, onSkip }: FaceIDConfirmationDialogProps) {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handleUseFaceID = async () => {
    setLoading(true)

    try {
      if (typeof window !== "undefined" && (window as any).Pi && (window as any).Pi.biometric) {
        const Pi = (window as any).Pi

        // Request biometric authentication
        const result = await Pi.biometric.authenticate({
          reason: "Xác thực Face ID cho Olivia PiMask",
          fallbackEnabled: true,
        })

        if (result.success) {
          // Save biometric enabled setting
          saveBiometricEnabled(true)

          toast({
            title: "Thành công",
            description: "Face ID đã được kích hoạt",
          })

          onSuccess()
        } else {
          toast({
            title: "Xác thực thất bại",
            description: "Vui lòng thử lại hoặc bỏ qua",
            variant: "destructive",
          })
          setLoading(false)
        }
      } else {
        // Preview/testnet mode: simulate success
        console.log("[v0] Biometric API not available (preview mode), simulating success...")
        await new Promise((resolve) => setTimeout(resolve, 800))

        saveBiometricEnabled(true)

        toast({
          title: "Thành công",
          description: "Face ID đã được kích hoạt (chế độ xem trước)",
        })

        onSuccess()
      }
    } catch (err) {
      console.error("[v0] Face ID authentication error:", err)
      toast({
        title: "Lỗi",
        description: "Không thể xác thực Face ID",
        variant: "destructive",
      })
      setLoading(false)
    }
  }

  const handleSkip = () => {
    saveBiometricEnabled(false)
    onSkip()
  }

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleSkip()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg">
            <Fingerprint className="w-10 h-10 text-white" />
          </div>
          <DialogTitle className="text-2xl font-bold text-gray-900">Xác thực Face ID</DialogTitle>
          <DialogDescription className="text-base text-gray-600">
            Bảo vệ ví của bạn bằng Face ID / Touch ID để truy cập nhanh và an toàn hơn
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-blue-900">Bảo mật tăng cường</p>
              <p className="text-xs text-blue-700">
                Face ID sử dụng sinh trắc học của bạn để xác thực, an toàn hơn nhiều so với chỉ dùng seed phrase
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={handleUseFaceID}
              disabled={loading}
              className="w-full h-12 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white font-semibold text-base"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Đang xác thực...
                </div>
              ) : (
                <>
                  <Fingerprint className="mr-2 h-5 w-5" />
                  Sử dụng Face ID
                </>
              )}
            </Button>

            <Button
              onClick={handleSkip}
              variant="ghost"
              disabled={loading}
              className="w-full text-sm text-gray-500 hover:text-gray-700 hover:bg-gray-100"
            >
              Bỏ qua
            </Button>
          </div>
        </div>

        <p className="text-xs text-center text-gray-500">Bạn có thể bật/tắt Face ID bất cứ lúc nào trong Cài đặt</p>
      </DialogContent>
    </Dialog>
  )
}
