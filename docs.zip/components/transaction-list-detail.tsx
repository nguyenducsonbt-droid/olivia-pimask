"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useWallet } from "@/hooks/use-wallet"
import { SentTransactionsDetail } from "./sent-transactions-detail"
import { ReceivedTransactionsDetail } from "./received-transactions-detail"
import { triggerHaptic } from "@/lib/haptic"

interface TransactionListDetailProps {
  onBack: () => void
}

export function TransactionListDetail({ onBack }: TransactionListDetailProps) {
  const { transactions, address } = useWallet()
  const [view, setView] = useState<"main" | "sent" | "received">("main")

  const totalSent = transactions
    .filter((tx) => tx.from.toLowerCase() === address.toLowerCase())
    .reduce((sum, tx) => sum + Number.parseFloat(tx.value), 0)

  const totalReceived = transactions
    .filter((tx) => tx.to.toLowerCase() === address.toLowerCase())
    .reduce((sum, tx) => sum + Number.parseFloat(tx.value), 0)

  const sentCount = transactions.filter((tx) => tx.from.toLowerCase() === address.toLowerCase()).length
  const receivedCount = transactions.filter((tx) => tx.to.toLowerCase() === address.toLowerCase()).length

  const handleBack = () => {
    triggerHaptic("light")
    onBack()
  }

  if (view === "sent") {
    return (
      <SentTransactionsDetail
        onBack={() => {
          triggerHaptic("light")
          setView("main")
        }}
      />
    )
  }

  if (view === "received") {
    return (
      <ReceivedTransactionsDetail
        onBack={() => {
          triggerHaptic("light")
          setView("main")
        }}
      />
    )
  }

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center gap-3 mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="text-purple-700 hover:bg-purple-50 transition-all active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-xl font-bold text-purple-900">Chi tiết giao dịch</h2>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card
          className="border-purple-200 bg-gradient-to-br from-purple-50/50 to-transparent cursor-pointer transition-all hover:shadow-lg hover:scale-105 active:scale-100"
          onClick={() => setView("sent")}
        >
          <CardContent className="pt-6">
            <p className="text-xs text-purple-600 mb-1">Tổng gửi</p>
            <p className="text-xl font-bold text-pink-600">{totalSent.toFixed(4)} π</p>
            <p className="text-xs text-purple-500 mt-1">{sentCount} giao dịch</p>
          </CardContent>
        </Card>

        <Card
          className="border-purple-200 bg-gradient-to-br from-pink-50/50 to-transparent cursor-pointer transition-all hover:shadow-lg hover:scale-105 active:scale-100"
          onClick={() => setView("received")}
        >
          <CardContent className="pt-6">
            <p className="text-xs text-purple-600 mb-1">Tổng nhận</p>
            <p className="text-xl font-bold text-purple-600">{totalReceived.toFixed(4)} π</p>
            <p className="text-xs text-purple-500 mt-1">{receivedCount} giao dịch</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
