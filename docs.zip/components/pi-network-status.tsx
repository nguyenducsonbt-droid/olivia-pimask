"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Clock, TrendingUp, Users, Zap, ShieldCheck, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { loadPiSession } from "@/lib/persistent-storage"
import { useLanguage } from "@/hooks/use-language"

interface PiNetworkStatus {
  balance: number
  miningRate: number
  boost: number
  lockupDays: number
  kycStatus: "verified" | "pending" | "not_started"
  referralCount: number
  nodeStatus: "active" | "inactive"
}

export function PiNetworkStatus() {
  const [status, setStatus] = useState<PiNetworkStatus | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [username, setUsername] = useState<string | null>(null)
  const { toast } = useToast()
  const { language } = useLanguage()

  const fetchPiStatus = async () => {
    try {
      // Check for Pi SDK availability
      if (typeof window === "undefined" || !(window as any).Pi) {
        setIsLoading(false)
        return
      }

      const Pi = (window as any).Pi

      // Load saved session
      const session = await loadPiSession()
      if (session && session.user) {
        setUsername(session.user.username)
      }

      // Fetch balance
      let balance = 0
      try {
        const balanceResult = await Pi.getBalance()
        if (balanceResult && balanceResult.balance) {
          balance = Number.parseFloat(balanceResult.balance)
        }
      } catch (error) {
        console.log("[v0] Failed to fetch Pi balance:", error)
      }

      // Mock data for now - will be replaced with real Pi API calls when available
      setStatus({
        balance,
        miningRate: 0.25, // Pi per hour
        boost: 1.5, // 150%
        lockupDays: 180,
        kycStatus: "pending",
        referralCount: 12,
        nodeStatus: "inactive",
      })

      setIsLoading(false)
    } catch (error) {
      console.error("[v0] Failed to fetch Pi status:", error)
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchPiStatus()

    // Refresh when page becomes visible
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        fetchPiStatus()
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await fetchPiStatus()
    setIsRefreshing(false)
    toast({
      title: language === "vi" ? "Đã cập nhật" : language === "en" ? "Updated" : "已更新",
      description:
        language === "vi"
          ? "Trạng thái Pi Network đã được làm mới"
          : language === "en"
            ? "Pi Network status has been refreshed"
            : "Pi Network 状态已刷新",
    })
  }

  const handleVerifyKYC = () => {
    if (typeof window !== "undefined" && (window as any).Pi) {
      // Try Pi deep link first
      try {
        window.location.href = "pi://kyc"
      } catch (error) {
        // Fallback to web
        window.open("https://kyc.pi", "_blank")
      }
    } else {
      toast({
        title:
          language === "vi"
            ? "Vui lòng mở Pi Browser"
            : language === "en"
              ? "Please open Pi Browser"
              : "请打开 Pi Browser",
        description:
          language === "vi"
            ? "KYC chỉ khả dụng trong Pi Browser"
            : language === "en"
              ? "KYC is only available in Pi Browser"
              : "KYC 仅在 Pi Browser 中可用",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <RefreshCw className="w-6 h-6 text-purple-500 animate-spin" />
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!status) {
    return (
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="py-8">
          <div className="text-center text-sm text-purple-700">
            {language === "vi"
              ? "Vui lòng kết nối với Pi Browser để xem trạng thái Pi Network"
              : language === "en"
                ? "Please connect to Pi Browser to view Pi Network status"
                : "请连接到 Pi Browser 以查看 Pi Network 状态"}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2 text-purple-900">
            <Zap className="w-5 h-5 text-purple-600" />
            Pi Network Status
            {username && <span className="text-sm font-normal text-purple-600">(@{username})</span>}
          </CardTitle>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="h-8 w-8 p-0 hover:bg-purple-100"
          >
            <RefreshCw className={`w-4 h-4 text-purple-600 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Pi Mainnet Balance */}
        <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-purple-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-purple-700 font-medium">Pi Mainnet Balance</span>
            <Badge variant="outline" className="border-green-500 text-green-700 bg-green-50">
              Live
            </Badge>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-purple-900">{status.balance.toFixed(4)}</span>
            <span className="text-lg font-semibold text-purple-600">π</span>
          </div>
        </div>

        {/* Mining Status */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-purple-200">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-purple-600" />
              <span className="text-xs text-purple-700 font-medium">Mining Rate</span>
            </div>
            <p className="text-xl font-bold text-purple-900">{status.miningRate.toFixed(2)} π/h</p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-purple-200">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-purple-600" />
              <span className="text-xs text-purple-700 font-medium">Boost</span>
            </div>
            <p className="text-xl font-bold text-purple-900">{status.boost}x</p>
          </div>
        </div>

        {/* Lockup */}
        <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-purple-200">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-purple-700 font-medium">Lockup Period</span>
            </div>
            <Badge variant="outline" className="border-purple-500 text-purple-700 bg-purple-50">
              Active
            </Badge>
          </div>
          <p className="text-lg font-bold text-purple-900">{status.lockupDays} days remaining</p>
        </div>

        {/* KYC Status */}
        <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-purple-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-purple-900">KYC Status</p>
                <div className="flex items-center gap-2 mt-1">
                  {status.kycStatus === "verified" ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span className="text-xs font-semibold text-green-700">Verified</span>
                    </>
                  ) : status.kycStatus === "pending" ? (
                    <>
                      <Clock className="w-4 h-4 text-yellow-500" />
                      <span className="text-xs font-semibold text-yellow-700">Pending</span>
                    </>
                  ) : (
                    <>
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-xs font-semibold text-gray-700">Not Started</span>
                    </>
                  )}
                </div>
              </div>
            </div>
            {status.kycStatus !== "verified" && (
              <Button size="sm" onClick={handleVerifyKYC} className="bg-purple-600 hover:bg-purple-700 text-white">
                Verify Now
              </Button>
            )}
          </div>
        </div>

        {/* Referrals & Node */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-purple-200">
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-purple-600" />
              <span className="text-xs text-purple-700 font-medium">Referrals</span>
            </div>
            <p className="text-xl font-bold text-purple-900">{status.referralCount}</p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm rounded-lg p-3 border border-purple-200">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-purple-600" />
              <span className="text-xs text-purple-700 font-medium">Node</span>
            </div>
            <Badge
              variant="outline"
              className={
                status.nodeStatus === "active"
                  ? "border-green-500 text-green-700 bg-green-50"
                  : "border-gray-400 text-gray-700 bg-gray-50"
              }
            >
              {status.nodeStatus === "active" ? "Active" : "Inactive"}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
