"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, AlertCircle, Copy } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import * as bip39 from "bip39"
import { derivePath } from "ed25519-hd-key"
import nacl from "tweetnacl"
import { toast } from "@/hooks/use-toast"
import QRCode from "react-qr-code"
import { saveWalletData, simpleEncrypt } from "@/lib/storage"

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

function base32Encode(data: Uint8Array): string {
  let bits = 0
  let value = 0
  let output = ""

  for (let i = 0; i < data.length; i++) {
    value = (value << 8) | data[i]
    bits += 8

    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31]
      bits -= 5
    }
  }

  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31]
  }

  return output
}

function generateStellarAddress(publicKey: Uint8Array): string {
  // Stellar uses ed25519 public keys with version byte 6 << 3 = 48 (0x30) for account IDs
  const versionByte = 6 << 3
  const data = new Uint8Array(1 + publicKey.length)
  data[0] = versionByte
  data.set(publicKey, 1)

  // Calculate checksum (CRC16-XModem)
  const checksum = crc16(data)
  const checksumBytes = new Uint8Array(2)
  checksumBytes[0] = checksum & 0xff
  checksumBytes[1] = (checksum >> 8) & 0xff

  // Combine data and checksum
  const full = new Uint8Array(data.length + 2)
  full.set(data)
  full.set(checksumBytes, data.length)

  return base32Encode(full)
}

function crc16(data: Uint8Array): number {
  let crc = 0x0000
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i] << 8
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021
      } else {
        crc = crc << 1
      }
    }
  }
  return crc & 0xffff
}

interface ImportPiScreenProps {
  onClose: () => void
  onImportSuccess: () => void
}

export default function ImportPiScreen({ onClose, onImportSuccess }: ImportPiScreenProps) {
  const [activeTab, setActiveTab] = useState<"seed" | "privateKey">("seed")
  const [words, setWords] = useState<string[]>(Array(24).fill(""))
  const [privateKey, setPrivateKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [derivedAddress, setDerivedAddress] = useState<string | null>(null)
  const [isValidSeed, setIsValidSeed] = useState(false)

  useEffect(() => {
    if (activeTab === "seed" && words.every((w) => w.length > 0)) {
      const seedString = words.join(" ")
      tryDeriveAddress(seedString)
    } else {
      setDerivedAddress(null)
      setIsValidSeed(false)
    }
  }, [words, activeTab])

  const handleWordChange = (index: number, value: string) => {
    const newWords = [...words]
    newWords[index] = value.toLowerCase().trim()
    setWords(newWords)
    setDerivedAddress(null)
    setIsValidSeed(false)
  }

  const handlePaste = (e: React.ClipboardEvent, index: number) => {
    e.preventDefault()
    const pastedText = e.clipboardData.getData("text")
    const pastedWords = pastedText
      .trim()
      .split(/\s+/)
      .filter((w) => w.length > 0)

    if (pastedWords.length === 24) {
      setWords(pastedWords.map((w) => w.toLowerCase().trim()))
      tryDeriveAddress(pastedWords.join(" "))
      toast({
        title: "Đã paste 24 từ",
        description: "Seed phrase đã được điền vào tất cả ô",
      })
    } else if (pastedWords.length === 1) {
      handleWordChange(index, pastedWords[0])
    } else {
      const newWords = [...words]
      pastedWords.forEach((word, i) => {
        if (index + i < 24) {
          newWords[index + i] = word.toLowerCase().trim()
        }
      })
      setWords(newWords)
      setDerivedAddress(null)
      setIsValidSeed(false)
    }
  }

  const tryDeriveAddress = (seedString: string) => {
    try {
      if (!bip39.validateMnemonic(seedString)) {
        setDerivedAddress(null)
        setIsValidSeed(false)
        return
      }

      setIsValidSeed(true)

      const seed = bip39.mnemonicToSeedSync(seedString)

      let derivedKey
      try {
        derivedKey = derivePath("m/44'/314159'/0'/0/0", seed.toString("hex"))
      } catch (pathError) {
        console.log("[v0] Standard path failed, trying alternative:", pathError)
        try {
          derivedKey = derivePath("m/44'/314159'/0'/0", seed.toString("hex"))
        } catch (fallbackError) {
          console.log("[v0] Fallback path failed, using direct seed:", fallbackError)
          derivedKey = { key: seed.slice(0, 32) }
        }
      }

      const keypair = nacl.sign.keyPair.fromSeed(derivedKey.key)
      const publicKey = generateStellarAddress(keypair.publicKey)

      setDerivedAddress(publicKey)
      console.log("[v0] Address derived successfully:", publicKey.slice(0, 10) + "...")
    } catch (error) {
      console.error("[v0] Address derivation error:", error)
      setDerivedAddress(null)
      setIsValidSeed(false)
    }
  }

  const isImportEnabled = () => {
    if (activeTab === "seed") {
      const allWordsFilled = words.every((w) => w.trim().length > 0)
      return allWordsFilled
    } else {
      return privateKey.trim().length > 0 && privateKey.trim().startsWith("S")
    }
  }

  const handleImport = async () => {
    if (!isImportEnabled()) {
      toast({
        title: "Chưa đủ thông tin",
        description: "Vui lòng nhập đầy đủ seed phrase hoặc private key",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      if (activeTab === "seed") {
        const seedString = words.join(" ")

        if (!bip39.validateMnemonic(seedString)) {
          toast({
            title: "Seed phrase không hợp lệ",
            description: "Kiểm tra chính tả và thứ tự các từ nhé!",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        let finalAddress = derivedAddress

        if (!finalAddress) {
          try {
            const seed = bip39.mnemonicToSeedSync(seedString)

            let derivedKey
            try {
              derivedKey = derivePath("m/44'/314159'/0'/0/0", seed.toString("hex"))
            } catch (pathError) {
              console.log("[v0] Using fallback derivation")
              derivedKey = derivePath("m/44'/314159'/0'/0", seed.toString("hex"))
            }

            const keypair = nacl.sign.keyPair.fromSeed(derivedKey.key)
            finalAddress = generateStellarAddress(keypair.publicKey)
            setDerivedAddress(finalAddress)
          } catch (deriveError: any) {
            console.error("[v0] Derivation failed:", deriveError)
            toast({
              title: "Lỗi derive key",
              description: "Thử import bằng Private Key (tab bên phải) hoặc liên hệ hỗ trợ",
              variant: "destructive",
            })
            setIsLoading(false)
            return
          }
        }

        try {
          const encryptedMnemonic = simpleEncrypt(seedString, finalAddress.slice(0, 16))
          const saved = saveWalletData(finalAddress, encryptedMnemonic)

          if (!saved) {
            throw new Error("Failed to save wallet data")
          }

          const piWalletData = {
            address: finalAddress,
            balance: "0",
            savedAt: Date.now(),
          }

          // Save to localStorage for persistence
          localStorage.setItem("olivia_pi_wallet", JSON.stringify(piWalletData))

          // Save to sessionStorage for current session (cleared on app close)
          sessionStorage.setItem("olivia_pi_wallet_session", JSON.stringify(piWalletData))
          sessionStorage.setItem("olivia_wallet_imported", "true")

          console.log("[v0] Wallet saved successfully to storage (persistent + session)")

          toast({
            title: "Import ví thành công!",
            description: `Address: ${finalAddress.slice(0, 10)}...${finalAddress.slice(-10)}\nSố dư Pi đang được tải...`,
            duration: 5000,
          })
        } catch (saveError: any) {
          console.error("[v0] Failed to save wallet:", saveError)
          toast({
            title: "Cảnh báo",
            description: "Ví đã import nhưng chưa lưu được. Vui lòng thử lại.",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        setTimeout(() => {
          setIsLoading(false)
          onImportSuccess()
          onClose()
        }, 1000)
      } else if (activeTab === "privateKey") {
        const privKey = privateKey.trim()

        if (!privKey.startsWith("S")) {
          toast({
            title: "Private key không hợp lệ",
            description: "Private key Pi phải bắt đầu bằng chữ S",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        try {
          const mockAddress = "G" + privKey.slice(1, 50)

          const encryptedPrivateKey = simpleEncrypt(privKey, mockAddress.slice(0, 16))
          const saved = saveWalletData(mockAddress, encryptedPrivateKey)

          if (!saved) {
            throw new Error("Failed to save wallet data")
          }

          const piWalletData = {
            address: mockAddress,
            balance: "0",
            savedAt: Date.now(),
          }

          // Save to localStorage for persistence
          localStorage.setItem("olivia_pi_wallet", JSON.stringify(piWalletData))

          // Save to sessionStorage for current session (cleared on app close)
          sessionStorage.setItem("olivia_pi_wallet_session", JSON.stringify(piWalletData))
          sessionStorage.setItem("olivia_wallet_imported", "true")

          toast({
            title: "Import ví thành công!",
            description: "Private key đã được nhập và lưu an toàn",
            duration: 5000,
          })

          setTimeout(() => {
            setIsLoading(false)
            onImportSuccess()
            onClose()
          }, 1000)
        } catch (saveError: any) {
          console.error("[v0] Failed to save private key wallet:", saveError)
          toast({
            title: "Lỗi lưu ví",
            description: "Không thể lưu private key. Vui lòng thử lại.",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }
      }
    } catch (error: any) {
      console.error("[v0] Import error:", error)
      toast({
        title: "Lỗi import",
        description: error?.message || "Seed phrase không hợp lệ hoặc lỗi kết nối, thử lại nhé!",
        variant: "destructive",
      })
      setIsLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-background">
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 px-4 py-4">
        <div className="flex items-center gap-3">
          <Button size="icon" variant="ghost" onClick={onClose} className="text-white hover:bg-purple-700/50">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-white">Import ví Pi</h1>
        </div>
      </div>

      <div className="p-4 space-y-4 overflow-y-auto pb-24" style={{ height: "calc(100vh - 64px)" }}>
        <Alert className="border-red-500 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800 font-medium">
            Chỉ nhập trên thiết bị cá nhân, không chia sẻ seed/private key
          </AlertDescription>
        </Alert>

        <div className="flex gap-2 border-b">
          <button
            onClick={() => setActiveTab("seed")}
            className={`flex-1 py-3 px-4 font-medium transition-colors ${
              activeTab === "seed"
                ? "text-purple-600 border-b-2 border-purple-600"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            Seed Phrase (24 từ)
          </button>
          <button
            onClick={() => setActiveTab("privateKey")}
            className={`flex-1 py-3 px-4 font-medium transition-colors ${
              activeTab === "privateKey"
                ? "text-purple-600 border-b-2 border-purple-600"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            Private Key
          </button>
        </div>

        {activeTab === "seed" ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">💡 Tip: Paste tất cả 24 từ vào bất kỳ ô nào</p>

            <div className="grid grid-cols-4 gap-2">
              {words.map((word, index) => (
                <div key={index} className="space-y-1">
                  <label className="text-xs text-muted-foreground">{index + 1}</label>
                  <Input
                    value={word}
                    onChange={(e) => handleWordChange(index, e.target.value)}
                    onPaste={(e) => handlePaste(e, index)}
                    placeholder={`Từ ${index + 1}`}
                    className="text-sm rounded-lg"
                  />
                </div>
              ))}
            </div>

            {derivedAddress && (
              <div className="mt-6 p-4 bg-purple-50 rounded-lg space-y-4">
                <div className="text-center">
                  <p className="text-sm font-medium text-purple-900 mb-2">Địa chỉ ví Pi của bạn:</p>
                  <div className="flex items-center gap-2 justify-center">
                    <p className="text-xs font-mono text-purple-700 break-all bg-white p-2 rounded flex-1">
                      {derivedAddress}
                    </p>
                    <button
                      onClick={() => {
                        navigator.clipboard
                          .writeText(derivedAddress)
                          .then(() => {
                            toast({
                              title: "Đã copy!",
                              description: "Địa chỉ đã được copy vào clipboard",
                              duration: 2000,
                            })
                          })
                          .catch(() => {
                            const textarea = document.createElement("textarea")
                            textarea.value = derivedAddress
                            textarea.style.position = "fixed"
                            textarea.style.opacity = "0"
                            document.body.appendChild(textarea)
                            textarea.select()
                            document.execCommand("copy")
                            document.body.removeChild(textarea)
                            toast({
                              title: "Đã copy!",
                              description: "Địa chỉ đã được copy vào clipboard",
                              duration: 2000,
                            })
                          })
                      }}
                      className="p-2 hover:bg-purple-100 rounded-lg transition-colors"
                    >
                      <Copy className="w-4 h-4 text-purple-600" />
                    </button>
                  </div>
                </div>

                <div className="flex justify-center">
                  <div className="p-4 bg-white rounded-2xl shadow-sm">
                    <QRCode value={derivedAddress} size={200} fgColor="#7c3aed" level="H" />
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">Nhập private key của ví Pi (bắt đầu với S...)</p>
            <Input
              value={privateKey}
              onChange={(e) => setPrivateKey(e.target.value)}
              placeholder="S..."
              className="font-mono text-sm"
              type="password"
            />
          </div>
        )}

        <Button
          onClick={handleImport}
          disabled={isLoading}
          className="w-full h-12 text-base font-semibold bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 disabled:opacity-50"
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Đang xử lý...</span>
            </div>
          ) : (
            "Import Ví Pi"
          )}
        </Button>
      </div>
    </div>
  )
}
