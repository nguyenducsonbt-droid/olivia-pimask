"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { QRCodeSVG } from "qrcode.react"
import { Copy, Check, Shield, Sparkles } from "lucide-react"
import { Card } from "@/components/ui/card"

interface FiatWithdrawDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const vietnameseBanks = [
  { id: "vnpay", name: "VNPay", logo: "🏦", description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở" },
  { id: "bidv", name: "BIDV", logo: "🏢", description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở" },
  {
    id: "vietcombank",
    name: "Vietcombank",
    logo: "🏛️",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  { id: "momo", name: "Momo", logo: "💳", description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở" },
  {
    id: "techcombank",
    name: "Techcombank",
    logo: "🏦",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  { id: "zalopay", name: "ZaloPay", logo: "💰", description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở" },
  {
    id: "viettelpay",
    name: "ViettelPay",
    logo: "📱",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
]

export function FiatWithdrawDialog({ open, onOpenChange }: FiatWithdrawDialogProps) {
  const [step, setStep] = useState<"kyc-check" | "amount" | "bank" | "qr" | "processing">("kyc-check")
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState<"VND" | "USD">("VND")
  const [selectedBank, setSelectedBank] = useState("")
  const [accountNumber, setAccountNumber] = useState("")
  const [accountName, setAccountName] = useState("")

  const [isKYCVerified, setIsKYCVerified] = useState(false)
  const [isCheckingKYC, setIsCheckingKYC] = useState(true)

  const [withdrawQRData, setWithdrawQRData] = useState("")
  const [withdrawMemo, setWithdrawMemo] = useState("")
  const [copied, setCopied] = useState(false)

  const [piExchangeRate, setPiExchangeRate] = useState(0.2092)
  const [lastUpdated, setLastUpdated] = useState<string>("")
  const [isLoadingRate, setIsLoadingRate] = useState(false)
  const [usdVndRate, setUsdVndRate] = useState(25000)
  const [isLoadingUsdVnd, setIsLoadingUsdVnd] = useState(false)

  const fetchUsdVndRate = async () => {
    try {
      setIsLoadingUsdVnd(true)
      const response = await fetch("https://api.exchangerate-api.com/v4/latest/USD")
      const data = await response.json()

      if (data.rates?.VND) {
        setUsdVndRate(data.rates.VND)
      }
    } catch (error) {
      console.error("[v0] Error fetching USD/VND rate:", error)
      // Fallback to 25,000 if API fails
      setUsdVndRate(25000)
    } finally {
      setIsLoadingUsdVnd(false)
    }
  }

  useEffect(() => {
    if (open) {
      checkKYCStatus()
      fetchPiPrice()
      fetchUsdVndRate()

      // Refresh price every 30 seconds
      const interval = setInterval(() => {
        fetchPiPrice()
        fetchUsdVndRate()
      }, 30000)

      return () => clearInterval(interval)
    }
  }, [open])

  const checkKYCStatus = async () => {
    setIsCheckingKYC(true)
    toast.info("Đang kiểm tra trạng thái KYC...")

    try {
      if (typeof window !== "undefined") {
        const Pi = (window as any).Pi

        // Check cached KYC status first
        const cachedKYC = localStorage.getItem("kyc_completed")
        if (cachedKYC === "true") {
          setIsKYCVerified(true)
          setStep("amount")
          setIsCheckingKYC(false)
          toast.success("✅ Đã xác thực KYC – Sẵn sàng rút tiền")
          return
        }

        // Try to get real KYC status from Pi SDK
        if (Pi?.user?.getKYCStatus) {
          const kycData = await Pi.user.getKYCStatus()
          const verified = kycData?.status === "approved" || kycData?.verified === true
          setIsKYCVerified(verified)
          localStorage.setItem("kyc_completed", verified ? "true" : "false")

          if (verified) {
            setStep("amount")
            toast.success("✅ Đã xác thực KYC – Sẵn sàng rút tiền")
          } else {
            setStep("kyc-check")
            toast.warning("⚠️ Cần hoàn tất KYC trước khi rút tiền")
          }
        } else {
          // Fallback: Use cached value or default to not verified
          setIsKYCVerified(false)
          setStep("kyc-check")
          toast.info("💡 Cần xác thực KYC để rút tiền")
        }
      }
    } catch (error) {
      console.error("[v0] KYC check error:", error)
      setIsKYCVerified(false)
      setStep("kyc-check")
      toast.warning("⚠️ Không thể kiểm tra KYC, vui lòng thử lại")
    } finally {
      setIsCheckingKYC(false)
    }
  }

  const handleDoKYC = async () => {
    try {
      if (typeof window !== "undefined") {
        const Pi = (window as any).Pi

        toast.info("Đang xác thực với Pi Network...")

        if (Pi?.authenticate) {
          const authResult = await Pi.authenticate(["username", "payments"], (payment: any) => {
            console.log("[v0] Pi authentication callback:", payment)
          })

          console.log("[v0] Pi auth result:", authResult)

          // Authentication successful
          toast.success("✅ Xác thực thành công!")

          // Step 2: Check KYC status with authenticated session
          if (Pi?.user?.getKYCStatus) {
            const kycData = await Pi.user.getKYCStatus()
            const verified = kycData?.status === "approved" || kycData?.verified === true

            if (verified) {
              // KYC already completed - proceed to withdrawal demo
              setIsKYCVerified(true)
              localStorage.setItem("kyc_completed", "true")
              setStep("amount")
              toast.success("✅ Rút tiền sẵn sàng - Tài khoản đã KYC")
              return
            } else {
              // KYC not completed - redirect to KYC page (one time only)
              toast.info("Đang mở trang KYC...")

              if (Pi?.navigation?.open) {
                await Pi.navigation.open("kyc", { backToApp: true })
              } else if (Pi?.app?.launchBrowser) {
                Pi.app.launchBrowser("kyc")
              } else {
                window.location.href = "pi://browser/kyc"
              }

              toast.info("Hoàn tất KYC và quay lại để tiếp tục rút tiền")
              return
            }
          } else {
            // SDK not available but auth successful - allow demo withdrawal
            setIsKYCVerified(true)
            localStorage.setItem("kyc_completed", "true")
            setStep("amount")
            toast.success("✅ Rút tiền sẵn sàng - Demo mode (Testnet)")
            return
          }
        } else {
          // Pi SDK not available - show demo mode
          toast.warning("Pi SDK không khả dụng - Chế độ demo")
          setIsKYCVerified(true)
          setStep("amount")
          return
        }
      }
    } catch (error) {
      console.error("[v0] KYC authentication error:", error)

      // Check if error indicates KYC is already complete
      if (error && typeof error === "object" && "message" in error) {
        const errorMsg = (error as any).message?.toLowerCase() || ""
        if (errorMsg.includes("kyc") && errorMsg.includes("complete")) {
          setIsKYCVerified(true)
          localStorage.setItem("kyc_completed", "true")
          setStep("amount")
          toast.success("✅ Rút tiền sẵn sàng - Tài khoản đã KYC")
          return
        }
      }

      toast.error("Không thể xác thực KYC. Vui lòng thử lại.")
    }
  }

  const fetchPiPrice = async () => {
    try {
      setIsLoadingRate(true)
      const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd")
      const data = await response.json()

      if (data["pi-network"]?.usd) {
        const price = data["pi-network"].usd
        setPiExchangeRate(price)

        const now = new Date()
        const timeStr = now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })
        setLastUpdated(timeStr)
      }
    } catch (error) {
      console.error("[v0] Error fetching Pi price:", error)
    } finally {
      setIsLoadingRate(false)
    }
  }

  const calculatePiNeeded = () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (isNaN(numAmount) || numAmount <= 0) return "0.00"

    const usdAmount = currency === "VND" ? numAmount / usdVndRate : numAmount
    return (usdAmount / piExchangeRate).toFixed(2)
  }

  const calculateEquivalentAmount = () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (isNaN(numAmount) || numAmount <= 0) return ""

    if (currency === "VND") {
      // Convert VND to USD
      return (numAmount / usdVndRate).toFixed(2)
    } else {
      // Convert USD to VND
      return (numAmount * usdVndRate).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
  }

  const formatNumber = (value: string) => {
    const cleaned = value.replace(/[^\d.]/g, "")

    const parts = cleaned.split(".")
    if (parts.length > 2) {
      return parts[0] + "." + parts.slice(1).join("")
    }

    if (parts.length === 2) {
      const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",")
      return intPart + "." + parts[1]
    } else {
      return cleaned.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
  }

  const handleNextToBank = () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (!amount || isNaN(numAmount) || numAmount <= 0) {
      toast.error("Vui lòng nhập số tiền hợp lệ")
      return
    }
    setStep("bank")
  }

  const handleGenerateWithdrawQR = () => {
    if (!selectedBank || !accountNumber || !accountName) {
      toast.error("Vui lòng điền đầy đủ thông tin ngân hàng")
      return
    }

    // Generate unique withdrawal memo
    const timestamp = Date.now()
    const memo = `OLIVIA-WD-${timestamp}`
    setWithdrawMemo(memo)

    // Generate QR data with withdrawal info
    const bankName = vietnameseBanks.find((b) => b.id === selectedBank)?.name
    const qrPayload = {
      bank: selectedBank,
      bankName,
      accountNumber,
      accountName,
      amount: Number.parseFloat(amount.replace(/,/g, "")),
      currency,
      memo,
      timestamp,
      type: "withdrawal",
    }

    setWithdrawQRData(JSON.stringify(qrPayload))
    setStep("qr")

    toast.success("QR rút tiền đã được tạo!")
  }

  const handleCopyMemo = async () => {
    try {
      await navigator.clipboard.writeText(withdrawMemo)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast.success("Đã sao chép mã giao dịch!")
    } catch (error) {
      toast.error("Không thể sao chép")
    }
  }

  const resetDialog = () => {
    setStep("kyc-check")
    setAmount("")
    setSelectedBank("")
    setAccountNumber("")
    setAccountName("")
    setWithdrawQRData("")
    setWithdrawMemo("")
    setCopied(false)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
        if (!open) resetDialog()
      }}
    >
      <DialogContent className="max-w-md bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-purple-900 dark:text-purple-100 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            {step === "kyc-check" && "Xác thực KYC"}
            {step === "amount" && "Rút tiền về tài khoản"}
            {step === "bank" && "Chọn ngân hàng để rút"}
            {step === "qr" && "QR rút tiền"}
            {step === "processing" && "Đang xử lý..."}
          </DialogTitle>
        </DialogHeader>

        {/* Step 1: KYC Check */}
        {step === "kyc-check" && (
          <div className="space-y-4">
            {isCheckingKYC ? (
              <div className="py-8 text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
                <p className="text-purple-700 dark:text-purple-300">Đang kiểm tra trạng thái KYC...</p>
              </div>
            ) : (
              <>
                <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-2 border-amber-300 dark:border-amber-700 p-6">
                  <div className="flex items-start gap-4">
                    <Shield className="w-12 h-12 text-amber-600 flex-shrink-0" />
                    <div className="space-y-3">
                      <h3 className="font-bold text-amber-900 dark:text-amber-100 text-lg">Yêu cầu xác thực KYC</h3>
                      <p className="text-sm text-amber-800 dark:text-amber-200">
                        Bạn cần hoàn tất KYC trong Pi Browser trước khi rút VND. Sau khi hoàn tất, quay lại đây để rút
                        tiền khi Pi Mainnet mở full on/off-ramp.
                      </p>
                      <div className="space-y-2 text-xs text-amber-700 dark:text-amber-300">
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                          <span>Xác thực danh tính qua Pi Network</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                          <span>An toàn & bảo mật 100%</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-amber-500 rounded-full" />
                          <span>Chỉ cần làm 1 lần</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                <Button
                  onClick={handleDoKYC}
                  className="w-full h-12 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold"
                >
                  <Shield className="w-5 h-5 mr-2" />
                  Xác thực KYC để rút tiền
                </Button>

                <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg p-4 border border-purple-200 dark:border-purple-700 text-center space-y-2">
                  <p className="text-sm font-semibold text-purple-800 dark:text-purple-200">
                    💡 Sắp hỗ trợ khi Pi Mainnet mở full on/off-ramp
                  </p>
                  <p className="text-xs text-purple-700 dark:text-purple-300">
                    Sau khi hoàn tất KYC, quay lại đây để rút VND – Miễn phí 100%, an toàn qua Pi Network
                  </p>
                </div>
              </>
            )}
          </div>
        )}

        {/* Step 2: Enter amount */}
        {step === "amount" && (
          <div className="space-y-4">
            <DialogDescription className="text-purple-700 dark:text-purple-300">
              Nhập số tiền bạn muốn rút về ngân hàng
            </DialogDescription>

            {/* Currency Selection */}
            <div className="flex gap-2">
              <Button
                onClick={() => setCurrency("VND")}
                variant={currency === "VND" ? "default" : "outline"}
                className={
                  currency === "VND"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                VND (₫)
              </Button>
              <Button
                onClick={() => setCurrency("USD")}
                variant={currency === "USD" ? "default" : "outline"}
                className={
                  currency === "USD"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                USD ($)
              </Button>
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Số tiền rút</label>
              <Input
                type="text"
                placeholder={currency === "VND" ? "100,000" : "10.00"}
                value={amount}
                onChange={(e) => {
                  const formatted = formatNumber(e.target.value)
                  setAmount(formatted)
                }}
                className="h-14 text-lg border-purple-300 focus:border-purple-500"
              />
              {amount && Number.parseFloat(amount.replace(/,/g, "")) > 0 && (
                <p className="text-sm text-purple-600 dark:text-purple-400">
                  ≈ {currency === "VND" ? `$${calculateEquivalentAmount()} USD` : `${calculateEquivalentAmount()} VND`}
                </p>
              )}
            </div>

            {/* Exchange Info */}
            {amount && Number.parseFloat(amount.replace(/,/g, "")) > 0 && (
              <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg p-4 space-y-2 border border-purple-200 dark:border-purple-700">
                <div className="flex justify-between text-sm">
                  <span className="text-purple-700 dark:text-purple-300">Pi cần rút:</span>
                  <span className="font-semibold text-purple-900 dark:text-purple-100">~{calculatePiNeeded()} Pi</span>
                </div>
                <div className="pt-2 border-t border-purple-300 dark:border-purple-600 flex justify-between items-center">
                  <span className="font-bold text-purple-900 dark:text-purple-100">Bạn nhận:</span>
                  <span className="font-bold text-2xl text-purple-900 dark:text-purple-100">
                    {amount} {currency}
                  </span>
                </div>
                <p className="text-xs text-purple-600 dark:text-purple-400 text-center">
                  Miễn phí 100%, an toàn qua Pi Network – Sắp hỗ trợ khi Mainnet mở full on/off-ramp
                </p>
              </div>
            )}

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/40 dark:to-pink-900/40 rounded-lg p-3 border border-purple-200 dark:border-purple-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-purple-900 dark:text-purple-100">Tỷ giá Pi:</span>
                <div className="text-right">
                  {isLoadingRate ? (
                    <span className="text-sm text-purple-600 dark:text-purple-400 animate-pulse">Đang cập nhật...</span>
                  ) : (
                    <>
                      <div className="text-sm font-bold text-purple-900 dark:text-purple-100">
                        1 Pi ≈ ${piExchangeRate.toFixed(4)} USD
                      </div>
                      {lastUpdated && (
                        <div className="text-xs text-purple-600 dark:text-purple-400">cập nhật lúc {lastUpdated}</div>
                      )}
                    </>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-purple-300 dark:border-purple-600">
                <span className="text-sm font-semibold text-purple-900 dark:text-purple-100">Tỷ giá USD/VND:</span>
                <div className="text-right">
                  {isLoadingUsdVnd ? (
                    <span className="text-sm text-purple-600 dark:text-purple-400 animate-pulse">Đang cập nhật...</span>
                  ) : (
                    <div className="text-sm font-bold text-purple-900 dark:text-purple-100">
                      1 USD ≈ {usdVndRate.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} VND
                    </div>
                  )}
                </div>
              </div>
              <p className="text-xs text-purple-600 dark:text-purple-400 text-center pt-1">Tỷ giá cập nhật realtime</p>
            </div>

            <Button
              onClick={handleNextToBank}
              className="w-full bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
            >
              Chọn ngân hàng để rút
            </Button>
          </div>
        )}

        {/* Step 3: Bank selection and account info */}
        {step === "bank" && (
          <div className="space-y-4">
            <DialogDescription className="text-purple-700 dark:text-purple-300">
              Chọn ngân hàng và nhập thông tin tài khoản
            </DialogDescription>

            {/* Bank Selection */}
            <div className="space-y-2">
              <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Chọn ngân hàng</label>
              <div className="grid grid-cols-2 gap-2 max-h-[40vh] overflow-y-auto pr-1">
                {vietnameseBanks.map((bank) => (
                  <button
                    key={bank.id}
                    onClick={() => setSelectedBank(bank.id)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedBank === bank.id
                        ? "border-purple-500 bg-purple-100 dark:bg-purple-900/40"
                        : "border-purple-200 dark:border-purple-700 bg-white dark:bg-purple-900/20"
                    }`}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <span className="text-2xl">{bank.logo}</span>
                      <span className="text-xs font-semibold text-purple-900 dark:text-purple-100">{bank.name}</span>
                    </div>
                  </button>
                ))}
              </div>
              <p className="text-xs text-purple-600 dark:text-purple-400 text-center">
                Hỗ trợ khi ramp mở – Miễn phí 100%
              </p>
            </div>

            <div className="space-y-3">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Số tài khoản</label>
                <Input
                  placeholder="Nhập số tài khoản"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="border-purple-300 focus:border-purple-500"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Tên tài khoản</label>
                <Input
                  placeholder="NGUYEN VAN A"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value.toUpperCase())}
                  className="border-purple-300 focus:border-purple-500"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setStep("amount")}
                variant="outline"
                className="flex-1 border-purple-300 text-purple-700"
              >
                Quay lại
              </Button>
              <Button
                onClick={handleGenerateWithdrawQR}
                className="flex-1 bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
              >
                Tạo QR rút tiền
              </Button>
            </div>
          </div>
        )}

        {/* Step 4: Show QR code for withdrawal */}
        {step === "qr" && withdrawQRData && (
          <div className="space-y-4">
            <Card className="p-6 bg-white dark:bg-purple-900/20 border-2 border-purple-300 dark:border-purple-600">
              <div className="flex justify-center mb-4">
                <div className="bg-white p-4 rounded-xl shadow-lg">
                  <QRCodeSVG value={withdrawQRData} size={200} level="H" fgColor="#9C27B0" includeMargin />
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3">
                  <p className="text-xs text-purple-600 dark:text-purple-400 mb-1">Số tiền rút</p>
                  <p className="text-xl font-bold text-purple-900 dark:text-purple-100">
                    {calculatePiNeeded()} Pi → {amount} {currency}
                  </p>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-xs text-purple-600 dark:text-purple-400 mb-1">Mã giao dịch</p>
                      <p className="text-sm font-mono font-semibold text-purple-900 dark:text-purple-100 break-all">
                        {withdrawMemo}
                      </p>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleCopyMemo}
                      className="ml-2 text-purple-600 hover:text-purple-700 hover:bg-purple-100"
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-600 dark:text-purple-400">Ngân hàng:</span>
                    <span className="font-semibold text-purple-900 dark:text-purple-100">
                      {vietnameseBanks.find((b) => b.id === selectedBank)?.name}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-600 dark:text-purple-400">Số TK:</span>
                    <span className="font-mono text-purple-900 dark:text-purple-100">{accountNumber}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-600 dark:text-purple-400">Tên TK:</span>
                    <span className="font-semibold text-purple-900 dark:text-purple-100">{accountName}</span>
                  </div>
                </div>
              </div>
            </Card>

            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-700">
              <p className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-2">Hướng dẫn rút tiền:</p>
              <ol className="text-xs text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
                <li>Xác nhận thông tin ngân hàng chính xác</li>
                <li>Lưu mã QR hoặc chụp màn hình để tham khảo</li>
                <li>Tiền sẽ được chuyển khi Pi Mainnet mở on/off-ramp</li>
                <li>Thời gian xử lý: 1-3 ngày làm việc</li>
              </ol>
            </div>

            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 border border-green-200 dark:border-green-700 text-center">
              <p className="text-xs font-semibold text-green-800 dark:text-green-200">
                ⚡ Powered by Pi Network On/Off-Ramp
              </p>
              <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                Miễn phí 100%, an toàn qua Pi Network – Tỷ giá cập nhật realtime
              </p>
            </div>

            <Button
              onClick={() => {
                toast.success("Yêu cầu rút tiền đã được ghi nhận!")
                onOpenChange(false)
                resetDialog()
              }}
              className="w-full bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
            >
              Hoàn tất
            </Button>
          </div>
        )}

        {step === "processing" && (
          <div className="py-8 text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-br from-[#9C27B0] to-[#E1BEE7] rounded-full flex items-center justify-center mx-auto animate-pulse">
              <span className="text-4xl">💸</span>
            </div>
            <div>
              <p className="text-lg font-bold text-purple-900 dark:text-purple-100 mb-2">
                Đang xử lý yêu cầu rút tiền...
              </p>
              <p className="text-sm text-purple-700 dark:text-purple-300">Vui lòng chờ trong giây lát</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
