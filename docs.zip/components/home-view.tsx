"use client"

import { useEffect, useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWallet } from "@/hooks/use-wallet"
import { getBalance } from "@/lib/wallet"
import { addNotification } from "@/lib/notifications"
import { ArrowDownLeft, ArrowUpRight, QrCode, Loader2 } from "lucide-react"
import { NetworkSelector } from "./network-selector"
import { SendDialog } from "./send-dialog"
import { ReceiveDialog } from "./receive-dialog"
import { PiWalletConnectDialog } from "./pi-wallet-connect-dialog"
import { QRScannerDialog } from "./qr-scanner-dialog"
import { NetworkQRCard } from "./network-qr-card"
import { RippleButton } from "./ripple-button"
import { useLanguage } from "@/hooks/use-language"
import { useToast } from "@/hooks/use-toast"
import { saveHideBal, loadHideBal } from "@/lib/persistent-storage"
import { triggerHaptic, triggerSuccessFeedback } from "@/lib/haptic"
import { PiPriceCard } from "./pi-price-card"
import { OptionalFeaturesCard } from "./optional-features-card"

type HomeViewProps = {}

export function HomeView() {
  const { address, balance, setBalance, currentNetwork } = useWallet()
  const [showSend, setShowSend] = useState(false)
  const [showReceive, setShowReceive] = useState(false)
  const [showPiWalletConnect, setShowPiWalletConnect] = useState(false)
  const [isPiWalletConnected, setIsPiWalletConnected] = useState(false)
  const [showQRScanner, setShowQRScanner] = useState(false)
  const [scannedAddress, setScannedAddress] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isPiAppsLoading, setIsPiAppsLoading] = useState(false)
  const [isPiWalletOpening, setIsPiWalletOpening] = useState(false)
  const [effectsEnabled, setEffectsEnabled] = useState(true)
  const [isBalanceHidden, setIsBalanceHidden] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isConnectingPi, setIsConnectingPi] = useState(false)
  const [isLoadingPiBalance, setIsLoadingPiBalance] = useState(false)
  const [piUser, setPiUser] = useState<{ username: string; uid: string } | null>(null)
  const [isPiConnected, setIsPiConnected] = useState(false)
  const { t } = useLanguage()
  const { toast } = useToast()

  const [piPriceUsd, setPiPriceUsd] = useState(0)
  const [priceChange24h, setPriceChange24h] = useState(0)
  const [totalBalance, setTotalBalance] = useState(0)
  const [totalBalanceUsd, setTotalBalanceUsd] = useState(0)

  const isMountedRef = useRef(true)

  useEffect(() => {
    isMountedRef.current = true
    return () => {
      isMountedRef.current = false
    }
  }, [])

  useEffect(() => {
    try {
      const savedHiddenState = loadHideBal()
      if (isMountedRef.current) {
        setIsBalanceHidden(savedHiddenState)
      }
    } catch (error) {
      console.error("Failed to load balance visibility state:", error)
      setIsBalanceHidden(false)
    }
  }, [])

  useEffect(() => {
    async function fetchBalance() {
      if (address && currentNetwork) {
        setIsLoading(true)
        const bal = await getBalance(address, currentNetwork.rpcUrl)
        if (isMountedRef.current) {
          setBalance(bal)
          setTotalBalance(Number.parseFloat(bal))
          setTotalBalanceUsd(Number.parseFloat(bal) * piPriceUsd)
          setIsLoading(false)
        }
      }
    }
    fetchBalance()
  }, [address, currentNetwork, setBalance, piPriceUsd])

  useEffect(() => {
    const checkPiWalletConnection = () => {
      if (typeof window !== "undefined" && (window as any).Pi) {
        const connected = localStorage.getItem("pi_wallet_connected") === "true"
        setIsPiWalletConnected(connected)
      }
    }
    checkPiWalletConnection()
  }, [])

  useEffect(() => {
    const effects = localStorage.getItem("visual_effects")
    setEffectsEnabled(effects !== "false")
  }, [])

  const playClickSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.value = 800
      oscillator.type = "sine"

      gainNode.gain.setValueAtTime(0.5, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.1)
    } catch (error) {
      // Silent fail for audio
    }
  }

  const handleConnectPiWallet = async () => {
    try {
      if (typeof window !== "undefined") {
        if ((window as any).Pi?.authenticate) {
          const authResult = await (window as any).Pi.authenticate(["username", "payments", "wallet_address"], () => {})

          if (authResult) {
            localStorage.setItem("pi_wallet_connected", "true")
            setIsPiWalletConnected(true)

            toast({
              title: "Đã kết nối siêu ví !",
              description: "Bấm lại nút để mở ví xem balance Mainnet nhé 🎉❤️",
            })

            addNotification(t.dashboard.piWalletConnected, t.dashboard.paymentReady, "success")

            if (address && currentNetwork) {
              const bal = await getBalance(address, currentNetwork.rpcUrl)
              setBalance(bal)
              setTotalBalance(Number.parseFloat(bal))
              setTotalBalanceUsd(Number.parseFloat(bal) * piPriceUsd)
            }

            return
          }
        }
        if ((window as any).Pi?.app?.launchBrowser) {
          ;(window as any).Pi.app.launchBrowser("wallet.pi")
        } else {
          window.location.href = "pi://browser/wallet"
        }
      }
    } catch (error) {
      console.error("Pi Wallet connection error:", error)
      toast({
        title: t.dashboard.walletConnectionFailed,
        description: "Vui lòng thử lại hoặc mở Pi Browser thủ công",
        variant: "destructive",
      })
    }
  }

  const handleLaunchPiApps = async () => {
    if (!isPiWalletConnected) {
      setShowPiWalletConnect(true)
      return
    }

    setIsPiAppsLoading(true)
    triggerHaptic("medium")
    playClickSound()

    try {
      toast({
        title: "Đang mở Explore the Ecosystem! 🚀",
        description: "Bấm Back để quay về Olivia PiMask",
        duration: 2000,
      })

      if (typeof window !== "undefined") {
        localStorage.setItem("pi_session_active", "true")
        localStorage.setItem("pi_return_url", window.location.href)
        localStorage.setItem("pi_apps_timestamp", Date.now().toString())
        sessionStorage.setItem("olivia_navigating_away", "true")
        sessionStorage.setItem("olivia_scroll_position", window.scrollY.toString())

        window.location.href = "https://ecosystem.pinet.com"

        setTimeout(() => {
          if (isMountedRef.current) {
            setIsPiAppsLoading(false)
          }
        }, 300) // Reduced from 500ms
      }
    } catch (error) {
      console.error("Pi Apps launch error:", error)
      if (isMountedRef.current) {
        setIsPiAppsLoading(false)
        sessionStorage.removeItem("olivia_navigating_away")
      }

      toast({
        title: "Không thể mở Pi Ecosystem",
        description: "Vui lòng mở Pi Browser và truy cập ecosystem.pinet.com",
        variant: "destructive",
      })
    }
  }

  const handleRefresh = async () => {
    if (isRefreshing || !isMountedRef.current) return

    setIsRefreshing(true)
    triggerHaptic("light")
    playClickSound()

    try {
      if (typeof window !== "undefined" && (window as any).Pi) {
        try {
          const Pi = (window as any).Pi
          const balanceResult = await Pi.getBalance()

          let piBalance = null
          if (balanceResult && typeof balanceResult === "object" && "balance" in balanceResult) {
            piBalance = balanceResult.balance
          } else if (typeof balanceResult === "number") {
            piBalance = balanceResult
          }

          if (piBalance !== null && isMountedRef.current) {
            setBalance(piBalance.toString())
            setTotalBalance(Number.parseFloat(piBalance.toString()))
            setTotalBalanceUsd(Number.parseFloat(piBalance.toString()) * piPriceUsd)

            toast({
              title: "✓ Đã cập nhật số dư",
              description: `Balance Pi Mainnet: ${piBalance} π`,
              duration: 2000,
            })

            setIsRefreshing(false)
            return
          }
        } catch (error) {
          console.error("Failed to refresh Pi balance:", error)
        }
      }

      if (address && currentNetwork && isMountedRef.current) {
        const bal = await getBalance(address, currentNetwork.rpcUrl)
        setBalance(bal)
        setTotalBalance(Number.parseFloat(bal))
        setTotalBalanceUsd(Number.parseFloat(bal) * piPriceUsd)

        triggerSuccessFeedback()

        toast({
          title: "✓ Đã cập nhật số dư",
          description: "Số dư đã được làm mới",
          duration: 2000,
        })
      }
    } finally {
      if (isMountedRef.current) {
        setIsRefreshing(false)
      }
    }
  }

  const handleConnectPiBrowser = async () => {
    if (isConnectingPi || !isMountedRef.current) return

    setIsConnectingPi(true)
    triggerHaptic("medium")
    playClickSound()

    try {
      if (typeof window !== "undefined" && (window as any).Pi) {
        console.log("[v0] Authenticating with Pi Browser...")

        const authResult = await (window as any).Pi.authenticate(
          ["username", "payments", "wallet_address"],
          (payment: any) => {
            console.log("[v0] Incomplete payment found:", payment)
          },
        )

        console.log("[v0] Pi authentication successful:", authResult.user.username)

        if (isMountedRef.current) {
          setPiUser(authResult.user)
          setIsPiConnected(true)

          try {
            const balanceResult = await (window as any).Pi.getBalance()

            let piBalance = null
            if (balanceResult && typeof balanceResult === "object" && "balance" in balanceResult) {
              piBalance = balanceResult.balance
            } else if (typeof balanceResult === "number") {
              piBalance = balanceResult
            } else if (balanceResult && balanceResult.amount) {
              piBalance = balanceResult.amount
            }

            if (piBalance !== null && isMountedRef.current) {
              setBalance(piBalance.toString())
              setTotalBalance(Number.parseFloat(piBalance.toString()))
              setTotalBalanceUsd(Number.parseFloat(piBalance.toString()) * piPriceUsd)

              toast({
                title: "Kết nối thành công!",
                description: `Số dư Pi: ${Number.parseFloat(piBalance.toString()).toFixed(4)} π`,
                duration: 4000,
              })
            }
          } catch (balanceError) {
            console.error("[v0] Failed to fetch Pi balance:", balanceError)
            toast({
              title: "Đã kết nối Pi Browser",
              description: "Nhưng không thể lấy số dư. Vui lòng làm mới thủ công.",
              variant: "destructive",
              duration: 4000,
            })
          }
        }
      } else {
        throw new Error("Pi SDK không khả dụng")
      }
    } catch (error: any) {
      console.error("[v0] Pi Browser authentication error:", error)

      if (error.message && error.message.includes("user_cancelled")) {
        toast({
          title: "Đã hủy xác thực",
          description: "Bạn đã từ chối xác thực với Pi Network.",
        })
      } else if (error.message && error.message.includes("không khả dụng")) {
        toast({
          title: "Pi SDK không khả dụng",
          description: "Vui lòng mở app trong Pi Browser để sử dụng chức năng này.",
          variant: "destructive",
          duration: 5000,
        })
      } else {
        toast({
          title: "Không thể sync số dư",
          description: "Thử kết nối Pi Browser hoặc kiểm tra kết nối mạng.",
          variant: "destructive",
          duration: 4000,
        })
      }
    } finally {
      if (isMountedRef.current) {
        setIsConnectingPi(false)
      }
    }
  }

  const handleToggleBalanceVisibility = () => {
    const newHidden = !isBalanceHidden
    setIsBalanceHidden(newHidden)
    saveHideBal(newHidden)
  }

  const handleOpenPiWallet = async () => {
    if (isPiConnected && piUser) {
      setIsPiWalletOpening(true)
      triggerHaptic("medium")
      playClickSound()

      try {
        toast({
          title: "Đang mở Explore the Ecosystem! 🚀",
          description: "Truy cập Pi Ecosystem với staking directory",
          duration: 2000,
        })

        if (typeof window !== "undefined") {
          window.location.href = "https://ecosystem.pinet.com"
        }
      } catch (error) {
        console.error("[v0] Navigate to ecosystem.pinet.com failed:", error)
      }

      setTimeout(() => setIsPiWalletOpening(false), 2000)
      return
    }

    setIsPiWalletOpening(true)
    triggerHaptic("medium")
    playClickSound()

    try {
      if (typeof window !== "undefined" && (window as any).Pi?.authenticate) {
        const authResult = await (window as any).Pi.authenticate(["username", "payments", "wallet_address"], () => {})

        if (authResult && authResult.user) {
          localStorage.setItem("pi_wallet_connected", "true")
          localStorage.setItem("pi_user_data", JSON.stringify(authResult.user))
          setIsPiConnected(true)
          setPiUser(authResult.user)

          toast({
            title: "Đã kết nối siêu ví !",
            description: "Bấm lại nút để mở Explore the Ecosystem 🎉❤️",
          })

          addNotification("Đã kết nối Pi Wallet", `Xin chào ${authResult.user.username}! Ví đã sẵn sàng`, "success")

          setIsPiWalletOpening(false)
          return
        }
      }

      setIsPiWalletOpening(false)
      toast({
        title: "Mở Pi Ecosystem",
        description: "Mở https://ecosystem.pinet.com trong Pi Browser để khám phá staking directory 💜",
      })
    } catch (error) {
      console.error("[v0] Pi Wallet connection error:", error)
      setIsPiWalletOpening(false)

      toast({
        title: "Mở Pi Ecosystem",
        description: "Mở https://ecosystem.pinet.com trong Pi Browser để khám phá staking directory 💜",
      })
    }
  }

  useEffect(() => {
    const handlePiSessionChange = async (event: CustomEvent) => {
      if (event.detail?.user) {
        const user = event.detail.user
        setPiUser(user)
        setIsPiConnected(true)

        if (event.detail?.balance) {
          const piBalance = event.detail.balance
          setBalance(piBalance.toString())
          setTotalBalance(Number.parseFloat(piBalance.toString()))
          setTotalBalanceUsd(Number.parseFloat(piBalance.toString()) * piPriceUsd)
        } else {
          try {
            if ((window as any).Pi?.getBalance) {
              const balanceResult = await (window as any).Pi.getBalance()
              let balance = null
              if (balanceResult && typeof balanceResult === "object" && "balance" in balanceResult) {
                balance = balanceResult.balance
              } else if (typeof balanceResult === "number") {
                balance = balanceResult
              }

              if (balance !== null && isMountedRef.current) {
                setBalance(balance.toString())
                setTotalBalance(Number.parseFloat(balance.toString()))
                setTotalBalanceUsd(Number.parseFloat(balance.toString()) * piPriceUsd)
              }
            }
          } catch (error) {
            console.error("[v0] Failed to fetch Pi balance:", error)
          }
        }
      }
    }

    window.addEventListener("olivia-pi-session-changed", handlePiSessionChange as EventListener)

    return () => {
      window.removeEventListener("olivia-pi-session-changed", handlePiSessionChange as EventListener)
    }
  }, [piPriceUsd, setBalance])

  useEffect(() => {
    const checkSavedPiConnection = () => {
      if (typeof window !== "undefined") {
        const connected = localStorage.getItem("pi_wallet_connected") === "true"
        const savedUser = localStorage.getItem("pi_user_data")

        if (connected && savedUser) {
          try {
            const userData = JSON.parse(savedUser)
            setIsPiConnected(true)
            setPiUser(userData)
          } catch (error) {
            console.error("[v0] Parse saved user data failed:", error)
          }
        }
      }
    }
    checkSavedPiConnection()
  }, [])

  useEffect(() => {
    const loadSavedPiSession = async () => {
      try {
        const { loadPiSession } = await import("@/lib/persistent-storage")
        const session = loadPiSession()

        if (session && session.user) {
          setPiUser(session.user)
          setIsPiConnected(true)
        }
      } catch (error) {
        console.error("Error loading Pi session:", error)
      }
    }

    loadSavedPiSession()
  }, [])

  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === "visible" && isMountedRef.current) {
        console.log("[v0] Home view visible - clearing states and refreshing")

        setIsPiAppsLoading(false)
        setIsLoading(false)
        setIsPiWalletOpening(false)

        sessionStorage.removeItem("olivia_navigating_away")

        const savedScroll = sessionStorage.getItem("olivia_scroll_position")
        if (savedScroll) {
          window.scrollTo(0, Number.parseInt(savedScroll, 10))
          sessionStorage.removeItem("olivia_scroll_position")
        }

        if (address && currentNetwork) {
          setIsRefreshing(true)
          try {
            const bal = await getBalance(address, currentNetwork.rpcUrl)
            if (isMountedRef.current) {
              setBalance(bal)
              setTotalBalance(Number.parseFloat(bal))
              setTotalBalanceUsd(Number.parseFloat(bal) * piPriceUsd)
              triggerSuccessFeedback()

              toast({
                title: "✓ Chào mừng trở lại!",
                description: "Số dư đã được cập nhật",
                duration: 2000,
              })
            }
          } catch (error) {
            console.error("Failed to refresh balance:", error)
          } finally {
            if (isMountedRef.current) {
              setIsRefreshing(false)
            }
          }
        }
      }
    }

    const handleFocus = async () => {
      if (document.visibilityState === "visible" && isMountedRef.current) {
        console.log("[v0] Home view focused")
        setIsPiAppsLoading(false)
        setIsLoading(false)
        sessionStorage.removeItem("olivia_navigating_away")
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    window.addEventListener("focus", handleFocus)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
      window.removeEventListener("focus", handleFocus)
    }
  }, [address, currentNetwork, setBalance, piPriceUsd, toast])

  useEffect(() => {
    const handlePiBalanceUpdate = (event: any) => {
      const piBalance = event.detail?.balance
      if (piBalance && isMountedRef.current) {
        setBalance(piBalance.toString())
        setTotalBalance(Number.parseFloat(piBalance.toString()))
        setTotalBalanceUsd(Number.parseFloat(piBalance.toString()) * piPriceUsd)
      }
    }

    window.addEventListener("olivia-pi-balance-updated", handlePiBalanceUpdate)
    return () => {
      window.removeEventListener("olivia-pi-balance-updated", handlePiBalanceUpdate)
    }
  }, [piPriceUsd])

  const displayAddress = address

  return (
    <div className="space-y-6 pb-24">
      <PiPriceCard
        onPriceUpdate={(price, change) => {
          setPiPriceUsd(price)
          setPriceChange24h(change)
        }}
      />

      <Card className="shadow-lg border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold text-purple-700 dark:text-purple-300">
              {t.dashboard.totalBalance}
            </CardTitle>
            <div className="flex items-center gap-2">
              <button
                onClick={handleToggleBalanceVisibility}
                className="p-2 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/20 transition-colors"
                aria-label={isBalanceHidden ? "Hiện số dư" : "Ẩn số dư"}
              >
                {!isBalanceHidden ? (
                  <svg className="w-5 h-5 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                ) : (
                  <svg className="w-5 h-5 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                    />
                  </svg>
                )}
              </button>
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="p-2 rounded-lg hover:bg-purple-100 transition-colors disabled:opacity-50"
                aria-label="Làm mới dữ liệu"
              >
                <svg
                  className={`w-5 h-5 text-purple-500 ${isRefreshing ? "animate-spin" : ""}`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                  />
                </svg>
              </button>
              <NetworkSelector />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center space-y-1">
            <div className="text-4xl font-bold text-purple-600 dark:text-purple-400">
              {isBalanceHidden ? "••••••" : totalBalance.toFixed(2)}
            </div>
            <div className="text-base text-muted-foreground">
              {isBalanceHidden ? "••••••" : `≈ $${totalBalanceUsd.toFixed(2)}`}
            </div>
            {address && !isPiConnected && (
              <button
                onClick={handleConnectPiBrowser}
                disabled={isConnectingPi}
                className="mt-3 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white text-sm font-semibold rounded-full shadow-md hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 mx-auto"
              >
                {isConnectingPi ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Đang kết nối...
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                      />
                    </svg>
                    Sync số dư từ Pi Browser
                  </>
                )}
              </button>
            )}
            {isPiConnected && piUser && (
              <div className="mt-2 text-sm text-green-600 dark:text-green-400 flex items-center justify-center gap-1">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                    clipRule="evenodd"
                  />
                </svg>
                Đã kết nối: {piUser.username}
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-4 pt-2">
            <RippleButton
              onClick={() => {
                triggerHaptic("light")
                playClickSound()
                setShowSend(true)
              }}
              className="flex flex-col items-center justify-center gap-3 px-8 py-6 bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-2xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-[1.02] active:scale-95"
            >
              <ArrowUpRight className="w-8 h-8" />
              <span className="text-base font-bold leading-none">{t.dashboard.send}</span>
            </RippleButton>
            <RippleButton
              onClick={() => {
                triggerHaptic("light")
                playClickSound()
                setShowReceive(true)
              }}
              className="flex flex-col items-center justify-center gap-3 px-8 py-6 bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-2xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-[1.02] active:scale-95"
            >
              <ArrowDownLeft className="w-8 h-8" />
              <span className="text-base font-bold leading-none">{t.dashboard.receive}</span>
            </RippleButton>
            <RippleButton
              onClick={() => {
                triggerHaptic("light")
                playClickSound()
                setShowQRScanner(true)
              }}
              className="flex flex-col items-center justify-center gap-3 px-8 py-6 bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-2xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-[1.02] active:scale-95"
            >
              <QrCode className="w-8 h-8" />
              <span className="text-base font-bold leading-none">{t.dashboard.scan}</span>
            </RippleButton>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-3">{/* ... existing buttons ... */}</div>

      <RippleButton
        onClick={handleLaunchPiApps}
        disabled={isPiAppsLoading}
        className="w-full h-16 text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all relative overflow-hidden rounded-3xl disabled:opacity-70 pi-apps-shimmer"
        style={{
          background: "linear-gradient(135deg, #7B1FA2 0%, #E91E63 100%)",
          fontSize: "18px",
        }}
      >
        {isPiAppsLoading ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Đang mở Pi Apps...
          </>
        ) : (
          <>
            <span className="mr-2 inline-block">⛏️</span>
            {t.dashboard.accessPiApps}
          </>
        )}
      </RippleButton>

      <Card className="shadow-lg border-2 border-purple-200 bg-white dark:bg-gray-900">
        <CardContent className="p-6">
          <OptionalFeaturesCard />
        </CardContent>
      </Card>

      <NetworkQRCard />

      {showSend && (
        <SendDialog
          open={showSend}
          onOpenChange={setShowSend}
          initialAddress={scannedAddress}
          activeWalletType="olivia" // Default value
          senderAddress={displayAddress}
        />
      )}
      {showReceive && (
        <ReceiveDialog
          open={showReceive}
          onOpenChange={setShowReceive}
          activeWalletType="olivia" // Default value
          receiveAddress={displayAddress}
        />
      )}
      {showPiWalletConnect && (
        <PiWalletConnectDialog open={showPiWalletConnect} onOpenChange={setShowPiWalletConnect} />
      )}
      {showQRScanner && (
        <QRScannerDialog
          open={showQRScanner}
          onOpenChange={setShowQRScanner}
          onScanSuccess={(address) => {
            setScannedAddress(address)
            setShowSend(true)
          }}
        />
      )}
    </div>
  )
}
