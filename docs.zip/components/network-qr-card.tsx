"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWallet } from "@/hooks/use-wallet"
import { useLanguage } from "@/hooks/use-language"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"
import QRCode from "qrcode"

interface NetworkQRCardProps {
  className?: string
}

export function NetworkQRCard({ className }: NetworkQRCardProps) {
  const { address, currentNetwork } = useWallet()
  const { t } = useLanguage()
  const { toast } = useToast()
  const [qrDataUrl, setQrDataUrl] = useState<string>("")
  const [isLoading, setIsLoading] = useState(true)
  const [isFullySupported, setIsFullySupported] = useState(false)

  useEffect(() => {
    const generateQR = async () => {
      if (!address) return

      setIsLoading(true)

      try {
        const fullySupported =
          currentNetwork.id === "pi-mainnet" ||
          currentNetwork.id === "pi-testnet" ||
          currentNetwork.id === "bsc-testnet"
        setIsFullySupported(fullySupported)

        let qrAddress = address

        // For Pi networks, try to get Pi-specific QR format
        if (typeof window !== "undefined" && (window as any).Pi?.wallet?.getQRCode) {
          try {
            const piQR = await (window as any).Pi.wallet.getQRCode({
              network: currentNetwork.chainId,
            })
            qrAddress = piQR
          } catch (error) {
            console.log("[v0] Using standard address for QR")
          }
        }

        // Generate QR code
        const dataUrl = await QRCode.toDataURL(qrAddress, {
          width: 220,
          margin: 2,
          color: {
            dark: "#000000",
            light: "#FFFFFF",
          },
          errorCorrectionLevel: "H",
        })

        setQrDataUrl(dataUrl)

        if (currentNetwork.id.includes("testnet")) {
          toast({
            title: "Testnet – Swap Pi test miễn phí",
            description: `Đang sử dụng ${currentNetwork.name} (Chain ID: ${currentNetwork.chainId})`,
            duration: 3000,
          })
        } else if (!fullySupported) {
          toast({
            title: t.dashboard.comingSoon,
            description: t.dashboard.qrFallbackMessage,
            duration: 2000,
          })
        }
      } catch (error) {
        console.error("[v0] QR generation error:", error)
      } finally {
        setIsLoading(false)
      }
    }

    generateQR()
  }, [address, currentNetwork])

  const getNetworkLogo = (networkId: string) => {
    const logos: Record<string, string> = {
      "pi-mainnet": "⛏️",
      "pi-testnet": "⛏️",
      "bsc-testnet": "🔶",
      polygon: "🟣",
      ethereum: "💎",
      solana: "🌊",
      bitcoin: "₿",
      arbitrum: "🔵",
      optimism: "🔴",
      base: "🔷",
      linea: "⚡",
    }
    return logos[networkId] || "🌐"
  }

  if (!address) return null

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium text-center">{t.dashboard.qrCodeTitle}</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center space-y-4">
        {/* QR Code Container */}
        <div
          className="relative p-4 bg-white rounded-xl transition-all duration-500"
          style={{
            border: "3px solid #8B5CF6",
            boxShadow: "0 4px 20px rgba(139, 92, 246, 0.2)",
          }}
        >
          {isLoading ? (
            <div className="w-[220px] h-[220px] flex items-center justify-center">
              <Loader2
                className="w-12 h-12 animate-spin"
                style={{
                  color: "#8B5CF6",
                  animation: "spin 1s linear infinite, pulse 2s ease-in-out infinite",
                }}
              />
            </div>
          ) : (
            <img
              src={qrDataUrl || "/placeholder.svg"}
              alt="Wallet QR Code"
              className="w-[220px] h-[220px]"
              style={{
                animation: "fadeIn 0.5s ease-in",
              }}
            />
          )}

          {/* Loading pulse animation */}
          {isLoading && (
            <div
              className="absolute inset-0 rounded-xl"
              style={{
                animation: "pulse-border 2s ease-in-out infinite",
                border: "2px solid rgba(139, 92, 246, 0.5)",
              }}
            />
          )}
        </div>

        {/* Network Badge with Logo */}
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300"
          style={{
            background: "linear-gradient(135deg, #8B5CF6 0%, #00FF9D 100%)",
            color: "white",
            fontSize: "14px",
            fontWeight: 600,
          }}
        >
          <span className="text-lg">{getNetworkLogo(currentNetwork.id)}</span>
          <span>{currentNetwork.name}</span>
        </div>

        <div
          className="text-xs px-3 py-1 rounded-full font-semibold transition-all duration-300"
          style={{
            background: "rgba(139, 92, 246, 0.1)",
            color: "#8B5CF6",
            border: "1px solid rgba(139, 92, 246, 0.3)",
          }}
        >
          Chain ID: {currentNetwork.chainId}
        </div>

        {/* Coming Soon Badge for unsupported networks */}
        {!isFullySupported && (
          <div
            className="text-xs px-3 py-1 rounded-full"
            style={{
              background: "rgba(139, 92, 246, 0.1)",
              color: "#8B5CF6",
              border: "1px solid rgba(139, 92, 246, 0.3)",
            }}
          >
            {t.dashboard.comingSoon}
          </div>
        )}
      </CardContent>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes pulse-border {
          0%,
          100% {
            opacity: 0.5;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.02);
          }
        }
      `}</style>
    </Card>
  )
}
