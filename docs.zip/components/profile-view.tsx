"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/use-wallet"
import {
  Wallet,
  Users,
  Star,
  Info,
  Mail,
  FileText,
  ChevronRight,
  Pencil,
  MessageSquare,
  Bug,
  HelpCircle,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { AvatarUploadDialog } from "./avatar-upload-dialog"
import { FAQDialog } from "./faq-dialog"
import { ReportBugDialog } from "./report-bug-dialog"
import { WalletNameEditDialog } from "./wallet-name-edit-dialog"
import { loadAvatar, saveAvatar, loadWalletName, saveWalletName } from "@/lib/persistent-storage"
import { PiNetworkStatus } from "./pi-network-status"
import { triggerHaptic } from "@/lib/haptic"

const WALLET_NAME_KEY = "oliviaWalletName"
const DEFAULT_WALLET_NAME = "Olivia PiMask"

export function ProfileView() {
  const { address } = useWallet()
  const { toast } = useToast()
  const { t } = useLanguage()
  const [showAvatarDialog, setShowAvatarDialog] = useState(false)
  const [walletName, setWalletName] = useState<string>(() => loadWalletName())
  const [showFAQ, setShowFAQ] = useState(false)
  const [showReportBug, setShowReportBug] = useState(false)
  const [customAvatar, setCustomAvatar] = useState<string | null>(null)
  const [isPiConnected, setIsPiConnected] = useState(false)
  const [showWalletNameEdit, setShowWalletNameEdit] = useState(false)

  useEffect(() => {
    const loadInitialAvatar = async () => {
      const avatar = await loadAvatar()
      setCustomAvatar(avatar)
    }
    loadInitialAvatar()
  }, [])

  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === "visible") {
        const name = loadWalletName()
        if (name !== walletName) {
          setWalletName(name)
        }

        const avatar = await loadAvatar()
        if (avatar !== customAvatar) {
          setCustomAvatar(avatar)
        }
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange)
  }, [walletName, customAvatar])

  useEffect(() => {
    let isMounted = true

    const handleAvatarChange = async () => {
      if (isMounted) {
        const avatar = await loadAvatar()
        setCustomAvatar(avatar)
      }
    }

    const handleWalletNameChange = () => {
      if (isMounted) {
        const name = loadWalletName()
        setWalletName(name)
      }
    }

    window.addEventListener("olivia-avatar-changed", handleAvatarChange)
    window.addEventListener("olivia-wallet-name-changed", handleWalletNameChange)

    return () => {
      isMounted = false
      window.removeEventListener("olivia-avatar-changed", handleAvatarChange)
      window.removeEventListener("olivia-wallet-name-changed", handleWalletNameChange)
    }
  }, [])

  useEffect(() => {
    const checkPiConnection = () => {
      try {
        const { loadPiSession } = require("@/lib/persistent-storage")
        const session = loadPiSession()
        setIsPiConnected(!!session && !!session.user)
      } catch (error) {
        console.error("Failed to check Pi connection:", error)
      }
    }

    checkPiConnection()

    const handlePiSessionChange = () => {
      checkPiConnection()
    }

    window.addEventListener("olivia-pi-session-changed", handlePiSessionChange)

    return () => {
      window.removeEventListener("olivia-pi-session-changed", handlePiSessionChange)
    }
  }, [])

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 10)}...${addr.slice(-8)}`
  }

  const handleInviteFriends = async () => {
    triggerHaptic("medium")

    const shareTitle = "Thử ví Pi siêu đẹp Olivia PiMask đi!"
    const shareText = `Ví Web3 siêu nhẹ, đẹp như Olivia 💜

Kết nối Pi Mainnet an toàn, gửi/nhận/quét QR mượt mà, truy cập Pi Apps dễ dàng.

Link tải: https://oliviapimask.com

#PiNetwork #OliviaPiMask #PiWallet 🚀`

    const shareUrl = "https://oliviapimask.com"

    // Check if Web Share API is available (works on mobile browsers and Pi Browser)
    if (navigator.share) {
      try {
        const shareData: ShareData = {
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        }

        // Try to include the logo image
        try {
          const response = await fetch("/apple-icon.png")
          if (response.ok) {
            const blob = await response.blob()
            const file = new File([blob], "olivia-pimask-logo.png", { type: "image/png" })

            // Check if files can be shared
            if (navigator.canShare && navigator.canShare({ files: [file] })) {
              shareData.files = [file]
            }
          }
        } catch (imageError) {
          // If image fetch fails, just share text - no need to show error
          console.log("[v0] Could not attach logo to share:", imageError)
        }

        await navigator.share(shareData)

        // Success feedback
        triggerHaptic("success")
        toast({
          title: "Cảm ơn bạn! 💜",
          description: "Chia sẻ Olivia PiMask giúp cộng đồng Pi lớn mạnh hơn!",
        })
      } catch (error: any) {
        // User cancelled share or error occurred
        if (error.name !== "AbortError") {
          console.error("[v0] Share failed:", error)
          // Show fallback copy option
          fallbackCopyToClipboard(shareTitle, shareText, shareUrl)
        }
      }
    } else {
      // Fallback for browsers without share API
      fallbackCopyToClipboard(shareTitle, shareText, shareUrl)
    }
  }

  const fallbackCopyToClipboard = async (title: string, text: string, url: string) => {
    const fullShareText = `${title}\n\n${text}\n\n${url}`

    try {
      await navigator.clipboard.writeText(fullShareText)
      triggerHaptic("success")
      toast({
        title: "Đã sao chép! 📋",
        description: "Link mời bạn bè đã được sao chép. Paste để chia sẻ trên X, Facebook, Telegram, Zalo...",
      })
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement("textarea")
      textArea.value = fullShareText
      textArea.style.position = "fixed"
      textArea.style.left = "-999999px"
      textArea.style.opacity = "0"
      document.body.appendChild(textArea)
      textArea.focus()
      textArea.select()

      try {
        const successful = document.execCommand("copy")
        if (successful) {
          triggerHaptic("success")
          toast({
            title: "Đã sao chép! 📋",
            description: "Link mời bạn bè đã được sao chép. Paste để chia sẻ!",
          })
        } else {
          throw new Error("Copy command failed")
        }
      } catch (err) {
        console.error("[v0] Clipboard fallback failed:", err)
        triggerHaptic("error")
        toast({
          title: "Lỗi sao chép",
          description: "Vui lòng thử lại hoặc share thủ công",
          variant: "destructive",
        })
      } finally {
        document.body.removeChild(textArea)
      }
    }
  }

  const handleRateApp = () => {
    triggerHaptic("light")
    toast({
      title: "Cảm ơn bạn!",
      description: "Tính năng đánh giá sẽ khả dụng khi app publish lên store",
    })
  }

  const handleContactSupport = () => {
    triggerHaptic("light")
    const supportLinks = [
      { name: "Telegram", url: "https://t.me/oliviapimask_support" },
      { name: "Discord", url: "https://discord.gg/oliviapimask" },
    ]

    window.open(supportLinks[0].url, "_blank")

    toast({
      title: "Mở kênh hỗ trợ",
      description: "Đang chuyển đến Telegram support channel",
    })
  }

  const handleTerms = () => {
    toast({
      title: "Điều khoản sử dụng",
      description: "Tính năng này sẽ có trong bản cập nhật sau",
    })
  }

  const handleAvatarUpdate = async (newAvatar: string | null) => {
    await saveAvatar(newAvatar)
    setCustomAvatar(newAvatar)
  }

  const handleWalletNameUpdate = (newName: string) => {
    saveWalletName(newName)
    setWalletName(newName)

    toast({
      title: "Đổi tên thành công!",
      description: `Ví của bạn giờ tên là "${newName}"`,
    })
  }

  return (
    <div className="space-y-6 pb-20">
      {/* Profile Header */}
      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 shadow-lg">
        <CardContent className="pt-8 pb-6">
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <div className="w-30 h-30 rounded-full overflow-hidden border-4 border-purple-400 shadow-lg">
                {customAvatar ? (
                  <img
                    src={customAvatar || "/placeholder.svg"}
                    alt="User avatar"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-purple-700 to-pink-500 flex items-center justify-center">
                    <Wallet className="w-16 h-16 text-white" />
                  </div>
                )}
              </div>
              <button
                onClick={() => setShowAvatarDialog(true)}
                className="absolute bottom-0 right-0 w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-purple-700 transition-all active:scale-95 border-3 border-white"
                title="Upload avatar"
              >
                <span className="text-2xl font-bold leading-none">+</span>
              </button>
            </div>

            {/* Wallet Name */}
            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                <h2 className="text-2xl font-bold text-purple-900">{walletName}</h2>
                <button
                  onClick={() => {
                    triggerHaptic("light")
                    setShowWalletNameEdit(true)
                  }}
                  className="w-6 h-6 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center hover:bg-purple-200 transition-all active:scale-95"
                  title="Đổi tên ví"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
              <p className="text-sm text-purple-600 font-mono mt-1">{formatAddress(address)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pi Network Status */}
      {isPiConnected && <PiNetworkStatus />}

      {/* About Olivia PiMask */}
      <Card className="border-purple-200 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 text-purple-900">
            <Info className="w-5 h-5 text-purple-600" />
            Về Olivia PiMask
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-purple-700 space-y-2">
            <p className="font-semibold text-purple-900">Ví Web3 siêu nhẹ, đẹp như Olivia</p>
            <p>
              Kết nối an toàn với Pi Network. Truy cập Pi Apps dễ dàng, gửi/nhận/quét QR, nạp/rút VND (VNPay, BIDV...).
            </p>
            <p className="text-purple-600">Bảo mật tuyệt đối, không lưu giữ private key.</p>
          </div>

          <div className="space-y-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-between border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
              onClick={handleInviteFriends}
            >
              <span className="flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-600" />
                Mời bạn bè
              </span>
              <ChevronRight className="w-4 h-4 text-purple-400" />
            </Button>

            <Button
              variant="outline"
              size="sm"
              className="w-full justify-between border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
              onClick={handleRateApp}
            >
              <span className="flex items-center gap-2">
                <Star className="w-4 h-4 text-purple-600" />
                Đánh giá app
              </span>
              <ChevronRight className="w-4 h-4 text-purple-400" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Support */}
      <Card className="border-purple-200 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 text-purple-900">
            <HelpCircle className="w-5 h-5 text-purple-600" />
            Hỗ trợ
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-between border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
            onClick={() => setShowFAQ(true)}
          >
            <span className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-purple-600" />
              FAQ / Câu hỏi thường gặp
            </span>
            <ChevronRight className="w-4 h-4 text-purple-400" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="w-full justify-between border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
            onClick={handleContactSupport}
          >
            <span className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-purple-600" />
              Liên hệ support
            </span>
            <ChevronRight className="w-4 h-4 text-purple-400" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="w-full justify-between border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
            onClick={() => setShowReportBug(true)}
          >
            <span className="flex items-center gap-2">
              <Bug className="w-4 h-4 text-purple-600" />
              Báo lỗi / Góp ý
            </span>
            <ChevronRight className="w-4 h-4 text-purple-400" />
          </Button>
        </CardContent>
      </Card>

      {/* App Information */}
      <Card className="border-purple-200 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 text-purple-900">
            <FileText className="w-5 h-5 text-purple-600" />
            Thông tin ứng dụng
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-purple-700">Phiên bản</span>
            <span className="text-sm font-mono text-purple-900">1.0.0</span>
          </div>
          <div className="h-px bg-purple-100" />
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-between text-purple-700 hover:bg-purple-50"
            onClick={handleTerms}
          >
            <span className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-600" />
              Điều khoản sử dụng
            </span>
            <ChevronRight className="w-4 h-4 text-purple-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-between text-purple-700 hover:bg-purple-50"
            onClick={handleContactSupport}
          >
            <span className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-purple-600" />
              Liên hệ hỗ trợ
            </span>
            <ChevronRight className="w-4 h-4 text-purple-400" />
          </Button>
        </CardContent>
      </Card>

      <AvatarUploadDialog
        open={showAvatarDialog}
        onOpenChange={setShowAvatarDialog}
        currentAvatar={customAvatar}
        onAvatarChange={handleAvatarUpdate}
      />

      <WalletNameEditDialog
        open={showWalletNameEdit}
        onOpenChange={setShowWalletNameEdit}
        currentName={walletName}
        onNameChange={handleWalletNameUpdate}
      />

      {/* FAQ and Report Bug dialogs */}
      <FAQDialog open={showFAQ} onOpenChange={setShowFAQ} />
      <ReportBugDialog open={showReportBug} onOpenChange={setShowReportBug} />
    </div>
  )
}
