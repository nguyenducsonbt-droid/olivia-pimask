"use client"

import { Home, ArrowLeftRight, Coins, Settings, Plus, BarChart3, Badge as Bridge } from "lucide-react"
import { useState } from "react"

interface BottomNavProps {
  activeTab: "home" | "swap" | "assets" | "bridge" | "portfolio" | "settings"
  onTabChange: (tab: "home" | "swap" | "assets" | "bridge" | "portfolio" | "settings") => void
  unreadCount?: number
  onFabClick?: () => void
}

export function BottomNav({ activeTab, onTabChange, unreadCount, onFabClick }: BottomNavProps) {
  const [isPressed, setIsPressed] = useState(false)
  const [isFocused, setIsFocused] = useState(false)

  const tabs = [
    { id: "home" as const, icon: Home, label: "Trang chủ" },
    { id: "swap" as const, icon: ArrowLeftRight, label: "Hoán đổi" },
    { id: "bridge" as const, icon: Bridge, label: "Cầu nối" },
    { id: "portfolio" as const, icon: BarChart3, label: "Danh mục" },
    { id: "assets" as const, icon: Coins, label: "Tài sản" },
    { id: "settings" as const, icon: Settings, label: "Cài đặt" },
  ]

  const handlePressStart = () => {
    setIsPressed(true)
  }

  const handlePressEnd = () => {
    setIsPressed(false)
    if (onFabClick) {
      onFabClick()
    }
  }

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-lg border-t border-purple-300/30 shadow-lg"
      style={{
        background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
      }}
    >
      <div className="max-w-2xl mx-auto px-2 py-3">
        <div className="flex items-center justify-between">
          {/* First 3 tabs */}
          {tabs.slice(0, 3).map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center gap-1 py-2 px-2 rounded-xl transition-all duration-200 relative ${
                  isActive ? "text-white" : "text-purple-200/70 hover:text-white hover:bg-white/10"
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${isActive ? "scale-110 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" : ""}`}
                />
                <span className={`text-[10px] font-medium ${isActive ? "font-semibold" : ""}`}>{tab.label}</span>
                {isActive && (
                  <div
                    className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-white rounded-full"
                    style={{
                      boxShadow: "0 0 8px rgba(255, 255, 255, 0.6)",
                    }}
                  />
                )}
              </button>
            )
          })}

          {/* FAB Button */}
          <button
            onClick={handlePressEnd}
            onMouseDown={handlePressStart}
            onMouseUp={() => setIsPressed(false)}
            onMouseLeave={() => setIsPressed(false)}
            onTouchStart={handlePressStart}
            onTouchEnd={handlePressEnd}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            className="flex flex-col items-center gap-1 py-2 px-2 transition-all duration-300 relative"
            style={{
              transform: isFocused ? "scale(1.1)" : isPressed ? "scale(0.95)" : "scale(1)",
            }}
          >
            {/* Green glow background layer */}
            <div
              className="absolute inset-0 rounded-full transition-all duration-300"
              style={{
                width: "56px",
                height: "56px",
                background: "radial-gradient(circle, rgba(0, 255, 136, 0.3) 0%, rgba(0, 255, 136, 0) 70%)",
                filter: "blur(16px)",
                opacity: isFocused ? 1 : 0.6,
                animation: isFocused ? "pulse 2s ease-in-out infinite" : "none",
              }}
            />

            {/* Main button */}
            <div
              className="relative w-[56px] h-[56px] rounded-full flex items-center justify-center transition-all duration-300"
              style={{
                background: "linear-gradient(135deg, #00FF88 0%, #00C853 100%)",
                boxShadow: `
                  0 8px 24px rgba(0, 200, 83, 0.35),
                  0 4px 12px rgba(0, 255, 136, 0.3),
                  0 0 32px ${isFocused ? "rgba(0, 255, 136, 0.5)" : "rgba(0, 255, 136, 0.3)"},
                  inset 0 2px 4px rgba(255, 255, 255, 0.3)
                `,
              }}
            >
              {/* Ripple effect when pressed */}
              {isPressed && (
                <div
                  className="absolute inset-0 rounded-full animate-ping"
                  style={{
                    background: "rgba(0, 255, 136, 0.6)",
                    animationDuration: "300ms",
                    animationIterationCount: "1",
                  }}
                />
              )}

              {/* Plus icon */}
              <Plus
                className="relative z-10 text-black"
                size={28}
                strokeWidth={3}
                style={{
                  filter: "drop-shadow(0 1px 2px rgba(0, 0, 0, 0.1))",
                }}
              />
            </div>
          </button>

          {/* Last 3 tabs */}
          {tabs.slice(3).map((tab) => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center gap-1 py-2 px-2 rounded-xl transition-all duration-200 relative ${
                  isActive ? "text-white" : "text-purple-200/70 hover:text-white hover:bg-white/10"
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${isActive ? "scale-110 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]" : ""}`}
                />
                <span className={`text-[10px] font-medium ${isActive ? "font-semibold" : ""}`}>{tab.label}</span>
                {isActive && (
                  <div
                    className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-white rounded-full"
                    style={{
                      boxShadow: "0 0 8px rgba(255, 255, 255, 0.6)",
                    }}
                  />
                )}
              </button>
            )
          })}
        </div>
      </div>

      <style jsx>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 0.6;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.05);
          }
        }
      `}</style>
    </div>
  )
}
