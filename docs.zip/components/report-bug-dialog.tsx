"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Send, Upload } from "lucide-react"

interface ReportBugDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ReportBugDialog({ open, onOpenChange }: ReportBugDialogProps) {
  const [description, setDescription] = useState("")
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async () => {
    if (!description.trim()) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng mô tả chi tiết lỗi gặp phải",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Đã gửi báo cáo",
        description: "Cảm ơn bạn đã góp ý! Team sẽ xử lý trong 24-48h.",
      })
      setDescription("")
      setEmail("")
      setIsSubmitting(false)
      onOpenChange(false)
    }, 1000)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader>
          <DialogTitle className="text-purple-900">Báo lỗi / Góp ý</DialogTitle>
          <DialogDescription>Mô tả chi tiết vấn đề bạn gặp phải để team có thể hỗ trợ nhanh nhất</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email (tùy chọn)</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/80"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Mô tả lỗi / Góp ý</Label>
            <Textarea
              id="description"
              placeholder="Ví dụ: Khi gửi Pi, app bị đơ sau khi bấm Xác nhận. Tôi đang dùng iPhone 13, iOS 17..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="min-h-[120px] bg-white/80"
            />
          </div>
          <div className="flex items-center gap-2 text-sm text-purple-700">
            <Upload className="w-4 h-4" />
            <span>Gửi kèm ảnh chụp màn hình nếu có</span>
          </div>
          <Button onClick={handleSubmit} disabled={isSubmitting} className="w-full bg-purple-600 hover:bg-purple-700">
            <Send className="mr-2 h-4 w-4" />
            {isSubmitting ? "Đang gửi..." : "Gửi báo cáo"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
