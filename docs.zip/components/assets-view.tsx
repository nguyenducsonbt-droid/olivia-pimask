"use client"

import { useState, memo, useCallback, useEffect, useTransition } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useWallet } from "@/hooks/use-wallet"
import { Coins, Plus, RefreshCw, Trash2, ImageIcon, ExternalLink } from "lucide-react"
import { AddTokenDialog } from "./add-token-dialog"
import { dataCache } from "@/lib/data-cache"
import dynamic from "next/dynamic"
import { NFTDetailDialog } from "./nft-detail-dialog"
import type { NFT } from "@/lib/nft-service"
import { NFTMarketplaceMini } from "./nft-marketplace-mini"
import { TokenSkeleton, NFTGridSkeleton, FiatSkeleton } from "@/components/ui/skeleton-loader"

const LiquidityProvidingTab = dynamic(
  () => import("./liquidity-providing-tab").then((mod) => ({ default: mod.LiquidityProvidingTab })),
  {
    loading: () => (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    ),
  },
)

const FiatTab = dynamic(() => import("./fiat-tab").then((mod) => ({ default: mod.FiatTab })), {
  loading: () => <FiatSkeleton />,
})

const PopularTokens = dynamic(() => import("./popular-tokens").then((mod) => ({ default: mod.PopularTokens })), {
  ssr: false,
  loading: () => (
    <Card className="border-purple-200 animate-pulse">
      <CardHeader className="pb-3">
        <div className="h-5 w-32 bg-muted rounded"></div>
      </CardHeader>
    </Card>
  ),
})

const TokenItem = memo(({ token, onRemove }: { token: any; onRemove: (address: string) => void }) => {
  const isWhiteTheme = token.theme === "white" || token.isPIMask
  const cardClass = isWhiteTheme
    ? "flex items-center justify-between p-3 rounded-lg bg-white border border-gray-200 shadow-sm"
    : "flex items-center justify-between p-3 rounded-lg bg-muted/50"

  return (
    <div className={cardClass}>
      <div className="flex items-center gap-3">
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center ${
            isWhiteTheme ? "bg-black text-white" : "bg-primary/10"
          }`}
        >
          <span className={`text-sm font-bold ${isWhiteTheme ? "text-white" : "text-primary"}`}>{token.symbol[0]}</span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <p className={`font-medium ${isWhiteTheme ? "text-black" : ""}`}>{token.name}</p>
            {token.isPIMask && <span className="text-xs bg-black text-white px-2 py-0.5 rounded-full">Privacy</span>}
          </div>
          <p className={`text-xs ${isWhiteTheme ? "text-gray-600" : "text-muted-foreground"}`}>{token.symbol}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="text-right">
          <p className={`font-semibold ${isWhiteTheme ? "text-black" : ""}`}>{token.balance || "0.00"}</p>
          <p className={`text-xs ${isWhiteTheme ? "text-gray-600" : "text-muted-foreground"}`}>{token.symbol}</p>
        </div>
        {token.isCustom && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemove(token.address)}
            className="h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
})
TokenItem.displayName = "TokenItem"

export function AssetsView() {
  const { tokens, removeToken, refreshTokenBalances, address } = useWallet()
  const [showAddToken, setShowAddToken] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [activeTab, setActiveTab] = useState("tokens")
  const [selectedNFT, setSelectedNFT] = useState<any>(null)
  const [showNFTDetail, setShowNFTDetail] = useState(false)
  // Removed showRecentTransactions state as it's no longer needed

  const [cachedTokens, setCachedTokens] = useState<any[]>([])
  const [isLoadingTokens, setIsLoadingTokens] = useState(true)
  const [isLoadingNFTs, setIsLoadingNFTs] = useState(false)
  const [isPending, startTransition] = useTransition()

  const [userNFTs, setUserNFTs] = useState<NFT[]>([])
  const [filteredNFTs, setFilteredNFTs] = useState<NFT[]>([])
  const [selectedCollection, setSelectedCollection] = useState("All")
  const [collections, setCollections] = useState<string[]>([])

  useEffect(() => {
    const loadTokensFromCache = async () => {
      try {
        // Try to get from cache first for instant display
        const cacheKey = "assets:tokens:list"
        const cached = await dataCache.get(cacheKey, async () => tokens, { ttl: 30000, staleWhileRevalidate: true })

        setCachedTokens(cached || tokens)
        setIsLoadingTokens(false)
      } catch (error) {
        console.error("[v0] Failed to load tokens from cache:", error)
        setCachedTokens(tokens)
        setIsLoadingTokens(false)
      }
    }

    loadTokensFromCache()
  }, [tokens])

  useEffect(() => {
    if (tokens.length > 0) {
      dataCache.set("assets:tokens:list", tokens, 30000)
      setCachedTokens(tokens)
    }
  }, [tokens])

  useEffect(() => {
    if (selectedCollection === "All") {
      setFilteredNFTs(userNFTs)
    } else {
      setFilteredNFTs(userNFTs.filter((nft) => nft.collection === selectedCollection))
    }
  }, [selectedCollection, userNFTs])

  const loadNFTs = async () => {
    // Placeholder for future mainnet integration
  }

  const handleNFTClick = (nft: any) => {
    setSelectedNFT(nft)
    setShowNFTDetail(true)
  }

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true)

    try {
      if (activeTab === "tokens") {
        await dataCache.get(
          "tokens:refresh:" + Date.now(),
          async () => {
            await refreshTokenBalances()
            return true
          },
          { ttl: 15000, staleWhileRevalidate: true },
        )
      }
    } catch (error) {
      console.error("[v0] Refresh failed:", error)
    } finally {
      setTimeout(() => setIsRefreshing(false), 500)
    }
  }, [activeTab, refreshTokenBalances])

  const handleRemoveToken = useCallback(
    (address: string) => {
      removeToken(address)
      dataCache.invalidate("assets:tokens:list")
    },
    [removeToken],
  )

  const handleTabChange = useCallback(
    (value: string) => {
      startTransition(() => {
        setActiveTab(value)

        // Preload tab content
        if (value === "nfts" && userNFTs.length === 0) {
          setIsLoadingNFTs(true)
          setTimeout(() => setIsLoadingNFTs(false), 300)
        }
      })
    },
    [userNFTs.length],
  )

  const displayTokens = cachedTokens.length > 0 ? cachedTokens : tokens

  // Removed handleViewAllTransactions function as it's no longer needed

  return (
    <div>
      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tokens">Tokens</TabsTrigger>
          <TabsTrigger value="nfts">NFTs</TabsTrigger>
          <TabsTrigger value="staking">Liquidity</TabsTrigger>
          <TabsTrigger value="fiat">Fiat</TabsTrigger>
        </TabsList>

        <TabsContent value="tokens" className="space-y-4 pb-[320px]">
          <PopularTokens />

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Token của bạn</CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRefresh}
                    disabled={isRefreshing}
                    className="h-8 px-2 bg-transparent"
                  >
                    <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => setShowAddToken(true)}
                    className="h-8 px-3 text-white"
                    style={{
                      background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Thêm Token
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingTokens ? (
                <div className="space-y-3">
                  <TokenSkeleton />
                  <TokenSkeleton />
                  <TokenSkeleton />
                </div>
              ) : displayTokens.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Coins className="w-16 h-16 mx-auto mb-3 opacity-30" />
                  <p className="text-sm font-medium">Chưa có token nào</p>
                  <p className="text-xs mt-1">Thêm token để bắt đầu</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {displayTokens.map((token) => (
                    <TokenItem key={token.address} token={token} onRemove={handleRemoveToken} />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="nfts" className="space-y-4 pb-[320px]">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">NFTs của bạn</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={true}
                  className="h-8 px-2 bg-transparent opacity-50 cursor-not-allowed"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingNFTs ? (
                <NFTGridSkeleton />
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <ImageIcon className="w-16 h-16 mx-auto mb-3 opacity-30" />
                  <p className="text-sm font-medium">Chưa có NFT nào</p>
                  <p className="text-xs mt-1 mb-4">Khám phá và sưu tầm NFT độc đáo trên Pi Network</p>

                  <Button
                    disabled
                    className="text-white font-semibold opacity-50 cursor-not-allowed"
                    style={{
                      background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
                    }}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Mở Ecosystem
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <NFTMarketplaceMini />
        </TabsContent>

        <TabsContent value="staking" className="pb-[320px]">
          {activeTab === "staking" && <LiquidityProvidingTab />}
        </TabsContent>

        <TabsContent value="fiat" className="pb-[320px]">
          {activeTab === "fiat" && <FiatTab />}
        </TabsContent>
      </Tabs>

      <AddTokenDialog open={showAddToken} onOpenChange={setShowAddToken} />
      <NFTDetailDialog open={showNFTDetail} onOpenChange={setShowNFTDetail} nft={selectedNFT} />
    </div>
  )
}
