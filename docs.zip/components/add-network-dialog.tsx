"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { Plus, Loader2, AlertCircle } from "lucide-react"
import type { Network } from "@/lib/wallet"
import { validateRpcUrl } from "@/lib/wallet"
import { useLanguage } from "@/hooks/use-language"
import { saveCustomNetworks } from "@/lib/storage"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface AddNetworkDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AddNetworkDialog({ open, onOpenChange }: AddNetworkDialogProps) {
  const { networks, setNetworks, setCurrentNetwork } = useWallet()
  const [name, setName] = useState("BSC Testnet")
  const [rpcUrl, setRpcUrl] = useState("https://data-seed-prebsc-1-s1.binance.org:8545")
  const [chainId, setChainId] = useState("97")
  const [symbol, setSymbol] = useState("BNB")
  const [explorerUrl, setExplorerUrl] = useState("https://testnet.bscscan.com")
  const [isValidating, setIsValidating] = useState(false)
  const { toast } = useToast()
  const { t, language } = useLanguage()

  const handleAdd = async () => {
    if (!name || !rpcUrl || !chainId || !symbol) {
      toast({
        title: t.common.error,
        description: t.networks.errors.fillRequired,
        variant: "destructive",
      })
      return
    }

    setIsValidating(true)
    const isValid = await validateRpcUrl(rpcUrl, 3000)
    setIsValidating(false)

    if (!isValid) {
      toast({
        title: language === "vi" ? "RPC không kết nối, thử lại!" : "RPC connection failed, try again!",
        description:
          language === "vi"
            ? "Không thể kết nối đến RPC URL. Vui lòng kiểm tra lại."
            : "Cannot connect to RPC URL. Please check again.",
        variant: "destructive",
      })
      return
    }

    const newNetwork: Network = {
      id: `custom-${Date.now()}`,
      name,
      rpcUrl,
      chainId: Number.parseInt(chainId),
      symbol,
      explorerUrl: explorerUrl || undefined,
    }

    const updatedNetworks = [...networks, newNetwork]
    setNetworks(updatedNetworks)

    const customNetworks = updatedNetworks.filter((n) => n.id.startsWith("custom-"))
    saveCustomNetworks(customNetworks)

    toast({
      title: t.networks.toasts.networkAdded,
      description: `${name} ${t.networks.toasts.addedSuccessfully}`,
    })

    setCurrentNetwork(newNetwork)

    // Reset form to BSC Testnet defaults
    setName("BSC Testnet")
    setRpcUrl("https://data-seed-prebsc-1-s1.binance.org:8545")
    setChainId("97")
    setSymbol("BNB")
    setExplorerUrl("https://testnet.bscscan.com")
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-sm border border-gray-200 shadow-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">
            {language === "vi" ? "Thêm mạng tùy chỉnh" : "Add Custom Network"}
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            {language === "vi"
              ? "Thêm mạng blockchain tùy chỉnh vào ví của bạn"
              : "Add a custom blockchain network to your wallet"}
          </DialogDescription>
        </DialogHeader>

        <Alert className="border border-gray-300 bg-gray-50">
          <AlertCircle className="h-4 w-4 text-purple-500" />
          <AlertDescription className="text-sm text-gray-900">
            {language === "vi"
              ? "Chỉ thêm mạng an toàn theo Pi guidelines 2025. Không thêm RPC không rõ nguồn gốc."
              : "Only add safe networks following Pi guidelines 2025. Do not add unknown RPC sources."}
          </AlertDescription>
        </Alert>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="network-name" className="text-sm font-medium text-gray-700">
              {language === "vi" ? "Tên mạng" : "Network Name"}
            </Label>
            <Input
              id="network-name"
              placeholder="BSC Testnet"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border border-gray-300 focus:border-purple-400 bg-white text-gray-900 placeholder:text-gray-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="rpc-url" className="text-sm font-medium text-gray-700">
              RPC URL
            </Label>
            <Input
              id="rpc-url"
              placeholder="https://..."
              value={rpcUrl}
              onChange={(e) => setRpcUrl(e.target.value)}
              className="border border-gray-300 focus:border-purple-400 bg-white text-gray-900 placeholder:text-gray-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="chain-id" className="text-sm font-medium text-gray-700">
              Chain ID
            </Label>
            <Input
              id="chain-id"
              type="number"
              placeholder="97"
              value={chainId}
              onChange={(e) => setChainId(e.target.value)}
              className="border border-gray-300 focus:border-purple-400 bg-white text-gray-900 placeholder:text-gray-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="symbol" className="text-sm font-medium text-gray-700">
              Symbol
            </Label>
            <Input
              id="symbol"
              placeholder="BNB"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="border border-gray-300 focus:border-purple-400 bg-white text-gray-900 placeholder:text-gray-400"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="explorer-url" className="text-sm font-medium text-gray-700">
              Explorer URL {language === "vi" ? "(tùy chọn)" : "(optional)"}
            </Label>
            <Input
              id="explorer-url"
              placeholder="https://testnet.bscscan.com"
              value={explorerUrl}
              onChange={(e) => setExplorerUrl(e.target.value)}
              className="border border-gray-300 focus:border-purple-400 bg-white text-gray-900 placeholder:text-gray-400"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border border-purple-300 bg-white hover:bg-purple-50 text-purple-600 font-medium"
          >
            {language === "vi" ? "Hủy" : "Cancel"}
          </Button>
          <Button
            onClick={handleAdd}
            disabled={isValidating}
            className="bg-purple-500 hover:bg-purple-600 text-white font-medium shadow-md"
          >
            {isValidating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {language === "vi" ? "Đang kiểm tra..." : "Testing..."}
              </>
            ) : (
              <>
                <Plus className="mr-2 h-4 w-4" />
                {language === "vi" ? "Test & Thêm" : "Test & Add"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
