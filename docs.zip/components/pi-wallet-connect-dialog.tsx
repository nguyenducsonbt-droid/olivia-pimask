"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Loader2, Shield, Wallet } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface PiWalletConnectDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onConnect: () => Promise<void>
}

export function PiWalletConnectDialog({ open, onOpenChange, onConnect }: PiWalletConnectDialogProps) {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [isOpening, setIsOpening] = useState(false)

  // Simplified connection flow - just open wallet.pi directly without SDK authentication
  const handleOpenWallet = async () => {
    setIsOpening(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Try Pi SDK navigation first
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi
        try {
          await Pi.init({ version: "2.0", sandbox: false })
          if (Pi.navigation && Pi.navigation.open) {
            await Pi.navigation.open("wallet.pi")

            onOpenChange(false)
            setIsOpening(false)
            return
          }
        } catch (err) {
          console.log("[v0] Pi SDK navigation not available, trying deep link")
        }
      }

      // Fallback to deep link
      const link = document.createElement("a")
      link.href = "pi://wallet.pi"
      link.style.display = "none"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      onOpenChange(false)
    } catch (error) {
      console.error("[v0] Error opening wallet.pi:", error)

      onOpenChange(false)
    } finally {
      setIsOpening(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-purple-900">
            <Wallet className="w-5 h-5 text-purple-700" />
            {t.dashboard.connectPiWallet}
          </DialogTitle>
          <DialogDescription className="text-purple-700">Mở ví Pi chính thức để thanh toán an toàn</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 space-y-2 border border-purple-200">
            <div className="flex items-center gap-2 text-sm font-medium text-purple-900">
              <Shield className="w-4 h-4 text-purple-700" />
              <span>Ví Pi chính thức</span>
            </div>
            <ul className="text-xs text-purple-700 space-y-1 ml-6">
              <li>• Hiển thị số dư Pi Mainnet</li>
              <li>• Gửi/Nhận Pi an toàn</li>
              <li>• Quét QR code để thanh toán</li>
            </ul>
          </div>

          <Button
            onClick={handleOpenWallet}
            disabled={isOpening}
            className="w-full h-12 text-base font-semibold text-white"
            style={{
              background: "linear-gradient(135deg, #7B1FA2 0%, #E91E63 100%)",
            }}
          >
            {isOpening ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Đang mở...
              </>
            ) : (
              <>
                <span className="mr-2">⛏️</span>
                {t.dashboard.loginViaPiApp}
              </>
            )}
          </Button>

          <p className="text-xs text-center text-purple-600">Mở ví Pi chính thức để thanh toán an toàn</p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
