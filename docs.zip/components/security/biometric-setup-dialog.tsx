"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Fingerprint, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface BiometricSetupDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
}

export function BiometricSetupDialog({ open, onClose, onSuccess }: BiometricSetupDialogProps) {
  const { toast } = useToast()

  const handleEnable = () => {
    // UI only - no real functionality
    toast({
      title: "Thành công",
      description: "Face ID / Touch ID đã được kích hoạt",
    })
    onSuccess()
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Fingerprint className="w-5 h-5 text-purple-600" />
            Face ID / Touch ID
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex justify-center">
            <div className="w-20 h-20 rounded-full bg-purple-100 flex items-center justify-center">
              <Fingerprint className="w-12 h-12 text-purple-600" />
            </div>
          </div>

          <div className="space-y-3 text-center">
            <h3 className="font-semibold text-lg">Kích hoạt sinh trắc học</h3>
            <p className="text-sm text-muted-foreground">
              Sử dụng Face ID hoặc Touch ID để mở khóa ví nhanh chóng và an toàn
            </p>
          </div>

          <div className="space-y-2 bg-purple-50 p-4 rounded-lg">
            <div className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Mở khóa ví chỉ bằng một chạm</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Bảo mật cao, không lưu trữ dữ liệu sinh trắc</p>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Vẫn cần PIN để thao tác quan trọng</p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
            Hủy
          </Button>
          <Button onClick={handleEnable} className="flex-1 bg-purple-600 hover:bg-purple-700">
            Kích hoạt
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
