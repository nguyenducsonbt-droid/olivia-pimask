"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Shield, Mail, Smartphone, MessageSquare, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

export type TwoFactorMethod = "google-auth" | "email-otp" | "sms"

interface TwoFactorMethodSelectorProps {
  open: boolean
  onClose: () => void
  onMethodSelected: (method: TwoFactorMethod) => void
  currentMethod?: TwoFactorMethod
}

export function TwoFactorMethodSelector({
  open,
  onClose,
  onMethodSelected,
  currentMethod,
}: TwoFactorMethodSelectorProps) {
  const [selectedMethod, setSelectedMethod] = useState<TwoFactorMethod>(currentMethod || "google-auth")

  const methods = [
    {
      id: "google-auth" as TwoFactorMethod,
      name: "Google Authenticator",
      description: "Mã 6 số từ app Authenticator (Authy, Google Auth)",
      icon: Smartphone,
      badge: "Khuyên dùng",
      badgeColor: "bg-purple-100 text-purple-700",
      features: ["Bảo mật cao nhất", "Hoạt động offline", "Không cần internet"],
    },
    {
      id: "email-otp" as TwoFactorMethod,
      name: "Email OTP",
      description: "Mã 6 số gửi qua Gmail/Email của bạn",
      icon: Mail,
      badge: "Tiện lợi",
      badgeColor: "bg-blue-100 text-blue-700",
      features: ["Dễ sử dụng", "Không cần app", "Phổ biến với Pioneer"],
    },
    {
      id: "sms" as TwoFactorMethod,
      name: "SMS OTP",
      description: "Mã 6 số gửi qua tin nhắn điện thoại",
      icon: MessageSquare,
      badge: "Sắp có",
      badgeColor: "bg-gray-100 text-gray-600",
      features: ["Backup khi mất app", "Dự phòng an toàn", "Coming soon"],
      disabled: true,
    },
  ]

  const handleConfirm = () => {
    onMethodSelected(selectedMethod)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600" />
            Chọn phương thức 2FA
          </DialogTitle>
          <DialogDescription>Bảo vệ giao dịch lớn với xác thực hai yếu tố</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-4">
          {methods.map((method) => {
            const Icon = method.icon
            const isSelected = selectedMethod === method.id
            const isDisabled = method.disabled

            return (
              <button
                key={method.id}
                onClick={() => !isDisabled && setSelectedMethod(method.id)}
                disabled={isDisabled}
                className={cn(
                  "w-full text-left p-4 rounded-lg border-2 transition-all",
                  isSelected && !isDisabled
                    ? "border-purple-600 bg-purple-50"
                    : "border-gray-200 hover:border-gray-300 bg-white",
                  isDisabled && "opacity-60 cursor-not-allowed",
                )}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                      isSelected && !isDisabled ? "bg-purple-600" : "bg-gray-100",
                    )}
                  >
                    <Icon className={cn("w-5 h-5", isSelected && !isDisabled ? "text-white" : "text-gray-600")} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-sm">{method.name}</h4>
                      <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium", method.badgeColor)}>
                        {method.badge}
                      </span>
                      {isSelected && !isDisabled && <CheckCircle className="w-4 h-4 text-purple-600 ml-auto" />}
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{method.description}</p>

                    <div className="space-y-1">
                      {method.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <div className="w-1 h-1 rounded-full bg-purple-600" />
                          <p className="text-xs text-gray-600">{feature}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </button>
            )
          })}
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-2">
          <p className="text-xs text-yellow-800">
            <strong>Lưu ý:</strong> 2FA sẽ bắt buộc khi gửi &gt; 50 Pi, transfer NFT giá trị cao, hoặc xuất private
            key/seed phrase.
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
            Hủy
          </Button>
          <Button onClick={handleConfirm} className="flex-1 bg-purple-600 hover:bg-purple-700">
            Tiếp tục thiết lập
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
