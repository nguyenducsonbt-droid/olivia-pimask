"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, Smartphone, CheckCircle, Copy, KeyRound } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  generateTwoFactorSecret,
  generateBackupCodes,
  saveTwoFactorData,
  verifyTOTP,
  getTwoFactorQRCodeURL,
} from "@/lib/two-factor"

interface TwoFactorSetupDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
}

export function TwoFactorSetupDialog({ open, onClose, onSuccess }: TwoFactorSetupDialogProps) {
  const [step, setStep] = useState<"intro" | "qr" | "verify" | "backup">("intro")
  const [secret, setSecret] = useState("")
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [verificationCode, setVerificationCode] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const { toast } = useToast()

  const handleStart = () => {
    const newSecret = generateTwoFactorSecret()
    const codes = generateBackupCodes()
    setSecret(newSecret)
    setBackupCodes(codes)
    setStep("qr")
  }

  const handleVerify = async () => {
    if (verificationCode.length !== 6) return

    setIsVerifying(true)

    try {
      const isValid = await verifyTOTP(verificationCode, secret)

      if (isValid) {
        saveTwoFactorData(secret, true, backupCodes)
        setStep("backup")
      } else {
        toast({
          title: "Mã không hợp lệ",
          description: "Vui lòng kiểm tra lại mã từ Authenticator",
          variant: "destructive",
        })
      }
    } finally {
      setIsVerifying(false)
    }
  }

  const handleComplete = () => {
    toast({
      title: "Google 2FA đã kích hoạt",
      description: "Giao dịch lớn giờ cần mã xác thực Google Authenticator",
    })
    onSuccess()
    onClose()
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Đã copy",
      description: "Đã sao chép vào clipboard",
    })
  }

  const qrCodeURL = secret ? getTwoFactorQRCodeURL(secret, "pioneer@olivia") : ""

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent
        className="sm:max-w-md max-h-[90vh] overflow-y-auto"
        onPointerDownOutside={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600" />
            Thiết lập Google Authenticator
          </DialogTitle>
        </DialogHeader>

        {step === "intro" && (
          <div className="space-y-4 py-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-purple-100 flex items-center justify-center">
                <Shield className="w-12 h-12 text-purple-600" />
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-lg text-center">Bảo vệ tăng cường</h3>
              <p className="text-sm text-muted-foreground text-center">
                Kích hoạt 2FA để bảo vệ các giao dịch quan trọng
              </p>
            </div>

            <div className="space-y-3 bg-purple-50 p-4 rounded-lg">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Giao dịch lớn</p>
                  <p className="text-xs text-muted-foreground">Cần 2FA khi gửi &gt; 50 Pi</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Xuất Seed Phrase</p>
                  <p className="text-xs text-muted-foreground">Yêu cầu mã 2FA trước khi hiển thị</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Tương thích Google Authenticator</p>
                  <p className="text-xs text-muted-foreground">Hoạt động offline, không cần internet</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                📱 Chuẩn bị ứng dụng: Google Authenticator, Authy, hoặc ứng dụng 2FA tương thích
              </p>
            </div>
          </div>
        )}

        {step === "qr" && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-center block font-semibold">Quét mã QR bằng ứng dụng Authenticator</Label>
              <div className="flex justify-center">
                <img
                  src={qrCodeURL || "/placeholder.svg"}
                  alt="QR Code"
                  className="w-48 h-48 border-2 border-purple-200 rounded-lg"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Hoặc nhập thủ công:</Label>
              <div className="bg-gray-100 p-3 rounded-lg flex items-center justify-between gap-2">
                <p className="font-mono text-sm font-semibold flex-1 break-all">{secret}</p>
                <Button size="sm" variant="ghost" onClick={() => copyToClipboard(secret)}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Lưu mã bí mật ở nơi an toàn. Nếu mất điện thoại, bạn cần mã này để khôi phục 2FA.
              </p>
            </div>
          </div>
        )}

        {step === "verify" && (
          <div className="space-y-4 py-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center">
                <Smartphone className="w-12 h-12 text-green-600" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-center">Xác nhận thiết lập</h3>
              <p className="text-sm text-muted-foreground text-center">
                Nhập mã 6 số từ Google Authenticator để xác nhận
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="verification-code">Mã xác thực 6 số</Label>
              <Input
                id="verification-code"
                type="text"
                placeholder="000000"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="text-center text-lg font-mono tracking-widest"
              />
              <p className="text-xs text-muted-foreground text-center">Mã thay đổi mỗi 30 giây</p>
            </div>
          </div>
        )}

        {step === "backup" && (
          <div className="space-y-4 py-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-center text-green-600">Thành công!</h3>
              <p className="text-sm text-muted-foreground text-center">
                Lưu các mã dự phòng này để khôi phục 2FA khi cần
              </p>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
              <div className="flex items-start gap-2 mb-3">
                <KeyRound className="w-5 h-5 text-yellow-700 mt-0.5" />
                <div>
                  <p className="font-semibold text-yellow-900">Mã dự phòng (Backup Codes)</p>
                  <p className="text-xs text-yellow-700 mt-1">
                    Lưu các mã này ở nơi an toàn. Mỗi mã chỉ dùng được 1 lần khi bạn mất thiết bị Authenticator.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {backupCodes.map((code, idx) => (
                  <div key={idx} className="bg-white p-2 rounded border border-yellow-200">
                    <p className="font-mono text-sm text-center font-semibold">{code}</p>
                  </div>
                ))}
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full mt-3 bg-transparent"
                onClick={() => copyToClipboard(backupCodes.join("\n"))}
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy tất cả mã
              </Button>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          {step === "backup" ? (
            <Button onClick={handleComplete} className="w-full bg-purple-600 hover:bg-purple-700">
              Hoàn tất
            </Button>
          ) : (
            <>
              <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
                Hủy
              </Button>
              {step === "intro" && (
                <Button onClick={handleStart} className="flex-1 bg-purple-600 hover:bg-purple-700">
                  <Smartphone className="w-4 h-4 mr-2" />
                  Bắt đầu
                </Button>
              )}
              {step === "qr" && (
                <Button onClick={() => setStep("verify")} className="flex-1 bg-purple-600 hover:bg-purple-700">
                  Tiếp tục
                </Button>
              )}
              {step === "verify" && (
                <Button
                  onClick={handleVerify}
                  disabled={verificationCode.length !== 6 || isVerifying}
                  className="flex-1 bg-purple-600 hover:bg-purple-700"
                >
                  {isVerifying ? "Đang xác thực..." : "Xác nhận"}
                </Button>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
