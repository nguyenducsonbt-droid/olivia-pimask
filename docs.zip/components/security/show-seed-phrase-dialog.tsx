"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Eye, EyeOff, Copy, Fingerprint } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { getWalletData, simpleDecrypt, getBiometricEnabled } from "@/lib/storage"

interface ShowSeedPhraseDialogProps {
  open: boolean
  onClose: () => void
}

export function ShowSeedPhraseDialog({ open, onClose }: ShowSeedPhraseDialogProps) {
  const [isVerified, setIsVerified] = useState(false)
  const [showSeed, setShowSeed] = useState(false)
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const { toast } = useToast()
  const [realSeed, setRealSeed] = useState("")

  const handleFaceIDAuth = async () => {
    const biometricEnabled = getBiometricEnabled()

    if (!biometricEnabled) {
      toast({
        title: "Face ID chưa bật",
        description: "Vui lòng bật Face ID trong Cài đặt để xem Seed Phrase",
        variant: "destructive",
      })
      return
    }

    setIsAuthenticating(true)

    try {
      if (typeof window !== "undefined" && (window as any).Pi && (window as any).Pi.biometric) {
        const Pi = (window as any).Pi

        const result = await Pi.biometric.authenticate({
          reason: "Xác thực Face ID để hiển thị Seed Phrase",
          fallbackEnabled: true,
        })

        if (result.success) {
          const walletData = getWalletData()

          if (!walletData) {
            toast({
              title: "Lỗi",
              description: "Không tìm thấy ví. Vui lòng đăng nhập lại.",
              variant: "destructive",
            })
            setIsAuthenticating(false)
            return
          }

          const mnemonic = simpleDecrypt(walletData.encryptedMnemonic, walletData.address)
          setRealSeed(mnemonic)
          setIsVerified(true)

          toast({
            title: "Xác thực thành công",
            description: "Seed Phrase của bạn đã được hiển thị",
          })
        } else {
          toast({
            title: "Xác thực thất bại",
            description: "Vui lòng thử lại",
            variant: "destructive",
          })
        }
      } else {
        // Simulated authentication for preview/testing
        console.log("[v0] Biometric API not available, simulating authentication...")
        await new Promise((resolve) => setTimeout(resolve, 800))

        const walletData = getWalletData()
        if (walletData) {
          const mnemonic = simpleDecrypt(walletData.encryptedMnemonic, walletData.address)
          setRealSeed(mnemonic)
          setIsVerified(true)

          toast({
            title: "Xác thực thành công (Preview)",
            description: "Seed Phrase đã được hiển thị",
          })
        } else {
          toast({
            title: "Lỗi",
            description: "Không tìm thấy ví",
            variant: "destructive",
          })
        }
      }
    } catch (err) {
      console.error("[v0] Face ID authentication error:", err)
      toast({
        title: "Lỗi",
        description: "Không thể xác thực Face ID",
        variant: "destructive",
      })
    } finally {
      setIsAuthenticating(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(realSeed)
    toast({
      title: "Đã sao chép",
      description: "Seed Phrase đã được sao chép vào clipboard",
    })
  }

  const handleClose = () => {
    setIsVerified(false)
    setShowSeed(false)
    setRealSeed("")
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-purple-600" />
            Hiển thị Seed Phrase
          </DialogTitle>
        </DialogHeader>

        {!isVerified ? (
          <div className="space-y-4 py-4">
            <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4 space-y-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-6 h-6 text-red-600" />
                <h3 className="font-bold text-red-900 text-lg">CẢNH BÁO BẢO MẬT</h3>
              </div>
              <ul className="text-sm text-red-800 space-y-1 list-disc list-inside">
                <li>KHÔNG BAO GIỜ chia sẻ Seed Phrase với bất kỳ ai</li>
                <li>Olivia PiMask KHÔNG BAO GIỜ yêu cầu Seed Phrase</li>
                <li>Ai có Seed Phrase = KIỂM SOÁT HOÀN TOÀN ví của bạn</li>
                <li>Lưu giữ an toàn, KHÔNG chụp ảnh hoặc lưu online</li>
              </ul>
            </div>

            <div className="space-y-3">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-3">
                <Fingerprint className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900 text-sm">Xác thực Face ID</p>
                  <p className="text-xs text-blue-700">Bảo vệ Seed Phrase bằng sinh trắc học</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-sm text-yellow-800 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Ghi chép cẩn thận và lưu giữ nơi an toàn
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="font-medium text-sm">Seed Phrase của bạn (12 từ)</p>
                <Button variant="ghost" size="sm" onClick={() => setShowSeed(!showSeed)} className="h-8">
                  {showSeed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 font-mono text-sm">
                {showSeed ? (
                  <div className="grid grid-cols-2 gap-2">
                    {realSeed.split(" ").map((word, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="text-gray-400 w-6">{i + 1}.</span>
                        <span>{word}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-400 py-8">••••••••••••••••••••</p>
                )}
              </div>

              <Button variant="outline" size="sm" onClick={handleCopy} className="w-full bg-transparent">
                <Copy className="w-4 h-4 mr-2" />
                Sao chép Seed Phrase
              </Button>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={handleClose} className="flex-1 bg-transparent">
            {isVerified ? "Đóng" : "Hủy"}
          </Button>
          {!isVerified && (
            <Button
              onClick={handleFaceIDAuth}
              disabled={isAuthenticating}
              className="flex-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600"
            >
              {isAuthenticating ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Đang xác thực...
                </div>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4 mr-2" />
                  Sử dụng Face ID
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
