"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { AlertTriangle, Download, Copy, Eye, EyeOff, Fingerprint } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { getBiometricEnabled } from "@/lib/storage"

interface ExportPrivateKeyDialogProps {
  open: boolean
  onClose: () => void
}

export function ExportPrivateKeyDialog({ open, onClose }: ExportPrivateKeyDialogProps) {
  const [isVerified, setIsVerified] = useState(false)
  const [showKey, setShowKey] = useState(false)
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const { toast } = useToast()

  // Demo private key (UI only)
  const demoPrivateKey = "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"

  const handleFaceIDAuth = async () => {
    const biometricEnabled = getBiometricEnabled()

    if (!biometricEnabled) {
      toast({
        title: "Face ID chưa bật",
        description: "Vui lòng bật Face ID trong Cài đặt để export Private Key",
        variant: "destructive",
      })
      return
    }

    setIsAuthenticating(true)

    try {
      if (typeof window !== "undefined" && (window as any).Pi && (window as any).Pi.biometric) {
        const Pi = (window as any).Pi

        const result = await Pi.biometric.authenticate({
          reason: "Xác thực Face ID để export Private Key",
          fallbackEnabled: true,
        })

        if (result.success) {
          setIsVerified(true)
          toast({
            title: "Xác thực thành công",
            description: "Private Key của bạn đã được hiển thị",
          })
        } else {
          toast({
            title: "Xác thực thất bại",
            description: "Vui lòng thử lại",
            variant: "destructive",
          })
        }
      } else {
        // Preview mode
        console.log("[v0] Biometric API not available, simulating authentication...")
        await new Promise((resolve) => setTimeout(resolve, 800))
        setIsVerified(true)
        toast({
          title: "Xác thực thành công (Preview)",
          description: "Private Key đã được hiển thị",
        })
      }
    } catch (err) {
      console.error("[v0] Face ID authentication error:", err)
      toast({
        title: "Lỗi",
        description: "Không thể xác thực Face ID",
        variant: "destructive",
      })
    } finally {
      setIsAuthenticating(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(demoPrivateKey)
    toast({
      title: "Đã sao chép",
      description: "Private Key đã được sao chép vào clipboard",
    })
  }

  const handleClose = () => {
    setIsVerified(false)
    setShowKey(false)
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5 text-purple-600" />
            Export Private Key
          </DialogTitle>
        </DialogHeader>

        {!isVerified ? (
          <div className="space-y-4 py-4">
            {/* VERY BIG RED WARNING */}
            <div className="bg-red-100 border-4 border-red-500 rounded-lg p-5 space-y-3">
              <div className="flex items-center gap-3 justify-center">
                <AlertTriangle className="w-10 h-10 text-red-600" />
                <h3 className="font-black text-red-900 text-2xl">NGUY HIỂM CỰC ĐỘ!</h3>
              </div>
              <div className="bg-red-200 p-3 rounded">
                <p className="text-red-900 font-bold text-center text-lg mb-2">⚠️ PRIVATE KEY = TOÀN BỘ TÀI SẢN ⚠️</p>
                <ul className="text-sm text-red-900 font-semibold space-y-1.5">
                  <li>🔴 Ai có Private Key = SỞ HỮU VÍ VĨNH VIỄN</li>
                  <li>🔴 KHÔNG THỂ KHÔI PHỤC nếu bị lộ</li>
                  <li>🔴 Olivia PiMask KHÔNG BAO GIỜ lưu hoặc yêu cầu</li>
                  <li>🔴 TUYỆT ĐỐI KHÔNG gửi qua mạng, email, chat</li>
                  <li>🔴 Chỉ dùng để import sang ví khác</li>
                </ul>
              </div>
            </div>

            <div className="space-y-3">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-3">
                <Fingerprint className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900 text-sm">Xác thực Face ID</p>
                  <p className="text-xs text-blue-700">Bảo vệ Private Key bằng sinh trắc học</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="bg-red-50 border-2 border-red-300 rounded-lg p-3">
              <p className="text-sm text-red-800 font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Đảm bảo KHÔNG AI nhìn thấy màn hình của bạn!
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="font-semibold">Private Key của bạn</Label>
                <Button variant="ghost" size="sm" onClick={() => setShowKey(!showKey)} className="h-8">
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>

              <div className="bg-gray-900 border-2 border-purple-500 rounded-lg p-4 font-mono text-sm">
                {showKey ? (
                  <p className="text-green-400 break-all">{demoPrivateKey}</p>
                ) : (
                  <p className="text-center text-gray-500 py-4">••••••••••••••••••••••••••••••••</p>
                )}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleCopy}
                className="w-full border-purple-300 bg-transparent"
              >
                <Copy className="w-4 h-4 mr-2" />
                Sao chép Private Key
              </Button>
            </div>

            <div className="bg-yellow-50 border border-yellow-300 rounded p-2">
              <p className="text-xs text-yellow-800">💡 Lưu Private Key vào nơi an toàn OFFLINE (giấy, két sắt)</p>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={handleClose} className="flex-1 bg-transparent">
            {isVerified ? "Đóng" : "Hủy"}
          </Button>
          {!isVerified && (
            <Button
              onClick={handleFaceIDAuth}
              disabled={isAuthenticating}
              className="flex-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600"
            >
              {isAuthenticating ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Đang xác thực...
                </div>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4 mr-2" />
                  Sử dụng Face ID
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
