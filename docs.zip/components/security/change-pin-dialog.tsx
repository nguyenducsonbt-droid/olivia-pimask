"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lock } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ChangePinDialogProps {
  open: boolean
  onClose: () => void
}

export function ChangePinDialog({ open, onClose }: ChangePinDialogProps) {
  const [oldPin, setOldPin] = useState("")
  const [newPin, setNewPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const { toast } = useToast()

  const isValid = oldPin.length >= 4 && newPin.length >= 4 && confirmPin.length >= 4 && newPin === confirmPin

  const handleConfirm = () => {
    if (!isValid) return

    // UI only - no real functionality
    toast({
      title: "Thành công",
      description: "Mã PIN đã được thay đổi",
    })
    onClose()
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-purple-600" />
            Đổi mã PIN
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="old-pin">Mã PIN hiện tại</Label>
            <Input
              id="old-pin"
              type="password"
              placeholder="Nhập mã PIN hiện tại"
              value={oldPin}
              onChange={(e) => setOldPin(e.target.value)}
              maxLength={6}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-pin">Mã PIN mới</Label>
            <Input
              id="new-pin"
              type="password"
              placeholder="Nhập mã PIN mới (4-6 số)"
              value={newPin}
              onChange={(e) => setNewPin(e.target.value)}
              maxLength={6}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-pin">Xác nhận mã PIN mới</Label>
            <Input
              id="confirm-pin"
              type="password"
              placeholder="Nhập lại mã PIN mới"
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value)}
              maxLength={6}
            />
          </div>

          {newPin && confirmPin && newPin !== confirmPin && (
            <p className="text-sm text-red-500">Mã PIN xác nhận không khớp</p>
          )}
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
            Hủy
          </Button>
          <Button onClick={handleConfirm} disabled={!isValid} className="flex-1 bg-purple-600 hover:bg-purple-700">
            Xác nhận
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
