"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mail, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { sendEmailOTP, verifyEmailOTP, saveEmailOTPData, getOTPExpirationTime } from "@/lib/email-otp"

interface EmailOTPSetupDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
}

export function EmailOTPSetupDialog({ open, onClose, onSuccess }: EmailOTPSetupDialogProps) {
  const [step, setStep] = useState<"email" | "verify">("email")
  const [email, setEmail] = useState("")
  const [otp, setOtp] = useState("")
  const [loading, setLoading] = useState(false)
  const [demoOTP, setDemoOTP] = useState<string>("")
  const [countdown, setCountdown] = useState(0)
  const { toast } = useToast()

  const handleSendOTP = async () => {
    if (!email || !email.includes("@")) {
      toast({
        title: "Email không hợp lệ",
        description: "Vui lòng nhập địa chỉ email đúng",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      const result = await sendEmailOTP(email)

      if (result.success) {
        setDemoOTP(result.otp || "") // For demo only
        setStep("verify")
        setCountdown(300) // 5 minutes

        // Start countdown
        const interval = setInterval(() => {
          const remaining = getOTPExpirationTime()
          if (remaining === null || remaining <= 0) {
            clearInterval(interval)
            setCountdown(0)
          } else {
            setCountdown(Math.ceil(remaining / 1000))
          }
        }, 1000)

        toast({
          title: "Đã gửi mã OTP",
          description: `Kiểm tra hộp thư ${email}`,
        })
      } else {
        toast({
          title: "Lỗi gửi OTP",
          description: result.error || "Vui lòng thử lại",
          variant: "destructive",
        })
      }
    } finally {
      setLoading(false)
    }
  }

  const handleVerifyOTP = () => {
    if (otp.length !== 6) {
      toast({
        title: "Mã OTP không đúng",
        description: "Vui lòng nhập đầy đủ 6 số",
        variant: "destructive",
      })
      return
    }

    const result = verifyEmailOTP(otp)

    if (result.success) {
      saveEmailOTPData(email, true)
      toast({
        title: "Email 2FA đã kích hoạt",
        description: "Giao dịch lớn giờ yêu cầu mã OTP từ email",
      })
      onSuccess()
      onClose()
    } else {
      toast({
        title: "Xác thực thất bại",
        description: result.error || "Mã OTP không đúng",
        variant: "destructive",
      })
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-blue-600" />
            Thiết lập Email OTP
          </DialogTitle>
          <DialogDescription>Nhận mã xác thực qua Gmail của bạn</DialogDescription>
        </DialogHeader>

        {step === "email" ? (
          <div className="space-y-4 py-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center">
                <Mail className="w-12 h-12 text-blue-600" />
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-lg text-center">Xác thực qua Email</h3>
              <p className="text-sm text-muted-foreground text-center">
                Mã OTP 6 số sẽ được gửi đến email của bạn mỗi khi thực hiện giao dịch lớn
              </p>
            </div>

            <div className="space-y-3 bg-blue-50 p-4 rounded-lg">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Không cần cài app</p>
                  <p className="text-xs text-muted-foreground">Chỉ cần Gmail/Email bạn đang dùng</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Dễ sử dụng</p>
                  <p className="text-xs text-muted-foreground">Nhận mã ngay trong hộp thư</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">An toàn</p>
                  <p className="text-xs text-muted-foreground">Mã OTP hết hạn sau 5 phút</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Địa chỉ Email / Gmail</Label>
              <Input
                id="email"
                type="email"
                placeholder="pioneer@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="text-sm"
              />
              <p className="text-xs text-muted-foreground">Nhập email bạn thường xuyên kiểm tra</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-center">Kiểm tra Email của bạn</h3>
              <p className="text-sm text-muted-foreground text-center">
                Mã OTP 6 số đã được gửi đến <strong>{email}</strong>
              </p>
            </div>

            {/* Demo OTP display - Remove in production */}
            {demoOTP && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs text-yellow-800 font-medium mb-1">Demo Mode - Mã OTP của bạn:</p>
                    <p className="font-mono text-xl font-bold text-yellow-900 text-center bg-yellow-100 py-2 rounded">
                      {demoOTP}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="otp">Nhập mã OTP 6 số</Label>
              <Input
                id="otp"
                type="text"
                placeholder="000000"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="text-center text-lg font-mono tracking-widest"
              />
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Mã từ email {email}</span>
                {countdown > 0 && (
                  <span className="flex items-center gap-1 text-orange-600 font-medium">
                    <Clock className="w-3 h-3" />
                    {formatTime(countdown)}
                  </span>
                )}
              </div>
            </div>

            <Button
              onClick={handleSendOTP}
              variant="outline"
              size="sm"
              className="w-full bg-transparent"
              disabled={countdown > 240} // Can resend after 1 minute
            >
              Gửi lại mã OTP
            </Button>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
            Hủy
          </Button>
          {step === "email" ? (
            <Button onClick={handleSendOTP} disabled={loading} className="flex-1 bg-blue-600 hover:bg-blue-700">
              {loading ? "Đang gửi..." : "Gửi mã OTP"}
            </Button>
          ) : (
            <Button
              onClick={handleVerifyOTP}
              disabled={otp.length !== 6}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Xác nhận
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
