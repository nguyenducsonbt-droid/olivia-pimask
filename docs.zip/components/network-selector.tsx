"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useWallet } from "@/hooks/use-wallet"
import { ChevronDown, Plus } from "lucide-react"
import { useState } from "react"
import { AddNetworkDialog } from "./add-network-dialog"
import { useLanguage } from "@/hooks/use-language"
import { useToast } from "@/hooks/use-toast"

export function NetworkSelector() {
  const { networks, currentNetwork, setCurrentNetwork } = useWallet()
  const [showAddNetwork, setShowAddNetwork] = useState(false)
  const { language } = useLanguage()
  const { toast } = useToast()

  const handleNetworkSwitch = async (network: typeof currentNetwork) => {
    try {
      // Try to use Pi SDK network switch if available
      if (typeof window !== "undefined" && (window as any).Pi?.network?.switch) {
        try {
          await (window as any).Pi.network.switch(network.chainId)
        } catch (error) {
          console.log("[v0] Pi SDK network switch not available, using local switch")
        }
      }

      setCurrentNetwork(network)

      // Show testnet notification
      if (network.id.includes("testnet")) {
        toast({
          title: "Testnet – Swap Pi test miễn phí",
          description: `Đã chuyển sang ${network.name} (Chain ID: ${network.chainId})`,
          duration: 3000,
        })
      } else {
        toast({
          title: language === "vi" ? "Đã chuyển mạng" : "Network Switched",
          description: `${network.name} (Chain ID: ${network.chainId})`,
          duration: 2000,
        })
      }
    } catch (error) {
      console.error("[v0] Network switch error:", error)
      toast({
        title: language === "vi" ? "Lỗi chuyển mạng" : "Network Switch Error",
        description: language === "vi" ? "Không thể chuyển mạng, vui lòng thử lại" : "Unable to switch network",
        variant: "destructive",
      })
    }
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 bg-transparent transition-all duration-300 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(0, 255, 157, 0.1) 100%)",
              transition: "all 0.3s ease",
            }}
          >
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            {currentNetwork.name}
            <ChevronDown className="w-4 h-4 transition-transform duration-300" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56 max-h-[400px] overflow-y-auto">
          <DropdownMenuLabel>{language === "vi" ? "Chọn mạng" : "Select Network"}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {networks.map((network) => (
            <DropdownMenuItem
              key={network.id}
              onClick={() => handleNetworkSwitch(network)}
              className="transition-all duration-200 hover:bg-purple-50 cursor-pointer"
              style={{
                background: currentNetwork.id === network.id ? "rgba(139, 92, 246, 0.1)" : "transparent",
              }}
            >
              <div className="flex items-center justify-between w-full gap-2">
                <div className="flex flex-col flex-1 min-w-0">
                  <span className="font-medium">{network.name}</span>
                  <span className="text-xs text-muted-foreground">Chain ID: {network.chainId}</span>
                </div>
                {currentNetwork.id === network.id && <span className="text-primary text-lg">✓</span>}
              </div>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setShowAddNetwork(true)} className="hover:bg-purple-50">
            <Plus className="w-4 h-4 mr-2" />
            {language === "vi" ? "Thêm mạng" : "Add Network"}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <AddNetworkDialog open={showAddNetwork} onOpenChange={setShowAddNetwork} />
    </>
  )
}
