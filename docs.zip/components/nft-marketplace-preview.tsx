"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, ImageIcon } from "lucide-react"

const hotCollections = [
  {
    name: "Pi Punks",
    image: "/placeholder.svg?height=120&width=120",
    floor: "15 Pi",
  },
  {
    name: "Pi Apes",
    image: "/placeholder.svg?height=120&width=120",
    floor: "25 Pi",
  },
  {
    name: "Pi Art",
    image: "/placeholder.svg?height=120&width=120",
    floor: "10 Pi",
  },
]

export function NFTMarketplacePreview() {
  const handleOpenMarketplace = () => {
    // Open Pi NFT marketplace
    window.open("https://nftpi.io", "_blank")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">NFTs của bạn</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Empty State Message */}
        <div className="text-center py-6">
          <ImageIcon className="w-12 h-12 mx-auto mb-3 text-purple-300" />
          <p className="text-sm font-medium text-gray-900 mb-1">Chưa có NFT nào</p>
          <p className="text-xs text-gray-500">Khám phá và sưu tầm NFT độc đáo trên Pi Network</p>
        </div>

        {/* Hot Collections Preview */}
        <div>
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Collection HOT 🔥</h3>
          <div className="grid grid-cols-3 gap-3 mb-4">
            {hotCollections.map((collection, index) => (
              <div key={index} className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg overflow-hidden">
                <div className="aspect-square bg-white/50">
                  <img
                    src={collection.image || "/placeholder.svg"}
                    alt={collection.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-2">
                  <p className="text-xs font-semibold text-gray-900 truncate">{collection.name}</p>
                  <p className="text-xs text-purple-600 font-medium">{collection.floor}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Button */}
        <Button
          onClick={handleOpenMarketplace}
          className="w-full text-white font-semibold"
          style={{
            background: "linear-gradient(135deg, #9C27B0 0%, #E91E63 100%)",
          }}
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          Khám phá Marketplace
        </Button>
      </CardContent>
    </Card>
  )
}
