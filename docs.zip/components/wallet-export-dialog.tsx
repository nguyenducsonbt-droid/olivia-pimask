"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Copy, QrCode, AlertTriangle, Lock, Info } from "lucide-react"
import { toast } from "sonner"
import QRCode from "qrcode"
import { getWalletData, getCustomTokens, getCustomNetworks } from "@/lib/storage"

interface WalletExportDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function WalletExportDialog({ open, onOpenChange }: WalletExportDialogProps) {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showQR, setShowQR] = useState(false)
  const [qrDataUrl, setQrDataUrl] = useState("")
  const [step, setStep] = useState<"password" | "export">("password")
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePasswordSubmit = () => {
    if (!password || password.length < 8) {
      toast.error("Mật khẩu phải có ít nhất 8 ký tự")
      return
    }
    if (password !== confirmPassword) {
      toast.error("Mật khẩu xác nhận không khớp")
      return
    }
    setStep("export")
  }

  const copyBackupText = async () => {
    if (isProcessing) return

    try {
      setIsProcessing(true)

      const walletData = getWalletData()
      const customTokens = getCustomTokens()
      const customNetworks = getCustomNetworks()

      if (!walletData) {
        toast.error("Không tìm thấy dữ liệu ví")
        setIsProcessing(false)
        return
      }

      const backupData = {
        version: "1.0",
        wallet: walletData,
        customTokens,
        customNetworks,
        exportDate: new Date().toISOString(),
      }

      // Encrypt with password using XOR cipher
      const encrypted = btoa(
        JSON.stringify(backupData)
          .split("")
          .map((char, i) => String.fromCharCode(char.charCodeAt(0) ^ password.charCodeAt(i % password.length)))
          .join(""),
      )

      // Copy to clipboard
      await navigator.clipboard.writeText(encrypted)

      toast.success("Đã copy backup text! Dán vào note bảo mật để lưu nhé 🎉", {
        duration: 4000,
      })

      // Reset state after short delay
      setTimeout(() => {
        setIsProcessing(false)
        setPassword("")
        setConfirmPassword("")
        setStep("password")
        onOpenChange(false)
      }, 1000)
    } catch (error) {
      console.error("Copy error:", error)
      toast.error("Lỗi khi copy backup: " + (error as Error).message)
      setIsProcessing(false)
    }
  }

  const generateQR = async () => {
    if (isProcessing) return

    try {
      setIsProcessing(true)

      const walletData = getWalletData()
      const customTokens = getCustomTokens()
      const customNetworks = getCustomNetworks()

      if (!walletData) {
        toast.error("Không tìm thấy dữ liệu ví")
        setIsProcessing(false)
        return
      }

      const backupData = {
        version: "1.0",
        wallet: walletData,
        customTokens,
        customNetworks,
        exportDate: new Date().toISOString(),
      }

      // Encrypt with password
      const encrypted = btoa(
        JSON.stringify(backupData)
          .split("")
          .map((char, i) => String.fromCharCode(char.charCodeAt(0) ^ password.charCodeAt(i % password.length)))
          .join(""),
      )

      // Generate QR code with high quality
      const qrUrl = await QRCode.toDataURL(encrypted, {
        width: 512,
        margin: 2,
        color: {
          dark: "#7B1FA2",
          light: "#FFFFFF",
        },
        errorCorrectionLevel: "H",
      })

      setQrDataUrl(qrUrl)
      setShowQR(true)
      setIsProcessing(false)

      toast.success("QR backup tạo thành công! Chụp màn hình để lưu", {
        duration: 3000,
      })
    } catch (error) {
      console.error("QR generation error:", error)
      toast.error("Lỗi khi tạo QR: " + (error as Error).message)
      setIsProcessing(false)
    }
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      // Reset all states when closing
      setPassword("")
      setConfirmPassword("")
      setShowQR(false)
      setQrDataUrl("")
      setStep("password")
      setIsProcessing(false)
    }
    onOpenChange(open)
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md bg-white dark:bg-[#2C003E] border-purple-300 dark:border-purple-500">
        <DialogHeader>
          <DialogTitle className="text-purple-900 dark:text-purple-200 flex items-center gap-2">
            <Copy className="w-5 h-5" />
            Export Ví Nhanh
          </DialogTitle>
        </DialogHeader>

        {step === "password" ? (
          <div className="space-y-4">
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 dark:text-red-300">
                  <strong>Cảnh báo an toàn:</strong> Không chia sẻ file/QR backup với ai. Mất mật khẩu = mất ví vĩnh
                  viễn.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="backup-password" className="text-purple-900 dark:text-purple-200">
                Mật khẩu backup (tối thiểu 8 ký tự)
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
                <Input
                  id="backup-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 border-purple-300 dark:border-purple-500 focus:border-purple-500 dark:focus:border-purple-400"
                  placeholder="Nhập mật khẩu mạnh"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-password" className="text-purple-900 dark:text-purple-200">
                Xác nhận mật khẩu
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
                <Input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10 border-purple-300 dark:border-purple-500 focus:border-purple-500 dark:focus:border-purple-400"
                  placeholder="Nhập lại mật khẩu"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handlePasswordSubmit()
                    }
                  }}
                />
              </div>
            </div>

            <Button
              onClick={handlePasswordSubmit}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900"
            >
              Tiếp tục
            </Button>
          </div>
        ) : showQR ? (
          <div className="space-y-4">
            <div className="flex justify-center p-4 bg-white dark:bg-gray-100 rounded-lg">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl || "/placeholder.svg"}
                  alt="QR Backup"
                  className="w-80 h-80 border-4 border-purple-300 dark:border-purple-500 rounded-lg"
                />
              ) : (
                <div className="w-80 h-80 border-4 border-purple-300 dark:border-purple-500 rounded-lg flex items-center justify-center bg-gray-100">
                  <p className="text-gray-500">Đang tạo QR...</p>
                </div>
              )}
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg p-3">
              <p className="text-sm text-center text-purple-800 dark:text-purple-300 font-medium leading-relaxed">
                Chụp màn hình QR này để backup an toàn!
                <br />
                <span className="text-xs">(Long press Power + Volume Down) 💜</span>
              </p>
            </div>

            <Button
              variant="outline"
              onClick={() => setShowQR(false)}
              className="w-full border-purple-300 dark:border-purple-500"
            >
              Quay lại
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-blue-700 dark:text-blue-300">
                  Backup an toàn nhất hiện tại: Chụp QR hoặc copy text (Pi Browser chưa hỗ trợ tải file tự động)
                </p>
              </div>
            </div>

            <Button
              onClick={copyBackupText}
              disabled={isProcessing}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Copy className="w-4 h-4 mr-2" />
              {isProcessing ? "Đang copy..." : "Copy Backup Text"}
            </Button>

            <Button
              onClick={generateQR}
              disabled={isProcessing}
              variant="outline"
              className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200 bg-transparent disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <QrCode className="w-4 h-4 mr-2" />
              {isProcessing ? "Đang tạo..." : "Tạo QR backup"}
            </Button>

            <p className="text-xs text-center text-purple-600 dark:text-purple-400">
              Dữ liệu chứa seed, token và cài đặt được mã hóa
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
