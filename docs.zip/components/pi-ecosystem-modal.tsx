"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

interface PiEcosystemModalProps {
  onClose: () => void
  onSelectApp: (url: string) => void
}

export default function PiEcosystemModal({ onClose, onSelectApp }: PiEcosystemModalProps) {
  const ecosystemApps = [
    {
      name: "My Profile",
      description: "Xem profile, @username, bạn bè và hoạt động",
      url: "pi://profile",
      icon: "👤",
    },
    {
      name: "Pi Browser",
      description: "Trình duyệt chính thức Pi Network",
      url: "https://browser.pi",
      icon: "🌐",
    },
    {
      name: "Pi Wallet",
      description: "Ví chính thức Pi Network",
      url: "pi://wallet",
      icon: "💼",
    },
    {
      name: "Pi Ecosystem",
      description: "Khám phá dApps và ứng dụng Pi",
      url: "https://ecosystem.pinet.com",
      icon: "🚀",
    },
    {
      name: "Pi Chat",
      description: "Trò chuyện với Pioneer khác",
      url: "pi://chat",
      icon: "💬",
    },
    {
      name: "Fireside Forum",
      description: "Cộng đồng thảo luận Pi",
      url: "https://minepi.com/fireside-forum",
      icon: "🔥",
    },
  ]

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Welcome to Pi Ecosystem!
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {ecosystemApps.map((app) => (
            <Button
              key={app.url}
              onClick={() => {
                onSelectApp(app.url)
                // Don't close immediately - let handler close after opening
              }}
              variant="outline"
              className="w-full h-auto p-4 flex items-start gap-3 hover:bg-purple-50 transition-colors"
            >
              <span className="text-3xl">{app.icon}</span>
              <div className="flex-1 text-left">
                <div className="font-semibold text-base flex items-center gap-2">
                  {app.name}
                  <ExternalLink className="w-4 h-4 text-purple-600" />
                </div>
                <p className="text-sm text-muted-foreground">{app.description}</p>
              </div>
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
