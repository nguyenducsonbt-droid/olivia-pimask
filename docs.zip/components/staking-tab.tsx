"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, Lock, Unlock, AlertCircle, Zap } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"

interface LockupPool {
  id: string
  name: string
  miningBoost: number // Mining rate boost percentage
  minLock: number
  totalLocked: number
  myLocked: number
  lockPeriod: string
  status: "active" | "inactive"
  description: string
}

export function StakingTab() {
  const { address, currentNetwork } = useWallet()
  const { toast } = useToast()
  const [lockupPools, setLockupPools] = useState<LockupPool[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPool, setSelectedPool] = useState<LockupPool | null>(null)
  const [showLockDialog, setShowLockDialog] = useState(false)
  const [showUnlockDialog, setShowUnlockDialog] = useState(false)
  const [lockAmount, setLockAmount] = useState("")
  const [unlockAmount, setUnlockAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    fetchLockupPools()
  }, [address, currentNetwork])

  const fetchLockupPools = async () => {
    setLoading(true)
    try {
      const mockPools: LockupPool[] = [
        {
          id: "pi-voluntary-lockup-30d",
          name: "30 Days Voluntary Lockup",
          miningBoost: 50, // +50% mining rate boost
          minLock: 10,
          totalLocked: 1250000,
          myLocked: 0,
          lockPeriod: "30 ngày",
          status: "active",
          description: "Lock Pi để tăng 50% mining rate trong 30 ngày",
        },
        {
          id: "pi-voluntary-lockup-90d",
          name: "90 Days Voluntary Lockup",
          miningBoost: 100, // +100% mining rate boost
          minLock: 50,
          totalLocked: 3500000,
          myLocked: 0,
          lockPeriod: "90 ngày",
          status: "active",
          description: "Lock Pi để tăng 100% mining rate trong 90 ngày",
        },
        {
          id: "pi-voluntary-lockup-180d",
          name: "180 Days Voluntary Lockup",
          miningBoost: 200, // +200% mining rate boost
          minLock: 100,
          totalLocked: 5750000,
          myLocked: 0,
          lockPeriod: "180 ngày",
          status: "active",
          description: "Lock Pi để tăng 200% mining rate trong 180 ngày",
        },
      ]

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setLockupPools(mockPools)
    } catch (error) {
      console.error("[v0] Failed to fetch lockup pools:", error)
      toast({
        title: "Lỗi",
        description: "Không thể tải thông tin Voluntary Lockup",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleLock = async () => {
    if (!selectedPool || !lockAmount) return

    const amount = Number.parseFloat(lockAmount)
    if (amount < selectedPool.minLock) {
      toast({
        title: "Số lượng không hợp lệ",
        description: `Số lượng tối thiểu là ${selectedPool.minLock} Pi`,
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Lock thành công!",
        description: `Đã lock ${amount} Pi vào ${selectedPool.name}. Mining rate tăng ${selectedPool.miningBoost}%!`,
      })

      setShowLockDialog(false)
      setLockAmount("")
      await fetchLockupPools()
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể lock. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleUnlock = async () => {
    if (!selectedPool || !unlockAmount) return

    const amount = Number.parseFloat(unlockAmount)
    if (amount > selectedPool.myLocked) {
      toast({
        title: "Số lượng không hợp lệ",
        description: `Bạn chỉ có ${selectedPool.myLocked} Pi đang lock`,
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Unlock thành công!",
        description: `Đã unlock ${amount} Pi từ ${selectedPool.name}`,
      })

      setShowUnlockDialog(false)
      setUnlockAmount("")
      await fetchLockupPools()
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể unlock. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-sm text-muted-foreground">Đang tải lockup pools...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            Pi Voluntary Lockup
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {lockupPools.map((pool) => (
              <div
                key={pool.id}
                className="bg-white dark:bg-gray-900 rounded-lg border border-purple-200 dark:border-purple-800 p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-purple-900 dark:text-purple-100">{pool.name}</h3>
                    <p className="text-xs text-purple-600 dark:text-purple-400">Lock: {pool.lockPeriod}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-purple-600 flex items-center gap-1">
                      <Zap className="w-5 h-5" />+{pool.miningBoost}%
                    </div>
                    <p className="text-xs text-purple-600 dark:text-purple-400">Mining Boost</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-purple-600 dark:text-purple-400">Min Lock</p>
                    <p className="font-semibold text-purple-900 dark:text-purple-100">{pool.minLock} Pi</p>
                  </div>
                  <div>
                    <p className="text-purple-600 dark:text-purple-400">Total Locked</p>
                    <p className="font-semibold text-purple-900 dark:text-purple-100">
                      {(pool.totalLocked / 1000000).toFixed(2)}M Pi
                    </p>
                  </div>
                </div>

                {pool.myLocked > 0 && (
                  <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3">
                    <p className="text-xs text-purple-600 dark:text-purple-400">Your Locked Pi</p>
                    <p className="text-lg font-bold text-purple-600">{pool.myLocked} Pi</p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      setSelectedPool(pool)
                      setShowLockDialog(true)
                    }}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
                    style={{
                      background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
                    }}
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Lock
                  </Button>
                  {pool.myLocked > 0 && (
                    <Button
                      onClick={() => {
                        setSelectedPool(pool)
                        setShowUnlockDialog(true)
                      }}
                      variant="outline"
                      className="flex-1 border-purple-600 text-purple-600 hover:bg-purple-50"
                    >
                      <Unlock className="w-4 h-4 mr-2" />
                      Unlock
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-purple-900 dark:text-purple-300">
              Voluntary Lockup: Lock Pi để tăng mining rate. Không có lãi suất APR, chỉ boost mining theo % lock. Pi
              được trả về sau khi hết lock period. Dựa trên Pi Network Whitepaper official.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Lock Dialog */}
      <Dialog open={showLockDialog} onOpenChange={setShowLockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Lock Pi - Voluntary Lockup</DialogTitle>
            <DialogDescription>
              {selectedPool && `Lock vào ${selectedPool.name} để boost mining rate +${selectedPool.miningBoost}%`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="lock-amount">Số lượng Pi</Label>
              <Input
                id="lock-amount"
                type="number"
                placeholder={`Tối thiểu ${selectedPool?.minLock || 0} Pi`}
                value={lockAmount}
                onChange={(e) => setLockAmount(e.target.value)}
              />
            </div>
            {selectedPool && (
              <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-purple-600 dark:text-purple-400">Lock Period:</span>
                  <span className="font-semibold text-purple-900 dark:text-purple-100">{selectedPool.lockPeriod}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-600 dark:text-purple-400">Mining Boost:</span>
                  <span className="font-semibold text-purple-600 flex items-center gap-1">
                    <Zap className="w-4 h-4" />+{selectedPool.miningBoost}%
                  </span>
                </div>
                <p className="text-xs text-purple-600 dark:text-purple-400 pt-2">{selectedPool.description}</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLockDialog(false)}>
              Hủy
            </Button>
            <Button
              onClick={handleLock}
              disabled={isProcessing}
              className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white"
              style={{
                background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
              }}
            >
              {isProcessing ? "Đang xử lý..." : "Xác nhận Lock"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Unlock Dialog */}
      <Dialog open={showUnlockDialog} onOpenChange={setShowUnlockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Unlock Pi</DialogTitle>
            <DialogDescription>{selectedPool && `Unlock Pi từ ${selectedPool.name}`}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="unlock-amount">Số lượng Pi</Label>
              <Input
                id="unlock-amount"
                type="number"
                placeholder={`Tối đa ${selectedPool?.myLocked || 0} Pi`}
                value={unlockAmount}
                onChange={(e) => setUnlockAmount(e.target.value)}
              />
            </div>
            {selectedPool && selectedPool.myLocked > 0 && (
              <div className="bg-purple-50 dark:bg-purple-950/30 rounded-lg p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-purple-600 dark:text-purple-400">Your Locked Amount:</span>
                  <span className="font-semibold text-purple-900 dark:text-purple-100">{selectedPool.myLocked} Pi</span>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUnlockDialog(false)}>
              Hủy
            </Button>
            <Button onClick={handleUnlock} disabled={isProcessing}>
              {isProcessing ? "Đang xử lý..." : "Xác nhận Unlock"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
