"use client"

import { useState, useEffect } from "react"
import { X, RefreshCw } from "lucide-react"
import { playSound } from "@/lib/sounds"
import { triggerHaptic } from "@/lib/haptics"
import { loadPiSession, savePiSession } from "@/lib/persistent-storage"
import { useToast } from "@/hooks/use-toast"

export function PiBrowserMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [connectedUser, setConnectedUser] = useState<{ username: string; uid: string } | null>(null)
  const [piBalance, setPiBalance] = useState<number | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    const loadSavedSession = async () => {
      const session = await loadPiSession()
      if (session && session.user) {
        setConnectedUser(session.user)
        setIsConnected(true)

        try {
          // @ts-ignore
          if (window.Pi && window.Pi.getBalance) {
            // @ts-ignore
            const balance = await window.Pi.getBalance()
            setPiBalance(balance)
          }
        } catch (error) {
          console.error("Could not fetch balance on load:", error)
        }
      }
    }

    loadSavedSession()
  }, [])

  const handleOpenMenu = () => {
    playSound("click")
    triggerHaptic("light")
    setIsOpen(true)
  }

  const handleClose = () => {
    playSound("click")
    triggerHaptic("light")
    setIsOpen(false)
  }

  const afterConnectSuccess = (user: { username: string; uid: string }) => {
    // Update button state and appearance
    setConnectedUser(user)
    setIsConnected(true)

    // Show sweet success message
    toast({
      title: "Đã kết nối siêu ví !",
      description: `Bấm lại nút để mở ví xem balance Mainnet nhé 🎉❤️`,
      duration: 3000,
    })

    // Close popup after short delay
    setTimeout(() => {
      setIsOpen(false)
    }, 500)
  }

  const handleConnectPiMainnet = async () => {
    console.log("[v0] Pi Connect button clicked")

    // Check if in Pi Browser
    const isPiBrowser =
      typeof window !== "undefined" &&
      // @ts-ignore
      (window.navigator.userAgent.includes("PiBrowser") || window.Pi !== undefined)

    if (!isPiBrowser) {
      console.log("[v0] Not in Pi Browser")
      toast({
        title: "Cần Pi Browser",
        description: "Mở Olivia trong Pi Browser để kết nối Pi Mainnet nhé ❤️",
        duration: 3000,
      })
      return
    }

    console.log("[v0] Starting Pi authentication...")

    try {
      // @ts-ignore
      if (!window.Pi) {
        throw new Error("Pi SDK không khả dụng")
      }

      // @ts-ignore
      const authResult = await window.Pi.authenticate(["username", "payments", "wallet_address"], (payment: any) => {
        console.log("[v0] Incomplete payment:", payment)
      })

      console.log("[v0] Authentication successful:", authResult?.user?.username)

      // Save session
      await savePiSession(authResult)

      // Fetch balance
      try {
        // @ts-ignore
        const balanceResult = await window.Pi.getBalance()
        const balance = typeof balanceResult === "number" ? balanceResult : (balanceResult?.balance ?? null)
        setPiBalance(balance)
        console.log("[v0] Balance fetched:", balance)
      } catch (balanceError) {
        console.warn("[v0] Could not fetch balance:", balanceError)
      }

      // Dispatch events
      window.dispatchEvent(
        new CustomEvent("olivia-pi-session-changed", {
          detail: { user: authResult.user, balance: piBalance },
        }),
      )

      afterConnectSuccess(authResult.user)
    } catch (error) {
      console.error("[v0] Pi authentication error:", error)
      toast({
        title: "Kết nối thất bại",
        description: "Không thể kết nối Pi Network. Vui lòng thử lại.",
        variant: "destructive",
        duration: 3000,
      })
    } finally {
      console.log("[v0] Connection attempt complete")
    }
  }

  const handleOpenPiWallet = () => {
    if (!connectedUser) {
      // Not connected yet, open the menu to connect
      handleOpenMenu()
      return
    }

    playSound("click")
    triggerHaptic("medium")

    toast({
      title: "Đang mở Explore the Ecosystem",
      description: "Chờ một chút nhé...",
      duration: 2000,
    })

    try {
      const ecosystemUrl = "https://ecosystem.pinet.com"

      // Use window.location.href for reliable navigation in Pi Browser
      window.location.href = ecosystemUrl

      console.log("[v0] Opening Pi Ecosystem:", ecosystemUrl)
    } catch (error) {
      console.error("[v0] Failed to open Pi Ecosystem:", error)

      toast({
        title: "Không thể mở Pi Ecosystem",
        description: "Vui lòng thử lại",
        variant: "destructive",
        duration: 2000,
      })
    }
  }

  const handleRefreshBalance = async () => {
    if (!connectedUser) return

    try {
      // @ts-ignore
      if (window.Pi && window.Pi.getBalance) {
        // @ts-ignore
        const balanceResult = await window.Pi.getBalance()
        if (balanceResult && typeof balanceResult === "object" && "balance" in balanceResult) {
          setPiBalance(balanceResult.balance)
        } else if (typeof balanceResult === "number") {
          setPiBalance(balanceResult)
        }
        toast({
          title: "Đã làm mới balance",
          description: "Balance Pi đã được cập nhật",
          duration: 2000,
        })
      }
    } catch (error) {
      console.error("Failed to refresh balance:", error)
    }
  }

  return (
    <>
      {/* Pi Browser Icon Button */}
      <button
        onClick={handleOpenPiWallet}
        className="relative p-2 rounded-full hover:bg-white/20 transition-all duration-200 active:scale-95"
        aria-label="Pi Browser Menu"
      >
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center text-white font-bold text-sm shadow-lg">
          {connectedUser ? (
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
              <path
                d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
                fill="white"
              />
              <path d="M11 8h2v8h-2V8z" fill="white" />
              <path d="M8 11h8v2H8v-2z" fill="white" />
            </svg>
          ) : (
            "π"
          )}
        </div>

        {connectedUser && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-purple-600 animate-pulse" />
        )}
      </button>

      {/* Popup Menu */}
      {isOpen && (
        <>
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9998] cursor-pointer"
            onClick={(e) => {
              e.stopPropagation()
              handleClose()
            }}
          />

          <div className="fixed inset-x-4 top-1/2 -translate-y-1/2 bg-white dark:bg-gray-900 rounded-3xl shadow-2xl z-[9999] max-w-md mx-auto overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-purple-200/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {connectedUser ? (
                    <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
                      <path
                        d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
                        fill="white"
                      />
                      <path d="M11 8h2v8h-2V8z" fill="white" />
                      <path d="M8 11h8v2H8v-2z" fill="white" />
                    </svg>
                  ) : (
                    "π"
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900 dark:text-white">
                    {connectedUser ? (
                      <span className="flex items-center gap-2">
                        Ví Pi • Đã kết nối<span className="text-green-500">✓</span>
                      </span>
                    ) : (
                      "Pi Browser"
                    )}
                  </h3>
                  {connectedUser ? (
                    <p className="text-xs text-green-600 dark:text-green-400">@{connectedUser.username}</p>
                  ) : (
                    <p className="text-xs text-gray-500 dark:text-gray-400">Liên kết với Pi Network</p>
                  )}
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  handleClose()
                }}
                className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800/50 transition-colors cursor-pointer z-10"
                aria-label="Đóng"
              >
                <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              </button>
            </div>

            {/* Balance Display */}
            {piBalance !== null && connectedUser && (
              <div className="px-6 py-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Pi Mainnet Balance</p>
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{piBalance} π</p>
                </div>
                <button
                  onClick={handleRefreshBalance}
                  className="p-2 rounded-full hover:bg-white/50 dark:hover:bg-gray-800/50 transition-colors"
                >
                  <RefreshCw className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                </button>
              </div>
            )}

            {connectedUser && (
              <div className="px-6 py-4 space-y-3">
                <button
                  onClick={() => {
                    handleClose()
                    handleOpenPiWallet()
                  }}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-200 active:scale-95 flex items-center justify-center gap-2"
                >
                  <span>🌐</span>
                  Explore the Ecosystem
                </button>
                <p className="text-xs text-center text-gray-500 dark:text-gray-400">
                  Khám phá App Studio, Wallet, Fireside, Staking & hơn thế nữa
                </p>
              </div>
            )}

            {/* Footer */}
            <div className="px-6 pb-6 pt-4">
              <p className="text-xs text-center text-gray-500 dark:text-gray-400">
                {connectedUser ? "Đã kết nối với Pi Network Mainnet chính chủ" : "Chưa kết nối với Pi Network"}
              </p>
            </div>
          </div>
        </>
      )}
    </>
  )
}
