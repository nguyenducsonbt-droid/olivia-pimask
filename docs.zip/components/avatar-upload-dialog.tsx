"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Upload, Wallet } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { saveAvatar } from "@/lib/persistent-storage"
import { optimizeImage } from "@/lib/image-optimizer"

interface AvatarUploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentAvatar: string | null
  onAvatarChange: (avatar: string | null) => void
}

export function AvatarUploadDialog({ open, onOpenChange, currentAvatar, onAvatarChange }: AvatarUploadDialogProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentAvatar)
  const [isCompressing, setIsCompressing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    setPreviewUrl(currentAvatar)
  }, [currentAvatar])

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Lỗi",
        description: "Vui lòng chọn file ảnh hợp lệ",
        variant: "destructive",
      })
      return
    }

    const targetSize = 200 * 1024 // 200KB
    let dataUrl: string

    if (file.size > targetSize) {
      setIsCompressing(true)
      toast({
        title: "Đang nén ảnh...",
        description: `Ảnh gốc ${(file.size / 1024).toFixed(0)}KB. Đang tối ưu về dưới 200KB`,
      })

      try {
        // Compress with aggressive quality reduction
        dataUrl = await optimizeImage(file, 400, 0.7)

        // Check if still too large, compress more aggressively
        while (dataUrl.length > targetSize && dataUrl.length > 0) {
          const currentQuality = 0.5 - (dataUrl.length / targetSize) * 0.1
          if (currentQuality < 0.3) break
          dataUrl = await optimizeImage(file, 300, Math.max(0.3, currentQuality))
        }

        if (dataUrl.length > targetSize) {
          toast({
            title: "Ảnh vẫn hơi nặng",
            description: "Đã nén tối đa! Khuyến nghị dùng ảnh nhỏ hơn để ví mượt hơn",
            variant: "destructive",
          })
          setIsCompressing(false)
          return
        }

        toast({
          title: "Nén thành công!",
          description: `Giảm xuống ${(dataUrl.length / 1024).toFixed(0)}KB. Ví sẽ mượt hơn`,
        })
      } catch (error) {
        toast({
          title: "Lỗi nén ảnh",
          description: "Vui lòng thử ảnh khác nhẹ hơn",
          variant: "destructive",
        })
        setIsCompressing(false)
        return
      }
      setIsCompressing(false)
    } else {
      // File already small enough, just read it
      const reader = new FileReader()
      dataUrl = await new Promise<string>((resolve, reject) => {
        reader.onload = (e) => resolve(e.target?.result as string)
        reader.onerror = reject
        reader.readAsDataURL(file)
      })
    }

    setPreviewUrl(dataUrl)
    await saveAvatar(dataUrl)
    onAvatarChange(dataUrl)

    // Dispatch multiple events to ensure all components update
    window.dispatchEvent(new CustomEvent("olivia-avatar-changed", { detail: { avatar: dataUrl } }))

    toast({
      title: "Thành công",
      description: "Avatar đã được lưu vĩnh viễn vào tất cả tầng lưu trữ",
    })

    // Close dialog automatically
    setTimeout(() => {
      onOpenChange(false)
    }, 500)
  }

  const handleReset = async () => {
    setPreviewUrl(null)
    await saveAvatar(null)
    onAvatarChange(null)

    // Dispatch events to update all components
    window.dispatchEvent(new CustomEvent("olivia-avatar-changed", { detail: { avatar: null } }))

    toast({
      title: "Đã đặt lại",
      description: "Sử dụng logo Olivia PiMask mặc định",
    })
    onOpenChange(false)
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white border-2 border-purple-200 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-purple-900">Chỉnh sửa Avatar</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Preview */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-purple-200 shadow-lg">
                {previewUrl ? (
                  <img
                    src={previewUrl || "/placeholder.svg"}
                    alt="Avatar preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-purple-700 to-pink-500 flex items-center justify-center">
                    <Wallet className="w-16 h-16 text-white" />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Hidden file input */}
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileSelect} className="hidden" />

          {/* Action Buttons */}
          <div className="space-y-2">
            <Button
              onClick={handleUploadClick}
              disabled={isCompressing}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:from-purple-700 hover:to-pink-600 font-bold"
            >
              {isCompressing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Đang nén...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Tải ảnh lên
                </>
              )}
            </Button>

            <Button
              onClick={handleReset}
              variant="outline"
              className="w-full border-2 border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              <Wallet className="w-4 h-4 mr-2" />
              Dùng logo mặc định
            </Button>
          </div>

          {/* Info text */}
          <p className="text-xs text-gray-500 text-center">
            Ảnh tối đa 200KB (tự động nén). Hỗ trợ JPG, PNG, GIF
            <br />💡 Tip: Dùng ảnh vuông 400x400px để tải nhanh hơn
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
