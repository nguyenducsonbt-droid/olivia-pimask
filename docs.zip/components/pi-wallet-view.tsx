"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { X, ArrowUpRight, ArrowDownLeft, RefreshCw, Copy, Check } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PiWalletViewProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  username: string
}

export function PiWalletView({ open, onOpenChange, username }: PiWalletViewProps) {
  const [balance, setBalance] = useState<number>(0)
  const [loading, setLoading] = useState(false)
  const [sendAmount, setSendAmount] = useState("")
  const [recipientAddress, setRecipientAddress] = useState("")
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (open) {
      fetchBalance()
    }
  }, [open])

  const fetchBalance = async () => {
    setLoading(true)
    try {
      const Pi = (window as any).Pi
      if (Pi) {
        // Note: Pi SDK doesn't directly expose balance, this is a placeholder
        // In real implementation, you'd use Pi.payments or backend API
        const mockBalance = Math.random() * 1000 // Mock balance for demo
        setBalance(mockBalance)

        toast({
          title: "Đã tải số dư",
          description: `Số dư Pi hiện tại: ${mockBalance.toFixed(2)} π`,
        })
      }
    } catch (error) {
      console.error("[v0] Failed to fetch balance:", error)
      toast({
        title: "Lỗi tải số dư",
        description: "Không thể lấy số dư Pi. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSend = async () => {
    if (!sendAmount || !recipientAddress) {
      toast({
        title: "Thiếu thông tin",
        description: "Vui lòng nhập số tiền và địa chỉ người nhận",
        variant: "destructive",
      })
      return
    }

    try {
      const Pi = (window as any).Pi
      const paymentData = {
        amount: Number.parseFloat(sendAmount),
        memo: `Gửi từ Olivia PiMask đến ${recipientAddress}`,
        metadata: { recipient: recipientAddress },
      }

      const payment = await Pi.createPayment(paymentData, {
        onReadyForServerApproval: (paymentId: string) => {
          console.log("[v0] Payment ready:", paymentId)
        },
        onReadyForServerCompletion: (paymentId: string, txid: string) => {
          console.log("[v0] Payment completed:", paymentId, txid)
          toast({
            title: "Giao dịch thành công",
            description: `Đã gửi ${sendAmount} π thành công!`,
          })
          setSendAmount("")
          setRecipientAddress("")
          fetchBalance()
        },
        onCancel: (paymentId: string) => {
          console.log("[v0] Payment cancelled:", paymentId)
          toast({
            title: "Đã hủy giao dịch",
            description: "Giao dịch đã được hủy bỏ",
          })
        },
        onError: (error: any, payment: any) => {
          console.error("[v0] Payment error:", error, payment)
          toast({
            title: "Lỗi giao dịch",
            description: error.message || "Không thể thực hiện giao dịch",
            variant: "destructive",
          })
        },
      })
    } catch (error: any) {
      console.error("[v0] Send error:", error)
      toast({
        title: "Lỗi gửi Pi",
        description: error.message || "Không thể gửi Pi. Vui lòng thử lại.",
        variant: "destructive",
      })
    }
  }

  const copyAddress = () => {
    navigator.clipboard.writeText(username)
    setCopied(true)
    toast({
      title: "Đã sao chép",
      description: "Địa chỉ ví đã được sao chép",
    })
    setTimeout(() => setCopied(false), 2000)
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-gray-900 flex flex-col">
      {/* Header */}
      <div
        className="px-4 py-3 flex items-center gap-3 shadow-md"
        style={{
          background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
        }}
      >
        <Button
          size="icon"
          variant="ghost"
          onClick={() => onOpenChange(false)}
          className="text-white hover:bg-white/20 rounded-full"
        >
          <X className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-white">Ví Pi</h2>
          <p className="text-xs text-white/80">@{username}</p>
        </div>
        <Button
          size="icon"
          variant="ghost"
          onClick={fetchBalance}
          disabled={loading}
          className="text-white hover:bg-white/20 rounded-full"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800 p-4">
        {/* Balance Card */}
        <Card className="p-6 mb-4 bg-gradient-to-br from-purple-600 to-pink-600 text-white border-0 shadow-xl">
          <p className="text-sm opacity-90 mb-2">Số dư khả dụng</p>
          <h3 className="text-4xl font-bold mb-4">{balance.toFixed(2)} π</h3>
          <div className="flex items-center gap-2 text-sm opacity-90">
            <span>Địa chỉ: @{username}</span>
            <Button size="icon" variant="ghost" onClick={copyAddress} className="h-6 w-6 text-white hover:bg-white/20">
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            </Button>
          </div>
        </Card>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Button
            className="h-20 flex flex-col gap-2 bg-gradient-to-br from-green-500 to-green-600 text-white hover:from-green-600 hover:to-green-700"
            onClick={() => {
              // Scroll to send section
              document.getElementById("send-section")?.scrollIntoView({ behavior: "smooth" })
            }}
          >
            <ArrowUpRight className="w-6 h-6" />
            <span>Gửi Pi</span>
          </Button>
          <Button
            className="h-20 flex flex-col gap-2 bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700"
            onClick={copyAddress}
          >
            <ArrowDownLeft className="w-6 h-6" />
            <span>Nhận Pi</span>
          </Button>
        </div>

        {/* Send Section */}
        <Card className="p-6" id="send-section">
          <h4 className="text-lg font-bold text-purple-900 dark:text-purple-200 mb-4">Gửi Pi</h4>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Số tiền (π)</label>
              <Input
                type="number"
                value={sendAmount}
                onChange={(e) => setSendAmount(e.target.value)}
                placeholder="0.00"
                className="border-purple-300 focus:border-purple-500"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                Địa chỉ người nhận
              </label>
              <Input
                value={recipientAddress}
                onChange={(e) => setRecipientAddress(e.target.value)}
                placeholder="@username hoặc địa chỉ Pi"
                className="border-purple-300 focus:border-purple-500"
              />
            </div>
            <Button
              onClick={handleSend}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700"
            >
              Gửi ngay
            </Button>
          </div>
        </Card>

        {/* Transaction History Placeholder */}
        <Card className="p-6 mt-4">
          <h4 className="text-lg font-bold text-purple-900 dark:text-purple-200 mb-3">Lịch sử giao dịch</h4>
          <p className="text-gray-500 dark:text-gray-400 text-center py-8">Chưa có giao dịch nào</p>
        </Card>
      </div>
    </div>
  )
}
