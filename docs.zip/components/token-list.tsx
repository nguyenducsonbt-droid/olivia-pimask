"use client"

import { useState, memo, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/use-wallet"
import { Coins, Plus, RefreshCw, Trash2 } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { AddTokenDialog } from "./add-token-dialog"
import { dataCache } from "@/lib/data-cache"

const TokenItem = memo(({ token, onRemove }: { token: any; onRemove: (address: string) => void }) => {
  const isWhiteTheme = token.theme === "white" || token.isPIMask
  const cardClass = isWhiteTheme
    ? "flex items-center justify-between p-3 rounded-lg bg-white border border-gray-200 shadow-sm"
    : "flex items-center justify-between p-3 rounded-lg bg-muted/50"

  return (
    <div className={cardClass}>
      <div className="flex items-center gap-3">
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center ${
            isWhiteTheme ? "bg-black text-white" : "bg-primary/10"
          }`}
        >
          <span className={`text-sm font-bold ${isWhiteTheme ? "text-white" : "text-primary"}`}>{token.symbol[0]}</span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <p className={`font-medium ${isWhiteTheme ? "text-black" : ""}`}>{token.name}</p>
            {token.isPIMask && <span className="text-xs bg-black text-white px-2 py-0.5 rounded-full">Privacy</span>}
          </div>
          <p className={`text-xs ${isWhiteTheme ? "text-gray-600" : "text-muted-foreground"}`}>{token.symbol}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="text-right">
          <p className={`font-semibold ${isWhiteTheme ? "text-black" : ""}`}>{token.balance || "0.00"}</p>
          <p className={`text-xs ${isWhiteTheme ? "text-gray-600" : "text-muted-foreground"}`}>{token.symbol}</p>
        </div>
        {token.isCustom && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemove(token.address)}
            className="h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
})
TokenItem.displayName = "TokenItem"
// </CHANGE>

export function TokenList() {
  const { tokens, removeToken, refreshTokenBalances } = useWallet()
  const { t } = useLanguage()
  const [showAddToken, setShowAddToken] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true)

    try {
      await dataCache.get(
        "tokens:refresh:" + Date.now(),
        async () => {
          await refreshTokenBalances()
          return true
        },
        { ttl: 15000, staleWhileRevalidate: true },
      )
    } catch (error) {
      console.error("[v0] Token refresh failed:", error)
    } finally {
      setTimeout(() => setIsRefreshing(false), 500)
    }
  }, [refreshTokenBalances])

  const handleRemove = useCallback(
    (address: string) => {
      removeToken(address)
      dataCache.invalidate("tokens:list")
    },
    [removeToken],
  )
  // </CHANGE>

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">{t.tokens.title}</CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="h-8 px-2 bg-transparent"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
              </Button>
              <Button variant="default" size="sm" onClick={() => setShowAddToken(true)} className="h-8 px-3">
                <Plus className="h-4 w-4 mr-1" />
                {t.tokens.addToken}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {tokens.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Coins className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">{t.tokens.noTokens}</p>
              <p className="text-xs">{t.tokens.noTokensDesc}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {tokens.map((token) => (
                <TokenItem key={token.address} token={token} onRemove={handleRemove} />
              ))}
              {/* </CHANGE> */}
            </div>
          )}
        </CardContent>
      </Card>

      <AddTokenDialog open={showAddToken} onOpenChange={setShowAddToken} />
    </>
  )
}
