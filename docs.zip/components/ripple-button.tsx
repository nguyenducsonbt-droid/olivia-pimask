"use client"

import type React from "react"
import { type ButtonHTMLAttributes, forwardRef, useState } from "react"
import { Button } from "@/components/ui/button"

interface RippleButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  variant?: "default" | "outline" | "ghost" | "link" | "destructive" | "secondary"
  size?: "default" | "sm" | "lg" | "icon"
  asChild?: boolean
  disabled?: boolean
}

export const RippleButton = forwardRef<HTMLButtonElement, RippleButtonProps>(
  ({ children, onClick, className, disabled, ...props }, ref) => {
    const [ripples, setRipples] = useState<{ x: number; y: number; id: number }[]>([])
    const [isPressed, setIsPressed] = useState(false)

    const playClickSound = () => {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)

        oscillator.frequency.value = 800
        oscillator.type = "sine"

        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)

        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.1)
      } catch (error) {
        // Silent fail
      }
    }

    const triggerHaptic = () => {
      try {
        if ((window as any).Pi?.haptic) {
          ;(window as any).Pi.haptic.light()
        } else if (navigator.vibrate) {
          navigator.vibrate(10)
        }
      } catch (error) {
        // Silent fail
      }
    }

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled) {
        if (onClick) {
          onClick(e)
        }
        return
      }

      const rect = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const id = Date.now()

      setRipples((prev) => [...prev, { x, y, id }])
      playClickSound()
      triggerHaptic()

      setTimeout(() => {
        setRipples((prev) => prev.filter((ripple) => ripple.id !== id))
      }, 500)

      if (onClick) {
        onClick(e)
      }
    }

    const handleMouseDown = () => {
      setIsPressed(true)
    }
    const handleMouseUp = () => {
      setIsPressed(false)
    }
    const handleMouseLeave = () => setIsPressed(false)
    const handleTouchStart = () => {
      setIsPressed(true)
    }
    const handleTouchEnd = () => {
      setIsPressed(false)
    }

    return (
      <Button
        ref={ref}
        onClick={handleClick}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        disabled={disabled}
        className={`relative overflow-hidden ${className}`}
        style={{
          transform: isPressed && !disabled ? "scale(0.95)" : "scale(1)",
          opacity: isPressed && !disabled ? 0.9 : disabled ? 0.7 : 1,
          transition: "transform 150ms cubic-bezier(0.4, 0, 0.2, 1), opacity 150ms ease-out, box-shadow 150ms ease-out",
          willChange: "transform, opacity",
          boxShadow:
            isPressed && !disabled
              ? "0 0 30px 6px rgba(156, 39, 176, 0.8), 0 0 50px 10px rgba(233, 30, 99, 0.6)"
              : "0 0 0 0 transparent",
        }}
        {...props}
      >
        {isPressed && !disabled && (
          <span
            className="absolute inset-0 pointer-events-none rounded-3xl"
            style={{
              border: "2px solid rgba(233, 30, 99, 0.8)",
              boxShadow: "0 0 20px 4px rgba(233, 30, 99, 0.8), inset 0 0 20px 4px rgba(156, 39, 176, 0.6)",
              animation: "glow-pulse 0.3s ease-in-out",
            }}
          />
        )}
        {children}
        {ripples.map((ripple) => (
          <span
            key={ripple.id}
            className="absolute rounded-full pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
              width: 0,
              height: 0,
              background: "radial-gradient(circle, rgba(255, 255, 255, 0.6) 0%, rgba(255, 255, 255, 0) 70%)",
              animation: "ripple-expand 0.5s ease-out",
            }}
          />
        ))}
      </Button>
    )
  },
)

RippleButton.displayName = "RippleButton"
