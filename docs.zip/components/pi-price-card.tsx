"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Loader2 } from "lucide-react"
import { subscribeToPriceUpdates, type PiPrice } from "@/lib/pi-price"

export function PiPriceCard() {
  const [price, setPrice] = useState<PiPrice | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(true)
    const unsubscribe = subscribeToPriceUpdates((newPrice) => {
      setPrice(newPrice)
      setIsLoading(false)
    })

    return () => {
      unsubscribe()
    }
  }, [])

  if (isLoading || !price) {
    return (
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
            <span className="text-sm text-purple-600">Đang tải giá Pi...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  const isPositive = price.change24h > 0
  const isNegative = price.change24h < 0

  return (
    <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 shadow-md">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">π</span>
            </div>
            <div>
              <p className="text-xs text-purple-600 font-medium">Giá Pi Network</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-lg font-bold text-purple-900">${price.usd.toFixed(4)}</span>
                <span className="text-xs text-purple-600">
                  ≈ {price.vnd.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} ₫
                </span>
              </div>
            </div>
          </div>

          <div
            className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
              isPositive
                ? "bg-green-100 text-green-700"
                : isNegative
                  ? "bg-red-100 text-red-700"
                  : "bg-purple-100 text-purple-700"
            }`}
          >
            {isPositive && <TrendingUp className="w-4 h-4" />}
            {isNegative && <TrendingDown className="w-4 h-4" />}
            <span className="text-sm font-semibold">
              {isPositive && "+"}
              {price.change24h.toFixed(2)}%
            </span>
          </div>
        </div>

        <div className="mt-2 text-xs text-purple-500">
          Cập nhật: {new Date(price.lastUpdated).toLocaleTimeString("vi-VN")}
        </div>
      </CardContent>
    </Card>
  )
}
