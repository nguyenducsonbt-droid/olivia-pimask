"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Eye, Copy, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { getPinHash, simpleDecrypt } from "@/lib/storage"
import { Input } from "@/components/ui/input"
import { isTwoFactorEnabled } from "@/lib/two-factor"
import { TwoFactorVerifyDialog } from "./two-factor-verify-dialog"

interface ShowSeedPhraseDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ShowSeedPhraseDialog({ open, onOpenChange }: ShowSeedPhraseDialogProps) {
  const [pin, setPin] = useState("")
  const [isPinVerified, setIsPinVerified] = useState(false)
  const [isVerifyingPin, setIsVerifyingPin] = useState(false)
  const [seedPhrase, setSeedPhrase] = useState("")
  const [showSeed, setShowSeed] = useState(false)
  const [loading, setLoading] = useState(false)
  const [show2FAVerify, setShow2FAVerify] = useState(false)
  const [pending2FAAction, setPending2FAAction] = useState<(() => void) | null>(null)
  const { toast } = useToast()

  const handleVerifyPin = async () => {
    if (pin.length !== 6) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ 6 số PIN",
        variant: "destructive",
      })
      return
    }

    setIsVerifyingPin(true)
    try {
      const pinData = await getPinHash()
      if (!pinData) {
        toast({
          title: "Lỗi",
          description: "Không tìm thấy ví. Vui lòng đăng nhập lại.",
          variant: "destructive",
        })
        setIsVerifyingPin(false)
        return
      }

      // Hash the entered PIN
      const encoder = new TextEncoder()
      const data = encoder.encode(pin)
      const hashBuffer = await crypto.subtle.digest("SHA-256", data)
      const hashArray = Array.from(new Uint8Array(hashBuffer))
      const hashedPinHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

      // Compare with stored pinHash
      if (hashedPinHex !== pinData.pinHash) {
        toast({
          title: "Lỗi",
          description: "Mã PIN không đúng. Vui lòng thử lại.",
          variant: "destructive",
        })
        setPin("")
        setIsVerifyingPin(false)
        return
      }

      if (isTwoFactorEnabled()) {
        setPending2FAAction(() => proceedToLoadSeedPhrase)
        setShow2FAVerify(true)
        setIsVerifyingPin(false)
        return
      }

      // PIN correct - load seed phrase directly if no 2FA
      proceedToLoadSeedPhrase()
      setIsVerifyingPin(false)
    } catch (err) {
      console.error("[v0] PIN verification error:", err)
      toast({
        title: "Lỗi",
        description: "Không thể xác thực PIN. Vui lòng thử lại.",
        variant: "destructive",
      })
      setIsVerifyingPin(false)
    }
  }

  const proceedToLoadSeedPhrase = () => {
    setIsPinVerified(true)
    loadSeedPhrase()
  }

  const loadSeedPhrase = async () => {
    setLoading(true)
    try {
      const pinData = await getPinHash()

      if (!pinData) {
        toast({
          title: "Lỗi",
          description: "Không tìm thấy ví. Vui lòng đăng nhập lại.",
          variant: "destructive",
        })
        setLoading(false)
        return
      }

      const mnemonic = simpleDecrypt(pinData.encryptedMnemonic, pinData.address)
      setSeedPhrase(mnemonic)
      setLoading(false)
    } catch (err) {
      console.error("[v0] Error loading seed phrase:", err)
      toast({
        title: "Lỗi",
        description: "Không thể tải seed phrase. Vui lòng thử lại.",
        variant: "destructive",
      })
      setLoading(false)
    }
  }

  const handle2FAVerified = () => {
    if (pending2FAAction) {
      pending2FAAction()
      setPending2FAAction(null)
    }
  }

  const handleCopySeed = () => {
    navigator.clipboard.writeText(seedPhrase)
    toast({
      title: "Đã sao chép",
      description: "Seed phrase đã được sao chép vào clipboard",
    })
  }

  const handleClose = () => {
    setSeedPhrase("")
    setShowSeed(false)
    setPin("")
    setIsPinVerified(false)
    setIsVerifyingPin(false)
    setShow2FAVerify(false)
    setPending2FAAction(null)
    onOpenChange(false)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Seed Phrase của bạn
            </DialogTitle>
            <DialogDescription>Đây là chìa khóa phục hồi ví. Không chia sẻ với bất kỳ ai!</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {!isPinVerified ? (
              <>
                <Card className="bg-purple-50 border-purple-200 p-4">
                  <p className="text-sm text-purple-900 font-medium">Nhập mã PIN 6 số để xem seed phrase</p>
                </Card>

                <div className="space-y-3">
                  <Input
                    type="password"
                    inputMode="numeric"
                    maxLength={6}
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                    placeholder="Nhập 6 số PIN"
                    className="text-center text-2xl tracking-widest"
                    autoFocus
                  />

                  <Button
                    onClick={handleVerifyPin}
                    disabled={pin.length !== 6 || isVerifyingPin}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
                  >
                    {isVerifyingPin ? "Đang xác thực..." : "Xác nhận"}
                  </Button>

                  <Button onClick={handleClose} variant="outline" className="w-full bg-transparent">
                    Hủy
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Card className="bg-red-50 border-red-200 p-4">
                  <div className="flex gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-red-700">
                      <p className="font-semibold mb-1">Cảnh báo bảo mật:</p>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Không chụp ảnh màn hình</li>
                        <li>Không chia sẻ cho bất kỳ ai</li>
                        <li>Viết ra giấy và cất nơi an toàn</li>
                        <li>Mất seed phrase = mất ví vĩnh viễn</li>
                      </ul>
                    </div>
                  </div>
                </Card>

                {loading ? (
                  <div className="text-center py-8">
                    <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="mt-2 text-sm text-gray-600">Đang tải seed phrase...</p>
                  </div>
                ) : (
                  <>
                    <Card className="bg-yellow-50 border-yellow-200 p-3">
                      <p className="text-sm text-yellow-800 font-medium">
                        Seed phrase của bạn (12 từ - viết xuống theo đúng thứ tự):
                      </p>
                    </Card>

                    <Card className="p-4 bg-purple-50 border-purple-200">
                      <div className="relative">
                        <div className={`grid grid-cols-3 gap-3 ${!showSeed ? "blur-md select-none" : ""}`}>
                          {seedPhrase.split(" ").map((word, index) => (
                            <div key={index} className="flex gap-2">
                              <span className="text-purple-500 font-mono text-sm">{index + 1}.</span>
                              <span className="text-purple-900 font-mono text-sm font-medium">{word}</span>
                            </div>
                          ))}
                        </div>
                        {!showSeed && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Button onClick={() => setShowSeed(true)} variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-2" />
                              Bấm để xem
                            </Button>
                          </div>
                        )}
                      </div>
                    </Card>

                    {showSeed && (
                      <Button onClick={handleCopySeed} className="w-full bg-transparent" variant="outline">
                        <Copy className="w-4 h-4 mr-2" />
                        Sao chép Seed Phrase
                      </Button>
                    )}

                    <Button
                      onClick={handleClose}
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
                    >
                      Đã sao lưu xong
                    </Button>
                  </>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <TwoFactorVerifyDialog
        open={show2FAVerify}
        onOpenChange={setShow2FAVerify}
        onVerified={handle2FAVerified}
        title="Xác thực xuất seed phrase"
        description="Thao tác nhạy cảm yêu cầu xác thực 2FA"
      />
    </>
  )
}
