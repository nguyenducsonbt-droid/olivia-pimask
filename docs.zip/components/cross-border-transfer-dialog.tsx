"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import {
  Globe,
  ArrowRight,
  Wallet,
  CreditCard,
  Smartphone,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Copy,
  QrCode,
  Clock,
  ShieldCheck,
  DollarSign,
} from "lucide-react"
import { CrossBorderService, SUPPORTED_COUNTRIES } from "@/lib/cross-border-service"
import type { CrossBorderTransfer, Country } from "@/types/cross-border"
import { playSound } from "@/lib/sounds"
import { triggerHaptic } from "@/lib/haptic"
import { OnramperWidget } from "@/components/onramper-widget" // Import Onramper widget

interface CrossBorderTransferDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CrossBorderTransferDialog({ open, onOpenChange }: CrossBorderTransferDialogProps) {
  const [step, setStep] = useState<"kyc" | "country" | "details" | "confirm" | "processing" | "success">("kyc")
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null)
  const [recipientType, setRecipientType] = useState<"wallet" | "bank" | "phone">("wallet")
  const [recipientAddress, setRecipientAddress] = useState("")
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState<"PI" | "USD" | "VND">("PI")
  const [exchangeRate, setExchangeRate] = useState(0)
  const [fees, setFees] = useState({ network: "0", service: "0", total: "0" })
  const [isLoadingRate, setIsLoadingRate] = useState(false)
  const [kycStatus, setKycStatus] = useState<any>(null)
  const [transferResult, setTransferResult] = useState<CrossBorderTransfer | null>(null)
  const [showQRScanner, setShowQRScanner] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showOnramper, setShowOnramper] = useState(false)
  const [currentWalletAddress, setCurrentWalletAddress] = useState("")

  useEffect(() => {
    if (open) {
      checkKYC()
      if (typeof window !== "undefined" && localStorage.getItem("olivia_current_wallet")) {
        const wallet = JSON.parse(localStorage.getItem("olivia_current_wallet") || "{}")
        setCurrentWalletAddress(wallet.address || "")
      }
    }
  }, [open])

  useEffect(() => {
    if (amount && selectedCountry) {
      fetchExchangeRate()
    }
  }, [amount, currency, selectedCountry])

  const checkKYC = async () => {
    const status = await CrossBorderService.checkKYCStatus()
    setKycStatus(status)

    if (status.verified) {
      setStep("country")
    } else {
      setStep("kyc")
    }
  }

  const fetchExchangeRate = async () => {
    if (!selectedCountry || !amount) return

    setIsLoadingRate(true)
    try {
      const rate = await CrossBorderService.getExchangeRate(currency, selectedCountry.currency)
      setExchangeRate(rate.rate)

      const calculatedFees = CrossBorderService.calculateFees(Number.parseFloat(amount), currency)
      setFees(calculatedFees)
    } catch (error) {
      console.error("[v0] Error fetching rate:", error)
      toast.error("Không thể lấy tỷ giá. Vui lòng thử lại.")
    } finally {
      setIsLoadingRate(false)
    }
  }

  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country)
    playSound("click")
    triggerHaptic("light")
    setStep("details")
  }

  const handleTransferSubmit = async () => {
    if (!selectedCountry || !recipientAddress || !amount) {
      toast.error("Vui lòng điền đầy đủ thông tin")
      return
    }

    // Validate address
    if (!CrossBorderService.validateAddress(recipientAddress, recipientType)) {
      toast.error(
        `Địa chỉ ${recipientType === "wallet" ? "ví" : recipientType === "bank" ? "ngân hàng" : "số điện thoại"} không hợp lệ`,
      )
      return
    }

    // Check amount limits
    const amountNum = Number.parseFloat(amount)
    if (kycStatus && amountNum > kycStatus.dailyLimit) {
      toast.error(`Vượt hạn mức chuyển tiền hàng ngày: ${kycStatus.dailyLimit} ${currency}`)
      return
    }

    setStep("confirm")
  }

  const executeTransfer = async () => {
    setStep("processing")
    playSound("send")
    triggerHaptic("medium")

    try {
      // Use Pi SDK for payment
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi

        const paymentData = {
          amount: Number.parseFloat(amount),
          memo: `Cross-border transfer to ${selectedCountry?.name} - ${recipientAddress}`,
          metadata: {
            type: "cross_border_transfer",
            recipientCountry: selectedCountry?.code,
            recipientAddress,
            recipientType,
            currency,
            exchangeRate,
            fees,
            timestamp: Date.now(),
          },
        }

        const payment = await Pi.createPayment(paymentData, {
          onReadyForServerApproval: (paymentId: string) => {
            console.log("[v0] Cross-border payment ready:", paymentId)
            toast.info("Đang xác thực giao dịch...")
          },
          onReadyForServerCompletion: (paymentId: string, txid: string) => {
            console.log("[v0] Cross-border payment completed:", paymentId, txid)

            const transfer: CrossBorderTransfer = {
              id: paymentId,
              from: "user",
              to: recipientAddress,
              amount,
              currency,
              recipientCountry: selectedCountry?.code || "",
              recipientAddress,
              recipientType,
              exchangeRate,
              fees,
              status: "completed",
              timestamp: Date.now(),
              txHash: txid,
              estimatedArrival:
                Date.now() + CrossBorderService.estimateArrivalTime(selectedCountry?.code || "", recipientType) * 60000,
            }

            CrossBorderService.saveTransfer(transfer)
            setTransferResult(transfer)
            setStep("success")
            playSound("receive")
            triggerHaptic("success")

            toast.success("Chuyển tiền quốc tế thành công!")
          },
          onCancel: (paymentId: string) => {
            console.log("[v0] Payment cancelled:", paymentId)
            toast.error("Đã hủy giao dịch")
            setStep("details")
          },
          onError: (error: any, payment: any) => {
            console.error("[v0] Payment error:", error)
            toast.error(error.message || "Giao dịch thất bại")
            setStep("details")
          },
        })
      } else {
        // Fallback for non-Pi Browser
        toast.error("Vui lòng mở trong Pi Browser để thực hiện giao dịch")
        setStep("details")
      }
    } catch (error: any) {
      console.error("[v0] Transfer error:", error)
      toast.error(error.message || "Lỗi chuyển tiền. Vui lòng thử lại.")
      setStep("details")
    }
  }

  const copyTransactionHash = () => {
    if (transferResult?.txHash) {
      navigator.clipboard.writeText(transferResult.txHash)
      setCopied(true)
      toast.success("Đã sao chép mã giao dịch")
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getTotalReceive = () => {
    const amountNum = Number.parseFloat(amount) || 0
    const feeNum = Number.parseFloat(fees.total) || 0
    const netAmount = amountNum - feeNum
    return (netAmount * exchangeRate).toFixed(2)
  }

  const handleOnramperSuccess = (transaction: any) => {
    toast.success(`Đã nạp ${transaction.cryptoAmount} Pi vào ví!`)
    // Optionally refresh wallet balance here
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-purple-600" />
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Chuyển tiền quốc tế
              </span>
            </DialogTitle>
          </DialogHeader>

          {/* KYC Check */}
          {step === "kyc" && (
            <div className="space-y-4">
              <Card className="p-4 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-yellow-300">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-yellow-900 dark:text-yellow-200 mb-1">Yêu cầu xác minh KYC</p>
                    <p className="text-sm text-yellow-800 dark:text-yellow-300">
                      Chuyển tiền quốc tế yêu cầu xác minh danh tính để tuân thủ quy định AML/KYC.
                    </p>
                  </div>
                </div>
              </Card>

              <div className="space-y-2">
                <p className="text-sm text-gray-600 dark:text-gray-400">Trạng thái KYC hiện tại:</p>
                <Card className="p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Level:</span>
                    <span className="text-red-600 font-semibold">{kycStatus?.level || "none"}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-medium">Hạn mức hàng ngày:</span>
                    <span className="font-semibold">{kycStatus?.dailyLimit || 0} Pi</span>
                  </div>
                </Card>
              </div>

              <Button
                onClick={() => {
                  toast.info("Đang chuyển đến Pi Network KYC...")
                  window.open("https://minepi.com/kyc", "_blank")
                }}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white"
              >
                <ShieldCheck className="w-4 h-4 mr-2" />
                Xác minh KYC ngay
              </Button>

              <Button variant="ghost" onClick={() => onOpenChange(false)} className="w-full">
                Đóng
              </Button>
            </div>
          )}

          {/* Country Selection */}
          {step === "country" && (
            <div className="space-y-4">
              <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20">
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  <strong>An toàn 100%</strong> - Chuyển Pi quốc tế nhanh chóng, phí thấp qua Pi Network Mainnet
                </p>
              </Card>

              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">Chọn quốc gia người nhận:</p>
                <div className="grid grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                  {SUPPORTED_COUNTRIES.map((country) => (
                    <Card
                      key={country.code}
                      className={`p-3 cursor-pointer transition-all hover:shadow-md ${
                        selectedCountry?.code === country.code
                          ? "border-2 border-purple-500 bg-purple-50 dark:bg-purple-900/20"
                          : ""
                      }`}
                      onClick={() => handleCountrySelect(country)}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-2xl">{country.flag}</span>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{country.name}</p>
                          <p className="text-xs text-gray-600 dark:text-gray-400">{country.currency}</p>
                        </div>
                      </div>
                      {country.piEnabled && (
                        <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Pi enabled</span>
                        </div>
                      )}
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Transfer Details */}
          {step === "details" && (
            <div className="space-y-4">
              <Card className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-300">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-green-900 dark:text-green-200 mb-1">
                      Cần nạp Pi để chuyển?
                    </p>
                    <p className="text-xs text-green-800 dark:text-green-300">
                      Nạp fiat (VND/USD) → Pi qua Onramper (Onramp.money, Transfi, Banxa)
                    </p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setShowOnramper(true)}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 text-white ml-2"
                  >
                    <DollarSign className="w-4 h-4 mr-1" />
                    Nạp Pi
                  </Button>
                </div>
              </Card>

              {/* Recipient Type */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">Loại người nhận:</p>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={recipientType === "wallet" ? "default" : "outline"}
                    onClick={() => setRecipientType("wallet")}
                    className="flex flex-col gap-1 h-auto py-3"
                  >
                    <Wallet className="w-5 h-5" />
                    <span className="text-xs">Ví</span>
                  </Button>
                  <Button
                    variant={recipientType === "bank" ? "default" : "outline"}
                    onClick={() => setRecipientType("bank")}
                    className="flex flex-col gap-1 h-auto py-3"
                  >
                    <CreditCard className="w-5 h-5" />
                    <span className="text-xs">Ngân hàng</span>
                  </Button>
                  <Button
                    variant={recipientType === "phone" ? "default" : "outline"}
                    onClick={() => setRecipientType("phone")}
                    className="flex flex-col gap-1 h-auto py-3"
                  >
                    <Smartphone className="w-5 h-5" />
                    <span className="text-xs">SĐT</span>
                  </Button>
                </div>
              </div>

              {/* Recipient Address */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                  {recipientType === "wallet"
                    ? "Địa chỉ ví (0x... hoặc @username)"
                    : recipientType === "bank"
                      ? "Số tài khoản ngân hàng"
                      : "Số điện thoại"}
                </label>
                <div className="flex gap-2">
                  <Input
                    value={recipientAddress}
                    onChange={(e) => setRecipientAddress(e.target.value)}
                    placeholder={
                      recipientType === "wallet"
                        ? "0x... hoặc @username"
                        : recipientType === "bank"
                          ? "1234567890"
                          : "+84..."
                    }
                    className="flex-1"
                  />
                  <Button size="icon" variant="outline" onClick={() => setShowQRScanner(!showQRScanner)}>
                    <QrCode className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Amount */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Số tiền gửi:</label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="flex-1"
                  />
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as any)}
                    className="px-3 py-2 border rounded-lg bg-background"
                  >
                    <option value="PI">Pi</option>
                    <option value="USD">USD</option>
                    <option value="VND">VND</option>
                  </select>
                </div>
              </div>

              {/* Exchange Rate Preview */}
              {amount && exchangeRate > 0 && (
                <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm text-gray-700 dark:text-gray-300">Tỷ giá:</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={fetchExchangeRate}
                      disabled={isLoadingRate}
                      className="h-6 w-6"
                    >
                      <RefreshCw className={`w-3 h-3 ${isLoadingRate ? "animate-spin" : ""}`} />
                    </Button>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>1 {currency} =</span>
                      <span className="font-semibold">
                        {exchangeRate.toFixed(4)} {selectedCountry?.currency}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
                      <span>Phí network:</span>
                      <span>
                        {fees.network} {currency}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
                      <span>Phí dịch vụ (0.5%):</span>
                      <span>
                        {fees.service} {currency}
                      </span>
                    </div>
                    <div className="h-px bg-gray-300 dark:bg-gray-600 my-2" />
                    <div className="flex justify-between font-bold text-green-700 dark:text-green-400">
                      <span>Người nhận sẽ nhận:</span>
                      <span>
                        {getTotalReceive()} {selectedCountry?.currency}
                      </span>
                    </div>
                  </div>
                </Card>
              )}

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep("country")} className="flex-1">
                  Quay lại
                </Button>
                <Button
                  onClick={handleTransferSubmit}
                  disabled={!recipientAddress || !amount}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                >
                  Tiếp tục
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {/* Confirmation */}
          {step === "confirm" && (
            <div className="space-y-4">
              <Card className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Gửi đến:</span>
                  <span className="font-semibold flex items-center gap-2">
                    <span className="text-2xl">{selectedCountry?.flag}</span>
                    {selectedCountry?.name}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Người nhận:</span>
                  <span className="font-mono text-sm">{recipientAddress.slice(0, 20)}...</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Số tiền:</span>
                  <span className="font-semibold text-lg">
                    {amount} {currency}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Phí:</span>
                  <span className="text-red-600 font-semibold">
                    {fees.total} {currency}
                  </span>
                </div>
                <div className="h-px bg-gray-300 dark:bg-gray-600" />
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Người nhận sẽ nhận:</span>
                  <span className="font-bold text-green-600 text-lg">
                    {getTotalReceive()} {selectedCountry?.currency}
                  </span>
                </div>
              </Card>

              <Card className="p-3 bg-blue-50 dark:bg-blue-900/20 border-blue-300">
                <div className="flex items-start gap-2">
                  <Clock className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-800 dark:text-blue-300">
                    Thời gian dự kiến:{" "}
                    {CrossBorderService.estimateArrivalTime(selectedCountry?.code || "", recipientType)} phút
                  </p>
                </div>
              </Card>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep("details")} className="flex-1">
                  Sửa
                </Button>
                <Button
                  onClick={executeTransfer}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white"
                >
                  Xác nhận gửi
                </Button>
              </div>
            </div>
          )}

          {/* Processing */}
          {step === "processing" && (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 mx-auto border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
              <p className="font-semibold text-lg">Đang xử lý giao dịch...</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Vui lòng xác nhận trong Pi Browser</p>
            </div>
          )}

          {/* Success */}
          {step === "success" && transferResult && (
            <div className="space-y-4">
              <div className="text-center py-6">
                <div className="w-20 h-20 mx-auto mb-4 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-green-600 mb-2">Chuyển tiền thành công!</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Giao dịch đã được xác nhận trên Pi Network</p>
              </div>

              <Card className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Mã giao dịch:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs">{transferResult.txHash?.slice(0, 10)}...</span>
                    <Button size="icon" variant="ghost" onClick={copyTransactionHash} className="h-6 w-6">
                      {copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Số tiền đã gửi:</span>
                  <span className="font-semibold">
                    {transferResult.amount} {transferResult.currency}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Người nhận sẽ nhận:</span>
                  <span className="font-bold text-green-600">
                    {getTotalReceive()} {selectedCountry?.currency}
                  </span>
                </div>
              </Card>

              <Button
                onClick={() => {
                  onOpenChange(false)
                  setStep("country")
                  setAmount("")
                  setRecipientAddress("")
                }}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white"
              >
                Hoàn tất
              </Button>
            </div>
          )}

          {/* Disclaimer */}
          {(step === "country" || step === "details") && (
            <Card className="p-3 bg-purple-50 dark:bg-purple-900/20 border-purple-300">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-purple-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-purple-800 dark:text-purple-300">
                  Tính năng cross-border sẽ hoàn thiện khi Pi Network mở chuyển tiền quốc tế. Hiện tại hỗ trợ P2P qua
                  địa chỉ ví.
                </p>
              </div>
            </Card>
          )}
        </DialogContent>
      </Dialog>

      <OnramperWidget
        open={showOnramper}
        onOpenChange={setShowOnramper}
        walletAddress={currentWalletAddress}
        defaultAmount={Number.parseFloat(amount) || 100}
        defaultFiat={currency === "VND" ? "VND" : "USD"}
        onSuccess={handleOnramperSuccess}
      />
    </>
  )
}
