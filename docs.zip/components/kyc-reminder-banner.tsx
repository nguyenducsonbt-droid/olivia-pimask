"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, X, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function KYCReminderBanner() {
  const [isKYCCompleted, setIsKYCCompleted] = useState(false)
  const [isDismissed, setIsDismissed] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchKYCStatus = async () => {
      try {
        if (typeof window !== "undefined") {
          const Pi = (window as any).Pi

          // Check dismissed state
          const dismissed = localStorage.getItem("kyc_banner_dismissed")
          setIsDismissed(dismissed === "true")

          // Try to get real KYC status from Pi SDK
          if (Pi?.user?.getKYCStatus) {
            const kycData = await Pi.user.getKYCStatus()
            const completed = kycData?.status === "approved" || kycData?.verified === true
            setIsKYCCompleted(completed)
            localStorage.setItem("kyc_completed", completed ? "true" : "false")
          } else if (Pi?.authenticate) {
            // Fallback: authenticate to check user data
            try {
              const authResult = await Pi.authenticate(["username"], () => {})
              if (authResult?.user?.kyc_status) {
                const completed = authResult.user.kyc_status === "approved"
                setIsKYCCompleted(completed)
                localStorage.setItem("kyc_completed", completed ? "true" : "false")
              }
            } catch (err) {
              // Use cached value on auth error
              const cached = localStorage.getItem("kyc_completed")
              setIsKYCCompleted(cached === "true")
            }
          } else {
            // Use cached value if Pi SDK not available
            const cached = localStorage.getItem("kyc_completed")
            setIsKYCCompleted(cached === "true")
          }
        }
      } catch (error) {
        console.error("[v0] KYC status fetch error:", error)
        // Use cached value on error
        const cached = localStorage.getItem("kyc_completed")
        setIsKYCCompleted(cached === "true")
      } finally {
        setIsLoading(false)
      }
    }

    fetchKYCStatus()

    // Refresh KYC status when returning to app
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        fetchKYCStatus()
      }
    }
    document.addEventListener("visibilitychange", handleVisibilityChange)
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange)
  }, [])

  const handleDoKYC = () => {
    try {
      if (typeof window !== "undefined") {
        const Pi = (window as any).Pi

        if (Pi?.navigation?.open) {
          Pi.navigation.open("kyc", { backToApp: true })
        } else if (Pi?.app?.launchBrowser) {
          Pi.app.launchBrowser("kyc")
        } else {
          // Deep link fallback
          window.location.href = "pi://browser/kyc"
        }

        toast({
          title: "Đang mở KYC",
          description: "Hoàn tất xác minh để nhận Pi Mainnet",
        })
      }
    } catch (error) {
      console.error("[v0] KYC navigation error:", error)
      toast({
        title: "Không thể mở KYC",
        description: "Vui lòng mở Pi Browser và vào phần KYC",
        variant: "destructive",
      })
    }
  }

  const handleDismiss = () => {
    setIsDismissed(true)
    localStorage.setItem("kyc_banner_dismissed", "true")
  }

  if (isLoading) {
    return (
      <Card className="border-amber-300 bg-gradient-to-r from-amber-50 to-orange-50">
        <CardContent className="p-4 flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 text-amber-600 animate-spin" />
          <span className="text-sm text-amber-700">Đang kiểm tra trạng thái KYC...</span>
        </CardContent>
      </Card>
    )
  }

  if (isKYCCompleted || isDismissed) {
    return null
  }

  return (
    <Card className="border-amber-300 bg-gradient-to-r from-amber-50 to-orange-50 shadow-md">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1 space-y-2">
            <p className="text-sm font-semibold text-amber-900">Hoàn tất KYC để nhận Pi Mainnet đầy đủ</p>
            <p className="text-xs text-amber-700">
              Xác minh danh tính để truy cập tất cả tính năng và rút Pi về ví cá nhân
            </p>
            <Button
              onClick={handleDoKYC}
              size="sm"
              className="h-8 bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600 text-white"
            >
              Làm KYC ngay
            </Button>
          </div>
          <Button
            onClick={handleDismiss}
            size="sm"
            variant="ghost"
            className="h-6 w-6 p-0 hover:bg-amber-100 flex-shrink-0"
          >
            <X className="w-4 h-4 text-amber-600" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
