"use client"

import { memo, useState } from "react"
import { Badge } from "@/components/ui/badge"

interface NFTItemProps {
  nft: {
    id: string
    name: string
    collection: string
    image: string
    rarity: "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"
    tokenId: string
  }
  onClick: () => void
}

const rarityConfig = {
  Common: {
    color: "bg-gradient-to-br from-green-400 to-green-600",
    label: "Common",
    shadow: "shadow-green-500/50",
  },
  Uncommon: {
    color: "bg-gradient-to-br from-blue-400 to-blue-600",
    label: "Uncommon",
    shadow: "shadow-blue-500/50",
  },
  Rare: {
    color: "bg-gradient-to-br from-indigo-400 to-indigo-600",
    label: "Rare",
    shadow: "shadow-indigo-500/50",
  },
  Epic: {
    color: "bg-gradient-to-br from-purple-400 to-purple-600",
    label: "Epic",
    shadow: "shadow-purple-500/50",
  },
  Legendary: {
    color: "bg-gradient-to-br from-yellow-400 via-orange-500 to-red-600",
    label: "Legendary",
    shadow: "shadow-yellow-500/50",
  },
}

export const NFTItem = memo(({ nft, onClick }: NFTItemProps) => {
  const [imageLoaded, setImageLoaded] = useState(false)
  const rarityStyle = rarityConfig[nft.rarity]

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200 cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all duration-200"
    >
      {/* NFT Image with shimmer placeholder */}
      <div className="relative aspect-square bg-gradient-to-br from-purple-100 to-pink-100">
        {/* Shimmer effect while loading */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-shimmer" />
        )}

        <img
          src={nft.image || "/placeholder.svg?height=400&width=400"}
          alt={nft.name}
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />

        {/* 3D Rarity Badge with shadow effect */}
        <Badge
          className={`absolute top-2 right-2 ${rarityStyle.color} text-white border-0 text-xs font-bold ${rarityStyle.shadow} shadow-lg transform hover:scale-110 transition-transform`}
          style={{
            textShadow: "0 2px 4px rgba(0,0,0,0.3)",
          }}
        >
          {rarityStyle.label}
        </Badge>
      </div>

      {/* NFT Info */}
      <div className="p-3">
        <p className="font-semibold text-sm text-gray-900 truncate">{nft.name}</p>
        <p className="text-xs text-gray-500 truncate">{nft.collection}</p>
        <p className="text-xs text-purple-600 font-medium mt-1">#{nft.tokenId}</p>
      </div>
    </div>
  )
})

NFTItem.displayName = "NFTItem"
