"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWallet } from "@/hooks/use-wallet"
import {
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  Receipt,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Loader2,
  Search,
  Filter,
  TrendingUp,
  ArrowLeftRight,
} from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useState, useEffect, useRef, useMemo, useCallback, memo } from "react"
import { getTransactionHistory } from "@/lib/wallet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Transaction } from "@/lib/wallet"
import type { JSX } from "react" // Import JSX to fix the undeclared variable error

const fetchTransactions = async (
  address: string,
  currentNetwork: any,
  addTransaction: any,
  transactions: any[],
  silent = false,
) => {
  if (!address || !currentNetwork) return
  if (document.hidden && silent) {
    return
  }

  try {
    const txs = await getTransactionHistory(address, currentNetwork)

    txs.forEach((tx) => {
      const exists = transactions.find((t) => t.hash === tx.hash)
      if (!exists) {
        addTransaction(tx)
      }
    })
  } catch (error) {
    console.error("Error fetching transactions:", error)
  }
}

const TransactionItem = memo(
  ({
    tx,
    address,
    currentNetwork,
    formatDate,
    formatAddress,
    getTypeIcon,
    getStatusBadge,
    onViewDetails,
    t,
  }: {
    tx: Transaction
    address: string
    currentNetwork: any
    formatDate: (timestamp: number) => string
    formatAddress: (addr: string) => string
    getTypeIcon: (tx: Transaction) => JSX.Element
    getStatusBadge: (status: string) => JSX.Element | null
    onViewDetails: (tx: Transaction) => void
    t: any
  }) => {
    const isSent = tx.from.toLowerCase() === address.toLowerCase()

    return (
      <div
        id={`tx-${tx.hash}`}
        className="flex items-center gap-3 p-3 rounded-lg bg-purple-50/50 hover:bg-purple-100/50 cursor-pointer transition-all border border-purple-100"
        onClick={() => onViewDetails(tx)}
      >
        <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br from-purple-100 to-pink-100 border border-purple-200">
          {getTypeIcon(tx)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm text-purple-900">
            {tx.type === "stake"
              ? "Stake"
              : tx.type === "swap"
                ? "Swap"
                : isSent
                  ? t.transactions.sent
                  : t.transactions.received}
          </p>
          <p className="text-xs text-purple-600 truncate">
            {isSent
              ? `${t.transactions.to} ${formatAddress(tx.to)}`
              : `${t.transactions.from} ${formatAddress(tx.from)}`}
          </p>
          {getStatusBadge(tx.status)}
        </div>
        <div className="text-right">
          <p className={`font-semibold text-sm ${isSent ? "text-pink-600" : "text-purple-600"}`}>
            {isSent ? "-" : "+"}
            {tx.value} {currentNetwork.symbol}
          </p>
          <div className="flex items-center gap-1 text-xs text-purple-500">
            <Clock className="w-3 h-3" />
            <span>{formatDate(tx.timestamp)}</span>
          </div>
          {tx.fee && <p className="text-xs text-purple-400">Fee: {tx.fee}</p>}
        </div>
      </div>
    )
  },
)

TransactionItem.displayName = "TransactionItem"

export function TransactionHistory() {
  const { transactions, address, currentNetwork, addTransaction } = useWallet()
  const { t, language } = useLanguage()
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState<"all" | "sent" | "received" | "stake" | "swap">("all")
  const [filterDate, setFilterDate] = useState<"all" | "today" | "week" | "month">("all")

  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const isMountedRef = useRef(true)

  useEffect(() => {
    isMountedRef.current = true

    const startInterval = () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
      intervalRef.current = setInterval(() => {
        if (!document.hidden) {
          fetchTransactions(address, currentNetwork, addTransaction, transactions, true)
        }
      }, 30000)
    }

    if (address && currentNetwork) {
      fetchTransactions(address, currentNetwork, addTransaction, transactions)

      startInterval()

      const handleVisibilityChange = () => {
        if (document.hidden) {
          if (intervalRef.current) {
            clearInterval(intervalRef.current)
            intervalRef.current = null
          }
        } else {
          fetchTransactions(address, currentNetwork, addTransaction, transactions, true)
          startInterval()
        }
      }

      document.addEventListener("visibilitychange", handleVisibilityChange)

      return () => {
        isMountedRef.current = false
        if (intervalRef.current) {
          clearInterval(intervalRef.current)
          intervalRef.current = null
        }
        document.removeEventListener("visibilitychange", handleVisibilityChange)
      }
    }
  }, [address, currentNetwork, addTransaction, transactions])

  const formatDate = useCallback(
    (timestamp: number) => {
      const date = new Date(timestamp)
      const locale = language === "vi" ? "vi-VN" : "en-US"
      return date.toLocaleDateString(locale, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
    },
    [language],
  )

  const formatAddress = useCallback((addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }, [])

  const handleViewDetails = useCallback((tx: Transaction) => {
    setSelectedTx(tx)
    setIsDetailOpen(true)
  }, [])

  const openInExplorer = useCallback(
    (tx: Transaction) => {
      if (currentNetwork.explorerUrl) {
        window.open(`${currentNetwork.explorerUrl}/tx/${tx.hash}`, "_blank")
      }
    },
    [currentNetwork],
  )

  const getStatusBadge = useCallback(
    (status: string) => {
      switch (status) {
        case "confirmed":
          return (
            <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
              <CheckCircle2 className="w-3 h-3" />
              <span>{t.transactions.confirmed}</span>
            </div>
          )
        case "pending":
          return (
            <div className="flex items-center gap-1 text-xs text-yellow-600 dark:text-yellow-400">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>{t.transactions.pending}</span>
            </div>
          )
        case "failed":
          return (
            <div className="flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
              <XCircle className="w-3 h-3" />
              <span>{t.transactions.failed}</span>
            </div>
          )
        default:
          return null
      }
    },
    [t],
  )

  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      const isSent = tx.from.toLowerCase() === address.toLowerCase()
      if (filterType === "sent" && !isSent) return false
      if (filterType === "received" && isSent) return false
      if (filterType === "stake" && tx.type !== "stake") return false
      if (filterType === "swap" && tx.type !== "swap") return false

      const now = Date.now()
      const txDate = tx.timestamp
      if (filterDate === "today" && now - txDate > 24 * 60 * 60 * 1000) return false
      if (filterDate === "week" && now - txDate > 7 * 24 * 60 * 60 * 1000) return false
      if (filterDate === "month" && now - txDate > 30 * 24 * 60 * 60 * 1000) return false

      if (searchQuery) {
        const query = searchQuery.toLowerCase()
        return (
          tx.hash.toLowerCase().includes(query) ||
          tx.from.toLowerCase().includes(query) ||
          tx.to.toLowerCase().includes(query)
        )
      }

      return true
    })
  }, [transactions, address, filterType, filterDate, searchQuery])

  const getTypeIcon = useCallback(
    (tx: Transaction) => {
      const isSent = tx.from.toLowerCase() === address.toLowerCase()
      if (tx.type === "stake") return <TrendingUp className="w-5 h-5 text-purple-600" />
      if (tx.type === "swap") return <ArrowLeftRight className="w-5 h-5 text-purple-600" />
      return isSent ? (
        <ArrowUpRight className="w-5 h-5 text-pink-600" />
      ) : (
        <ArrowDownLeft className="w-5 h-5 text-purple-600" />
      )
    },
    [address],
  )

  const handleRefresh = useCallback(() => {
    fetchTransactions(address, currentNetwork, addTransaction, transactions)
  }, [address, currentNetwork, addTransaction, transactions])

  return (
    <>
      <Card className="border-purple-200 bg-white/80 backdrop-blur-sm">
        <CardHeader className="flex flex-row items-center justify-between border-b border-purple-100">
          <CardTitle className="text-base text-purple-900">{t.transactions.title}</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="text-purple-700 hover:bg-purple-50"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-3 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-purple-400" />
              <Input
                placeholder="Tìm kiếm hash, địa chỉ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-purple-200 focus:border-purple-400 focus:ring-purple-400"
              />
            </div>
            <div className="flex gap-2">
              <Select value={filterType} onValueChange={(v: any) => setFilterType(v)}>
                <SelectTrigger className="flex-1 border-purple-200 text-purple-900">
                  <Filter className="w-4 h-4 mr-2 text-purple-600" />
                  <SelectValue placeholder="Loại" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="sent">Gửi</SelectItem>
                  <SelectItem value="received">Nhận</SelectItem>
                  <SelectItem value="stake">Stake</SelectItem>
                  <SelectItem value="swap">Swap</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterDate} onValueChange={(v: any) => setFilterDate(v)}>
                <SelectTrigger className="flex-1 border-purple-200 text-purple-900">
                  <Clock className="w-4 h-4 mr-2 text-purple-600" />
                  <SelectValue placeholder="Thời gian" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="today">Hôm nay</SelectItem>
                  <SelectItem value="week">7 ngày</SelectItem>
                  <SelectItem value="month">30 ngày</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {isRefreshing && transactions.length === 0 ? (
            <div className="text-center py-8 text-purple-600">
              <Loader2 className="w-12 h-12 mx-auto mb-2 animate-spin opacity-50" />
              <p className="text-sm">{t.transactions.refreshing}</p>
            </div>
          ) : filteredTransactions.length === 0 ? (
            <div className="text-center py-8 text-purple-600">
              <Receipt className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">
                {searchQuery || filterType !== "all" || filterDate !== "all"
                  ? "Không tìm thấy giao dịch"
                  : t.transactions.noTransactions}
              </p>
              {!searchQuery && filterType === "all" && filterDate === "all" && (
                <p className="text-xs mt-1">{t.transactions.noTransactionsDesc}</p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTransactions.map((tx) => (
                <TransactionItem
                  key={tx.hash}
                  tx={tx}
                  address={address}
                  currentNetwork={currentNetwork}
                  formatDate={formatDate}
                  formatAddress={formatAddress}
                  getTypeIcon={getTypeIcon}
                  getStatusBadge={getStatusBadge}
                  onViewDetails={handleViewDetails}
                  t={t}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="border-purple-200">
          <DialogHeader>
            <DialogTitle className="text-purple-900">{t.transactions.viewDetails}</DialogTitle>
            <DialogDescription className="font-mono text-xs break-all text-purple-600">
              {selectedTx?.hash}
            </DialogDescription>
          </DialogHeader>

          {selectedTx && (
            <div className="space-y-4">
              <div className="space-y-3 p-4 bg-purple-50/50 rounded-lg border border-purple-100">
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">Loại:</span>
                  <span className="font-medium text-purple-900">
                    {selectedTx.type === "stake"
                      ? "Stake"
                      : selectedTx.type === "swap"
                        ? "Swap"
                        : selectedTx.from.toLowerCase() === address.toLowerCase()
                          ? "Gửi"
                          : "Nhận"}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">{t.transactions.from}:</span>
                  <span className="font-mono text-xs text-purple-900">{formatAddress(selectedTx.from)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">{t.transactions.to}:</span>
                  <span className="font-mono text-xs text-purple-900">{formatAddress(selectedTx.to)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">Số lượng:</span>
                  <span className="font-semibold text-purple-900">
                    {selectedTx.value} {currentNetwork.symbol}
                  </span>
                </div>
                {selectedTx.fee && (
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-600">Phí giao dịch:</span>
                    <span className="text-purple-900">{selectedTx.fee}</span>
                  </div>
                )}
                {selectedTx.blockNumber && (
                  <div className="flex justify-between text-sm">
                    <span className="text-purple-600">Block:</span>
                    <span className="font-mono text-xs text-purple-900">{selectedTx.blockNumber}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">Trạng thái:</span>
                  {getStatusBadge(selectedTx.status)}
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-purple-600">Thời gian:</span>
                  <span className="text-purple-900">{formatDate(selectedTx.timestamp)}</span>
                </div>
              </div>

              {currentNetwork.explorerUrl && (
                <Button
                  onClick={() => openInExplorer(selectedTx)}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  {t.transactions.viewOnExplorer}
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
