"use client"

import { useState, useEffect } from "react"
import { X, Sparkles, Check, Crown, AlertCircle } from "lucide-react"
import { PayWithPiButton } from "./pay-with-pi-button"
import { playSound } from "@/lib/sounds"
import { hasPaymentsScope } from "@/lib/persistent-storage"

interface PiPaymentModalProps {
  open: boolean
  onClose: () => void
  feature: string
  featureId: string
  description: string
  amount: number
  benefits: string[]
}

export function PiPaymentModal({
  open,
  onClose,
  feature,
  featureId,
  description,
  amount,
  benefits,
}: PiPaymentModalProps) {
  const [isPremium, setIsPremium] = useState(false)
  const [hasPaymentAccess, setHasPaymentAccess] = useState(false)

  useEffect(() => {
    const unlocked = localStorage.getItem(`olivia_premium_${featureId}`) === "true"
    setIsPremium(unlocked)

    const scopeAccess = hasPaymentsScope()
    setHasPaymentAccess(scopeAccess)
  }, [featureId])

  useEffect(() => {
    const handlePaymentSuccess = (event: CustomEvent) => {
      if (event.detail.featureId === featureId) {
        setIsPremium(true)
        setTimeout(() => {
          onClose()
        }, 2000)
      }
    }

    const handleSessionChange = () => {
      const scopeAccess = hasPaymentsScope()
      setHasPaymentAccess(scopeAccess)
    }

    window.addEventListener("olivia-payment-success", handlePaymentSuccess as EventListener)
    window.addEventListener("olivia-pi-session-changed", handleSessionChange)

    return () => {
      window.removeEventListener("olivia-payment-success", handlePaymentSuccess as EventListener)
      window.removeEventListener("olivia-pi-session-changed", handleSessionChange)
    }
  }, [featureId, onClose])

  if (!open) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9998]"
        onClick={() => {
          playSound("click")
          onClose()
        }}
      />

      {/* Modal */}
      <div className="fixed inset-x-4 top-1/2 -translate-y-1/2 bg-white dark:bg-gray-900 rounded-3xl shadow-2xl z-[9999] max-w-md mx-auto overflow-hidden">
        {/* Header with sparkle background */}
        <div className="relative bg-gradient-to-br from-purple-600 via-pink-600 to-yellow-500 p-6">
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-4 left-4 w-2 h-2 bg-white rounded-full animate-pulse" />
            <div className="absolute top-8 right-8 w-1 h-1 bg-white rounded-full animate-pulse delay-75" />
            <div className="absolute bottom-6 left-12 w-1.5 h-1.5 bg-white rounded-full animate-pulse delay-150" />
            <div className="absolute bottom-4 right-4 w-1 h-1 bg-white rounded-full animate-pulse delay-300" />
          </div>

          <button
            onClick={() => {
              playSound("click")
              onClose()
            }}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors z-10"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="relative text-center">
            {isPremium ? (
              <div className="w-16 h-16 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center">
                <Check className="w-8 h-8 text-white" />
              </div>
            ) : (
              <div className="w-16 h-16 mx-auto mb-4 bg-white/20 backdrop-blur rounded-full flex items-center justify-center">
                <Crown className="w-8 h-8 text-white" />
              </div>
            )}
            <h2 className="text-2xl font-bold text-white mb-2">{feature}</h2>
            <p className="text-white/90 text-sm">{description}</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {isPremium ? (
            <div className="text-center py-8">
              <div className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Đã kích hoạt!</h3>
              <p className="text-gray-600 dark:text-gray-400">Bạn đã sở hữu tính năng này</p>
            </div>
          ) : (
            <>
              {/* Benefits */}
              <div className="space-y-3 mb-6">
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Bạn sẽ nhận được:</p>
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="mt-0.5">
                      <Sparkles className="w-5 h-5 text-purple-600" />
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300">{benefit}</p>
                  </div>
                ))}
              </div>

              {/* Price */}
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-4 mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Giá:</span>
                  <div className="flex items-center gap-2">
                    <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
                      <path
                        d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
                        fill="white"
                      />
                      <path d="M11 8h2v8h-2V8z" fill="white" />
                      <path d="M8 11h8v2H8v-2z" fill="white" />
                    </svg>
                    <span className="text-2xl font-bold text-purple-600 dark:text-purple-400">{amount} Pi</span>
                  </div>
                </div>
              </div>

              {/* Pay Button */}
              <PayWithPiButton amount={amount} feature={feature} featureId={featureId} className="w-full" />

              {!hasPaymentAccess && (
                <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 rounded-xl border-2 border-red-300 dark:border-red-700">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-red-900 dark:text-red-200 mb-1">Thiếu quyền thanh toán</p>
                      <p className="text-xs text-red-700 dark:text-red-300">
                        Vui lòng Allow quyền payments trong popup Pi Browser để có thể thanh toán.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 px-6 py-4 flex items-center justify-center gap-2 border-t border-purple-200 dark:border-purple-800">
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
            <path
              d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
              fill="white"
            />
            <path d="M11 8h2v8h-2V8z" fill="white" />
            <path d="M8 11h8v2H8v-2z" fill="white" />
          </svg>
          <span className="text-xs font-bold text-purple-700 dark:text-purple-300">Powered by Pi Network Payments</span>
        </div>
      </div>
    </>
  )
}
