"use client"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useWallet } from "@/hooks/use-wallet"
import {
  getBiometricEnabled,
  saveBiometricEnabled,
  getPinHash,
  clearWalletData,
  deleteWalletCompletely,
} from "@/lib/storage"
import { useToast } from "@/hooks/use-toast"
import { useTheme } from "./theme-context"
import {
  LogOut,
  Info,
  Languages,
  Fingerprint,
  Key,
  HelpCircle,
  MessageCircle,
  AlertCircle,
  SettingsIcon,
  DollarSign,
  Clock,
  Moon,
  Sun,
  Download,
  Upload,
  Sparkles,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLanguage } from "@/hooks/use-language"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useState, useEffect } from "react"
import { PinManagementDialog } from "./pin-management-dialog"
import { SeedPhraseDisplayDialog } from "./seed-phrase-display-dialog"
import { FAQDialog } from "./faq-dialog"
import { BugReportDialog } from "./bug-report-dialog"
import { DeleteWalletDialog } from "./delete-wallet-dialog"
import { WalletExportDialog } from "./wallet-export-dialog"
import { WalletImportDialog } from "./wallet-import-dialog"
import { NetworkSwitcher } from "./network-switcher"

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { address } = useWallet()
  const { toast } = useToast()
  const { t, language, setLanguage } = useLanguage()
  const [biometricEnabled, setBiometricEnabled] = useState(false)
  const [showPinDialog, setShowPinDialog] = useState(false)
  const [showSeedDialog, setShowSeedDialog] = useState(false)
  const [showFAQDialog, setShowFAQDialog] = useState(false)
  const [showBugReportDialog, setShowBugReportDialog] = useState(false)
  const [showDeleteWalletDialog, setShowDeleteWalletDialog] = useState(false)
  const [showExportDialog, setShowExportDialog] = useState(false)
  const [showImportDialog, setShowImportDialog] = useState(false)
  const [hasPin, setHasPin] = useState(false)
  const [autoLockTime, setAutoLockTime] = useState("5")
  const [currency, setCurrency] = useState("vnd")
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    if (open) {
      const enabled = getBiometricEnabled()
      setBiometricEnabled(enabled)
      checkPinStatus()

      const savedAutoLock = localStorage.getItem("olivia_autolock_time")
      if (savedAutoLock) {
        setAutoLockTime(savedAutoLock)
      } else {
        // First time - check old key for migration
        const oldAutoLock = localStorage.getItem("auto_lock")
        if (oldAutoLock) {
          setAutoLockTime(oldAutoLock)
          localStorage.setItem("olivia_autolock_time", oldAutoLock)
          localStorage.removeItem("auto_lock")
        }
      }

      const savedCurrency = localStorage.getItem("olivia_currency")
      if (savedCurrency) {
        setCurrency(savedCurrency.toLowerCase())
      } else {
        // Detect from device language if no saved preference
        const userLanguage = navigator.language || "en"
        const defaultCurrency = userLanguage.startsWith("vi") ? "vnd" : "usd"
        setCurrency(defaultCurrency)
      }
    }
  }, [open])

  useEffect(() => {
    let autoLockTimer: NodeJS.Timeout
    let lastActivityTime = Date.now()

    const resetAutoLockTimer = () => {
      lastActivityTime = Date.now()

      if (autoLockTimer) {
        clearTimeout(autoLockTimer)
      }

      const lockMinutes = Number.parseInt(autoLockTime)
      if (autoLockTime !== "never") {
        autoLockTimer = setTimeout(
          () => {
            const currentTime = Date.now()
            const timeSinceLastActivity = (currentTime - lastActivityTime) / 1000 / 60

            if (timeSinceLastActivity >= lockMinutes) {
              // Lock the wallet - reload to trigger PIN unlock
              window.location.reload()
            }
          },
          lockMinutes * 60 * 1000,
        )
      }
    }

    const activityEvents = ["mousedown", "keydown", "scroll", "touchstart"]
    activityEvents.forEach((event) => {
      document.addEventListener(event, resetAutoLockTimer)
    })

    resetAutoLockTimer()

    return () => {
      if (autoLockTimer) {
        clearTimeout(autoLockTimer)
      }
      activityEvents.forEach((event) => {
        document.removeEventListener(event, resetAutoLockTimer)
      })
    }
  }, [autoLockTime])

  const checkPinStatus = async () => {
    const pinData = await getPinHash()
    setHasPin(!!pinData)
  }

  const handleBiometricToggle = async (checked: boolean) => {
    if (checked) {
      // Enable biometric
      try {
        if (typeof window !== "undefined" && (window as any).Pi && (window as any).Pi.biometric) {
          const Pi = (window as any).Pi

          const result = await Pi.biometric.authenticate({
            reason: "Kích hoạt Face ID / Touch ID cho Olivia PiMask",
            fallbackEnabled: true,
          })

          if (result.success) {
            saveBiometricEnabled(true)
            setBiometricEnabled(true)
            toast({
              title: "Thành công",
              description: "Face ID / Touch ID đã được bật",
            })
          } else {
            toast({
              title: "Không thành công",
              description: "Không thể kích hoạt sinh trắc học",
              variant: "destructive",
            })
          }
        } else {
          // Preview mode: auto-enable
          saveBiometricEnabled(true)
          setBiometricEnabled(true)
          toast({
            title: "Đã bật (Chế độ xem trước)",
            description: "Face ID sẽ hoạt động khi publish mainnet",
          })
        }
      } catch (error) {
        console.error("[v0] Biometric toggle error:", error)
        toast({
          title: "Lỗi",
          description: "Không thể thay đổi cài đặt sinh trắc học",
          variant: "destructive",
        })
      }
    } else {
      // Disable biometric
      saveBiometricEnabled(false)
      setBiometricEnabled(false)
      toast({
        title: "Đã tắt",
        description: "Face ID / Touch ID đã được tắt",
      })
    }
  }

  const handleAutoLockChange = (value: string) => {
    setAutoLockTime(value)
    localStorage.setItem("olivia_autolock_time", value)
    toast({
      title: "Đã cập nhật",
      description:
        value === "never" ? "Ví sẽ không tự động khóa" : `Ví sẽ tự động khóa sau ${value} phút không hoạt động`,
    })
  }

  const handleCurrencyChange = (value: string) => {
    setCurrency(value)
    localStorage.setItem("olivia_currency", value.toUpperCase())
    const currencySymbol = value === "vnd" ? "₫" : value === "usd" ? "$" : "€"
    toast({
      title: "Đã cập nhật",
      description: `Đơn vị tiền tệ: ${currencySymbol}`,
    })
  }

  const handleContactSupport = () => {
    window.open("mailto:support@oliviapimask.com?subject=Hỗ trợ Olivia PiMask", "_blank")
  }

  const handleInviteFriends = async () => {
    const shareText = "Mời bạn dùng Olivia PiMask - ví Web3 đẹp như Olivia! 💜\n\nTải ngay: https://oliviapimask.com"

    if (navigator.share) {
      try {
        await navigator.share({
          title: "Olivia PiMask",
          text: shareText,
        })
      } catch (error) {
        console.log("[v0] Share cancelled or error:", error)
      }
    } else {
      // Fallback to copy to clipboard
      navigator.clipboard.writeText(shareText)
      toast({
        title: "Đã sao chép",
        description: "Link mời bạn bè đã được sao chép vào clipboard",
      })
    }
  }

  const handleRateApp = () => {
    toast({
      title: "Cảm ơn bạn!",
      description: "Tính năng đánh giá sẽ khả dụng khi app publish lên store",
    })
  }

  const handleLogout = () => {
    clearWalletData()
    toast({
      title: "Đã đăng xuất",
      description: "Quay lại màn hình chào",
    })
    // Reload to go back to welcome screen
    window.location.reload()
  }

  const handleDeleteWallet = () => {
    deleteWalletCompletely()
    toast({
      title: "Ví đã được xóa",
      description: "Tất cả dữ liệu đã bị xóa khỏi thiết bị",
    })
    // Reload to go back to welcome screen
    setTimeout(() => {
      window.location.reload()
    }, 1000)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="fixed bottom-0 left-1/2 -translate-x-1/2 w-[90%] max-h-[85vh] mb-0 rounded-t-3xl rounded-b-none bg-gradient-to-br from-purple-50 to-pink-50 dark:from-[#121212] dark:to-[#121212] border-t border-purple-200 dark:border-[#252525] shadow-2xl animate-slide-up overflow-hidden flex flex-col">
          <div className="flex-shrink-0 py-2 flex justify-center">
            <div className="w-12 h-1 bg-purple-300 dark:bg-purple-700 rounded-full" />
          </div>

          <DialogHeader className="flex-shrink-0 px-6 pb-4">
            <DialogTitle className="text-purple-900 dark:text-purple-200">{t.settings.title}</DialogTitle>
            <DialogDescription className="text-purple-700 dark:text-purple-400">
              {t.settings.subtitle}
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto space-y-3 px-6 pb-[100px]">
            {/* Network Switcher - Compact */}
            <NetworkSwitcher />

            {/* Quick Actions - Top priority buttons */}
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 bg-white/80 dark:bg-[#33004D]/80 justify-start"
                onClick={() => setShowImportDialog(true)}
              >
                <Upload className="w-4 h-4 mr-2 text-purple-600 dark:text-purple-400" />
                Import ví nhanh
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 bg-white/80 dark:bg-[#33004D]/80 justify-start"
                onClick={() => setShowSeedDialog(true)}
              >
                <Key className="w-4 h-4 mr-2 text-purple-600 dark:text-purple-400" />
                Hiển thị seed phrase
              </Button>
            </div>

            {/* Security - Compact card */}
            <Card className="border-purple-200 dark:border-purple-500 bg-white/80 dark:bg-[#33004D]/80 backdrop-blur-sm">
              <CardHeader className="pb-2 pt-3">
                <CardTitle className="text-sm flex items-center gap-2 text-purple-900 dark:text-purple-200">
                  <Fingerprint className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  Bảo mật
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label className="text-sm text-purple-900 dark:text-purple-200">Face ID / Touch ID</Label>
                    <p className="text-xs text-purple-600 dark:text-purple-400">
                      {biometricEnabled ? "Đã bật" : "Chưa bật"}
                    </p>
                  </div>
                  <Switch checked={biometricEnabled} onCheckedChange={handleBiometricToggle} />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-purple-100 dark:border-purple-700">
                  <div className="flex-1">
                    <Label className="text-sm text-purple-900 dark:text-purple-200">Mã PIN</Label>
                    <p className="text-xs text-purple-600 dark:text-purple-400">
                      {hasPin ? "Đã thiết lập" : "Chưa thiết lập"}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowPinDialog(true)}
                    className="border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 h-8 text-xs"
                  >
                    {hasPin ? "Đổi PIN" : "Thiết lập"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Backup - Compact card */}
            <Card className="border-purple-200 dark:border-purple-500 bg-white/80 dark:bg-[#33004D]/80 backdrop-blur-sm">
              <CardHeader className="pb-2 pt-3">
                <CardTitle className="text-sm flex items-center gap-2 text-purple-900 dark:text-purple-200">
                  <Download className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  Backup ví
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 h-8"
                  onClick={() => setShowExportDialog(true)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export ví nhanh
                </Button>
              </CardContent>
            </Card>

            {/* Support - List items */}
            <Card className="border-purple-200 dark:border-purple-500 bg-white/80 dark:bg-[#33004D]/80 backdrop-blur-sm">
              <CardHeader className="pb-2 pt-3">
                <CardTitle className="text-sm flex items-center gap-2 text-purple-900 dark:text-purple-200">
                  <HelpCircle className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  Hỗ trợ
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 pb-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 h-8"
                  onClick={() => setShowFAQDialog(true)}
                >
                  <Info className="w-4 h-4 mr-2" />
                  FAQ
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 h-8"
                  onClick={handleContactSupport}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Liên hệ support
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-purple-700 dark:text-purple-200 hover:bg-purple-50 dark:hover:bg-purple-700 h-8"
                  onClick={() => setShowBugReportDialog(true)}
                >
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Báo lỗi
                </Button>
              </CardContent>
            </Card>

            {/* Customization - Compact settings */}
            <Card className="border-purple-200 dark:border-purple-500 bg-white/80 dark:bg-[#33004D]/80 backdrop-blur-sm">
              <CardHeader className="pb-2 pt-3">
                <CardTitle className="text-sm flex items-center gap-2 text-purple-900 dark:text-purple-200">
                  <SettingsIcon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  Tùy chỉnh
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 pb-3">
                {/* Dark Mode */}
                <div className="flex items-center justify-between py-1">
                  <Label
                    className="text-sm text-purple-900 dark:text-purple-200 flex items-center gap-2"
                    htmlFor="dark-mode"
                  >
                    {theme === "dark" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                    Dark Mode
                  </Label>
                  <Switch id="dark-mode" checked={theme === "dark"} onCheckedChange={toggleTheme} />
                </div>

                <div className="h-px bg-purple-100 dark:bg-purple-700" />

                {/* Visual Effects */}
                <div className="flex items-center justify-between py-1">
                  <Label
                    className="text-sm text-purple-900 dark:text-purple-200 flex items-center gap-2"
                    htmlFor="visual-effects"
                  >
                    <Sparkles className="w-4 h-4" />
                    Hiệu ứng
                  </Label>
                  <Switch
                    id="visual-effects"
                    checked={localStorage.getItem("visual_effects") !== "false"}
                    onCheckedChange={(checked) => {
                      localStorage.setItem("visual_effects", String(checked))
                      window.location.reload()
                    }}
                  />
                </div>

                <div className="h-px bg-purple-100 dark:bg-purple-700" />

                {/* Language */}
                <div className="space-y-1">
                  <Label className="text-sm text-purple-900 dark:text-purple-200 flex items-center gap-2">
                    <Languages className="w-4 h-4" />
                    Ngôn ngữ
                  </Label>
                  <Select value={language} onValueChange={(value: "vi" | "en" | "zh") => setLanguage(value)}>
                    <SelectTrigger className="h-9 bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500 text-purple-900 dark:text-purple-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500">
                      <SelectItem value="vi">Tiếng Việt</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="zh">中文 (简体)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="h-px bg-purple-100 dark:bg-purple-700" />

                {/* Currency */}
                <div className="space-y-1">
                  <Label className="text-sm text-purple-900 dark:text-purple-200 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Đơn vị tiền tệ
                  </Label>
                  <Select value={currency} onValueChange={handleCurrencyChange}>
                    <SelectTrigger className="h-9 bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500 text-purple-900 dark:text-purple-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500">
                      <SelectItem value="vnd">VND (₫)</SelectItem>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="h-px bg-purple-100 dark:bg-purple-700" />

                {/* Auto-lock */}
                <div className="space-y-1">
                  <Label className="text-sm text-purple-900 dark:text-purple-200 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Auto-lock
                  </Label>
                  <Select value={autoLockTime} onValueChange={handleAutoLockChange}>
                    <SelectTrigger className="h-9 bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500 text-purple-900 dark:text-purple-200">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white dark:bg-[#2C003E] border-purple-200 dark:border-purple-500">
                      <SelectItem value="1">1 phút</SelectItem>
                      <SelectItem value="5">5 phút</SelectItem>
                      <SelectItem value="10">10 phút</SelectItem>
                      <SelectItem value="never">Không bao giờ</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Logout Button */}
            <Button
              variant="destructive"
              size="sm"
              onClick={handleLogout}
              className="w-full bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 text-white h-9"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Đăng xuất
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <PinManagementDialog
        open={showPinDialog}
        onOpenChange={setShowPinDialog}
        hasExistingPin={hasPin}
        onPinChanged={checkPinStatus}
      />
      <SeedPhraseDisplayDialog open={showSeedDialog} onOpenChange={setShowSeedDialog} onPinVerified={() => {}} />
      <FAQDialog open={showFAQDialog} onOpenChange={setShowFAQDialog} />
      <BugReportDialog open={showBugReportDialog} onOpenChange={setShowBugReportDialog} />
      <DeleteWalletDialog
        open={showDeleteWalletDialog}
        onOpenChange={setShowDeleteWalletDialog}
        onConfirmDelete={handleDeleteWallet}
      />
      <WalletExportDialog open={showExportDialog} onOpenChange={setShowExportDialog} />

      <WalletImportDialog
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
        onImportSuccess={() => {
          window.location.reload()
        }}
      />
    </>
  )
}
