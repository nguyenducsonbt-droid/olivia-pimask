"use client"

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface LogoutConfirmationDialogProps {
  open: boolean
  onClose?: () => void
  onOpenChange?: (open: boolean) => void
  onConfirm: () => void
}

export function LogoutConfirmationDialog({ open, onClose, onOpenChange, onConfirm }: LogoutConfirmationDialogProps) {
  const handleOpenChange = (newOpen: boolean) => {
    if (onOpenChange) onOpenChange(newOpen)
    if (!newOpen && onClose) onClose()
  }

  return (
    <AlertDialog open={open} onOpenChange={handleOpenChange}>
      <AlertDialogContent className="bg-gradient-to-br from-red-50 to-orange-50">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-red-900">⚠️ Ngừng kết nối & Thoát</AlertDialogTitle>
          <AlertDialogDescription className="text-red-700 space-y-2">
            <p>
              <strong className="text-red-800">CẢNH BÁO:</strong> Hành động này sẽ <strong>XÓA HOÀN TOÀN</strong> tất cả
              dữ liệu ví khỏi thiết bị này:
            </p>
            <ul className="list-disc list-inside space-y-1 text-sm">
              <li>Khóa riêng tư (Private Key)</li>
              <li>Địa chỉ ví Pi Mainnet</li>
              <li>PIN & Face ID</li>
              <li>Lịch sử giao dịch</li>
              <li>Kết nối Pi Browser</li>
            </ul>
            <p className="font-bold text-red-800 mt-3">
              ⚠️ BẠN PHẢI CÓ SẴN SEED PHRASE (24 từ) ĐỂ KHÔI PHỤC VÍ SAU NÀY!
            </p>
            <p className="text-sm mt-2">
              Sau khi ngừng kết nối, bạn cần tạo ví mới hoặc import lại seed phrase để sử dụng app.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="border-purple-300">Hủy</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-red-600 hover:bg-red-700 text-white">
            Ngừng kết nối & Xóa dữ liệu
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
