"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"
import { useState } from "react"

interface FAQDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const faqs = [
  {
    question: "Tôi quên mã PIN, làm sao để khôi phục?",
    answer:
      "Nếu bạn quên PIN, bạn cần khôi phục ví bằng 12 từ seed phrase. Vào màn hình chào, chọn 'Khôi phục ví', nhập 12 từ seed phrase, sau đó thiết lập PIN mới.",
  },
  {
    question: "Làm sao để sao lưu ví an toàn?",
    answer:
      "Vào Settings > Sao lưu & Khôi phục > Hiển thị 12 từ seed phrase. Viết 12 từ này ra giấy và cất giữ nơi an toàn. KHÔNG chụp màn hình, không lưu trên điện thoại, không chia sẻ với ai.",
  },
  {
    question: "Gửi Pi có an toàn không?",
    answer:
      "Có. Olivia PiMask sử dụng mã hóa chuẩn Pi Network. Luôn kiểm tra kỹ địa chỉ ví nhận trước khi gửi. Sau khi gửi, giao dịch không thể hoàn tác.",
  },
  {
    question: "Tại sao số dư Pi của tôi là 0?",
    answer:
      "Trong chế độ preview/testnet, số dư mặc định là 0. Khi publish lên mainnet và kết nối với Pi Browser thật, số dư Pi thực sẽ hiển thị.",
  },
  {
    question: "Face ID không hoạt động?",
    answer:
      "Đảm bảo bạn đã bật Face ID trong Settings > Bảo mật. Nếu vẫn lỗi, bạn có thể dùng PIN để mở khóa. Face ID chỉ hoạt động đầy đủ khi publish mainnet.",
  },
  {
    question: "Làm sao để thêm token tùy chỉnh?",
    answer:
      "Vào tab Tài sản, bấm nút '+', dán địa chỉ contract của token. Hệ thống sẽ tự động lấy thông tin token và thêm vào danh sách.",
  },
  {
    question: "Ví có lưu giữ seed phrase của tôi không?",
    answer:
      "KHÔNG. Olivia PiMask chỉ lưu ví đã mã hóa trên thiết bị của bạn. Seed phrase chỉ hiển thị khi bạn yêu cầu và nhập PIN. Không có server nào lưu giữ seed phrase.",
  },
]

export function FAQDialog({ open, onOpenChange }: FAQDialogProps) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader>
          <DialogTitle className="text-purple-900 text-xl">FAQ - Câu hỏi thường gặp</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-4">
          {faqs.map((faq, index) => (
            <Card key={index} className="border-purple-200 bg-white/80 backdrop-blur-sm">
              <CardHeader
                className="pb-3 cursor-pointer hover:bg-purple-50 transition-colors rounded-t-lg"
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
              >
                <CardTitle className="text-sm flex items-center justify-between text-purple-900">
                  <span>{faq.question}</span>
                  {expandedIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-purple-600" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-purple-600" />
                  )}
                </CardTitle>
              </CardHeader>
              {expandedIndex === index && (
                <CardContent className="pt-0">
                  <p className="text-sm text-purple-700 leading-relaxed">{faq.answer}</p>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
