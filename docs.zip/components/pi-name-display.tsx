"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Globe, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PiNameDisplayProps {
  address: string
}

export function PiNameDisplay({ address }: PiNameDisplayProps) {
  const [piName, setPiName] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchPiName = async () => {
      setIsLoading(true)

      try {
        if (typeof window !== "undefined") {
          const Pi = (window as any).Pi

          // Try to get authenticated user's Pi Name
          if (Pi?.authenticate) {
            try {
              const authResult = await Pi.authenticate(["username"], () => {})

              if (authResult?.user?.username) {
                const username = authResult.user.username

                // Check if user has claimed .pi domain
                if (Pi?.names?.check) {
                  const hasName = await Pi.names.check(username)

                  if (hasName) {
                    const fullName = `${username}.pi`
                    setPiName(fullName)
                    localStorage.setItem("pi_name", fullName)
                    console.log("[v0] Pi Name fetched:", fullName)
                  } else {
                    setPiName(null)
                    localStorage.removeItem("pi_name")
                  }
                } else {
                  // Fallback: assume user has .pi name if authenticated
                  const fullName = `${username}.pi`
                  setPiName(fullName)
                  localStorage.setItem("pi_name", fullName)
                }
              }
            } catch (authError) {
              console.log("[v0] Pi authentication skipped, checking stored name")

              // Check stored Pi Name
              const storedName = localStorage.getItem("pi_name")
              if (storedName) {
                setPiName(storedName)
              }
            }
          } else {
            // Fallback to stored name if Pi SDK not available
            const storedName = localStorage.getItem("pi_name")
            if (storedName) {
              setPiName(storedName)
            }
          }
        }
      } catch (error) {
        console.error("[v0] Pi Name fetch error:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPiName()

    // Listen for visibility changes to refresh Pi Name
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        fetchPiName()
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [address])

  const handleManagePiName = () => {
    try {
      if (typeof window !== "undefined") {
        const Pi = (window as any).Pi

        // Store session for back navigation
        localStorage.setItem("pi_session_active", "true")

        // Try Pi SDK navigation with backToApp
        if (Pi?.navigation?.open) {
          Pi.navigation.open("https://pi.network/names", { backToApp: true })
        } else if (Pi?.app?.launchBrowser) {
          Pi.app.launchBrowser("https://pi.network/names")
        } else {
          // Deep link fallback
          const link = document.createElement("a")
          link.href = "pi://browser/names"
          link.click()

          // Fallback to web if deep link fails
          setTimeout(() => {
            window.open("https://pi.network/names", "_blank")
          }, 1000)
        }

        toast({
          title: piName ? "Quản lý Pi Name" : "Đặt Pi Name",
          description: piName ? "Đang mở Pi Names để quản lý domain của bạn" : "Đang mở Pi Names để đặt tên .pi cho ví",
        })
      }
    } catch (error) {
      console.error("[v0] Pi Name management error:", error)
      toast({
        title: "Không thể mở Pi Names",
        description: "Vui lòng mở Pi Browser và truy cập pi.network/names",
        variant: "destructive",
      })
    }
  }

  return (
    <div
      className="flex items-center justify-between gap-3 px-1 py-2 animate-fade-in"
      style={{ animation: "fade-in 0.3s ease-out" }}
    >
      <div className="flex items-center gap-2 min-w-0 flex-1">
        <Globe className="w-4 h-4 text-purple-600 flex-shrink-0" />
        {isLoading ? (
          <Loader2 className="w-4 h-4 text-purple-600 animate-spin" />
        ) : piName ? (
          <span className="text-base font-bold text-purple-900 truncate">{piName}</span>
        ) : (
          <span className="text-sm font-medium text-purple-400 truncate">Chưa có Pi Name</span>
        )}
      </div>

      <Button
        onClick={handleManagePiName}
        size="sm"
        className="h-8 text-xs font-semibold rounded-full flex-shrink-0 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white border-0 shadow-sm"
      >
        <Globe className="w-3 h-3 mr-1" />
        {piName ? "Quản lý Pi Name" : "Đặt Pi Name"}
      </Button>
    </div>
  )
}
