"use client"

import { useState, useEffect, memo, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import {
  LogOut,
  Globe,
  DollarSign,
  Lock,
  Sparkles,
  Trash2,
  RefreshCw,
  Info,
  Shield,
  Eye,
  Fingerprint,
  Clock,
  ArrowLeft,
  Settings,
  Download,
} from "lucide-react"
import { NetworkSwitcher } from "./network-switcher"
import { LogoutConfirmationDialog } from "./logout-confirmation-dialog"
import { ClearCacheDialog } from "./clear-cache-dialog"
import { BiometricSetupDialog } from "./security/biometric-setup-dialog"
import { ShowSeedPhraseDialog } from "./security/show-seed-phrase-dialog"
import { ExportPrivateKeyDialog } from "./security/export-private-key-dialog"
import { TwoFactorSetupDialog } from "./security/two-factor-setup-dialog"
import { EmailOTPSetupDialog } from "./security/email-otp-setup-dialog"
import { TwoFactorMethodSelector, type TwoFactorMethod } from "./security/two-factor-method-selector"
import { useLanguage } from "@/hooks/use-language"
import { useToast } from "@/hooks/use-toast"
import { useAppUpdate } from "@/hooks/use-app-update"
import { getBiometricEnabled, saveBiometricEnabled } from "@/lib/storage"
import { disableTwoFactor } from "@/lib/two-factor"
import { disableEmailOTP } from "@/lib/email-otp"
import { getAutoLockTime, saveAutoLockTime } from "@/lib/auto-lock"
import { HistoryView } from "./history-view"

const SettingRow = memo(
  ({
    icon: Icon,
    label,
    description,
    checked,
    onCheckedChange,
    disabled,
    id,
  }: {
    icon: any
    label: string
    description?: string
    checked: boolean
    onCheckedChange: (checked: boolean) => void
    disabled?: boolean
    id: string
  }) => (
    <div className="flex items-center justify-between">
      <div className="flex flex-col gap-1">
        <Label htmlFor={id} className="flex items-center gap-2 text-sm">
          <Icon className="w-4 h-4 text-purple-600" />
          {label}
        </Label>
        {description && <p className="text-xs text-muted-foreground">{description}</p>}
      </div>
      <Switch id={id} checked={checked} onCheckedChange={onCheckedChange} disabled={disabled} />
    </div>
  ),
)

SettingRow.displayName = "SettingRow"

export function SettingsView() {
  const [showBiometricDialog, setShowBiometricDialog] = useState(false)
  const [showSeedDialog, setShowSeedDialog] = useState(false)
  const [showExportKeyDialog, setShowExportKeyDialog] = useState(false)
  const [show2FAMethodSelector, setShow2FAMethodSelector] = useState(false)
  const [show2FADialog, setShow2FADialog] = useState(false)
  const [showEmailOTPDialog, setShowEmailOTPDialog] = useState(false)
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)
  const [showClearCache, setShowClearCache] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [visualEffects, setVisualEffects] = useState(true)
  const [currency, setCurrency] = useState(() => {
    const saved = localStorage.getItem("olivia_currency")
    if (saved) return saved.toUpperCase()
    const userLanguage = navigator.language || "en"
    return userLanguage.startsWith("vi") ? "VND" : "USD"
  })
  const [autoLock, setAutoLock] = useState<string | null>(null)
  const [biometricEnabled, setBiometricEnabled] = useState(false)
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [emailOTPEnabled, setEmailOTPEnabled] = useState(false)
  const [current2FAMethod, setCurrent2FAMethod] = useState<TwoFactorMethod | undefined>()
  const { t, language, changeLanguage } = useLanguage()
  const { toast } = useToast()
  const { currentVersion, checking, checkForUpdates } = useAppUpdate()
  const [showHistoryView, setShowHistoryView] = useState(false)

  useEffect(() => {
    const theme = localStorage.getItem("theme")
    setDarkMode(theme === "dark")

    const effects = localStorage.getItem("visual_effects")
    setVisualEffects(effects !== "false")

    const savedCurrency = localStorage.getItem("olivia_currency")
    if (savedCurrency) setCurrency(savedCurrency.toUpperCase())

    const savedAutoLock = getAutoLockTime()
    setAutoLock(savedAutoLock) // Can be null if not set

    const loadBiometric = () => {
      const enabled = getBiometricEnabled()
      console.log("[v0] Loading biometric setting:", enabled)
      setBiometricEnabled(enabled)
    }

    loadBiometric()

    // Listen for biometric changes from other components
    const handleBiometricChange = (e: any) => {
      console.log("[v0] Biometric changed event:", e.detail.enabled)
      setBiometricEnabled(e.detail.enabled)
    }

    window.addEventListener("biometric-changed", handleBiometricChange)

    return () => {
      window.removeEventListener("biometric-changed", handleBiometricChange)
    }
  }, [])

  const handleDarkModeToggle = useCallback(
    (checked: boolean) => {
      setDarkMode(checked)
      localStorage.setItem("theme", checked ? "dark" : "light")
      document.documentElement.classList.toggle("dark", checked)
      const modeText = checked
        ? language === "vi"
          ? "Dark Mode"
          : language === "en"
            ? "Dark Mode"
            : "深色模式"
        : language === "vi"
          ? "Light Mode"
          : language === "en"
            ? "Light Mode"
            : "浅色模式"
      toast({
        title: checked
          ? `${modeText} ${language === "vi" ? "đã bật" : language === "en" ? "Enabled" : "已启用"}`
          : `${modeText} ${language === "vi" ? "đã tắt" : language === "en" ? "Disabled" : "已禁用"}`,
        description: checked
          ? language === "vi"
            ? "Giao diện tối giúp bảo vệ mắt ban đêm"
            : language === "en"
              ? "Dark interface protects eyes at night"
              : "深色界面保护夜间视力"
          : language === "vi"
            ? "Giao diện sáng cho ban ngày"
            : language === "en"
              ? "Light interface for daytime"
              : "浅色界面适合白天",
      })
    },
    [language, toast],
  )

  const handleVisualEffectsToggle = useCallback(
    (checked: boolean) => {
      setVisualEffects(checked)
      localStorage.setItem("visual_effects", checked.toString())
      const effectsText =
        language === "vi" ? "hiệu ứng giao diện" : language === "en" ? "interface animation" : "界面动画"
      toast({
        title: checked
          ? `${language === "vi" ? "Đã bật" : language === "en" ? "Enabled" : "已启用"} ${effectsText}`
          : `${language === "vi" ? "Đã tắt" : language === "en" ? "Disabled" : "已禁用"} ${effectsText}`,
        description: checked
          ? language === "vi"
            ? "Glow, ripple, particles đã được kích hoạt"
            : language === "en"
              ? "Glow, ripple, particles activated"
              : "光效、涟漪、粒子已激活"
          : language === "vi"
            ? "Hiệu ứng đã tắt để tăng hiệu suất"
            : language === "en"
              ? "Effects disabled for better performance"
              : "已禁用效果以提高性能",
      })
    },
    [language, toast],
  )

  const handleCurrencyChange = useCallback(
    (value: string) => {
      const upperValue = value.toUpperCase()
      setCurrency(upperValue)
      localStorage.setItem("olivia_currency", upperValue)
      toast({
        title: language === "vi" ? "Đã đổi đơn vị tiền tệ" : language === "en" ? "Currency changed" : "已更改货币单位",
        description: `${language === "vi" ? "Hiển thị giá trị theo" : language === "en" ? "Display values in" : "显示价值为"} ${upperValue}`,
      })
    },
    [language, toast],
  )

  const handleLanguageChange = useCallback(
    (value: string) => {
      changeLanguage(value as "vi" | "en" | "zh")

      const languageNames = {
        vi: "Tiếng Việt",
        en: "English",
        zh: "中文 (简体)",
      }

      toast({
        title: t.common.success,
        description: `${t.settings.language}: ${languageNames[value as keyof typeof languageNames]}`,
      })
    },
    [changeLanguage, t, toast],
  )

  const handleAutoLockChange = useCallback(
    (value: string) => {
      setAutoLock(value)
      saveAutoLockTime(value)

      const minutes =
        value === "never"
          ? language === "vi"
            ? "không bao giờ"
            : language === "en"
              ? "never"
              : "从不"
          : value === "60"
            ? `1 ${language === "vi" ? "giờ" : language === "en" ? "hour" : "小时"}`
            : `${value} ${language === "vi" ? "phút" : language === "en" ? "minutes" : "分钟"}`

      toast({
        title: language === "vi" ? "Đã cập nhật Auto-lock" : language === "en" ? "Auto-lock updated" : "已更新自动锁定",
        description:
          language === "vi"
            ? `Ví sẽ tự khóa sau ${minutes} không hoạt động. Mở lại dùng Face ID (nếu bật) để mở nhanh.`
            : language === "en"
              ? `Wallet will auto-lock after ${minutes} of inactivity. Use Face ID (if enabled) for quick unlock.`
              : `钱包将在 ${minutes} 不活动后自动锁定。使用Face ID（如果启用）快速解锁。`,
      })
    },
    [language, toast],
  )

  const handleBiometricToggle = useCallback(
    (checked: boolean) => {
      if (checked) {
        setShowBiometricDialog(true)
      } else {
        saveBiometricEnabled(false)
        setBiometricEnabled(false)
        console.log("[v0] Face ID disabled by user")
        toast({
          title: "Đã tắt",
          description: "Face ID / Touch ID đã được tắt",
        })
      }
    },
    [toast],
  )

  const handle2FAToggle = useCallback(
    (checked: boolean) => {
      if (checked) {
        setShow2FAMethodSelector(true)
      } else {
        disableTwoFactor()
        disableEmailOTP()
        setTwoFactorEnabled(false)
        setEmailOTPEnabled(false)
        setCurrent2FAMethod(undefined)
        toast({
          title: "2FA đã tắt",
          description: "Bảo vệ giao dịch lớn đã được vô hiệu hóa",
        })
      }
    },
    [toast],
  )

  const handle2FAMethodSelected = useCallback(
    (method: TwoFactorMethod) => {
      setShow2FAMethodSelector(false)

      if (method === "google-auth") {
        setShow2FADialog(true)
      } else if (method === "email-otp") {
        setShowEmailOTPDialog(true)
      } else if (method === "sms") {
        toast({
          title: "Sắp có",
          description: "SMS OTP sẽ được bổ sung trong phiên bản tiếp theo",
        })
      }
    },
    [toast],
  )

  const confirmLogout = useCallback(() => {
    window.dispatchEvent(new Event("olivia-wallet-logout"))

    // Clear all session storage
    sessionStorage.clear()

    // Delete ALL wallet data completely
    if (typeof window !== "undefined") {
      // Remove all wallet-related data
      localStorage.removeItem("olivia_wallet_encrypted")
      localStorage.removeItem("olivia_pi_wallet")
      localStorage.removeItem("olivia_pi_address")
      localStorage.removeItem("olivia_pin_hash")
      localStorage.removeItem("olivia_biometric_enabled")
      localStorage.removeItem("pi_session_active")
      localStorage.removeItem("olivia_pi_session")
      localStorage.removeItem("olivia_pi_user")
      localStorage.removeItem("olivia_networks")
      localStorage.removeItem("olivia_tokens")
      localStorage.removeItem("olivia_transactions")
      localStorage.removeItem("olivia_custom_tokens")
      localStorage.removeItem("olivia_custom_networks")
      localStorage.removeItem("olivia_pi_connection")
      localStorage.removeItem("olivia_autolock_time")

      // Clear session wallet cache
      sessionStorage.removeItem("olivia_wallet_session")
      sessionStorage.removeItem("olivia_pi_wallet_session")

      // Disconnect Pi SDK completely
      if ((window as any).Pi) {
        try {
          if ((window as any).Pi.closeSession) {
            ;(window as any).Pi.closeSession()
          }
          // Clear Pi SDK secure storage
          if ((window as any).Pi.storage) {
            ;(window as any).Pi.storage.removeSecure("userPinHash")
          }
        } catch (err) {
          console.warn("[v0] Failed to disconnect Pi SDK:", err)
        }
      }
    }

    // Show disconnect toast
    toast({
      title: "Đã ngừng kết nối",
      description: "Tất cả dữ liệu ví đã được xóa. Vui lòng tạo hoặc import ví mới để tiếp tục.",
    })

    // Redirect to welcome screen after a short delay
    setTimeout(() => {
      window.location.href = "/"
    }, 1500)
  }, [toast])

  const clearCache = useCallback(() => {
    localStorage.removeItem("cache")
    toast({
      title: t.settings.cacheCleared,
      description: t.settings.cacheClearedDesc,
    })
  }, [t, toast])

  if (showHistoryView) {
    return (
      <div>
        <Button onClick={() => setShowHistoryView(false)} variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {language === "vi" ? "Quay lại" : language === "en" ? "Back" : "返回"}
        </Button>
        <HistoryView />
      </div>
    )
  }

  return (
    <div className="space-y-4 pb-20">
      <NetworkSwitcher />

      <Card className="border-purple-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="w-4 h-4 text-purple-600" />
            {language === "vi" ? "Bảo mật" : language === "en" ? "Security" : "安全"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <SettingRow
            icon={Fingerprint}
            label="Face ID / Touch ID"
            checked={biometricEnabled}
            onCheckedChange={handleBiometricToggle}
            id="biometric"
          />

          <SettingRow
            icon={Shield}
            label={
              language === "vi"
                ? `Xác thực hai yếu tố (2FA)${current2FAMethod ? ` - ${current2FAMethod === "google-auth" ? "Google Auth" : "Email OTP"}` : ""}`
                : language === "en"
                  ? `Two-Factor Authentication (2FA)${current2FAMethod ? ` - ${current2FAMethod === "google-auth" ? "Google Auth" : "Email OTP"}` : ""}`
                  : `双因素认证 (2FA)${current2FAMethod ? ` - ${current2FAMethod === "google-auth" ? "Google" : "Email"}` : ""}`
            }
            description={
              current2FAMethod
                ? language === "vi"
                  ? "Bấm để đổi phương thức"
                  : language === "en"
                    ? "Tap to change method"
                    : "点击更改方法"
                : undefined
            }
            checked={twoFactorEnabled || emailOTPEnabled}
            onCheckedChange={handle2FAToggle}
            id="two-factor"
          />

          <Button onClick={() => setShowSeedDialog(true)} variant="outline" className="w-full justify-start" size="sm">
            <Eye className="mr-2 h-4 w-4 text-purple-600" />
            {language === "vi" ? "Hiển thị Seed Phrase" : language === "en" ? "Show Seed Phrase" : "显示助记词"}
          </Button>

          <Button
            onClick={() => setShowExportKeyDialog(true)}
            variant="outline"
            className="w-full justify-start"
            size="sm"
          >
            <Download className="mr-2 h-4 w-4 text-purple-600" />
            {language === "vi" ? "Export Private Key" : language === "en" ? "Export Private Key" : "导出私钥"}
          </Button>
        </CardContent>
      </Card>

      <Card className="border-purple-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            {language === "vi" ? "Tùy chỉnh" : language === "en" ? "Customize" : "自定义"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="dark-mode" className="flex items-center gap-2 text-sm">
              Dark Mode
            </Label>
            <Switch id="dark-mode" checked={darkMode} onCheckedChange={handleDarkModeToggle} />
          </div>

          <SettingRow
            icon={Sparkles}
            label={language === "vi" ? "Hiệu ứng giao diện" : language === "en" ? "Interface Animation" : "界面动画"}
            checked={visualEffects}
            onCheckedChange={handleVisualEffectsToggle}
            id="visual-effects"
          />

          <div className="space-y-2">
            <Label htmlFor="currency" className="flex items-center gap-2 text-sm">
              <DollarSign className="w-4 h-4" />
              {language === "vi" ? "Đơn vị tiền tệ" : language === "en" ? "Currency Unit" : "货币单位"}
            </Label>
            <Select value={currency} onValueChange={handleCurrencyChange}>
              <SelectTrigger id="currency" className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD ($)</SelectItem>
                <SelectItem value="VND">VND (₫)</SelectItem>
                <SelectItem value="EUR">EUR (€)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="language" className="flex items-center gap-2 text-sm">
              <Globe className="w-4 h-4" />
              {t.settings.language}
            </Label>
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger id="language" className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="vi">Tiếng Việt</SelectItem>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="zh">中文 (简体)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="border-purple-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="w-4 h-4 text-purple-600" />
            {language === "vi" ? "Chung" : language === "en" ? "General" : "通用"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button onClick={() => setShowHistoryView(true)} variant="outline" className="w-full justify-start" size="sm">
            <Clock className="mr-2 h-4 w-4 text-purple-600" />
            {language === "vi" ? "Lịch sử giao dịch" : language === "en" ? "Transaction History" : "交易历史"}
          </Button>

          <div className="space-y-2 pt-2 border-t border-purple-100">
            <Label htmlFor="auto-lock" className="flex items-center gap-2 text-sm">
              <Lock className="w-4 h-4" />
              Auto-lock
            </Label>
            <Select value={autoLock || ""} onValueChange={handleAutoLockChange}>
              <SelectTrigger id="auto-lock" className="h-9">
                <SelectValue placeholder="-- Chọn thời gian --" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">
                  1 {language === "vi" ? "phút" : language === "en" ? "minute" : "分钟"}
                </SelectItem>
                <SelectItem value="5">
                  5 {language === "vi" ? "phút" : language === "en" ? "minutes" : "分钟"}
                </SelectItem>
                <SelectItem value="15">
                  15 {language === "vi" ? "phút" : language === "en" ? "minutes" : "分钟"}
                </SelectItem>
                <SelectItem value="30">
                  30 {language === "vi" ? "phút" : language === "en" ? "minutes" : "分钟"}
                </SelectItem>
                <SelectItem value="60">1 {language === "vi" ? "giờ" : language === "en" ? "hour" : "小时"}</SelectItem>
                <SelectItem value="never">
                  {language === "vi" ? "Không bao giờ" : language === "en" ? "Never" : "从不"}
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {language === "vi"
                ? "Mở ví lại sẽ yêu cầu Face ID hoặc seed phrase"
                : language === "en"
                  ? "Reopening wallet will require Face ID or seed phrase"
                  : "重新打开钱包需要Face ID或助记词"}
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-purple-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            {language === "vi" ? "Hệ thống" : language === "en" ? "System" : "系统"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between p-2 rounded-lg bg-purple-50 border border-purple-100">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {language === "vi" ? "Phiên bản" : language === "en" ? "Version" : "版本"}
                </p>
                <p className="text-xs text-gray-500">v{currentVersion}</p>
              </div>
            </div>
            <Button
              onClick={() => checkForUpdates(false)}
              variant="ghost"
              size="sm"
              disabled={checking}
              className="text-purple-600 hover:text-purple-700 hover:bg-purple-100"
            >
              <RefreshCw className={`h-4 w-4 mr-1 ${checking ? "animate-spin" : ""}`} />
              {checking
                ? language === "vi"
                  ? "Đang kiểm tra..."
                  : language === "en"
                    ? "Checking..."
                    : "检查中..."
                : language === "vi"
                  ? "Kiểm tra update"
                  : language === "en"
                    ? "Check update"
                    : "检查更新"}
            </Button>
          </div>

          <Button onClick={() => setShowClearCache(true)} variant="outline" className="w-full justify-start" size="sm">
            <Trash2 className="mr-2 h-4 w-4" />
            {language === "vi" ? "Xóa cache" : language === "en" ? "Clear Cache" : "清除缓存"}
          </Button>
          <Button
            onClick={() => setShowLogoutConfirm(true)}
            variant="outline"
            className="w-full justify-start bg-transparent text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
            size="sm"
          >
            <LogOut className="mr-2 h-4 w-4" />
            {language === "vi" ? "Ngừng kết nối & Thoát" : language === "en" ? "Disconnect & Exit" : "断开连接并退出"}
          </Button>
        </CardContent>
      </Card>

      {showBiometricDialog && (
        <BiometricSetupDialog
          open={showBiometricDialog}
          onClose={() => setShowBiometricDialog(false)}
          onSuccess={() => {
            setBiometricEnabled(true)
            saveBiometricEnabled(true)
            console.log("[v0] Face ID enabled by user")
            toast({
              title: "Đã bật",
              description: "Face ID / Touch ID đã được kích hoạt",
            })
          }}
        />
      )}

      {showSeedDialog && <ShowSeedPhraseDialog open={showSeedDialog} onClose={() => setShowSeedDialog(false)} />}

      {showExportKeyDialog && (
        <ExportPrivateKeyDialog open={showExportKeyDialog} onClose={() => setShowExportKeyDialog(false)} />
      )}

      {show2FAMethodSelector && (
        <TwoFactorMethodSelector
          open={show2FAMethodSelector}
          onClose={() => setShow2FAMethodSelector(false)}
          onMethodSelected={handle2FAMethodSelected}
          currentMethod={current2FAMethod}
        />
      )}

      {show2FADialog && (
        <TwoFactorSetupDialog
          open={show2FADialog}
          onClose={() => setShow2FADialog(false)}
          onSuccess={() => {
            setTwoFactorEnabled(true)
            setEmailOTPEnabled(false)
            setCurrent2FAMethod("google-auth")
          }}
        />
      )}

      {showEmailOTPDialog && (
        <EmailOTPSetupDialog
          open={showEmailOTPDialog}
          onClose={() => setShowEmailOTPDialog(false)}
          onSuccess={() => {
            setEmailOTPEnabled(true)
            setTwoFactorEnabled(false)
            setCurrent2FAMethod("email-otp")
          }}
        />
      )}

      {showLogoutConfirm && (
        <LogoutConfirmationDialog
          open={showLogoutConfirm}
          onClose={() => setShowLogoutConfirm(false)}
          onConfirm={confirmLogout}
        />
      )}
      {showClearCache && (
        <ClearCacheDialog open={showClearCache} onClose={() => setShowClearCache(false)} onConfirm={clearCache} />
      )}
    </div>
  )
}
