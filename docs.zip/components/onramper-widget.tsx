"use client"

import { useState, useEffect, useCallback } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import { Loader2, X, ShieldCheck, DollarSign } from "lucide-react"
import { OnramperService } from "@/lib/onramper-service"
import type { OnramperTransaction } from "@/lib/onramper-service"

interface OnramperWidgetProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  walletAddress?: string
  defaultAmount?: number
  defaultFiat?: string
  onSuccess?: (transaction: OnramperTransaction) => void
}

export function OnramperWidget({
  open,
  onOpenChange,
  walletAddress,
  defaultAmount = 100,
  defaultFiat = "USD",
  onSuccess,
}: OnramperWidgetProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [widgetUrl, setWidgetUrl] = useState("")

  useEffect(() => {
    if (open) {
      const url = OnramperService.getWidgetUrl({
        defaultAmount,
        defaultFiat,
        walletAddress,
      })
      setWidgetUrl(url)
      setIsLoading(true)
    }
  }, [open, walletAddress, defaultAmount, defaultFiat])

  const handleMessage = useCallback(
    (event: MessageEvent) => {
      OnramperService.handleWidgetEvent(event, {
        onSuccess: (data) => {
          // Create transaction record
          const transaction: OnramperTransaction = {
            id: data.transactionId || `onramper_${Date.now()}`,
            status: "completed",
            type: "onramp",
            fiatAmount: data.fiatAmount || defaultAmount,
            fiatCurrency: data.fiatCurrency || defaultFiat,
            cryptoAmount: data.cryptoAmount || 0,
            cryptoCurrency: data.cryptoCurrency || "PI",
            provider: data.provider || "Onramper",
            walletAddress: walletAddress || "",
            timestamp: Date.now(),
            txHash: data.txHash,
          }

          OnramperService.saveTransaction(transaction)
          toast.success(`Nạp ${transaction.cryptoAmount} ${transaction.cryptoCurrency} thành công!`)

          onSuccess?.(transaction)
          onOpenChange(false)
        },
        onError: (error) => {
          toast.error(error.message || "Giao dịch thất bại. Vui lòng thử lại.")
        },
        onClose: () => {
          onOpenChange(false)
        },
      })
    },
    [defaultAmount, defaultFiat, walletAddress, onSuccess, onOpenChange],
  )

  useEffect(() => {
    window.addEventListener("message", handleMessage)
    return () => window.removeEventListener("message", handleMessage)
  }, [handleMessage])

  const handleIframeLoad = () => {
    setIsLoading(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Nạp tiền qua Onramper
            </span>
          </DialogTitle>
        </DialogHeader>

        {/* Info Card */}
        <div className="px-6">
          <Card className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20">
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-gray-700 dark:text-gray-300">
                <strong>An toàn 100%</strong> - Tích hợp Onramper aggregator chuẩn Pi Network 2026. Hỗ trợ Onramp.money,
                Transfi, Banxa và nhiều provider khác. Low fee, KYB-compliant.
              </div>
            </div>
          </Card>
        </div>

        {/* Widget iframe */}
        <div className="relative w-full h-[600px] bg-gray-50 dark:bg-gray-900">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white dark:bg-gray-900">
              <div className="text-center">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600 dark:text-gray-400">Đang tải Onramper...</p>
              </div>
            </div>
          )}
          {widgetUrl && (
            <iframe
              src={widgetUrl}
              title="Onramper Widget"
              className="w-full h-full border-0"
              allow="payment; camera"
              onLoad={handleIframeLoad}
            />
          )}
        </div>

        {/* Close button */}
        <div className="p-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full">
            <X className="w-4 h-4 mr-2" />
            Đóng
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
