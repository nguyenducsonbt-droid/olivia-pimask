"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Wallet, Check } from "lucide-react"

interface WalletNameEditDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  currentName: string
  onNameChange: (newName: string) => void
}

export function WalletNameEditDialog({ open, onOpenChange, currentName, onNameChange }: WalletNameEditDialogProps) {
  const [name, setName] = useState(currentName)
  const [error, setError] = useState("")

  useEffect(() => {
    setName(currentName)
    setError("")
  }, [currentName, open])

  const handleSave = () => {
    const trimmedName = name.trim()

    // Validation
    if (!trimmedName) {
      setError("Tên ví không được để trống")
      return
    }

    if (trimmedName.length > 20) {
      setError("Tên ví tối đa 20 ký tự")
      return
    }

    // Save the name
    onNameChange(trimmedName)
    onOpenChange(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSave()
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white border-2 border-purple-200 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-purple-900 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-purple-600" />
            Đổi tên ví
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Current Name Display */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
            <p className="text-xs text-purple-600 mb-1">Tên hiện tại:</p>
            <p className="text-sm font-semibold text-purple-900">{currentName}</p>
          </div>

          {/* Name Input */}
          <div className="space-y-2">
            <label className="text-sm text-purple-700 font-medium">Tên mới:</label>
            <Input
              value={name}
              onChange={(e) => {
                setName(e.target.value)
                setError("")
              }}
              onKeyPress={handleKeyPress}
              placeholder="Nhập tên ví mới"
              maxLength={20}
              className="border-2 border-purple-200 focus:border-purple-400 text-purple-900"
              autoFocus
            />
            <div className="flex items-center justify-between">
              <p className="text-xs text-gray-500">{name.length}/20 ký tự</p>
              {error && <p className="text-xs text-red-500">{error}</p>}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              onClick={() => onOpenChange(false)}
              variant="outline"
              className="flex-1 border-2 border-gray-300 text-gray-700 hover:bg-gray-50 bg-transparent"
            >
              Hủy
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:from-purple-700 hover:to-pink-600 font-bold"
              disabled={!name.trim() || name.trim() === currentName}
            >
              <Check className="w-4 h-4 mr-2" />
              Lưu
            </Button>
          </div>

          {/* Info text */}
          <p className="text-xs text-gray-500 text-center">
            Tên ví sẽ hiển thị ở header và trang Hồ sơ
            <br />💡 Tip: Chọn tên ngắn gọn, dễ nhớ
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
