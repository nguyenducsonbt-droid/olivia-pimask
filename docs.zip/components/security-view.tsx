"use client"

import { useState } from "react"
import { Shield, CheckCircle, Lock, AlertTriangle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useWallet } from "@/hooks/use-wallet"
import { getCustomNetworks, getTransactions, getWalletData } from "@/lib/storage"
import { loadPiSession } from "@/lib/persistent-storage"
import { triggerHaptic } from "@/lib/haptic"

interface SecurityCheck {
  id: string
  name: string
  description: string
  status: "pending" | "checking" | "pass" | "warning" | "fail"
  message?: string
  recommendation?: string
}

interface ScanProgress {
  current: number
  total: number
  message: string
}

export default function SecurityView() {
  const { address, network } = useWallet()
  const [isScanning, setIsScanning] = useState(false)
  const [scanComplete, setScanComplete] = useState(false)
  const [progress, setProgress] = useState<ScanProgress>({ current: 0, total: 5, message: "" })
  const [securityChecks, setSecurityChecks] = useState<SecurityCheck[]>([])

  const handleBack = () => {
    triggerHaptic("light")
    // Dispatch event that wallet-dashboard listens for
    window.dispatchEvent(new CustomEvent("security-back-to-home"))
  }

  const handleSecurityScan = async () => {
    setIsScanning(true)
    setScanComplete(false)
    setProgress({ current: 0, total: 5, message: "Đang khởi tạo quét bảo mật..." })

    const checks: SecurityCheck[] = [
      {
        id: "rpc",
        name: "Kiểm tra RPC Networks",
        description: "Xác minh độ an toàn của các RPC tùy chỉnh",
        status: "pending",
      },
      {
        id: "dapps",
        name: "Kiểm tra dApp kết nối",
        description: "Phát hiện các dApp đáng ngờ",
        status: "pending",
      },
      {
        id: "transactions",
        name: "Phân tích lịch sử giao dịch",
        description: "Tìm kiếm dấu hiệu scam trong giao dịch",
        status: "pending",
      },
      {
        id: "keys",
        name: "Kiểm tra bảo mật khóa",
        description: "Xác nhận seed/private key không bị lộ",
        status: "pending",
      },
      {
        id: "network",
        name: "Explorer Ecosystem",
        description: "Kiểm tra kết nối ví với Pi Ecosystem chính thức",
        status: "pending",
      },
    ]

    setSecurityChecks(checks)

    // Check 1: RPC Networks
    await new Promise((resolve) => setTimeout(resolve, 400))
    setProgress({ current: 1, total: 5, message: "Đang kiểm tra RPC networks..." })
    const customNetworks = getCustomNetworks()
    const suspiciousRpcs = customNetworks.filter((net) => {
      const url = net.rpcUrl?.toLowerCase() || ""
      // Check for suspicious patterns
      return (
        url.includes("scam") ||
        url.includes("phishing") ||
        url.includes("fake") ||
        (!url.startsWith("https://") && !url.startsWith("http://localhost"))
      )
    })

    checks[0].status = suspiciousRpcs.length > 0 ? "warning" : "pass"
    if (suspiciousRpcs.length > 0) {
      checks[0].message = `Phát hiện ${suspiciousRpcs.length} RPC đáng ngờ`
      checks[0].recommendation = `Xóa các RPC: ${suspiciousRpcs.map((n) => n.name).join(", ")}`
    } else {
      checks[0].message = "Tất cả RPC an toàn"
    }
    setSecurityChecks([...checks])

    // Check 2: Connected dApps
    await new Promise((resolve) => setTimeout(resolve, 400))
    setProgress({ current: 2, total: 5, message: "Đang kiểm tra dApp kết nối..." })
    const connectedDapps: string[] = []
    try {
      const dappData = localStorage.getItem("olivia_connected_dapps")
      if (dappData) {
        connectedDapps.push(...JSON.parse(dappData))
      }
    } catch (e) {
      // No connected dApps
    }

    const suspiciousDapps = connectedDapps.filter(
      (dapp) => dapp.toLowerCase().includes("scam") || dapp.toLowerCase().includes("phishing"),
    )

    checks[1].status = suspiciousDapps.length > 0 ? "warning" : "pass"
    if (suspiciousDapps.length > 0) {
      checks[1].message = `Phát hiện ${suspiciousDapps.length} dApp đáng ngờ`
      checks[1].recommendation = "Ngắt kết nối các dApp không tin cậy"
    } else {
      checks[1].message = connectedDapps.length > 0 ? `${connectedDapps.length} dApp an toàn` : "Không có dApp kết nối"
    }
    setSecurityChecks([...checks])

    // Check 3: Transaction History
    await new Promise((resolve) => setTimeout(resolve, 400))
    setProgress({ current: 3, total: 5, message: "Đang phân tích lịch sử giao dịch..." })
    const transactions = getTransactions()
    const suspiciousTransactions = transactions.filter((tx) => {
      // Check for very large amounts or suspicious patterns
      const amount = Number.parseFloat(tx.amount || "0")
      return amount > 1000000 || tx.to?.toLowerCase().includes("scam")
    })

    checks[2].status = suspiciousTransactions.length > 0 ? "warning" : "pass"
    if (suspiciousTransactions.length > 0) {
      checks[2].message = `Phát hiện ${suspiciousTransactions.length} giao dịch đáng ngờ`
      checks[2].recommendation = "Xem lại các giao dịch có số tiền bất thường"
    } else {
      checks[2].message = transactions.length > 0 ? "Lịch sử giao dịch sạch" : "Chưa có giao dịch"
    }
    setSecurityChecks([...checks])

    // Check 4: Key Security
    await new Promise((resolve) => setTimeout(resolve, 400))
    setProgress({ current: 4, total: 5, message: "Đang kiểm tra bảo mật khóa..." })
    const walletData = getWalletData()
    const hasEncryptedMnemonic = walletData?.encryptedMnemonic && walletData.encryptedMnemonic.length > 0

    checks[3].status = hasEncryptedMnemonic ? "pass" : "warning"
    if (hasEncryptedMnemonic) {
      checks[3].message = "Seed phrase được mã hóa an toàn"
    } else {
      checks[3].message = "Không tìm thấy dữ liệu ví được mã hóa"
      checks[3].recommendation = "Kiểm tra lại ví của bạn"
    }
    setSecurityChecks([...checks])

    // Check 5: Pi Network Connection
    await new Promise((resolve) => setTimeout(resolve, 400))
    setProgress({ current: 5, total: 5, message: "Đang kiểm tra kết nối Ecosystem..." })
    const piSession = await loadPiSession()
    const isPiConnected = piSession !== null && piSession.user !== undefined

    checks[4].status = isPiConnected ? "pass" : "warning"
    if (isPiConnected) {
      checks[4].message = `Ví Pi Ecosystem • Đã kết nối (@${piSession.user.username}) ✓`
    } else {
      checks[4].message = "Chưa kết nối với Pi Ecosystem chính thức"
      checks[4].recommendation = "Bấm icon sợi xích 🔗 ở header để kết nối ví với Pi Ecosystem/Mainnet"
    }
    setSecurityChecks([...checks])

    // Final delay for completion animation
    await new Promise((resolve) => setTimeout(resolve, 300))
    setProgress({ current: 5, total: 5, message: "Quét hoàn tất!" })
    setIsScanning(false)
    setScanComplete(true)
  }

  const securityScore = scanComplete
    ? Math.round((securityChecks.filter((c) => c.status === "pass").length / securityChecks.length) * 100)
    : 0

  const hasWarnings = securityChecks.some((c) => c.status === "warning" || c.status === "fail")

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center gap-3 mb-4">
        <Button
          onClick={handleBack}
          variant="outline"
          className="flex items-center gap-2 bg-white hover:bg-purple-50 border-purple-200 transition-all active:scale-95"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          <span className="font-medium">Quay lại</span>
        </Button>
      </div>

      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center shadow-lg">
            <Lock className="w-8 h-8 text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900">An toàn</h2>
        <p className="text-sm text-gray-600">Kiểm tra bảo mật ví của bạn</p>
      </div>

      {/* Scan Button */}
      <div className="flex justify-center">
        <Button
          onClick={handleSecurityScan}
          disabled={isScanning || !address}
          className="relative h-auto py-6 px-8 text-lg font-bold rounded-2xl transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:hover:scale-100"
          style={{
            background: "linear-gradient(135deg, #9B59B6 0%, #8E44AD 100%)",
            boxShadow: isScanning ? "0 8px 20px rgba(155, 89, 182, 0.4)" : "0 6px 15px rgba(155, 89, 182, 0.4)",
          }}
        >
          <div className="flex flex-col items-center gap-2">
            {isScanning ? <Loader2 className="w-8 h-8 animate-spin" /> : <Lock className="w-8 h-8" />}
            <span>{isScanning ? "Đang quét..." : "Quét bảo mật ví"}</span>
          </div>
        </Button>
      </div>

      {isScanning && (
        <Card className="p-6 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-gray-700">{progress.message}</span>
              <span className="text-gray-500">
                {progress.current} / {progress.total}
              </span>
            </div>
            <Progress value={(progress.current / progress.total) * 100} className="h-2" />
          </div>

          {/* Show checks as they complete */}
          <div className="space-y-2">
            {securityChecks.map((check) => (
              <div key={check.id} className="flex items-center gap-2 text-sm">
                {check.status === "pass" ? (
                  <CheckCircle className="w-4 h-4 text-green-600" />
                ) : check.status === "warning" || check.status === "fail" ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                ) : (
                  <div className="w-4 h-4 rounded-full border-2 border-gray-300" />
                )}
                <span className={check.status === "pending" ? "text-gray-400" : "text-gray-700"}>{check.name}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Not Connected Warning */}
      {!address && (
        <Card className="p-4 bg-amber-50 border-amber-200">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-amber-900">Chưa kết nối ví</p>
              <p className="text-sm text-amber-700 mt-1">Vui lòng kết nối ví Pi trước để quét nha~</p>
            </div>
          </div>
        </Card>
      )}

      {scanComplete && address && (
        <Card
          className={`p-6 ${hasWarnings ? "bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200" : "bg-gradient-to-br from-green-50 to-emerald-50 border-green-200"} space-y-4`}
        >
          {/* Success Header */}
          <div className="flex items-center justify-center gap-3">
            {hasWarnings ? (
              <AlertTriangle className="w-12 h-12 text-amber-600" />
            ) : (
              <CheckCircle className="w-12 h-12 text-green-600" />
            )}
            <div>
              <h3 className={`text-2xl font-bold ${hasWarnings ? "text-amber-900" : "text-green-900"}`}>
                {hasWarnings ? `Ví an toàn ${securityScore}%` : "Ví an toàn 100% ✓"}
              </h3>
              <p className={`text-sm ${hasWarnings ? "text-amber-700" : "text-green-700"}`}>
                {hasWarnings ? "Phát hiện một số cảnh báo" : "Tất cả kiểm tra đã vượt qua"}
              </p>
            </div>
          </div>

          <div className="space-y-3 mt-6">
            {securityChecks.map((check) => (
              <div
                key={check.id}
                className={`p-3 ${check.status === "pass" ? "bg-white/60" : "bg-white/80"} rounded-xl`}
              >
                <div className="flex items-start gap-3">
                  {check.status === "pass" ? (
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{check.name}</p>
                    <p className="text-sm text-gray-600">{check.message || check.description}</p>
                    {check.recommendation && (
                      <p className="text-sm text-amber-700 mt-1 font-medium">💡 {check.recommendation}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Sweet Reminder */}
          <div className="mt-6 p-4 bg-purple-50 border-2 border-purple-200 rounded-xl">
            <div className="flex items-start gap-3">
              <div className="text-2xl">❤️</div>
              <div>
                <p className="font-semibold text-purple-900">Lời nhắc ngọt ngào</p>
                <p className="text-sm text-purple-700 mt-1">
                  Không bao giờ chia sẻ passphrase với ai nhé! Bảo mật là trên hết! Olivia luôn bảo vệ bạn.
                </p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Security Tips */}
      {!scanComplete && address && (
        <Card className="p-6 space-y-4">
          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600" />
            Mẹo bảo mật
          </h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
              <p className="text-sm text-gray-700">Luôn sao lưu seed phrase ở nơi an toàn, không kết nối internet</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
              <p className="text-sm text-gray-700">Không chia sẻ mã PIN hoặc seed phrase với bất kỳ ai</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
              <p className="text-sm text-gray-700">Kiểm tra kỹ địa chỉ nhận trước khi gửi Pi</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-purple-600 mt-2 flex-shrink-0" />
              <p className="text-sm text-gray-700">Sử dụng Face ID/Touch ID để bảo vệ ví tốt hơn</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}
