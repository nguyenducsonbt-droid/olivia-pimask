"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useWallet } from "@/hooks/use-wallet"
import { BarChart3, TrendingUp, TrendingDown, Wallet, Info, RefreshCw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"

interface CoinGeckoPriceData {
  "pi-network": {
    usd: number
    usd_24h_change: number
  }
  tether: {
    usd: number
    usd_24h_change: number
  }
  ethereum: {
    usd: number
    usd_24h_change: number
  }
}

interface CoinGeckoChartData {
  prices: [number, number][]
}

export function PortfolioTrackerView() {
  const { balance, tokens } = useWallet()
  const { toast } = useToast()
  const [totalValue, setTotalValue] = useState(0)
  const [pnl, setPnl] = useState(0)
  const [pnlPercentage, setPnlPercentage] = useState(0)

  const [piPrice, setPiPrice] = useState(0)
  const [priceChange24h, setPriceChange24h] = useState(0)
  const [usdtPrice, setUsdtPrice] = useState(1.0)
  const [usdtChange24h, setUsdtChange24h] = useState(0)
  const [ethPrice, setEthPrice] = useState(0)
  const [ethChange24h, setEthChange24h] = useState(0)
  const [chartData, setChartData] = useState<{ day: string; value: number }[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isUsingFallback, setIsUsingFallback] = useState(false)
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null)

  const fetchPrices = async () => {
    try {
      const response = await fetch(
        "https://api.coingecko.com/api/v3/simple/price?ids=pi-network,tether,ethereum&vs_currencies=usd&include_24hr_change=true",
      )

      if (!response.ok) {
        throw new Error("Failed to fetch price data")
      }

      const data: CoinGeckoPriceData = await response.json()

      // Set Pi price
      if (data["pi-network"]) {
        setPiPrice(data["pi-network"].usd)
        setPriceChange24h(data["pi-network"].usd_24h_change || 0)
      } else {
        throw new Error("Pi Network data not available")
      }

      // Set USDT price
      if (data["tether"]) {
        setUsdtPrice(data["tether"].usd)
        setUsdtChange24h(data["tether"].usd_24h_change || 0)
      }

      // Set ETH price
      if (data["ethereum"]) {
        setEthPrice(data["ethereum"].usd)
        setEthChange24h(data["ethereum"].usd_24h_change || 0)
      }

      setIsUsingFallback(false)
      setLastUpdateTime(new Date())
      return data["pi-network"]?.usd || 0.208
    } catch (error) {
      console.error("[v0] CoinGecko API error:", error)
      setIsUsingFallback(true)
      setPiPrice(0.208)
      setPriceChange24h(0)
      setUsdtPrice(1.0)
      setUsdtChange24h(0)
      setEthPrice(3000)
      setEthChange24h(0)
      toast({
        title: "Không lấy được giá CoinGecko",
        description: "Thử lại sau. Đang dùng giá fallback",
        variant: "destructive",
      })
      return 0.208
    }
  }

  const fetch7DayChart = async (currentPrice: number) => {
    try {
      const response = await fetch(
        "https://api.coingecko.com/api/v3/coins/pi-network/market_chart?vs_currency=usd&days=7",
      )

      if (!response.ok) {
        throw new Error("Failed to fetch chart data")
      }

      const data: CoinGeckoChartData = await response.json()

      if (data.prices && data.prices.length > 0) {
        const dailyData = []
        const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        const pointsPerDay = Math.floor(data.prices.length / 7)

        for (let i = 0; i < 7; i++) {
          const index = i * pointsPerDay
          if (data.prices[index]) {
            const timestamp = data.prices[index][0]
            const price = data.prices[index][1]
            const date = new Date(timestamp)
            const dayName = daysOfWeek[date.getDay()]

            const actualBalance = Number.parseFloat(balance) || 100
            const value = actualBalance * price

            dailyData.push({
              day: dayName,
              value: value,
            })
          }
        }

        if (dailyData.length > 0) {
          setChartData(dailyData)
        }
      }
    } catch (error) {
      console.error("[v0] CoinGecko chart API error:", error)
    }
  }

  const handleRefresh = async () => {
    setIsLoading(true)
    const price = await fetchPrices()
    await fetch7DayChart(price)
    setIsLoading(false)

    if (!isUsingFallback) {
      toast({
        title: "Đã cập nhật",
        description: "Giá Pi, USDT, ETH đã được cập nhật từ CoinGecko",
      })
    }
  }

  useEffect(() => {
    const initializeData = async () => {
      const price = await fetchPrices()
      await fetch7DayChart(price)
      setIsLoading(false)
    }
    initializeData()
  }, [])

  useEffect(() => {
    const intervalId = setInterval(async () => {
      const price = await fetchPrices()
      await fetch7DayChart(price)
    }, 30000) // 30 seconds

    return () => clearInterval(intervalId)
  }, [balance])

  useEffect(() => {
    const actualBalance = Number.parseFloat(balance) || 100
    const piValue = actualBalance * piPrice

    const tokensValue = tokens.reduce((acc, token) => {
      const tokenBalance = Number.parseFloat(token.balance || "0")
      let tokenPrice = 0

      if (token.symbol === "USDT" || token.symbol === "USDC") {
        tokenPrice = usdtPrice
      } else if (token.symbol === "ETH" || token.symbol === "WETH") {
        tokenPrice = ethPrice
      }

      return acc + tokenBalance * tokenPrice
    }, 0)

    const total = piValue + tokensValue
    setTotalValue(total)

    const calculatedPnl = (actualBalance * piPrice * priceChange24h) / 100
    const calculatedPnlPercentage = priceChange24h

    setPnl(calculatedPnl)
    setPnlPercentage(calculatedPnlPercentage)
  }, [balance, tokens, piPrice, priceChange24h, usdtPrice, ethPrice])

  const actualBalance = Number.parseFloat(balance) || 100
  const piValue = actualBalance * piPrice

  const mockUsdtBalance = 50
  const mockEthBalance = 0.5

  const usdtBalance = tokens.find((t) => t.symbol === "USDT")
  const ethBalance = tokens.find((t) => t.symbol === "ETH" || t.symbol === "WETH")
  const usdcBalance = tokens.find((t) => t.symbol === "USDC")

  const usdtValue = (Number.parseFloat(usdtBalance?.balance || "0") || mockUsdtBalance) * usdtPrice
  const ethValue = (Number.parseFloat(ethBalance?.balance || "0") || mockEthBalance) * ethPrice
  const usdcValue = Number.parseFloat(usdcBalance?.balance || "0") * usdtPrice

  const totalAllocation = piValue + usdtValue + ethValue + usdcValue

  const assetAllocation = [
    {
      name: "Pi (π)",
      percentage: totalAllocation > 0 ? (piValue / totalAllocation) * 100 : 0,
      value: piValue,
      color: "bg-purple-500",
    },
    {
      name: "USDT",
      percentage: totalAllocation > 0 ? (usdtValue / totalAllocation) * 100 : 0,
      value: usdtValue,
      color: "bg-green-500",
    },
    {
      name: "ETH",
      percentage: totalAllocation > 0 ? (ethValue / totalAllocation) * 100 : 0,
      value: ethValue,
      color: "bg-blue-600",
    },
    {
      name: "USDC",
      percentage: totalAllocation > 0 ? (usdcValue / totalAllocation) * 100 : 0,
      value: usdcValue,
      color: "bg-blue-400",
    },
  ]

  const maxChartValue = Math.max(...chartData.map((d) => d.value), 1)

  if (isLoading && piPrice === 0) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center space-y-3">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-purple-600" />
          <p className="text-muted-foreground">Đang tải dữ liệu từ CoinGecko...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 pb-24">
      <div className="grid grid-cols-3 gap-2">
        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
          <CardContent className="pt-4 pb-3">
            <div className="text-center space-y-1">
              <p className="text-xs text-muted-foreground">Pi</p>
              <p className="text-lg font-bold text-purple-600">${piPrice.toFixed(3)}</p>
              <div className="flex items-center justify-center gap-1">
                <span className={`text-xs font-medium ${priceChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {priceChange24h >= 0 ? "+" : ""}
                  {priceChange24h.toFixed(2)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardContent className="pt-4 pb-3">
            <div className="text-center space-y-1">
              <p className="text-xs text-muted-foreground">USDT</p>
              <p className="text-lg font-bold text-green-600">${usdtPrice.toFixed(3)}</p>
              <div className="flex items-center justify-center gap-1">
                <span className={`text-xs font-medium ${usdtChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {usdtChange24h >= 0 ? "+" : ""}
                  {usdtChange24h.toFixed(2)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardContent className="pt-4 pb-3">
            <div className="text-center space-y-1">
              <p className="text-xs text-muted-foreground">ETH</p>
              <p className="text-lg font-bold text-blue-600">${ethPrice.toFixed(0)}</p>
              <div className="flex items-center justify-center gap-1">
                <span className={`text-xs font-medium ${ethChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {ethChange24h >= 0 ? "+" : ""}
                  {ethChange24h.toFixed(2)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Total Portfolio Value */}
      <Card className="border-purple-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-purple-600" />
              Tổng giá trị danh mục
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={isLoading} className="h-8 w-8 p-0">
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            </Button>
          </div>
          {lastUpdateTime && (
            <CardDescription className="text-xs">
              Cập nhật lần cuối: {lastUpdateTime.toLocaleTimeString("vi-VN")} (tự động mỗi 30s)
            </CardDescription>
          )}
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <p className="text-3xl font-bold">${totalValue.toFixed(2)}</p>
              <div className="flex items-center gap-2 mt-2">
                {pnl >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-green-600" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-red-600" />
                )}
                <span className={`text-sm font-medium ${pnl >= 0 ? "text-green-600" : "text-red-600"}`}>
                  {pnl >= 0 ? "+" : ""}${Math.abs(pnl).toFixed(2)} ({pnlPercentage >= 0 ? "+" : ""}
                  {pnlPercentage.toFixed(2)}%)
                </span>
                <span className="text-xs text-muted-foreground">24h</span>
              </div>
            </div>

            {/* 7-Day Chart */}
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground">Biểu đồ 7 ngày</p>
              {chartData.length > 0 ? (
                <div className="flex items-end gap-2 h-32">
                  {chartData.map((data, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full bg-purple-100 rounded-t relative overflow-hidden"
                        style={{ height: `${(data.value / maxChartValue) * 100 || 2}%`, minHeight: "2px" }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-t from-purple-600 to-purple-400"></div>
                      </div>
                      <span className="text-xs text-muted-foreground">{data.day}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
                  Không có dữ liệu biểu đồ
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Holdings */}
      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="w-4 h-4" />
            Tài sản nắm giữ
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-500 flex items-center justify-center">
                <span className="text-white font-bold">π</span>
              </div>
              <div>
                <p className="font-medium">Pi Network</p>
                <p className="text-xs text-muted-foreground">{actualBalance.toFixed(4)} π</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold">${piValue.toFixed(2)}</p>
              <p className={`text-xs ${priceChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                {priceChange24h >= 0 ? "+" : ""}
                {priceChange24h.toFixed(2)}%
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                <span className="text-white font-bold text-xs">₮</span>
              </div>
              <div>
                <p className="font-medium">Tether USD</p>
                <p className="text-xs text-muted-foreground">{mockUsdtBalance.toFixed(2)} USDT</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold">${usdtValue.toFixed(2)}</p>
              <p className={`text-xs ${usdtChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                {usdtChange24h >= 0 ? "+" : ""}
                {usdtChange24h.toFixed(2)}%
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-xs">Ξ</span>
              </div>
              <div>
                <p className="font-medium">Ethereum</p>
                <p className="text-xs text-muted-foreground">{mockEthBalance.toFixed(4)} ETH</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold">${ethValue.toFixed(2)}</p>
              <p className={`text-xs ${ethChange24h >= 0 ? "text-green-600" : "text-red-600"}`}>
                {ethChange24h >= 0 ? "+" : ""}
                {ethChange24h.toFixed(2)}%
              </p>
            </div>
          </div>

          {tokens
            .filter(
              (token) =>
                Number.parseFloat(token.balance || "0") > 0 &&
                token.symbol !== "USDT" &&
                token.symbol !== "ETH" &&
                token.symbol !== "WETH",
            )
            .slice(0, 2)
            .map((token, index) => {
              const tokenBalance = Number.parseFloat(token.balance || "0")
              const tokenPrice = token.symbol === "USDC" ? usdtPrice : 0
              const tokenValue = tokenBalance * tokenPrice

              return (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">{token.symbol[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium">{token.symbol}</p>
                      <p className="text-xs text-muted-foreground">{tokenBalance.toFixed(4)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">${tokenValue.toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">≈ ${tokenPrice.toFixed(2)}</p>
                  </div>
                </div>
              )
            })}
        </CardContent>
      </Card>

      {/* Asset Allocation Pie Chart */}
      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="text-base">Phân bổ tài sản</CardTitle>
          <CardDescription>Tỷ lệ token trong danh mục</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {totalAllocation > 0 ? (
            <>
              <div className="flex gap-1 h-8 rounded-full overflow-hidden">
                {assetAllocation
                  .filter((asset) => asset.percentage > 0)
                  .map((asset, index) => (
                    <div
                      key={index}
                      className={asset.color}
                      style={{ width: `${asset.percentage}%` }}
                      title={`${asset.name}: ${asset.percentage.toFixed(1)}%`}
                    />
                  ))}
              </div>

              {/* Legend */}
              <div className="space-y-2">
                {assetAllocation
                  .filter((asset) => asset.percentage > 0)
                  .map((asset, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${asset.color}`} />
                        <span>{asset.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-muted-foreground">{asset.percentage.toFixed(1)}%</span>
                        <span className="font-medium">${asset.value.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </>
          ) : (
            <div className="text-center text-muted-foreground text-sm py-4">Chưa có tài sản</div>
          )}
        </CardContent>
      </Card>

      <Alert className={isUsingFallback ? "bg-yellow-50 border-yellow-200" : "bg-blue-50 border-blue-200"}>
        <Info className={`h-4 w-4 ${isUsingFallback ? "text-yellow-600" : "text-blue-600"}`} />
        <AlertDescription className={`text-xs ${isUsingFallback ? "text-yellow-800" : "text-blue-800"}`}>
          <strong>
            {isUsingFallback
              ? "Không kết nối được CoinGecko. Đang dùng giá fallback."
              : "Giá Pi, USDT, ETH realtime từ CoinGecko API (auto-refresh 30s)."}
          </strong>{" "}
          Balance mock/demo. Thực tế đầy đủ khi Pi Mainnet kết nối DeFi 2026.
        </AlertDescription>
      </Alert>
    </div>
  )
}
