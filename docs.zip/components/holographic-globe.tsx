"use client"

import { useEffect, useRef } from "react"

export function HolographicGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2
    const globeRadius = Math.min(width, height) * 0.35

    let rotation = 0
    let animationFrame: number

    // Money transfer arrows
    const arrows = [
      { startAngle: 0, color: "#3B82F6" },
      { startAngle: Math.PI / 2, color: "#EC4899" },
      { startAngle: Math.PI, color: "#F59E0B" },
      { startAngle: (3 * Math.PI) / 2, color: "#EF4444" },
    ]

    // Coins particles
    const coins: Array<{ angle: number; radius: number; speed: number; yOffset: number }> = []
    for (let i = 0; i < 12; i++) {
      coins.push({
        angle: (i * Math.PI * 2) / 12,
        radius: globeRadius * 1.3,
        speed: 0.01 + Math.random() * 0.02,
        yOffset: Math.sin(i) * 10,
      })
    }

    function drawGlobe() {
      if (!ctx) return

      // Clear canvas
      ctx.clearRect(0, 0, width, height)

      // Draw holographic glow
      const glowGradient = ctx.createRadialGradient(
        centerX,
        centerY,
        globeRadius * 0.5,
        centerX,
        centerY,
        globeRadius * 1.4,
      )
      glowGradient.addColorStop(0, "rgba(59, 130, 246, 0.3)")
      glowGradient.addColorStop(0.5, "rgba(168, 85, 247, 0.2)")
      glowGradient.addColorStop(1, "rgba(236, 72, 153, 0)")
      ctx.fillStyle = glowGradient
      ctx.beginPath()
      ctx.arc(centerX, centerY, globeRadius * 1.4, 0, Math.PI * 2)
      ctx.fill()

      // Draw globe base (ocean)
      const oceanGradient = ctx.createRadialGradient(
        centerX - globeRadius * 0.3,
        centerY - globeRadius * 0.3,
        0,
        centerX,
        centerY,
        globeRadius,
      )
      oceanGradient.addColorStop(0, "#2563EB")
      oceanGradient.addColorStop(0.7, "#1E40AF")
      oceanGradient.addColorStop(1, "#1E3A8A")
      ctx.fillStyle = oceanGradient
      ctx.beginPath()
      ctx.arc(centerX, centerY, globeRadius, 0, Math.PI * 2)
      ctx.fill()

      // Draw continents (simplified shapes)
      ctx.fillStyle = "#10B981"
      const continents = [
        { x: -0.3, y: 0.1, size: 0.4 },
        { x: 0.2, y: -0.2, size: 0.35 },
        { x: -0.1, y: -0.4, size: 0.3 },
        { x: 0.35, y: 0.2, size: 0.25 },
      ]

      continents.forEach((cont) => {
        const angle = rotation + cont.x * 2
        const visible = Math.cos(angle) > -0.3
        if (visible) {
          const x = centerX + Math.sin(angle) * globeRadius * 0.7
          const y = centerY + cont.y * globeRadius * 0.8
          const size = globeRadius * cont.size * (0.7 + Math.cos(angle) * 0.3)

          ctx.beginPath()
          ctx.ellipse(x, y, size, size * 0.8, rotation * 0.5, 0, Math.PI * 2)
          ctx.fill()
        }
      })

      // Draw holographic edge highlight
      const edgeGradient = ctx.createLinearGradient(centerX - globeRadius, centerY, centerX + globeRadius, centerY)
      edgeGradient.addColorStop(0, "rgba(251, 191, 36, 0.8)")
      edgeGradient.addColorStop(0.5, "rgba(245, 158, 11, 1)")
      edgeGradient.addColorStop(1, "rgba(251, 191, 36, 0.8)")
      ctx.strokeStyle = edgeGradient
      ctx.lineWidth = 3
      ctx.shadowBlur = 15
      ctx.shadowColor = "#F59E0B"
      ctx.beginPath()
      ctx.arc(centerX, centerY, globeRadius, 0, Math.PI * 2)
      ctx.stroke()
      ctx.shadowBlur = 0

      // Draw latitude lines
      ctx.strokeStyle = "rgba(255, 255, 255, 0.2)"
      ctx.lineWidth = 1
      for (let lat = -0.6; lat <= 0.6; lat += 0.3) {
        ctx.beginPath()
        const latY = centerY + lat * globeRadius
        const latRadius = Math.sqrt(Math.max(0, globeRadius * globeRadius - (lat * globeRadius) ** 2))
        ctx.ellipse(centerX, latY, latRadius, latRadius * 0.3, 0, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Draw longitude lines
      for (let lon = 0; lon < 6; lon++) {
        ctx.beginPath()
        const angle = (lon * Math.PI) / 3 + rotation
        ctx.ellipse(centerX, centerY, globeRadius * Math.abs(Math.cos(angle)), globeRadius, rotation, 0, Math.PI * 2)
        ctx.stroke()
      }
    }

    function drawArrows() {
      if (!ctx) return

      arrows.forEach((arrow) => {
        const angle = arrow.startAngle + rotation * 1.5
        const arrowRadius = globeRadius * 1.2
        const startX = centerX + Math.cos(angle) * arrowRadius
        const startY = centerY + Math.sin(angle) * arrowRadius
        const endX = centerX + Math.cos(angle + Math.PI * 0.4) * arrowRadius
        const endY = centerY + Math.sin(angle + Math.PI * 0.4) * arrowRadius

        // Draw curved arrow
        ctx.strokeStyle = arrow.color
        ctx.lineWidth = 3
        ctx.shadowBlur = 10
        ctx.shadowColor = arrow.color
        ctx.beginPath()
        ctx.arc(centerX, centerY, arrowRadius, angle, angle + Math.PI * 0.4)
        ctx.stroke()

        // Draw arrowhead
        const headAngle = angle + Math.PI * 0.4
        const headSize = 8
        ctx.fillStyle = arrow.color
        ctx.beginPath()
        ctx.moveTo(endX, endY)
        ctx.lineTo(endX - Math.cos(headAngle - 0.5) * headSize, endY - Math.sin(headAngle - 0.5) * headSize)
        ctx.lineTo(endX - Math.cos(headAngle + 0.5) * headSize, endY - Math.sin(headAngle + 0.5) * headSize)
        ctx.closePath()
        ctx.fill()
        ctx.shadowBlur = 0
      })
    }

    function drawCoins() {
      if (!ctx) return

      coins.forEach((coin) => {
        coin.angle += coin.speed
        const x = centerX + Math.cos(coin.angle) * coin.radius
        const y = centerY + Math.sin(coin.angle) * coin.radius + Math.sin(coin.angle * 3) * coin.yOffset

        // Draw coin
        const coinGradient = ctx.createRadialGradient(x - 2, y - 2, 0, x, y, 6)
        coinGradient.addColorStop(0, "#FCD34D")
        coinGradient.addColorStop(0.7, "#F59E0B")
        coinGradient.addColorStop(1, "#D97706")
        ctx.fillStyle = coinGradient
        ctx.shadowBlur = 8
        ctx.shadowColor = "#F59E0B"
        ctx.beginPath()
        ctx.arc(x, y, 6, 0, Math.PI * 2)
        ctx.fill()
        ctx.shadowBlur = 0

        // Draw coin highlight
        ctx.fillStyle = "rgba(255, 255, 255, 0.6)"
        ctx.beginPath()
        ctx.arc(x - 2, y - 2, 2, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    function animate() {
      rotation += 0.008 // Slightly slower rotation for smoother 8-10s loop
      drawGlobe()
      drawArrows()
      drawCoins()
      animationFrame = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame)
      }
    }
  }, [])

  return (
    <div className="flex justify-center items-center">
      <canvas
        ref={canvasRef}
        width={300}
        height={300}
        className="w-[32vw] max-w-[180px] h-auto"
        style={{ filter: "drop-shadow(0 0 20px rgba(168, 85, 247, 0.4))" }}
      />
    </div>
  )
}
