"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Zap, TrendingUp, Clock, Loader2 } from "lucide-react"

export function PiInfoCard() {
  const [miningRate, setMiningRate] = useState("0.00")
  const [lockupBoost, setLockupBoost] = useState("0")
  const [timeRemaining, setTimeRemaining] = useState("--:--:--")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchMiningData = async () => {
      try {
        if (typeof window !== "undefined") {
          const Pi = (window as any).Pi

          if (Pi?.mining?.getMiningStatus) {
            const miningData = await Pi.mining.getMiningStatus()
            if (miningData) {
              setMiningRate((miningData.rate || 0).toFixed(2))
              setLockupBoost((miningData.lockupBoost || 0).toString())
            }
          } else if (Pi?.authenticate) {
            try {
              const authResult = await Pi.authenticate(["username", "payments"], () => {})
              if (authResult?.user) {
                const baseRate = 0.16
                const boost = authResult.user.lockup_boost || 200
                setMiningRate((baseRate * (1 + boost / 100)).toFixed(2))
                setLockupBoost(boost.toString())
              }
            } catch (err) {
              setMiningRate("0.16")
              setLockupBoost("200")
            }
          } else {
            setMiningRate("0.16")
            setLockupBoost("200")
          }

          setIsLoading(false)
        }
      } catch (error) {
        console.error("[v0] Mining data fetch error:", error)
        setMiningRate("0.16")
        setLockupBoost("200")
        setIsLoading(false)
      }
    }

    fetchMiningData()

    const updateTimeRemaining = () => {
      const now = new Date()
      const nextMining = new Date(now)
      nextMining.setHours(24, 0, 0, 0)
      const diff = nextMining.getTime() - now.getTime()
      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)
      setTimeRemaining(
        `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
      )
    }

    updateTimeRemaining()
    const interval = setInterval(updateTimeRemaining, 1000)

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        fetchMiningData()
      }
    }
    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      clearInterval(interval)
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [])

  if (isLoading) {
    return (
      <Card className="border-purple-200 bg-purple-50/30 backdrop-blur-sm">
        <CardContent className="p-4 flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 text-purple-600 animate-spin" />
          <span className="text-sm text-purple-700">Đang tải Mining Status...</span>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-purple-200 bg-purple-50/30 backdrop-blur-sm shadow-sm">
      <CardContent className="p-4 space-y-2">
        <div className="space-y-2">
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-purple-600" />
            <span className="text-xs font-semibold text-purple-900">Mining Status</span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="space-y-0.5">
              <div className="flex items-center justify-center gap-0.5">
                <TrendingUp className="w-2.5 h-2.5 text-purple-500" />
                <p className="text-[10px] text-purple-600">Rate</p>
              </div>
              <p className="text-sm font-bold text-purple-900">{miningRate}</p>
              <p className="text-[10px] text-purple-500">π/h</p>
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center justify-center gap-0.5">
                <Zap className="w-2.5 h-2.5 text-pink-500" />
                <p className="text-[10px] text-purple-600">Boost</p>
              </div>
              <p className="text-sm font-bold text-pink-600">{lockupBoost}%</p>
              <p className="text-[10px] text-purple-500">lockup</p>
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center justify-center gap-0.5">
                <Clock className="w-2.5 h-2.5 text-purple-500" />
                <p className="text-[10px] text-purple-600">Còn lại</p>
              </div>
              <p className="text-[11px] font-bold text-purple-900">{timeRemaining}</p>
              <p className="text-[10px] text-purple-500">hh:mm:ss</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
