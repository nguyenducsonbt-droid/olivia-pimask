"use client"

import { Card, CardContent } from "@/components/ui/card"
import { TransactionHistory } from "./transaction-history"
import { PiTransactionHistory } from "./pi-transaction-history"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useState } from "react"
import { AssetValueDetail } from "./asset-value-detail"
import { TransactionListDetail } from "./transaction-list-detail"

export function HistoryView() {
  const [showAssetDetail, setShowAssetDetail] = useState(false)
  const [showTransactionDetail, setShowTransactionDetail] = useState(false)

  if (showAssetDetail) {
    return <AssetValueDetail onBack={() => setShowAssetDetail(false)} />
  }

  if (showTransactionDetail) {
    return <TransactionListDetail onBack={() => setShowTransactionDetail(false)} />
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Card
          className="border-purple-200 bg-gradient-to-br from-purple-50/50 to-transparent cursor-pointer transition-all hover:shadow-md hover:scale-[1.02] active:scale-[0.98]"
          onClick={() => setShowAssetDetail(true)}
        >
          <CardContent className="pt-6">
            <p className="text-xs text-purple-600 mb-1">Giá trị tài sản</p>
            <p className="text-2xl font-bold text-purple-900">$0.00</p>
            <p className="text-xs text-green-600 mt-1">+0.00%</p>
          </CardContent>
        </Card>
        <Card
          className="border-purple-200 bg-gradient-to-br from-pink-50/50 to-transparent cursor-pointer transition-all hover:shadow-md hover:scale-[1.02] active:scale-[0.98]"
          onClick={() => setShowTransactionDetail(true)}
        >
          <CardContent className="pt-6">
            <p className="text-xs text-purple-600 mb-1">Tổng giao dịch</p>
            <p className="text-2xl font-bold text-purple-900">0</p>
            <p className="text-xs text-purple-500 mt-1">Trong 30 ngày</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-purple-100">
          <TabsTrigger value="all" className="data-[state=active]:bg-white">
            Tất cả giao dịch
          </TabsTrigger>
          <TabsTrigger value="pi" className="data-[state=active]:bg-white">
            Pi Network
          </TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-4">
          <TransactionHistory />
        </TabsContent>
        <TabsContent value="pi" className="mt-4">
          <PiTransactionHistory />
        </TabsContent>
      </Tabs>
    </div>
  )
}
