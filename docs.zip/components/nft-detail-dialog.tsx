"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Send, X, Copy, ChevronLeft, ChevronRight, ExternalLink } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface NFTDetailDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  nft: {
    id: string
    name: string
    collection: string
    image: string
    rarity: "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"
    tokenId: string
    description?: string
    attributes?: Array<{ trait_type: string; value: string }>
    owner?: string
    contractAddress?: string
  } | null
}

const rarityConfig = {
  Common: {
    color: "bg-gradient-to-br from-green-400 to-green-600",
    label: "Common",
  },
  Uncommon: {
    color: "bg-gradient-to-br from-blue-400 to-blue-600",
    label: "Uncommon",
  },
  Rare: {
    color: "bg-gradient-to-br from-indigo-400 to-indigo-600",
    label: "Rare",
  },
  Epic: {
    color: "bg-gradient-to-br from-purple-400 to-purple-600",
    label: "Epic",
  },
  Legendary: {
    color: "bg-gradient-to-br from-yellow-400 via-orange-500 to-red-600",
    label: "Legendary",
  },
}

export function NFTDetailDialog({ open, onOpenChange, nft }: NFTDetailDialogProps) {
  const [isSending, setIsSending] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const { toast } = useToast()

  if (!nft) return null

  const rarityStyle = rarityConfig[nft.rarity]

  // For carousel - support multiple images in future
  const images = [nft.image]

  const handleSendNFT = async () => {
    setIsSending(true)

    try {
      toast({
        title: "Đang mở Pi Wallet...",
        description: "Đang chuyển đến Pi Wallet để gửi NFT",
        duration: 2000,
      })

      // Try Pi Browser deep link first
      const piWalletSendUrl = `pi://wallet/send-nft?contract=${nft.contractAddress}&tokenId=${nft.tokenId}`

      // Create hidden iframe to trigger deep link
      const iframe = document.createElement("iframe")
      iframe.style.display = "none"
      iframe.src = piWalletSendUrl
      document.body.appendChild(iframe)

      // Clean up after 2 seconds
      setTimeout(() => {
        document.body.removeChild(iframe)
      }, 2000)

      // Fallback to Pi SDK if available
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi
        await Pi.init({ version: "2.0" })
      }
    } catch (error) {
      console.error("[v0] Send NFT error:", error)
      toast({
        title: "Lỗi",
        description: "Không thể mở Pi Wallet. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Đã sao chép",
      description: `${label} đã được sao chép vào clipboard`,
    })
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto p-0 safe-area-padding">
        {/* Close Button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onOpenChange(false)}
          className="absolute right-4 top-4 z-10 rounded-full bg-black/50 text-white hover:bg-black/70"
        >
          <X className="h-4 w-4" />
        </Button>

        {/* NFT Image Carousel - Fullscreen */}
        <div className="relative aspect-square bg-gradient-to-br from-purple-100 to-pink-100">
          <img
            src={images[currentImageIndex] || "/placeholder.svg?height=600&width=600"}
            alt={nft.name}
            className="w-full h-full object-cover"
          />

          {/* Rarity Badge with 3D effect */}
          <Badge
            className={`absolute top-4 left-4 ${rarityStyle.color} text-white border-0 font-bold shadow-lg`}
            style={{
              textShadow: "0 2px 4px rgba(0,0,0,0.3)",
            }}
          >
            {rarityStyle.label}
          </Badge>

          {/* Carousel controls (for future multi-image support) */}
          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                onClick={prevImage}
                className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 text-white hover:bg-black/70"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={nextImage}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 text-white hover:bg-black/70"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>

              {/* Image indicator */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {images.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentImageIndex ? "bg-white w-4" : "bg-white/50"
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* NFT Details */}
        <div className="p-6 space-y-4">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gray-900">{nft.name}</DialogTitle>
            <p className="text-sm text-gray-500">{nft.collection}</p>
            <div className="flex items-center gap-2">
              <p className="text-sm text-purple-600 font-medium">Token ID: #{nft.tokenId}</p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => copyToClipboard(nft.tokenId, "Token ID")}
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </DialogHeader>

          {/* Owner Info */}
          {nft.owner && (
            <div className="bg-purple-50 rounded-lg p-3 border border-purple-100">
              <p className="text-xs text-purple-600 font-medium mb-1">Owner</p>
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-mono text-gray-900 truncate">{nft.owner}</p>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 flex-shrink-0"
                  onClick={() => copyToClipboard(nft.owner!, "Owner address")}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          )}

          {/* Description */}
          {nft.description && (
            <div>
              <h3 className="text-sm font-semibold text-gray-900 mb-2">Mô tả</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{nft.description}</p>
            </div>
          )}

          {/* Attributes Table */}
          {nft.attributes && nft.attributes.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-gray-900 mb-2">Thuộc tính</h3>
              <div className="grid grid-cols-2 gap-2">
                {nft.attributes.map((attr, index) => (
                  <div key={index} className="bg-purple-50 rounded-lg p-3 border border-purple-100">
                    <p className="text-xs text-purple-600 font-medium">{attr.trait_type}</p>
                    <p className="text-sm font-semibold text-gray-900 mt-1">{attr.value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contract Address */}
          {nft.contractAddress && (
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>Contract</span>
              <div className="flex items-center gap-1">
                <span className="font-mono">
                  {nft.contractAddress.slice(0, 6)}...{nft.contractAddress.slice(-4)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-5 w-5"
                  onClick={() => copyToClipboard(nft.contractAddress!, "Contract address")}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              onClick={handleSendNFT}
              disabled={isSending}
              className="flex-1 text-white font-semibold"
              style={{
                background: "linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%)",
              }}
            >
              <Send className="h-4 w-4 mr-2" />
              {isSending ? "Đang xử lý..." : "Gửi NFT"}
            </Button>

            {nft.contractAddress && (
              <Button
                variant="outline"
                onClick={() => {
                  window.open(`https://piexplorer.com/nft/${nft.contractAddress}/${nft.tokenId}`, "_blank")
                }}
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
