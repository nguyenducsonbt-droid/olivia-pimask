"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { QRCodeSVG } from "qrcode.react"
import { Copy, Check, Sparkles } from "lucide-react"
import { Card } from "@/components/ui/card"

interface FiatDepositDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  initialProvider?: string
}

const paymentProviders = [
  {
    id: "vnpay",
    name: "VNPay",
    logo: "🏦",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "bidv",
    name: "BIDV",
    logo: "🏢",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "vietcombank",
    name: "Vietcombank",
    logo: "🏛️",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "momo",
    name: "Momo",
    logo: "💳",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "techcombank",
    name: "Techcombank",
    logo: "🏦",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "zalopay",
    name: "ZaloPay",
    logo: "💰",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
  {
    id: "viettelpay",
    name: "ViettelPay",
    logo: "📱",
    description: "Nạp/Rút VND nhanh chóng, miễn phí khi Pi Mainnet mở",
  },
]

export function FiatDepositDialog({ open, onOpenChange, initialProvider }: FiatDepositDialogProps) {
  const [step, setStep] = useState<"select" | "amount" | "qr" | "processing">("select")
  const [selectedProvider, setSelectedProvider] = useState("")
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState<"VND" | "USD">("VND")
  const [usdVndRate, setUsdVndRate] = useState(25000)
  const [isLoadingUsdVnd, setIsLoadingUsdVnd] = useState(false)

  const [piExchangeRate, setPiExchangeRate] = useState(0.5)
  const [lastUpdated, setLastUpdated] = useState<string>("")
  const [isLoadingRate, setIsLoadingRate] = useState(false)

  const [depositQRData, setDepositQRData] = useState("")
  const [depositMemo, setDepositMemo] = useState("")
  const [copied, setCopied] = useState(false)

  const fetchUsdVndRate = async () => {
    try {
      setIsLoadingUsdVnd(true)
      const response = await fetch("https://api.exchangerate-api.com/v4/latest/USD")
      const data = await response.json()

      if (data.rates?.VND) {
        setUsdVndRate(data.rates.VND)
      }
    } catch (error) {
      console.error("[v0] Error fetching USD/VND rate:", error)
      setUsdVndRate(25000)
    } finally {
      setIsLoadingUsdVnd(false)
    }
  }

  const fetchPiPrice = async () => {
    try {
      setIsLoadingRate(true)
      const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd")
      const data = await response.json()

      if (data["pi-network"]?.usd) {
        const price = data["pi-network"].usd
        setPiExchangeRate(price)

        const now = new Date()
        const timeStr = now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })
        setLastUpdated(timeStr)
      }
    } catch (error) {
      console.error("[v0] Error fetching Pi price:", error)
      toast.error("Không thể cập nhật tỷ giá, sử dụng tỷ giá trước đó")
    } finally {
      setIsLoadingRate(false)
    }
  }

  useEffect(() => {
    if (open) {
      fetchPiPrice()
      fetchUsdVndRate()

      const interval = setInterval(() => {
        fetchPiPrice()
        fetchUsdVndRate()
      }, 30000)

      if (initialProvider) {
        setSelectedProvider(initialProvider)
        setStep("amount")
      } else {
        setStep("select")
      }

      return () => clearInterval(interval)
    }
  }, [open, initialProvider])

  const handleProviderSelect = (providerId: string) => {
    setSelectedProvider(providerId)
    setStep("amount")
  }

  const calculatePiAmount = () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (isNaN(numAmount) || numAmount <= 0) return "0.00"

    const usdAmount = currency === "VND" ? numAmount / usdVndRate : numAmount
    return (usdAmount / piExchangeRate).toFixed(2)
  }

  const calculateEquivalentAmount = () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (isNaN(numAmount) || numAmount <= 0) return ""

    if (currency === "VND") {
      return (numAmount / usdVndRate).toFixed(2)
    } else {
      return (numAmount * usdVndRate).toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
  }

  const formatNumber = (value: string) => {
    const cleaned = value.replace(/[^\d.]/g, "")

    const parts = cleaned.split(".")
    if (parts.length > 2) {
      return parts[0] + "." + parts.slice(1).join("")
    }

    if (parts.length === 2) {
      const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",")
      return intPart + "." + parts[1]
    } else {
      return cleaned.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
  }

  const handleGenerateQR = async () => {
    const cleanAmount = amount.replace(/,/g, "")
    const numAmount = Number.parseFloat(cleanAmount)

    if (!amount || isNaN(numAmount) || numAmount <= 0) {
      toast.error("Vui lòng nhập số tiền hợp lệ")
      return
    }

    const timestamp = Date.now()
    const memo = `OLIVIA-DEP-${timestamp}`
    setDepositMemo(memo)

    const providerName = paymentProviders.find((p) => p.id === selectedProvider)?.name
    const qrPayload = {
      provider: selectedProvider,
      providerName,
      amount: numAmount,
      currency,
      memo,
      timestamp,
      recipient: "Olivia PiMask",
      type: "deposit",
    }

    setDepositQRData(JSON.stringify(qrPayload))
    setStep("qr")

    toast.success("Quét QR để thanh toán nhanh!")
  }

  const handleCopyMemo = async () => {
    try {
      await navigator.clipboard.writeText(depositMemo)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast.success("Đã sao chép mã giao dịch!")
    } catch (error) {
      toast.error("Không thể sao chép")
    }
  }

  const resetDialog = () => {
    setStep("select")
    setAmount("")
    setSelectedProvider("")
    setDepositQRData("")
    setDepositMemo("")
    setCopied(false)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
        if (!open) resetDialog()
      }}
    >
      <DialogContent className="max-w-md bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-purple-900 dark:text-purple-100 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            {step === "select" && "Chọn ngân hàng nạp tiền"}
            {step === "amount" && "Nhập số tiền nạp"}
            {step === "qr" && "Quét QR để thanh toán"}
            {step === "processing" && "Đang xử lý..."}
          </DialogTitle>
          {step === "qr" && (
            <DialogDescription className="text-purple-700 dark:text-purple-300 text-sm">
              Miễn phí 100%, an toàn qua Pi Network
            </DialogDescription>
          )}
        </DialogHeader>

        {step === "select" && (
          <div className="space-y-3">
            <DialogDescription className="text-purple-700 dark:text-purple-300">
              Chọn ngân hàng hoặc ví điện tử để nạp tiền
            </DialogDescription>

            <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-2">
              {paymentProviders.map((provider) => (
                <button
                  key={provider.id}
                  onClick={() => handleProviderSelect(provider.id)}
                  className="w-full bg-white dark:bg-purple-900/20 border-2 border-purple-300 dark:border-purple-600 hover:border-purple-500 dark:hover:border-purple-400 rounded-xl p-4 text-left transition-all hover:shadow-lg"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{provider.logo}</span>
                    <div className="flex-1">
                      <p className="font-bold text-purple-900 dark:text-purple-100">{provider.name}</p>
                      <p className="text-xs text-purple-600 dark:text-purple-400">{provider.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/40 dark:to-pink-900/40 rounded-lg p-3 border border-purple-200 dark:border-purple-700 text-center">
              <p className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                ⚡ Powered by Pi Network On/Off-Ramp
              </p>
              <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                Nạp/Rút VND/USD trực tiếp từ ví Pi, không phí ẩn
              </p>
            </div>
          </div>
        )}

        {step === "amount" && (
          <div className="space-y-4">
            <DialogDescription className="text-purple-700 dark:text-purple-300">
              Nhập số tiền bạn muốn nạp
            </DialogDescription>

            <div className="flex gap-2">
              <Button
                onClick={() => setCurrency("VND")}
                variant={currency === "VND" ? "default" : "outline"}
                className={
                  currency === "VND"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                VND (₫)
              </Button>
              <Button
                onClick={() => setCurrency("USD")}
                variant={currency === "USD" ? "default" : "outline"}
                className={
                  currency === "USD"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                USD ($)
              </Button>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Số tiền</label>
              <Input
                type="text"
                placeholder={currency === "VND" ? "100,000" : "10.00"}
                value={amount}
                onChange={(e) => {
                  const formatted = formatNumber(e.target.value)
                  setAmount(formatted)
                }}
                className="h-14 text-lg border-purple-300 focus:border-purple-500"
              />
              {amount && Number.parseFloat(amount.replace(/,/g, "")) > 0 && (
                <p className="text-sm text-purple-600 dark:text-purple-400">
                  ≈ {currency === "VND" ? `$${calculateEquivalentAmount()} USD` : `${calculateEquivalentAmount()} VND`}
                </p>
              )}
            </div>

            <div className="bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/40 dark:to-pink-900/40 rounded-lg p-3 border border-purple-200 dark:border-purple-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-purple-900 dark:text-purple-100">Tỷ giá Pi:</span>
                <div className="text-right">
                  {isLoadingRate ? (
                    <span className="text-sm text-purple-600 dark:text-purple-400 animate-pulse">Đang cập nhật...</span>
                  ) : (
                    <>
                      <div className="text-sm font-bold text-purple-900 dark:text-purple-100">
                        1 Pi ≈ ${piExchangeRate.toFixed(4)} USD
                      </div>
                      {lastUpdated && (
                        <div className="text-xs text-purple-600 dark:text-purple-400">cập nhật lúc {lastUpdated}</div>
                      )}
                    </>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-purple-300 dark:border-purple-600">
                <span className="text-sm font-semibold text-purple-900 dark:text-purple-100">Tỷ giá USD/VND:</span>
                <div className="text-right">
                  {isLoadingUsdVnd ? (
                    <span className="text-sm text-purple-600 dark:text-purple-400 animate-pulse">Đang cập nhật...</span>
                  ) : (
                    <div className="text-sm font-bold text-purple-900 dark:text-purple-100">
                      1 USD ≈ {usdVndRate.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} VND
                    </div>
                  )}
                </div>
              </div>
              <p className="text-xs text-purple-600 dark:text-purple-400 text-center pt-1">Tỷ giá cập nhật realtime</p>
            </div>

            {amount && Number.parseFloat(amount.replace(/,/g, "")) > 0 && (
              <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg p-4 space-y-2 border border-purple-200 dark:border-purple-700">
                <div className="pt-2 flex justify-between items-center">
                  <span className="font-bold text-purple-900 dark:text-purple-100">Nhận được:</span>
                  <span className="font-bold text-2xl text-purple-900 dark:text-purple-100">
                    ~{calculatePiAmount()} Pi
                  </span>
                </div>
                <p className="text-xs text-purple-600 dark:text-purple-400 text-center">
                  Miễn phí 100%, an toàn qua Pi Network – Sắp hỗ trợ khi Mainnet mở full on/off-ramp
                </p>
              </div>
            )}

            <div className="flex gap-3">
              <Button
                onClick={() => setStep("select")}
                variant="outline"
                className="flex-1 border-purple-300 text-purple-700"
              >
                Quay lại
              </Button>
              <Button
                onClick={handleGenerateQR}
                className="flex-1 bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
              >
                Tạo QR thanh toán
              </Button>
            </div>
          </div>
        )}

        {step === "qr" && (
          <div className="space-y-4">
            <Card className="p-6 bg-white dark:bg-purple-900/20 border-2 border-purple-300 dark:border-purple-600">
              <div className="flex justify-center mb-4">
                <div className="bg-white p-4 rounded-xl shadow-lg">
                  <QRCodeSVG value={depositQRData} size={200} level="H" fgColor="#9C27B0" includeMargin />
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3">
                  <p className="text-xs text-purple-600 dark:text-purple-400 mb-1">Số tiền</p>
                  <p className="text-xl font-bold text-purple-900 dark:text-purple-100">
                    {amount} {currency} → ~{calculatePiAmount()} Pi
                  </p>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-xs text-purple-600 dark:text-purple-400 mb-1">Mã giao dịch</p>
                      <p className="text-sm font-mono font-semibold text-purple-900 dark:text-purple-100 break-all">
                        {depositMemo}
                      </p>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleCopyMemo}
                      className="ml-2 text-purple-600 hover:text-purple-700 hover:bg-purple-100"
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-3">
                  <p className="text-xs text-purple-600 dark:text-purple-400 mb-1">Ngân hàng</p>
                  <p className="text-sm font-semibold text-purple-900 dark:text-purple-100">
                    {paymentProviders.find((p) => p.id === selectedProvider)?.name}
                  </p>
                </div>
              </div>
            </Card>

            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-700">
              <p className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-2">Hướng dẫn thanh toán:</p>
              <ol className="text-xs text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
                <li>Mở app ngân hàng và chọn chức năng quét QR</li>
                <li>Quét mã QR phía trên hoặc nhập mã giao dịch</li>
                <li>Xác nhận thanh toán trong app ngân hàng</li>
                <li>Pi sẽ được cộng vào ví sau 5-15 phút</li>
              </ol>
            </div>

            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 border border-green-200 dark:border-green-700 text-center">
              <p className="text-xs font-semibold text-green-800 dark:text-green-200">
                ⚡ Powered by Pi Network On/Off-Ramp
              </p>
              <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                Miễn phí 100%, an toàn qua Pi Network – Tỷ giá cập nhật realtime
              </p>
            </div>

            <Button
              onClick={() => {
                toast.success("Đang chờ xác nhận thanh toán...")
                onOpenChange(false)
                resetDialog()
              }}
              className="w-full bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
            >
              Đã thanh toán
            </Button>
          </div>
        )}

        {step === "processing" && (
          <div className="py-8 text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-br from-[#9C27B0] to-[#E1BEE7] rounded-full flex items-center justify-center mx-auto animate-pulse">
              <span className="text-4xl">💳</span>
            </div>
            <div>
              <p className="text-lg font-bold text-purple-900 dark:text-purple-100 mb-2">Đang xử lý giao dịch...</p>
              <p className="text-sm text-purple-700 dark:text-purple-300">Vui lòng chờ trong giây lát</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
