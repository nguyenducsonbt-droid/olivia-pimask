"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { generateMnemonic, validateMnemonicDetailed, getWalletFromMnemonic } from "@/lib/wallet"
import { simpleEncrypt } from "@/lib/storage"
import { AlertCircle, CheckCircle2, Copy, Eye, EyeOff, Wallet } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/hooks/use-language"

interface WalletSetupProps {
  onComplete: (address: string, encryptedMnemonic: string) => void // Pass wallet data to parent for PIN setup
  initialMode?: "create" | "restore"
}

export function WalletSetup({ onComplete, initialMode }: WalletSetupProps) {
  const [mode, setMode] = useState<"select" | "create" | "restore">(initialMode || "select")
  const [mnemonic, setMnemonic] = useState("")
  const [importMnemonic, setImportMnemonic] = useState("")
  const [showMnemonic, setShowMnemonic] = useState(false)
  const [error, setError] = useState("")
  const [validationResult, setValidationResult] = useState<{
    isValid: boolean
    error?: string
  } | null>(null)
  const { toast } = useToast()
  const { t } = useLanguage()

  useEffect(() => {
    if (initialMode === "create" && !mnemonic) {
      const newMnemonic = generateMnemonic()
      setMnemonic(newMnemonic)
    }
  }, [initialMode, mnemonic])

  const handleGenerateMnemonic = () => {
    const newMnemonic = generateMnemonic()
    setMnemonic(newMnemonic)
    setError("")
  }

  const handleCopyMnemonic = () => {
    navigator.clipboard.writeText(mnemonic)
    toast({
      title: t.common.copied,
      description: t.setup.toasts.copiedSeed,
    })
  }

  const handleCreateWallet = () => {
    if (!mnemonic) {
      setError(t.setup.errors.generateFirst)
      return
    }

    try {
      const wallet = getWalletFromMnemonic(mnemonic)
      const encrypted = simpleEncrypt(mnemonic, wallet.address)

      console.log("[v0] Wallet created successfully")
      console.log("[v0] Address:", wallet.address)

      toast({
        title: "Thành công",
        description: "Ví đã được tạo thành công!",
      })

      onComplete(wallet.address, encrypted)
    } catch (err) {
      console.error("[v0] Create wallet error:", err)
      setError(t.setup.errors.createFailed)
    }
  }

  const handleImportWallet = () => {
    if (!importMnemonic) {
      setError(t.setup.errors.enterSeed)
      return
    }

    const trimmed = importMnemonic.trim()
    const result = validateMnemonicDetailed(trimmed)
    setValidationResult(result)

    if (!result.isValid) {
      setError(result.error || t.setup.errors.invalidSeed)
      return
    }

    try {
      const wallet = getWalletFromMnemonic(trimmed)
      const encrypted = simpleEncrypt(trimmed, wallet.address)

      console.log("[v0] Wallet restored successfully")
      console.log("[v0] Address:", wallet.address)
      console.log("[v0] Mnemonic words:", result.wordCount)

      toast({
        title: "Thành công",
        description: `Ví đã được khôi phục thành công từ ${result.wordCount} từ!`,
      })

      onComplete(wallet.address, encrypted)
    } catch (err) {
      console.error("[v0] Import wallet error:", err)
      setError("Không thể khôi phục ví. Vui lòng kiểm tra lại cụm từ khôi phục.")
    }
  }

  if (mode === "select" && !initialMode) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
        <Card className="w-full max-w-lg shadow-2xl border-0 bg-white">
          <CardHeader className="text-center space-y-6 pb-8">
            <div className="mx-auto w-24 h-24 bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl">
              <Wallet className="w-12 h-12 text-white" />
            </div>
            <div className="space-y-2">
              <CardTitle className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Olivia PiMask
              </CardTitle>
              <CardDescription className="text-lg text-gray-600">Ví Web3 siêu nhẹ, đẹp như Olivia</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pb-8">
            <div className="space-y-3">
              <Button
                onClick={() => {
                  handleGenerateMnemonic()
                  setMode("create")
                }}
                className="w-full h-16 text-lg bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white font-bold rounded-2xl shadow-xl hover:shadow-2xl transition-all"
              >
                <Wallet className="mr-3 h-6 w-6" />
                Tạo ví riêng
              </Button>
              <p className="text-xs text-center text-gray-500">Tạo ví mới với 12 từ bí mật</p>
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">Hoặc</span>
              </div>
            </div>

            <Button
              onClick={() => setMode("restore")}
              variant="outline"
              className="w-full h-14 text-base border-2 border-gray-300 hover:border-gray-400 text-gray-700 hover:text-gray-900 font-semibold rounded-xl hover:bg-gray-50"
            >
              Khôi phục ví từ 12 từ
            </Button>

            <Alert className="border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-xs text-blue-900">
                Ví của bạn được mã hóa và lưu trên thiết bị này. Bạn chỉ cần tạo hoặc khôi phục ví một lần duy nhất.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-purple-600 via-purple-500 to-pink-400">
      <Card className="w-full max-w-lg shadow-xl border-purple-200 bg-white/95 backdrop-blur-sm">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-700 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
            <Wallet className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold text-purple-900">
            {mode === "create" ? t.setup.createTab : t.setup.importTab}
          </CardTitle>
          <CardDescription className="text-base text-purple-700">{t.setup.subtitle}</CardDescription>
        </CardHeader>
        <CardContent>
          {mode === "create" ? (
            <div className="space-y-4">
              {!mnemonic ? (
                <Button
                  onClick={handleGenerateMnemonic}
                  className="w-full h-12 text-base bg-gradient-to-r from-purple-800 to-purple-700 hover:from-purple-900 hover:to-purple-800 text-white"
                  size="lg"
                >
                  {t.setup.generateButton}
                </Button>
              ) : (
                <div className="space-y-4">
                  <Alert className="border-purple-300 bg-purple-50">
                    <AlertCircle className="h-4 w-4 text-purple-600" />
                    <AlertDescription className="text-sm text-balance text-purple-900">
                      {t.setup.seedWarning}
                    </AlertDescription>
                  </Alert>

                  <div className="relative">
                    <div className="grid grid-cols-2 gap-2 p-4 bg-purple-50 rounded-lg border-2 border-dashed border-purple-300">
                      {mnemonic.split(" ").map((word, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm">
                          <span className="text-purple-500 w-6">{i + 1}.</span>
                          <span className={`font-mono font-medium text-purple-900 ${showMnemonic ? "" : "blur-sm"}`}>
                            {word}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="absolute top-2 right-2 flex gap-2">
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-8 w-8 bg-white border-purple-300 text-purple-700 hover:bg-purple-50"
                        onClick={() => setShowMnemonic(!showMnemonic)}
                      >
                        {showMnemonic ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-8 w-8 bg-white border-purple-300 text-purple-700 hover:bg-purple-50"
                        onClick={handleCopyMnemonic}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button
                    onClick={handleCreateWallet}
                    className="w-full h-12 text-base bg-gradient-to-r from-purple-800 to-purple-700 hover:from-purple-900 hover:to-purple-800 text-white"
                    size="lg"
                  >
                    <CheckCircle2 className="mr-2 h-5 w-5" />
                    {t.setup.createButton}
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="import-mnemonic" className="text-purple-900">
                    {t.setup.importMnemonic}
                  </Label>
                  <p className="text-xs text-purple-600">Hỗ trợ cụm từ khôi phục 12 từ hoặc 24 từ BIP39</p>
                  <textarea
                    id="import-mnemonic"
                    className="w-full min-h-[100px] px-3 py-2 text-sm rounded-md border-2 border-purple-300 bg-purple-50 resize-none font-mono text-purple-900 focus:border-purple-500 focus:ring-2 focus:ring-purple-200"
                    placeholder="Nhập 12 hoặc 24 từ cách nhau bởi dấu cách"
                    value={importMnemonic}
                    onChange={(e) => {
                      const value = e.target.value.toLowerCase().trim()
                      setImportMnemonic(value)
                      setValidationResult(null)
                      setError("")
                    }}
                    onBlur={() => {
                      if (importMnemonic.trim()) {
                        const result = validateMnemonicDetailed(importMnemonic.trim())
                        setValidationResult(result)
                        if (!result.isValid) {
                          setError(result.error || "Seed phrase không hợp lệ")
                        }
                      }
                    }}
                  />
                </div>
              </div>

              {validationResult && (
                <>
                  {validationResult.isValid ? (
                    <Alert className="border-green-500 bg-green-50">
                      <CheckCircle2 className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-900">
                        ✅ Seed phrase hợp lệ! Bạn có thể khôi phục ví ngay.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{validationResult.error}</AlertDescription>
                    </Alert>
                  )}
                </>
              )}

              {error && !validationResult && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                onClick={handleImportWallet}
                disabled={!importMnemonic.trim() || (validationResult !== null && !validationResult.isValid)}
                className="w-full h-12 text-base bg-gradient-to-r from-purple-800 to-purple-700 hover:from-purple-900 hover:to-purple-800 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                size="lg"
              >
                {t.setup.importButton}
              </Button>
            </div>
          )}

          {!initialMode && (
            <Button
              variant="ghost"
              className="w-full mt-4 text-purple-700 hover:text-purple-900 hover:bg-purple-100"
              onClick={() => setMode("select")}
            >
              {t.common.cancel}
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
