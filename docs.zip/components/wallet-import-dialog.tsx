"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, QrCode, Lock, AlertTriangle, FileText, Camera, X } from "lucide-react"
import { toast } from "sonner"
import { saveWalletData, saveCustomTokens, saveCustomNetworks } from "@/lib/storage"

interface WalletImportDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onImportSuccess: () => void
}

export function WalletImportDialog({ open, onOpenChange, onImportSuccess }: WalletImportDialogProps) {
  const [password, setPassword] = useState("")
  const [encryptedData, setEncryptedData] = useState("")
  const [importMethod, setImportMethod] = useState<"file" | "qr" | "text" | "camera" | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isScanning, setIsScanning] = useState(false)
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const streamRef = useRef<MediaStream | null>(null)

  useEffect(() => {
    if (!open) {
      stopCamera()
      setImportMethod(null)
      setEncryptedData("")
      setPassword("")
    }
  }, [open])

  const stopCamera = () => {
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
      scanIntervalRef.current = null
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
    setIsScanning(false)
  }

  const startQRScanner = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream

        videoRef.current.onloadedmetadata = () => {
          if (videoRef.current) {
            videoRef.current.play()
            setIsScanning(true)
            toast.success("Camera đã bật! Đưa QR code vào khung hình")

            // Start scanning loop
            scanIntervalRef.current = setInterval(() => {
              scanQRCode()
            }, 250)
          }
        }
      }
    } catch (error) {
      toast.error("Không thể mở camera. Vui lòng cho phép truy cập camera.")
      console.error("Camera error:", error)
      setImportMethod(null)
    }
  }

  const scanQRCode = async () => {
    if (!videoRef.current || !canvasRef.current || !isScanning) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context || video.readyState !== video.HAVE_ENOUGH_DATA) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    if (canvas.width === 0 || canvas.height === 0) return

    context.drawImage(video, 0, 0, canvas.width, canvas.height)
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height)

    try {
      const jsQR = (await import("jsqr")).default
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: "dontInvert",
      })

      if (code && code.data) {
        stopCamera()
        setEncryptedData(code.data)
        toast.success("Quét QR backup thành công! Nhập mật khẩu để khôi phục ví")
      }
    } catch (error) {
      console.error("QR scan error:", error)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.name.endsWith(".olivia")) {
      toast.error("Vui lòng chọn file .olivia")
      return
    }

    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      setEncryptedData(content)
      toast.success("Đã tải file backup")
    }
    reader.onerror = () => {
      toast.error("Lỗi khi đọc file")
    }
    reader.readAsText(file)
  }

  const handleImport = () => {
    if (!password) {
      toast.error("Vui lòng nhập mật khẩu")
      return
    }

    if (!encryptedData) {
      toast.error("Vui lòng chọn file hoặc quét QR")
      return
    }

    try {
      const decrypted = atob(encryptedData)
        .split("")
        .map((char, i) => String.fromCharCode(char.charCodeAt(0) ^ password.charCodeAt(i % password.length)))
        .join("")

      const backupData = JSON.parse(decrypted)

      if (!backupData.version || !backupData.wallet) {
        throw new Error("File backup không hợp lệ")
      }

      saveWalletData(backupData.wallet.address, backupData.wallet.encryptedMnemonic)

      if (backupData.customTokens) {
        saveCustomTokens(backupData.customTokens)
      }
      if (backupData.customNetworks) {
        saveCustomNetworks(backupData.customNetworks)
      }

      toast.success("Khôi phục ví thành công!")
      onOpenChange(false)

      setTimeout(() => {
        onImportSuccess()
      }, 500)
    } catch (error) {
      toast.error("Mật khẩu sai hoặc file bị lỗi")
      console.error("Import error:", error)
    }
  }

  const handleCloseCamera = () => {
    stopCamera()
    setImportMethod(null)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md bg-white dark:bg-[#2C003E] border-purple-300 dark:border-purple-500">
          <DialogHeader>
            <DialogTitle className="text-purple-900 dark:text-purple-200 flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Import Ví Nhanh
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-yellow-700 dark:text-yellow-300">
                  Import ví sẽ thay thế ví hiện tại. Đảm bảo bạn đã backup ví cũ.
                </p>
              </div>
            </div>

            {!importMethod ? (
              <div className="space-y-3">
                <Button
                  onClick={() => {
                    setImportMethod("file")
                    fileInputRef.current?.click()
                  }}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Chọn file .olivia
                </Button>

                <Button
                  onClick={() => setImportMethod("text")}
                  variant="outline"
                  className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Dán Backup Text
                </Button>

                <Button
                  onClick={() => {
                    setImportMethod("camera")
                    setTimeout(() => startQRScanner(), 100)
                  }}
                  variant="outline"
                  className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 hover:bg-gradient-to-r hover:from-purple-100 hover:to-pink-100"
                >
                  <Camera className="w-5 h-5 mr-2" />
                  Quét QR backup bằng camera
                </Button>

                <Button
                  onClick={() => setImportMethod("qr")}
                  variant="outline"
                  className="w-full border-purple-300 dark:border-purple-500 text-purple-700 dark:text-purple-200"
                >
                  <QrCode className="w-4 h-4 mr-2" />
                  Dán dữ liệu QR thủ công
                </Button>

                <input ref={fileInputRef} type="file" accept=".olivia" onChange={handleFileSelect} className="hidden" />
              </div>
            ) : importMethod === "camera" ? (
              <div className="space-y-3">
                <div className="relative bg-black rounded-lg overflow-hidden">
                  <video ref={videoRef} autoPlay playsInline muted className="w-full h-72 object-cover" />
                  <canvas ref={canvasRef} className="hidden" />

                  {isScanning && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <div className="relative w-56 h-56">
                        <div className="absolute inset-0 border-4 border-purple-500/50 rounded-2xl animate-pulse" />
                        <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-white rounded-tl-xl" />
                        <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-white rounded-tr-xl" />
                        <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-white rounded-bl-xl" />
                        <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-white rounded-br-xl" />
                      </div>
                      <div className="mt-4 bg-black/70 px-4 py-2 rounded-full">
                        <p className="text-white text-sm font-medium">Đưa QR vào khung để quét</p>
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={handleCloseCamera}
                    size="icon"
                    variant="destructive"
                    className="absolute top-2 right-2 z-10"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <p className="text-sm text-center text-purple-600 dark:text-purple-300 font-medium">
                  Camera sẽ tự động quét QR backup. Hỗ trợ quét từ ảnh chụp màn hình.
                </p>
              </div>
            ) : importMethod === "qr" ? (
              <div className="space-y-3">
                <Label className="text-purple-900 dark:text-purple-200">Dán dữ liệu QR (base64)</Label>
                <textarea
                  value={encryptedData}
                  onChange={(e) => setEncryptedData(e.target.value)}
                  className="w-full h-32 p-3 border border-purple-300 dark:border-purple-500 rounded-lg bg-white dark:bg-[#33004D] text-sm font-mono"
                  placeholder="Dán dữ liệu từ QR backup..."
                />
                <Button
                  variant="outline"
                  onClick={() => setImportMethod(null)}
                  className="w-full border-purple-300 dark:border-purple-500"
                >
                  Chọn phương thức khác
                </Button>
              </div>
            ) : importMethod === "text" ? (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label className="text-purple-900 dark:text-purple-200">Paste Backup Text</Label>
                  <p className="text-xs text-purple-600 dark:text-purple-300">
                    Dán toàn bộ text backup đã copy trước đó
                  </p>
                  <textarea
                    value={encryptedData}
                    onChange={(e) => setEncryptedData(e.target.value)}
                    className="w-full h-40 p-3 border border-purple-300 dark:border-purple-500 rounded-lg bg-white dark:bg-[#33004D] text-sm font-mono resize-none"
                    placeholder="Dán backup text dài tại đây (hàng nghìn ký tự)..."
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400">Đã dán: {encryptedData.length} ký tự</p>
                </div>
                <Button
                  variant="outline"
                  onClick={() => {
                    setImportMethod(null)
                    setEncryptedData("")
                  }}
                  className="w-full border-purple-300 dark:border-purple-500"
                >
                  Chọn phương thức khác
                </Button>
              </div>
            ) : null}

            {encryptedData && importMethod !== "camera" && (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="import-password" className="text-purple-900 dark:text-purple-200">
                    Mật khẩu backup
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
                    <Input
                      id="import-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 border-purple-300 dark:border-purple-500 focus:border-purple-500 dark:focus:border-purple-400"
                      placeholder="Nhập mật khẩu đã dùng khi export"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleImport}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900"
                >
                  {importMethod === "text" ? "Khôi phục từ Text" : "Khôi phục ví"}
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
