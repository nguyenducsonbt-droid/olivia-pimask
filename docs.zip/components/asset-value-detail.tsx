"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, TrendingUp, TrendingDown } from "lucide-react"
import { useWallet } from "@/hooks/use-wallet"
import { useState, useEffect } from "react"
import { triggerHaptic } from "@/lib/haptic"

interface AssetValueDetailProps {
  onBack: () => void
}

export function AssetValueDetail({ onBack }: AssetValueDetailProps) {
  const { balance, currentNetwork } = useWallet()
  const [assetHistory, setAssetHistory] = useState<Array<{ date: string; value: number; change: number }>>([])

  useEffect(() => {
    const mockHistory = []
    const today = new Date()
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      mockHistory.push({
        date: date.toLocaleDateString("vi-VN", { month: "short", day: "numeric" }),
        value: Number.parseFloat(balance) * (1 + (Math.random() - 0.5) * 0.1),
        change: (Math.random() - 0.5) * 10,
      })
    }
    setAssetHistory(mockHistory)
  }, [balance])

  const handleBack = () => {
    triggerHaptic("light")
    onBack()
  }

  return (
    <div className="space-y-4 pb-20">
      <div className="flex items-center gap-3 mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="text-purple-700 hover:bg-purple-50 transition-all active:scale-95"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2 className="text-xl font-bold text-purple-900">Biến động giá trị tài sản</h2>
      </div>

      <Card className="border-purple-200 bg-gradient-to-br from-purple-50/50 to-pink-50/50">
        <CardContent className="pt-6">
          <p className="text-sm text-purple-600 mb-2">Tổng giá trị hiện tại</p>
          <p className="text-3xl font-bold text-purple-900">$0.00</p>
          <div className="flex items-center gap-2 mt-2">
            <TrendingUp className="w-4 h-4 text-green-600" />
            <p className="text-sm text-green-600">+0.00% (7 ngày)</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="text-base text-purple-900">Biểu đồ 7 ngày</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex items-end justify-between gap-2">
            {assetHistory.map((item, index) => (
              <div key={index} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="w-full bg-gradient-to-t from-purple-500 to-purple-300 rounded-t-sm transition-all hover:from-purple-600 hover:to-purple-400"
                  style={{ height: `${50 + item.change * 2}%` }}
                />
                <p className="text-xs text-purple-600 rotate-45 origin-left mt-2">{item.date}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="text-base text-purple-900">Lịch sử giá trị</CardTitle>
        </CardHeader>
        <CardContent>
          {assetHistory.length === 0 ? (
            <p className="text-center text-purple-600 py-8">Chưa có dữ liệu lịch sử</p>
          ) : (
            <div className="space-y-3">
              {assetHistory.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-purple-50/50 border border-purple-100"
                >
                  <div>
                    <p className="font-medium text-sm text-purple-900">{item.date}</p>
                    <p className="text-xs text-purple-600">${item.value.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {item.change >= 0 ? (
                      <>
                        <TrendingUp className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-semibold text-green-600">+{item.change.toFixed(2)}%</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-4 h-4 text-red-600" />
                        <span className="text-sm font-semibold text-red-600">{item.change.toFixed(2)}%</span>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
