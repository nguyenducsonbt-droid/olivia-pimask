"use client"

import { useState, useEffect } from "react"
import { Sparkles, AlertCircle } from "lucide-react"
import { playSound } from "@/lib/sounds"
import { triggerHaptic } from "@/lib/haptics"
import { useToast } from "@/hooks/use-toast"
import { hasPaymentsScope, requestPaymentsScope } from "@/lib/persistent-storage"

interface PayWithPiButtonProps {
  amount: number
  feature: string
  featureId: string
  onSuccess?: () => void
  onError?: (error: any) => void
  className?: string
}

export function PayWithPiButton({
  amount,
  feature,
  featureId,
  onSuccess,
  onError,
  className = "",
}: PayWithPiButtonProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [hasScopeAccess, setHasScopeAccess] = useState(false)
  const [isCheckingScope, setIsCheckingScope] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Check if payments scope is available
    const checkScope = () => {
      const hasScope = hasPaymentsScope()
      setHasScopeAccess(hasScope)
      setIsCheckingScope(false)
    }

    checkScope()

    // Listen for session changes
    const handleSessionChange = () => {
      checkScope()
    }

    window.addEventListener("olivia-pi-session-changed", handleSessionChange)
    return () => {
      window.removeEventListener("olivia-pi-session-changed", handleSessionChange)
    }
  }, [])

  const handleRequestScope = async () => {
    setIsProcessing(true)
    playSound("click")
    triggerHaptic("light")

    try {
      toast({
        title: "Đang yêu cầu quyền thanh toán...",
        description: "Vui lòng Allow trong popup Pi Browser",
        duration: 5000,
      })

      const granted = await requestPaymentsScope()

      if (granted) {
        setHasScopeAccess(true)
        toast({
          title: "Đã cấp quyền thanh toán!",
          description: "Bạn có thể thanh toán Pi ngay bây giờ",
          duration: 3000,
        })
        triggerHaptic("success")
        playSound("receive")
      } else {
        toast({
          title: "Chưa cấp quyền",
          description: "Bạn cần Allow quyền payments để thanh toán",
          variant: "destructive",
          duration: 5000,
        })
      }
    } catch (error: any) {
      console.error("Failed to request scope:", error)
      toast({
        title: "Không thể yêu cầu quyền",
        description: error?.message || "Vui lòng thử lại",
        variant: "destructive",
        duration: 5000,
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handlePayment = async () => {
    if (!hasScopeAccess) {
      toast({
        title: "Thiếu quyền thanh toán",
        description: "Vui lòng Allow quyền payments trước",
        variant: "destructive",
        duration: 5000,
      })
      return
    }

    setIsProcessing(true)
    playSound("click")
    triggerHaptic("light")

    try {
      if (typeof window === "undefined" || !window.Pi) {
        throw new Error("Pi SDK không khả dụng. Vui lòng mở trong Pi Browser")
      }

      const savedNetwork = localStorage.getItem("olivia_network")
      const isTestnet = savedNetwork === "testnet"

      toast({
        title: "Đang khởi tạo thanh toán Pi...",
        description: `Thanh toán ${amount} Pi cho ${feature}`,
        duration: 3000,
      })

      const payment = await window.Pi.createPayment(
        {
          amount: amount,
          memo: `Olivia PiMask - ${feature}`,
          metadata: {
            featureId,
            feature,
            timestamp: Date.now(),
            source: "olivia_pimask",
            network: isTestnet ? "testnet" : "mainnet",
          },
        },
        {
          onReadyForServerApproval: (paymentId: string) => {
            toast({
              title: "Đang xác thực thanh toán...",
              description: "Vui lòng xác nhận trong Pi Wallet",
              duration: 5000,
            })
          },
          onReadyForServerCompletion: (paymentId: string, txid: string) => {
            // Save successful payment to unlock feature
            localStorage.setItem(`olivia_premium_${featureId}`, "true")
            localStorage.setItem(
              `olivia_payment_${featureId}`,
              JSON.stringify({
                paymentId,
                txid,
                amount,
                feature,
                timestamp: Date.now(),
                network: isTestnet ? "testnet" : "mainnet",
              }),
            )

            playSound("receive")
            triggerHaptic("success")

            toast({
              title: "Thanh toán thành công!",
              description: `${feature} đã được kích hoạt`,
              duration: 7000,
            })

            // Dispatch event for UI updates
            window.dispatchEvent(
              new CustomEvent("olivia-payment-success", {
                detail: { featureId, feature, amount, txid, paymentId },
              }),
            )

            onSuccess?.()
          },
          onCancel: (paymentId: string) => {
            toast({
              title: "Đã hủy thanh toán",
              description: "Bạn đã hủy giao dịch Pi",
              variant: "destructive",
              duration: 3000,
            })
          },
          onError: (error: any, payment: any) => {
            console.error("Payment error:", error, payment)

            if (error?.message?.includes("payments") && error?.message?.includes("scope")) {
              setHasScopeAccess(false)
              toast({
                title: "Thiếu quyền thanh toán",
                description: "Vui lòng Allow quyền payments để thanh toán",
                variant: "destructive",
                duration: 5000,
              })
            } else {
              toast({
                title: "Thanh toán thất bại",
                description: error?.message || "Có lỗi xảy ra khi thanh toán Pi",
                variant: "destructive",
                duration: 5000,
              })
            }
            onError?.(error)
          },
        },
      )
    } catch (error: any) {
      console.error("Payment initialization failed:", error)

      if (error?.message?.includes("payments") && error?.message?.includes("scope")) {
        setHasScopeAccess(false)
        toast({
          title: "Thiếu quyền thanh toán",
          description: "Vui lòng Allow quyền payments để thanh toán",
          variant: "destructive",
          duration: 5000,
        })
      } else {
        toast({
          title: "Không thể khởi tạo thanh toán",
          description: error?.message || "Vui lòng kiểm tra kết nối Pi Network",
          variant: "destructive",
          duration: 5000,
        })
      }
      onError?.(error)
    } finally {
      setIsProcessing(false)
    }
  }

  if (!hasScopeAccess && !isCheckingScope) {
    return (
      <button
        onClick={handleRequestScope}
        disabled={isProcessing}
        className={`
          relative overflow-hidden
          flex items-center justify-center gap-2
          px-6 py-3 rounded-xl
          bg-gradient-to-r from-orange-400 via-orange-500 to-red-500
          hover:from-orange-500 hover:via-orange-600 hover:to-red-600
          text-white font-bold
          shadow-lg hover:shadow-xl
          transition-all duration-200
          active:scale-95
          disabled:opacity-50 disabled:cursor-not-allowed
          ${className}
        `}
      >
        {isProcessing ? (
          <>
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span>Đang xử lý...</span>
          </>
        ) : (
          <>
            <AlertCircle className="w-5 h-5" />
            <span>Allow quyền payments</span>
          </>
        )}
      </button>
    )
  }

  return (
    <button
      onClick={handlePayment}
      disabled={isProcessing || !hasScopeAccess}
      className={`
        relative overflow-hidden
        flex items-center justify-center gap-2
        px-6 py-3 rounded-xl
        bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-500
        hover:from-yellow-500 hover:via-yellow-600 hover:to-amber-600
        text-white font-bold
        shadow-lg hover:shadow-xl
        transition-all duration-200
        active:scale-95
        disabled:opacity-50 disabled:cursor-not-allowed
        ${className}
      `}
    >
      {isProcessing ? (
        <>
          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          <span>Đang xử lý...</span>
        </>
      ) : (
        <>
          <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
            <path
              d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
              fill="white"
            />
            <path d="M11 8h2v8h-2V8z" fill="white" />
            <path d="M8 11h8v2H8v-2z" fill="white" />
          </svg>
          <span>Trả {amount} Pi</span>
          <Sparkles className="w-4 h-4" />
        </>
      )}
    </button>
  )
}
