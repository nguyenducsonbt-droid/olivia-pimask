"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Bell,
  Check,
  Trash2,
  X,
  ArrowUpRight,
  ArrowDownLeft,
  Gift,
  Wallet,
  AlertCircle,
  Smartphone,
  Globe,
} from "lucide-react"
import {
  getNotifications,
  markNotificationAsRead,
  deleteNotification,
  clearAllNotifications,
  type Notification,
} from "@/lib/notifications"

interface NotificationsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onTransactionClick?: (txHash: string) => void
}

export function NotificationsDialog({ open, onOpenChange, onTransactionClick }: NotificationsDialogProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    if (open) {
      loadNotifications()
    }
  }, [open])

  const loadNotifications = () => {
    setNotifications(getNotifications())
  }

  const handleMarkAsRead = (id: string) => {
    markNotificationAsRead(id)
    loadNotifications()
  }

  const handleMarkAllAsRead = () => {
    notifications.forEach((n) => {
      if (!n.read) {
        markNotificationAsRead(n.id)
      }
    })
    loadNotifications()
  }

  const handleDelete = (id: string) => {
    deleteNotification(id)
    loadNotifications()
  }

  const handleClearAll = () => {
    clearAllNotifications()
    loadNotifications()
  }

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.read) {
      handleMarkAsRead(notification.id)
    }

    if (notification.type.startsWith("transaction_") && notification.data?.hash && onTransactionClick) {
      onTransactionClick(notification.data.hash as string)
    }
  }

  const formatTime = (timestamp: number) => {
    const now = Date.now()
    const diff = now - timestamp
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return "Vừa xong"
    if (minutes < 60) return `${minutes} phút trước`
    if (hours < 24) return `${hours} giờ trước`
    return `${days} ngày trước`
  }

  const getNotificationIcon = (type: Notification["type"]) => {
    const iconClass = "w-5 h-5 text-purple-700"

    switch (type) {
      case "transaction_send":
        return <ArrowUpRight className={iconClass} />
      case "transaction_receive":
        return <ArrowDownLeft className={iconClass} />
      case "staking_reward":
        return <Gift className={iconClass} />
      case "fiat_deposit":
      case "fiat_withdraw":
        return <Wallet className={iconClass} />
      case "dapp":
        return <Globe className={iconClass} />
      case "system_update":
        return <Smartphone className={iconClass} />
      case "warning":
      case "error":
        return <AlertCircle className={iconClass} />
      default:
        return <Bell className={iconClass} />
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[80vh] p-0 bg-gradient-to-br from-purple-50 to-pink-50">
        <DialogHeader className="p-6 pb-4 border-b border-purple-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-pink-500 rounded-lg flex items-center justify-center">
                <Bell className="w-4 h-4 text-white" />
              </div>
              <DialogTitle className="text-purple-900">Thông báo</DialogTitle>
            </div>
            {notifications.length > 0 && (
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleMarkAllAsRead}
                  className="text-xs h-8 text-purple-700 hover:text-purple-900 hover:bg-purple-100"
                >
                  <Check className="w-3 h-3 mr-1" />
                  Đọc tất cả
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleClearAll}
                  className="text-xs h-8 text-pink-600 hover:text-pink-700 hover:bg-pink-100"
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  Xóa tất cả
                </Button>
              </div>
            )}
          </div>
          <DialogDescription className="text-purple-700">
            {notifications.length === 0
              ? "Chưa có thông báo mới"
              : `${notifications.filter((n) => !n.read).length} thông báo chưa đọc`}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[500px] px-6 pb-6">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                <Bell className="w-10 h-10 text-purple-300" />
              </div>
              <p className="text-purple-600 font-medium">Chưa có thông báo mới</p>
              <p className="text-purple-400 text-sm mt-1">Thông báo sẽ hiển thị ở đây</p>
            </div>
          ) : (
            <div className="space-y-3 mt-4">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  onClick={() => handleNotificationClick(notification)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    notification.read
                      ? "bg-white/50 border-purple-200 hover:bg-white/70"
                      : "bg-white border-purple-400 shadow-md hover:shadow-lg"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-start gap-3 mb-2">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {!notification.read && <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse" />}
                            <h4 className="font-semibold text-sm text-purple-900 truncate">{notification.title}</h4>
                          </div>
                          <p className="text-sm text-purple-700 leading-relaxed">{notification.message}</p>
                          <p className="text-xs text-purple-500 mt-2">{formatTime(notification.timestamp)}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {!notification.read && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-purple-600 hover:text-purple-900 hover:bg-purple-100"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleMarkAsRead(notification.id)
                          }}
                        >
                          <Check className="w-4 h-4" />
                        </Button>
                      )}
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-pink-600 hover:text-pink-700 hover:bg-pink-100"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDelete(notification.id)
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
