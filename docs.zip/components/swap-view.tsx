"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowDown, Info, Zap, TrendingUp, Loader2, AlertCircle } from "lucide-react"
import { useLanguage } from "@/hooks/use-language"
import { useState, useEffect, useRef, useMemo, useCallback, memo } from "react"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { piSwapAggregator, type SwapQuote, type LiquidityPool } from "@/lib/pi-swap-engine"

const AVAILABLE_TOKENS = [
  { symbol: "PI", name: "Pi Network", address: "native", decimals: 18 },
  { symbol: "USDT", name: "Tether USD", address: "0x1234...usdt", decimals: 6 },
  { symbol: "USDC", name: "USD Coin", address: "0x1234...usdc", decimals: 6 },
  { symbol: "DAI", name: "Dai Stablecoin", address: "0x1234...dai", decimals: 18 },
  { symbol: "BTC", name: "Wrapped Bitcoin", address: "0x1234...wbtc", decimals: 8 },
  { symbol: "ETH", name: "Wrapped Ethereum", address: "0x1234...weth", decimals: 18 },
  { symbol: "BNB", name: "Wrapped BNB", address: "0x1234...wbnb", decimals: 18 },
  { symbol: "XRP", name: "Wrapped XRP", address: "0x1234...wxrp", decimals: 6 },
  { symbol: "XLM", name: "Wrapped Stellar", address: "0x1234...wxlm", decimals: 7 },
  { symbol: "SOL", name: "Wrapped Solana", address: "0x1234...wsol", decimals: 9 },
  { symbol: "ADA", name: "Wrapped Cardano", address: "0x1234...wada", decimals: 6 },
  { symbol: "DOT", name: "Wrapped Polkadot", address: "0x1234...wdot", decimals: 10 },
]

const PoolCard = memo(({ pool }: { pool: LiquidityPool }) => (
  <div className="p-3 rounded-lg bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border">
    <div className="flex items-center justify-between mb-2">
      <span className="font-semibold text-sm">{pool.name}</span>
      <span className="text-xs text-green-600 font-medium">{pool.apy}% APY</span>
    </div>
    <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
      <div>TVL: ${(pool.tvl / 1000000).toFixed(2)}M</div>
      <div>24h Vol: ${(pool.volume24h / 1000).toFixed(0)}K</div>
      <div>Phí: {pool.fee}%</div>
      <div className="text-right text-purple-600 font-medium">Thanh khoản cao</div>
    </div>
  </div>
))

PoolCard.displayName = "PoolCard"

export function SwapView() {
  const { t } = useLanguage()
  const { currentNetwork, balance } = useWallet()
  const { toast } = useToast()

  const [fromToken, setFromToken] = useState("PI")
  const [toToken, setToToken] = useState("USDT")
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")
  const [swapQuote, setSwapQuote] = useState<SwapQuote | null>(null)
  const [isLoadingQuote, setIsLoadingQuote] = useState(false)
  const [isSwapping, setIsSwapping] = useState(false)
  const [liquidityPools, setLiquidityPools] = useState<LiquidityPool[]>([])
  const [showPoolDetails, setShowPoolDetails] = useState(false)
  const [piPrice, setPiPrice] = useState<number>(0.2)
  const [isPriceLoading, setIsPriceLoading] = useState(false)
  const [showInsufficientBalanceWarning, setShowInsufficientBalanceWarning] = useState(false)

  const priceIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const isMountedRef = useRef(true)

  useEffect(() => {
    const pools = piSwapAggregator.getPools()
    setLiquidityPools(pools)
  }, [])

  useEffect(() => {
    if (fromAmount && Number.parseFloat(fromAmount) > 0 && fromToken === currentNetwork.symbol) {
      const userBalance = Number.parseFloat(balance)
      const requiredAmount = Number.parseFloat(fromAmount)

      if (userBalance < requiredAmount) {
        setShowInsufficientBalanceWarning(true)
        toast({
          title: "Số dư Pi không đủ",
          description: `Số dư Pi không đủ để test swap. Bạn cần ${requiredAmount} Pi nhưng chỉ có ${userBalance.toFixed(6)} Pi. Vui lòng restore ví cũ hoặc kiểm tra số dư từ Pi Network mainnet.`,
          variant: "destructive",
        })
      } else {
        setShowInsufficientBalanceWarning(false)
      }
    } else {
      setShowInsufficientBalanceWarning(false)
    }
  }, [fromAmount, fromToken, balance, currentNetwork.symbol, toast])

  useEffect(() => {
    const fetchSwapQuote = async () => {
      if (!fromAmount || Number.parseFloat(fromAmount) <= 0 || fromToken === toToken) {
        setSwapQuote(null)
        setToAmount("")
        return
      }

      setIsLoadingQuote(true)
      try {
        await new Promise((resolve) => setTimeout(resolve, 300))

        const quote = await piSwapAggregator.findBestRoute(fromToken, toToken, Number.parseFloat(fromAmount))
        setSwapQuote(quote)
        setToAmount(quote.toAmount.toFixed(6))
      } catch (error) {
        console.error("Error fetching swap quote:", error)
        setSwapQuote(null)
        setToAmount("")
      } finally {
        setIsLoadingQuote(false)
      }
    }

    fetchSwapQuote()
  }, [fromAmount, fromToken, toToken])

  useEffect(() => {
    isMountedRef.current = true

    const fetchPiPrice = async () => {
      if (document.hidden) {
        return
      }

      setIsPriceLoading(true)
      try {
        const price = await piSwapAggregator.updatePiPrice()
        if (isMountedRef.current) {
          setPiPrice(price)
        }
      } catch (error) {
        console.error("Failed to fetch Pi price:", error)
        if (isMountedRef.current) {
          toast({
            title: "Lỗi lấy giá Pi",
            description: "Không thể lấy giá Pi từ CoinGecko. Đang dùng giá dự phòng.",
            variant: "destructive",
          })
        }
      } finally {
        if (isMountedRef.current) {
          setIsPriceLoading(false)
        }
      }
    }

    fetchPiPrice()

    const startInterval = () => {
      if (priceIntervalRef.current) {
        clearInterval(priceIntervalRef.current)
      }
      priceIntervalRef.current = setInterval(() => {
        if (!document.hidden) {
          fetchPiPrice()
        }
      }, 30000)
    }

    startInterval()

    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (priceIntervalRef.current) {
          clearInterval(priceIntervalRef.current)
          priceIntervalRef.current = null
        }
      } else {
        fetchPiPrice()
        startInterval()
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      isMountedRef.current = false
      if (priceIntervalRef.current) {
        clearInterval(priceIntervalRef.current)
        priceIntervalRef.current = null
      }
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [toast])

  const handleSwitchTokens = useCallback(() => {
    setFromToken(toToken)
    setToToken(fromToken)
    setFromAmount(toAmount)
  }, [fromToken, toToken, toAmount])

  const canSwap = useMemo(
    () =>
      fromAmount &&
      Number.parseFloat(fromAmount) > 0 &&
      fromToken &&
      toToken &&
      fromToken !== toToken &&
      swapQuote &&
      !showInsufficientBalanceWarning,
    [fromAmount, fromToken, toToken, swapQuote, showInsufficientBalanceWarning],
  )

  const handleSwap = useCallback(async () => {
    if (!canSwap || !swapQuote) return

    const userBalance = fromToken === currentNetwork.symbol ? Number.parseFloat(balance) : 0
    const requiredAmount = Number.parseFloat(fromAmount)

    if (userBalance === 0 || userBalance < requiredAmount) {
      toast({
        title: "Không đủ số dư Pi",
        description: `Số dư Pi không đủ để test swap. Bạn cần ${requiredAmount} ${fromToken} nhưng chỉ có ${userBalance.toFixed(6)} ${fromToken}. Vui lòng kiểm tra số dư và kết nối mạng.`,
        variant: "destructive",
      })
      return
    }

    setIsSwapping(true)

    try {
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("Network timeout")), 30000)

        setTimeout(() => {
          clearTimeout(timeout)
          resolve(true)
        }, 2000)
      })

      toast({
        title: "Hoán đổi thành công",
        description: `Đã hoán đổi ${fromAmount} ${fromToken} → ${swapQuote.toAmount.toFixed(4)} ${toToken} qua ${swapQuote.bestRoute.dex}. Phí gas: ${swapQuote.bestRoute.gasEstimate} Pi`,
      })
      setFromAmount("")
      setToAmount("")
      setSwapQuote(null)
    } catch (error) {
      console.error("Swap error:", error)

      const errorMessage =
        error instanceof Error && error.message.includes("timeout")
          ? "Kết nối mạng quá chậm hoặc bị gián đoạn. Vui lòng kiểm tra Internet và thử lại."
          : "Không thể thực hiện giao dịch swap. Vui lòng kiểm tra số dư và kết nối mạng."

      toast({
        title: "Lỗi hoán đổi",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsSwapping(false)
    }
  }, [canSwap, swapQuote, fromToken, currentNetwork.symbol, balance, fromAmount, toast, toToken])

  const relevantPools = useMemo(
    () =>
      liquidityPools.filter(
        (pool) =>
          (pool.tokenA === fromToken && pool.tokenB === toToken) ||
          (pool.tokenA === toToken && pool.tokenB === fromToken) ||
          pool.tokenA === fromToken ||
          pool.tokenB === fromToken ||
          pool.tokenA === toToken ||
          pool.tokenB === toToken,
      ),
    [liquidityPools, fromToken, toToken],
  )

  const handleMaxClick = useCallback(() => {
    setFromAmount(balance)
  }, [balance])

  return (
    <div className="space-y-4">
      <Card className="shadow-lg border-2">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            {t.swap.title}
            <span className="text-xs font-normal text-green-600 bg-green-50 px-2 py-1 rounded-full">Phí thấp nhất</span>
          </CardTitle>
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            {isPriceLoading ? (
              <Loader2 className="w-3 h-3 animate-spin" />
            ) : (
              <>
                <TrendingUp className="w-3 h-3 text-green-600" />
                <span>Pi = ${piPrice.toFixed(4)} USD (CoinGecko • Cập nhật 30s)</span>
              </>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {showInsufficientBalanceWarning && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/20 border-2 space-y-3">
              <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-semibold text-red-900 dark:text-red-100 mb-1">Số dư Pi không đủ để test swap</p>
                <p className="text-red-800 dark:text-red-200">
                  Vui lòng restore ví cũ hoặc kiểm tra số dư từ Pi Network mainnet.
                </p>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label className="text-sm font-medium">{t.swap.from}</Label>
            <div className="p-4 rounded-xl bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-2 space-y-3">
              <Input
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                placeholder="0.0"
                type="number"
                className="text-2xl font-bold h-12 bg-white/50 dark:bg-black/20"
              />
              <Select value={fromToken} onValueChange={setFromToken}>
                <SelectTrigger className="h-12 text-base font-semibold bg-white dark:bg-gray-900">
                  <SelectValue placeholder="Chọn token" />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABLE_TOKENS.map((token) => (
                    <SelectItem key={token.symbol} value={token.symbol} className="text-base">
                      {token.symbol} - {token.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>
                  {t.swap.balance}: {fromToken === currentNetwork.symbol ? balance : "0.00"}
                </span>
                {fromToken === currentNetwork.symbol && (
                  <Button variant="link" size="sm" onClick={handleMaxClick} className="h-auto p-0 text-xs">
                    {t.swap.max}
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-center -my-2">
            <Button
              size="icon"
              variant="outline"
              onClick={handleSwitchTokens}
              className="rounded-full w-12 h-12 shadow-md bg-white dark:bg-gray-900 border-2 hover:bg-purple-50 dark:hover:bg-purple-950/30 transition-all hover:scale-110"
            >
              <ArrowDown className="w-5 h-5 text-purple-600" />
            </Button>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">{t.swap.to}</Label>
            <div className="p-4 rounded-xl bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 border-2 space-y-3">
              <div className="relative">
                <Input
                  value={toAmount}
                  placeholder="0.0"
                  disabled
                  className="text-2xl font-bold h-12 bg-white/50 dark:bg-black/20 disabled:opacity-70"
                />
                {isLoadingQuote && (
                  <div className="absolute right-3 top-3">
                    <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
                  </div>
                )}
              </div>
              <Select value={toToken} onValueChange={setToToken}>
                <SelectTrigger className="h-12 text-base font-semibold bg-white dark:bg-gray-900">
                  <SelectValue placeholder="Chọn token" />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABLE_TOKENS.map((token) => (
                    <SelectItem key={token.symbol} value={token.symbol} className="text-base">
                      {token.symbol} - {token.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="text-sm text-muted-foreground">{t.swap.balance}: 0.00</div>
            </div>
          </div>

          {swapQuote && fromToken !== toToken && (
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-2 border-green-200 dark:border-green-800">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-semibold text-green-900 dark:text-green-100">Tuyến đường tốt nhất</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">DEX</span>
                    <span className="font-semibold">{swapQuote.bestRoute.dex}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Tuyến đường</span>
                    <span className="font-medium">{swapQuote.bestRoute.path.join(" → ")}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Tỷ giá</span>
                    <span className="font-semibold">
                      1 {fromToken} ≈ {(swapQuote.toAmount / swapQuote.fromAmount).toFixed(4)} {toToken}
                      {fromToken === "PI" && (
                        <span className="text-xs text-muted-foreground ml-1">(${piPrice.toFixed(4)})</span>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Phí giao dịch</span>
                    <span className="font-medium text-green-600">{swapQuote.bestRoute.fee}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Phí gas</span>
                    <span className="font-medium">~{swapQuote.bestRoute.gasEstimate} Pi</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Tác động giá</span>
                    <span
                      className={`font-medium ${
                        swapQuote.bestRoute.priceImpact < 1
                          ? "text-green-600"
                          : swapQuote.bestRoute.priceImpact < 3
                            ? "text-yellow-600"
                            : "text-red-600"
                      }`}
                    >
                      {swapQuote.bestRoute.priceImpact.toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Slippage tối ưu</span>
                    <span className="font-medium text-green-600">0.5%</span>
                  </div>
                </div>
              </div>

              {swapQuote.alternativeRoutes.length > 0 && (
                <div className="p-3 rounded-lg bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-800">
                  <div className="text-sm font-medium mb-2">Tuyến đường thay thế:</div>
                  {swapQuote.alternativeRoutes.slice(0, 2).map((route, idx) => (
                    <div key={idx} className="text-xs text-muted-foreground py-1">
                      {route.dex} - Output: {route.expectedOutput.toFixed(4)} {toToken} (Phí: {route.fee}%)
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {relevantPools.length > 0 && (
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPoolDetails(!showPoolDetails)}
                className="w-full justify-between"
              >
                <span className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Pools thanh khoản ({relevantPools.length})
                </span>
                <span className="text-xs">{showPoolDetails ? "Ẩn" : "Hiện"}</span>
              </Button>

              {showPoolDetails && (
                <div className="space-y-2">
                  {relevantPools.map((pool) => (
                    <PoolCard key={pool.id} pool={pool} />
                  ))}
                </div>
              )}
            </div>
          )}

          <Button
            className="w-full h-14 text-lg font-bold rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg"
            size="lg"
            disabled={!canSwap || isSwapping || isLoadingQuote}
            onClick={handleSwap}
          >
            {isSwapping ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Đang xử lý...
              </>
            ) : isLoadingQuote ? (
              "Đang tìm giá tốt nhất..."
            ) : !fromAmount ? (
              "Nhập số lượng"
            ) : fromToken === toToken ? (
              "Chọn token khác"
            ) : (
              <>
                <Zap className="mr-2 h-5 w-5" />
                Hoán đổi ngay
              </>
            )}
          </Button>

          <div className="flex items-start gap-2 p-3 rounded-lg bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-800">
            <Info className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-purple-900 dark:text-purple-100 space-y-1">
              <p className="font-medium">Tính năng Swap đang trong giai đoạn demo</p>
              <p>
                Các tuyến đường swap và pools thanh khoản được tích hợp từ các DEX Pi Network hàng đầu. Khi mainnet
                chính thức, giao dịch sẽ được thực hiện trên blockchain Pi.
              </p>
              <p className="font-medium text-purple-800 dark:text-purple-200 mt-2">
                ⚠️ Thêm token demo/mock. Swap thật phụ thuộc PiDEX launch & bridge EVM 2026. DYOR, rủi ro biến động giá.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
