"use client"

import { memo } from "react"

export const TokenSkeleton = memo(() => (
  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 animate-pulse">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-full bg-muted"></div>
      <div className="space-y-2">
        <div className="h-4 w-24 bg-muted rounded"></div>
        <div className="h-3 w-16 bg-muted rounded"></div>
      </div>
    </div>
    <div className="space-y-2 text-right">
      <div className="h-4 w-20 bg-muted rounded ml-auto"></div>
      <div className="h-3 w-12 bg-muted rounded ml-auto"></div>
    </div>
  </div>
))

TokenSkeleton.displayName = "TokenSkeleton"

export const NFTGridSkeleton = memo(() => (
  <div className="grid grid-cols-2 gap-3">
    {[1, 2, 3, 4].map((i) => (
      <div key={i} className="rounded-xl overflow-hidden bg-white border border-gray-200 animate-pulse">
        <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300"></div>
        <div className="p-3 space-y-2">
          <div className="h-4 bg-gray-300 rounded w-3/4"></div>
          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    ))}
  </div>
))

NFTGridSkeleton.displayName = "NFTGridSkeleton"

export const FiatSkeleton = memo(() => (
  <div className="space-y-3 animate-pulse">
    <div className="p-4 rounded-lg bg-muted/50">
      <div className="h-4 w-32 bg-muted rounded mb-3"></div>
      <div className="h-8 w-40 bg-muted rounded"></div>
    </div>
    <div className="p-4 rounded-lg bg-muted/50">
      <div className="h-4 w-32 bg-muted rounded mb-3"></div>
      <div className="h-8 w-40 bg-muted rounded"></div>
    </div>
  </div>
))

FiatSkeleton.displayName = "FiatSkeleton"
