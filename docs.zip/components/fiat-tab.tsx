"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Wallet, Sparkles, Bell } from "lucide-react"
import { FiatDepositDialog } from "./fiat-deposit-dialog"
import { FiatWithdrawDialog } from "./fiat-withdraw-dialog"
import { FiatNotificationDialog } from "./fiat-notification-dialog"

export function FiatTab() {
  const [showDeposit, setShowDeposit] = useState(false)
  const [showWithdraw, setShowWithdraw] = useState(false)
  const [showNotification, setShowNotification] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState<string>("")
  const [isKYCVerified, setIsKYCVerified] = useState(false)

  const [displayCurrency, setDisplayCurrency] = useState<"VND" | "USD">(() => {
    const saved = localStorage.getItem("olivia_currency")
    if (saved) {
      return saved.toUpperCase() as "VND" | "USD"
    }

    const userLanguage = navigator.language || "en"
    return userLanguage.startsWith("vi") ? "VND" : "USD"
  })

  const [balanceVND, setBalanceVND] = useState(0)
  const [balanceUSD, setBalanceUSD] = useState(0)
  const [isLoading, setIsLoading] = useState(true)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const withdrawAudioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    const fetchBalance = async () => {
      setIsLoading(true)
      setTimeout(() => {
        setBalanceVND(0)
        setBalanceUSD(0)
        setIsLoading(false)
      }, 1000)
    }

    fetchBalance()

    checkKYCStatus()

    audioRef.current = new Audio("/sounds/pop.mp3")
    audioRef.current.volume = 0.7

    withdrawAudioRef.current = new Audio("/sounds/pop.mp3")
    withdrawAudioRef.current.volume = 0.5
  }, [])

  const checkKYCStatus = async () => {
    try {
      if (typeof window !== "undefined") {
        const Pi = (window as any).Pi

        const cachedKYC = localStorage.getItem("kyc_completed")
        if (cachedKYC === "true") {
          setIsKYCVerified(true)
          return
        }

        if (Pi?.user?.getKYCStatus) {
          const kycData = await Pi.user.getKYCStatus()
          const verified = kycData?.status === "approved" || kycData?.verified === true
          setIsKYCVerified(verified)
          localStorage.setItem("kyc_completed", verified ? "true" : "false")
        }
      }
    } catch (error) {
      console.log("[v0] KYC check not available yet:", error)
      setIsKYCVerified(false)
    }
  }

  const createRipple = (event: React.MouseEvent<HTMLButtonElement>) => {
    const button = event.currentTarget
    const ripple = document.createElement("span")
    const rect = button.getBoundingClientRect()
    const size = Math.max(rect.width, rect.height)
    const x = event.clientX - rect.left - size / 2
    const y = event.clientY - rect.top - size / 2

    ripple.style.width = ripple.style.height = `${size}px`
    ripple.style.left = `${x}px`
    ripple.style.top = `${y}px`
    ripple.style.position = "absolute"
    ripple.style.borderRadius = "50%"
    ripple.style.backgroundColor = "rgba(255, 255, 255, 0.4)"
    ripple.style.opacity = "0.4"
    ripple.style.pointerEvents = "none"
    ripple.style.transform = "scale(0)"
    ripple.style.animation = "ripple-effect 0.4s ease-out"

    button.appendChild(ripple)

    setTimeout(() => {
      ripple.remove()
    }, 400)
  }

  const playPopSound = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0
      audioRef.current.play().catch(() => {})
    }
  }

  const playWithdrawPopSound = () => {
    if (withdrawAudioRef.current) {
      withdrawAudioRef.current.currentTime = 0
      withdrawAudioRef.current.play().catch(() => {})
    }
  }

  return (
    <>
      <style jsx global>{`
        @keyframes ripple-effect {
          to {
            transform: scale(4);
            opacity: 0;
          }
        }
      `}</style>

      <div className="bg-gradient-to-br from-purple-50 to-white dark:from-purple-950/30 dark:to-purple-900/10 rounded-3xl p-6 border-2 border-purple-200 dark:border-purple-800 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            <h3 className="text-lg font-bold text-gray-900 dark:text-purple-100">Tiền pháp định</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const newCurrency = displayCurrency === "VND" ? "USD" : "VND"
                setDisplayCurrency(newCurrency)
                localStorage.setItem("olivia_currency", newCurrency)
              }}
              className="px-3 py-1 rounded-lg bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 text-sm font-medium hover:bg-purple-200 dark:hover:bg-purple-800/50 transition-colors"
            >
              {displayCurrency}
            </button>
          </div>
        </div>

        <div className="mb-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
            </div>
          ) : balanceVND === 0 && balanceUSD === 0 ? (
            <div className="text-center py-4">
              <Wallet className="w-12 h-12 text-purple-300 dark:text-purple-600 mx-auto mb-3" />
              <p className="text-purple-600 dark:text-purple-400 mb-2 font-medium">Chưa có số dư</p>
              <p className="text-sm text-purple-500 dark:text-purple-500">Nạp tiền để bắt đầu</p>
            </div>
          ) : (
            <div>
              <p className="text-sm text-purple-600 dark:text-purple-400 mb-1">Số dư {displayCurrency}</p>
              <p className="text-4xl font-bold text-gray-900 dark:text-purple-100">
                {displayCurrency === "VND" ? `${balanceVND.toLocaleString("vi-VN")} ₫` : `$${balanceUSD.toFixed(2)}`}
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-center gap-5 mb-6">
          <button
            onClick={(e) => {
              createRipple(e)
              playPopSound()
              setShowDeposit(true)
            }}
            className="fiat-button"
            style={{
              background: "linear-gradient(135deg, #9C27B0, #E1BEE7)",
              color: "white",
              padding: "16px 32px",
              border: "none",
              borderRadius: "50px",
              fontSize: "18px",
              fontWeight: "bold",
              boxShadow: "0 6px 15px rgba(156,39,176,0.4)",
              minWidth: "140px",
              position: "relative",
              overflow: "hidden",
              cursor: "pointer",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
          >
            Nạp tiền
          </button>

          <button
            onClick={(e) => {
              createRipple(e)
              playWithdrawPopSound()
              setShowWithdraw(true)
            }}
            className="fiat-button"
            style={{
              background: isKYCVerified
                ? "linear-gradient(135deg, #FF6F00, #FF9800)"
                : "linear-gradient(135deg, #7B1FA2, #CE93D8)",
              color: "white",
              padding: "16px 32px",
              border: "none",
              borderRadius: "50px",
              fontSize: "18px",
              fontWeight: "bold",
              boxShadow: isKYCVerified ? "0 6px 15px rgba(255,111,0,0.4)" : "0 6px 15px rgba(123,31,162,0.4)",
              minWidth: "140px",
              position: "relative",
              overflow: "hidden",
              cursor: "pointer",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
          >
            Rút tiền
          </button>
        </div>

        {isKYCVerified ? (
          <div className="bg-gradient-to-r from-orange-100 to-amber-100 dark:from-orange-900/30 dark:to-amber-900/30 rounded-lg p-3 mb-6 border border-orange-300 dark:border-orange-700">
            <p className="text-center text-orange-800 dark:text-orange-200 text-sm font-semibold">
              ✅ Đã KYC – Sẵn sàng rút VND khi ramp mở
            </p>
          </div>
        ) : (
          <p className="text-center text-purple-600 dark:text-purple-400 text-sm mb-6">
            Sau khi hoàn tất KYC trong Pi Browser chính thức, quay lại để rút VND khi ramp mở – Miễn phí 100%, an toàn
            qua Pi Network
          </p>
        )}

        <div className="bg-purple-100 dark:bg-purple-950/30 rounded-lg p-4 border border-purple-200 dark:border-purple-800 mb-4">
          <p className="text-xs font-semibold text-gray-800 dark:text-purple-300 mb-3">Ngân hàng hỗ trợ:</p>
          <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
            {[
              { name: "VNPay", logo: "🏦" },
              { name: "BIDV", logo: "🏢" },
              { name: "Vietcombank", logo: "🏛️" },
              { name: "Momo", logo: "💳" },
              { name: "Techcombank", logo: "🏦" },
              { name: "ZaloPay", logo: "💰" },
              { name: "ViettelPay", logo: "📱" },
            ].map((bank) => (
              <div
                key={bank.name}
                className="flex items-center gap-2 bg-white dark:bg-purple-900/20 rounded-lg p-2 border border-purple-200 dark:border-purple-700"
              >
                <span className="text-lg">{bank.logo}</span>
                <div className="flex-1">
                  <p className="text-xs font-semibold text-gray-800 dark:text-purple-200">{bank.name}</p>
                  <p className="text-xs text-purple-600 dark:text-purple-400">Hỗ trợ khi ramp mở – Miễn phí 100%</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => setShowNotification(true)}
          className="w-full mb-4 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white py-3 px-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg"
        >
          <Bell className="w-5 h-5" />
          Đăng ký nhận thông báo
        </button>

        <div className="bg-purple-100 dark:bg-purple-950/30 rounded-lg p-4 border border-purple-200 dark:border-purple-800">
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-800 dark:text-purple-300 mb-2">Tính năng:</p>
            <div className="space-y-1.5 text-xs text-gray-700 dark:text-purple-400">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full" />
                <span>Nạp VND/USD trực tiếp từ ngân hàng (miễn phí)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full" />
                <span>Rút Pi ra tiền mặt VND/USD (miễn phí)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full" />
                <span>QR thanh toán nhanh cho mọi giao dịch</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-purple-500 rounded-full" />
                <span>Xác thực KYC bảo mật cho rút tiền</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-purple-600 dark:text-purple-400">⚡ Powered by Pi Network On/Off-Ramp</p>
          <p className="text-xs text-purple-500 dark:text-purple-500 mt-1">
            Nạp/Rút VND/USD trực tiếp từ ví Pi, không phí ẩn
          </p>
        </div>
      </div>

      <FiatDepositDialog open={showDeposit} onOpenChange={setShowDeposit} initialProvider={selectedProvider} />

      <FiatWithdrawDialog open={showWithdraw} onOpenChange={setShowWithdraw} />

      <FiatNotificationDialog open={showNotification} onOpenChange={setShowNotification} />
    </>
  )
}
