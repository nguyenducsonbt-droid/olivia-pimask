"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useWallet } from "@/hooks/use-wallet"
import { useToast } from "@/hooks/use-toast"
import { Copy, Share2, Check } from "lucide-react"
import { QRCodeSVG } from "qrcode.react"
import { useLanguage } from "@/hooks/use-language"
import { useEffect, useState, useRef } from "react"
import { triggerHaptic } from "@/lib/haptic"
import { playSound } from "@/lib/sounds"

interface ReceiveDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  activeWalletType?: "olivia" | "pi"
  receiveAddress?: string
}

export function ReceiveDialog({ open, onOpenChange, activeWalletType = "olivia", receiveAddress }: ReceiveDialogProps) {
  const { address } = useWallet()
  const { toast } = useToast()
  const { t } = useLanguage()

  const [currentAddress, setCurrentAddress] = useState(receiveAddress || address)
  const qrRef = useRef<HTMLDivElement>(null)
  const [showCopyCheck, setShowCopyCheck] = useState(false)
  const [showShareCheck, setShowShareCheck] = useState(false)

  useEffect(() => {
    const activeAddress = receiveAddress || address
    if (activeAddress !== currentAddress) {
      setCurrentAddress(activeAddress)
    }
  }, [address, receiveAddress, currentAddress])

  const handleCopy = async () => {
    try {
      triggerHaptic("light")
      playSound("receive")

      await navigator.clipboard.writeText(currentAddress)

      setShowCopyCheck(true)
      setTimeout(() => setShowCopyCheck(false), 2000)

      toast({
        title: "Đã copy!",
        description: "Địa chỉ đã được copy vào clipboard",
        duration: 2000,
      })
    } catch (error) {
      const textarea = document.createElement("textarea")
      textarea.value = currentAddress
      textarea.style.position = "fixed"
      textarea.style.opacity = "0"
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand("copy")
      document.body.removeChild(textarea)

      setShowCopyCheck(true)
      setTimeout(() => setShowCopyCheck(false), 2000)

      toast({
        title: "Đã copy!",
        description: "Địa chỉ đã được copy vào clipboard",
        duration: 2000,
      })
    }
  }

  const handleShare = async () => {
    triggerHaptic("light")
    playSound("receive")

    const shareText = `Nhận Pi từ mình nhé Bro ❤️\n\nĐịa chỉ ví: ${currentAddress}`

    try {
      const qrElement = qrRef.current?.querySelector("svg")

      if (qrElement && navigator.share) {
        const canvas = document.createElement("canvas")
        const ctx = canvas.getContext("2d")
        const svgData = new XMLSerializer().serializeToString(qrElement)
        const img = new Image()

        canvas.width = 280
        canvas.height = 280

        const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" })
        const url = URL.createObjectURL(svgBlob)

        img.onload = async () => {
          if (ctx) {
            ctx.fillStyle = "#ffffff"
            ctx.fillRect(0, 0, canvas.width, canvas.height)
            ctx.drawImage(img, 30, 30, 220, 220)
          }

          canvas.toBlob(
            async (blob) => {
              if (blob) {
                try {
                  const file = new File([blob], "olivia-pimask-qr.png", { type: "image/png" })
                  await navigator.share({
                    title: "Olivia PiMask - Nhận Pi",
                    text: shareText,
                    files: [file],
                  })
                  setShowShareCheck(true)
                  setTimeout(() => setShowShareCheck(false), 2000)
                } catch (shareError) {
                  if ((shareError as Error).name === "AbortError") {
                    return
                  }
                  await shareTextOnly(shareText)
                }
              }
            },
            "image/png",
            1.0,
          )

          URL.revokeObjectURL(url)
        }

        img.onerror = async () => {
          URL.revokeObjectURL(url)
          await shareTextOnly(shareText)
        }

        img.src = url
      } else {
        await shareTextOnly(shareText)
      }
    } catch (error) {
      if ((error as Error).name !== "AbortError") {
        await shareTextOnly(shareText)
      }
    }
  }

  const shareTextOnly = async (shareText: string) => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: "Olivia PiMask - Nhận Pi",
          text: shareText,
        })
        setShowShareCheck(true)
        setTimeout(() => setShowShareCheck(false), 2000)
      } else {
        await copyToClipboardFallback()
      }
    } catch (error) {
      if ((error as Error).name !== "AbortError") {
        await copyToClipboardFallback()
      }
    }
  }

  const copyToClipboardFallback = async () => {
    try {
      await navigator.clipboard.writeText(currentAddress)

      setShowShareCheck(true)
      setTimeout(() => setShowShareCheck(false), 2000)

      toast({
        title: "Đã copy, dán chia sẻ nhé ❤️",
        description: "Địa chỉ ví đã được sao chép vào clipboard",
        duration: 3000,
      })
    } catch (clipboardError) {
      const textarea = document.createElement("textarea")
      textarea.value = currentAddress
      textarea.style.position = "fixed"
      textarea.style.opacity = "0"
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand("copy")
      document.body.removeChild(textarea)

      setShowShareCheck(true)
      setTimeout(() => setShowShareCheck(false), 2000)

      toast({
        title: "Đã copy, dán chia sẻ nhé ❤️",
        description: "Địa chỉ ví đã được sao chép vào clipboard",
        duration: 3000,
      })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle
            className="text-center text-2xl font-bold"
            style={{
              background: "linear-gradient(135deg, #8A2BE2 0%, #DA70D6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            {t.receive.title} {activeWalletType === "pi" ? "Pi" : "Token"}
          </DialogTitle>
          <DialogDescription className="text-center" style={{ color: "#DA70D6" }}>
            {activeWalletType === "pi" ? "Nhận Pi vào ví Pi Mainnet" : "Nhận token vào ví Olivia EVM"}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center space-y-6 py-4">
          <div
            ref={qrRef}
            className="flex items-center justify-center p-6 rounded-2xl shadow-sm w-full max-w-[280px]"
            style={{
              background: "linear-gradient(135deg, #E6E6FA 0%, #D8BFD8 100%)",
              border: "2px solid #E6E6FA",
            }}
          >
            <QRCodeSVG
              value={currentAddress}
              size={220}
              level="H"
              includeMargin={false}
              bgColor="#ffffff"
              fgColor="#8A2BE2"
            />
          </div>

          <div className="w-full space-y-3">
            <div className="text-center">
              <p className="text-xs mb-2 font-medium uppercase tracking-wide" style={{ color: "#DA70D6" }}>
                {t.receive.subtitle}
              </p>
              <p
                className="text-sm font-mono break-all leading-relaxed px-4 py-3 rounded-lg"
                style={{
                  background: "linear-gradient(135deg, #E6E6FA 0%, #D8BFD8 100%)",
                  border: "1.5px solid #E6E6FA",
                  color: "#6A1B9A",
                }}
              >
                {currentAddress}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 w-full pt-2">
              <Button
                onClick={handleCopy}
                className="h-12 text-white font-semibold rounded-xl relative shadow-lg"
                style={{
                  background: "linear-gradient(135deg, #8A2BE2 0%, #DA70D6 50%, #FF69B4 100%)",
                  border: "none",
                }}
                size="lg"
              >
                {showCopyCheck ? (
                  <Check className="mr-2 h-4 w-4 animate-in fade-in zoom-in duration-200" />
                ) : (
                  <Copy className="mr-2 h-4 w-4" />
                )}
                {t.receive.copyButton}
              </Button>
              <Button
                onClick={handleShare}
                className="h-12 text-white font-semibold rounded-xl relative shadow-lg"
                style={{
                  background: "linear-gradient(135deg, #8A2BE2 0%, #DA70D6 50%, #FF69B4 100%)",
                  border: "none",
                }}
                size="lg"
              >
                {showShareCheck ? (
                  <Check className="mr-2 h-4 w-4 animate-in fade-in zoom-in duration-200" />
                ) : (
                  <Share2 className="mr-2 h-4 w-4" />
                )}
                {t.receive.shareButton}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
