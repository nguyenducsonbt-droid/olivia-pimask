"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Eye, EyeOff, Copy, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { getPinHash, simpleDecrypt } from "@/lib/storage"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface SeedPhraseDisplayDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onPinVerified: () => void
}

export function SeedPhraseDisplayDialog({ open, onOpenChange, onPinVerified }: SeedPhraseDisplayDialogProps) {
  const { toast } = useToast()
  const [step, setStep] = useState<"pin_verify" | "show_seed" | "confirm_copy">("pin_verify")
  const [seedPhrase, setSeedPhrase] = useState<string[]>([])
  const [showSeeds, setShowSeeds] = useState<boolean[]>([])
  const [pin, setPin] = useState(["", "", "", "", "", ""])
  const [pinError, setPinError] = useState(false)

  useEffect(() => {
    if (open) {
      setStep("pin_verify")
      setPin(["", "", "", "", "", ""])
      setPinError(false)
      setSeedPhrase([])
      setShowSeeds([])
    }
  }, [open])

  const handlePinChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return

    const newPin = [...pin]
    newPin[index] = value.slice(-1)
    setPin(newPin)

    if (value && index < 5) {
      const nextInput = document.getElementById(`pin-verify-${index + 1}`)
      nextInput?.focus()
    }

    // Auto-verify when 6 digits are entered
    if (newPin.every((digit) => digit !== "")) {
      verifyPin(newPin.join(""))
    }
  }

  const verifyPin = async (enteredPin: string) => {
    const pinData = await getPinHash()

    if (!pinData) {
      setPinError(true)
      toast({
        title: "Lỗi",
        description: "Không tìm thấy PIN. Vui lòng đăng nhập lại.",
        variant: "destructive",
      })
      return
    }

    // Hash entered PIN and compare
    const encoder = new TextEncoder()
    const data = encoder.encode(enteredPin)
    const hashBuffer = await crypto.subtle.digest("SHA-256", data)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")

    if (hashHex === pinData.pinHash) {
      // PIN correct - decrypt and show seed phrase
      try {
        const mnemonic = simpleDecrypt(pinData.encryptedMnemonic, pinData.address)
        const words = mnemonic.split(" ")
        setSeedPhrase(words)
        setShowSeeds(new Array(words.length).fill(false))
        setStep("show_seed")
        onPinVerified()
      } catch (err) {
        console.error("[v0] Error decrypting seed phrase:", err)
        setPinError(true)
        toast({
          title: "Lỗi",
          description: "Không thể giải mã seed phrase",
          variant: "destructive",
        })
      }
    } else {
      setPinError(true)
      setPin(["", "", "", "", "", ""])
      document.getElementById("pin-verify-0")?.focus()
      toast({
        title: "PIN sai",
        description: "Vui lòng thử lại",
        variant: "destructive",
      })
    }
  }

  const toggleShowSeed = (index: number) => {
    const newShowSeeds = [...showSeeds]
    newShowSeeds[index] = !newShowSeeds[index]
    setShowSeeds(newShowSeeds)
  }

  const showAllSeeds = () => {
    setShowSeeds(new Array(seedPhrase.length).fill(true))
  }

  const hideAllSeeds = () => {
    setShowSeeds(new Array(seedPhrase.length).fill(false))
  }

  const handleCopySeedPhrase = () => {
    setStep("confirm_copy")
  }

  const confirmCopy = () => {
    const phrase = seedPhrase.join(" ")
    navigator.clipboard.writeText(phrase)
    toast({
      title: "Đã sao chép",
      description: "Seed phrase đã được sao chép vào clipboard. Hãy lưu giữ an toàn!",
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto bg-gradient-to-br from-purple-50 to-pink-50">
        {step === "pin_verify" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-purple-900 text-center">Xác nhận PIN</DialogTitle>
              <DialogDescription className="text-purple-700 text-center">
                Nhập mã PIN để xem seed phrase
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="flex gap-2 justify-center mb-4">
                {pin.map((digit, index) => (
                  <input
                    key={index}
                    id={`pin-verify-${index}`}
                    type="password"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handlePinChange(index, e.target.value)}
                    className={`w-12 h-14 text-center text-2xl font-bold border-2 rounded-lg bg-white/80 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all ${
                      pinError ? "border-red-500" : digit ? "border-purple-500" : "border-purple-200"
                    }`}
                    autoFocus={index === 0}
                  />
                ))}
              </div>
              {pinError && <p className="text-red-600 text-sm text-center">PIN không đúng. Vui lòng thử lại.</p>}
            </div>
          </>
        )}

        {step === "show_seed" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-purple-900">Seed Phrase của bạn</DialogTitle>
              <DialogDescription className="text-purple-700">12 từ bí mật để khôi phục ví</DialogDescription>
            </DialogHeader>
            <Alert className="bg-red-50 border-red-300">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-900 text-sm">
                <strong>CẢNH BÁO QUAN TRỌNG:</strong>
                <ul className="list-disc ml-4 mt-2 space-y-1">
                  <li>Không bao giờ chia sẻ seed phrase với bất kỳ ai</li>
                  <li>Sao lưu trên giấy hoặc offline an toàn</li>
                  <li>Không chụp màn hình hoặc lưu vào cloud</li>
                  <li>Ai có seed phrase sẽ kiểm soát hoàn toàn ví của bạn</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="py-4 space-y-3">
              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={showAllSeeds}
                  className="border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Hiện tất cả
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={hideAllSeeds}
                  className="border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
                >
                  <EyeOff className="w-4 h-4 mr-1" />
                  Ẩn tất cả
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {seedPhrase.map((word, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 p-3 bg-white/80 backdrop-blur-sm border border-purple-200 rounded-lg"
                  >
                    <span className="text-purple-600 font-semibold text-sm w-6">{index + 1}.</span>
                    <span className="flex-1 font-mono text-purple-900">{showSeeds[index] ? word : "••••••"}</span>
                    <button
                      onClick={() => toggleShowSeed(index)}
                      className="text-purple-500 hover:text-purple-700 transition-colors"
                    >
                      {showSeeds[index] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                ))}
              </div>

              <Button
                onClick={handleCopySeedPhrase}
                variant="outline"
                className="w-full border-purple-300 text-purple-700 hover:bg-purple-50 mt-4 bg-transparent"
              >
                <Copy className="w-4 h-4 mr-2" />
                Sao chép seed phrase
              </Button>
            </div>
          </>
        )}

        {step === "confirm_copy" && (
          <>
            <DialogHeader>
              <DialogTitle className="text-purple-900">Xác nhận sao chép</DialogTitle>
              <DialogDescription className="text-purple-700">
                Bạn có chắc chắn muốn sao chép seed phrase?
              </DialogDescription>
            </DialogHeader>
            <Alert className="bg-yellow-50 border-yellow-300">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900 text-sm">
                Seed phrase sẽ được sao chép vào clipboard. Hãy chắc chắn bạn sẽ dán vào nơi an toàn và không chia sẻ
                với ai.
              </AlertDescription>
            </Alert>
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setStep("show_seed")}
                className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50"
              >
                Quay lại
              </Button>
              <Button
                onClick={confirmCopy}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
              >
                Xác nhận sao chép
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
