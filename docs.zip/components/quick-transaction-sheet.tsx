"use client"

import { useEffect, useState } from "react"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { History, Copy, Check, Loader2, AlertCircle, ArrowUp, ArrowDown, Edit2, RefreshCw, Globe } from "lucide-react"
import QRCode from "qrcode"
import { CrossBorderTransferDialog } from "./cross-border-transfer-dialog"

interface QuickTransactionSheetProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  activeWalletType?: "olivia" | "pi"
  activeAddress?: string
  currentNetwork?: { id: string; name: string }
}

export function QuickTransactionSheet({
  open,
  onOpenChange,
  activeWalletType = "pi",
  activeAddress,
  currentNetwork,
}: QuickTransactionSheetProps) {
  const [activeView, setActiveView] = useState<"main" | "deposit" | "withdraw" | "history">("main")
  const [piAddress, setPiAddress] = useState<string | null>(null)
  const [piBalance, setPiBalance] = useState<string>("0")
  const [qrCode, setQrCode] = useState<string>("")
  const [isLoadingBalance, setIsLoadingBalance] = useState(false)
  const [showAddressForm, setShowAddressForm] = useState(false)
  const [piAddressInput, setPiAddressInput] = useState("")
  const [inlineError, setInlineError] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [withdrawAddress, setWithdrawAddress] = useState("")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [showCrossBorder, setShowCrossBorder] = useState(false)

  const { toast } = useToast()

  const loadPiWallet = async () => {
    try {
      // This ensures the quick transaction sheet always displays the currently active wallet
      if (activeAddress) {
        setPiAddress(activeAddress)

        // Generate QR code for active address
        if (activeAddress.startsWith("G") || activeAddress.startsWith("0x")) {
          try {
            const qr = await QRCode.toDataURL(activeAddress, {
              width: 256,
              margin: 2,
              color: { dark: "#9C27B0", light: "#FFFFFF" },
            })
            setQrCode(qr)
          } catch (error) {
            console.error("[v0] Error generating QR:", error)
          }

          // Fetch balance based on wallet type
          if (activeAddress.startsWith("G")) {
            // Pi wallet - fetch from horizon
            setIsLoadingBalance(true)
            try {
              const realBalance = await getPiBalance(activeAddress)
              setPiBalance(realBalance)
            } catch (error) {
              console.error("[v0] Error fetching Pi balance:", error)
              setPiBalance("0")
            } finally {
              setIsLoadingBalance(false)
            }
          } else {
            // Olivia EVM wallet - load from storage
            const oliviaWallet = localStorage.getItem("olivia_wallet_encrypted")
            if (oliviaWallet) {
              const parsed = JSON.parse(oliviaWallet)
              setPiBalance(parsed.balance || "0")
            } else {
              setPiBalance("0")
            }
          }
        }
        return
      }

      let piWalletData = localStorage.getItem("olivia_pi_wallet")

      if (!piWalletData) {
        const mainWalletData = localStorage.getItem("olivia_wallet_encrypted")
        if (mainWalletData) {
          const parsed = JSON.parse(mainWalletData)
          if (parsed.address && parsed.address.startsWith("G")) {
            const piData = {
              address: parsed.address,
              balance: "0",
              savedAt: Date.now(),
            }
            localStorage.setItem("olivia_pi_wallet", JSON.stringify(piData))
            piWalletData = JSON.stringify(piData)
          }
        }
      }

      if (piWalletData) {
        const parsed = JSON.parse(piWalletData)
        setPiAddress(parsed.address)

        if (parsed.address && parsed.address.startsWith("G")) {
          try {
            const qr = await QRCode.toDataURL(parsed.address, {
              width: 256,
              margin: 2,
              color: { dark: "#9C27B0", light: "#FFFFFF" },
            })
            setQrCode(qr)
          } catch (error) {
            console.error("[v0] Error generating QR:", error)
          }

          setIsLoadingBalance(true)
          try {
            const realBalance = await getPiBalance(parsed.address)
            setPiBalance(realBalance)

            parsed.balance = realBalance
            localStorage.setItem("olivia_pi_wallet", JSON.stringify(parsed))
          } catch (error) {
            console.error("[v0] Error fetching Pi balance:", error)
            setPiBalance(parsed.balance || "0")
          } finally {
            setIsLoadingBalance(false)
          }
        } else {
          setPiBalance(parsed.balance || "0")
        }
      } else {
        setPiAddress(null)
        setPiBalance("0")
        setQrCode("")
      }
    } catch (error) {
      console.error("[v0] Error loading Pi wallet:", error)
      setPiAddress(null)
      setPiBalance("0")
      setQrCode("")
    }
  }

  useEffect(() => {
    if (open) {
      // When in Olivia mode and no Pi address is saved, show address entry form directly
      if (activeWalletType === "olivia" && !piAddress) {
        setActiveView("main")
        setShowAddressForm(true)
      } else {
        loadPiWallet()
        setShowAddressForm(false)
      }

      // Blur any focused elements to prevent keyboard from opening
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur()
      }

      // Additional blur after a short delay to catch any auto-focus attempts
      const blurTimeout = setTimeout(() => {
        if (
          document.activeElement instanceof HTMLElement &&
          (document.activeElement.tagName === "INPUT" || document.activeElement.tagName === "TEXTAREA")
        ) {
          document.activeElement.blur()
        }
      }, 100)

      return () => clearTimeout(blurTimeout)
    }
  }, [open, activeAddress, activeWalletType])

  const handleSavePiAddress = async () => {
    const trimmedAddress = piAddressInput.trim()

    if (!trimmedAddress) {
      setInlineError("Vui lòng nhập địa chỉ ví Pi")
      return
    }

    if (!validatePiAddress(trimmedAddress)) {
      setInlineError("Vui lòng kiểm tra lại định dạng địa chỉ")
      return
    }

    setInlineError("")
    setIsSaving(true)

    try {
      // Fetch balance for the address
      let realBalance = "0"
      try {
        setIsLoadingBalance(true)
        realBalance = await getPiBalance(trimmedAddress)
        console.log("[v0] Fetched Pi balance:", realBalance)
      } catch (error) {
        console.error("[v0] Error fetching initial balance:", error)
      } finally {
        setIsLoadingBalance(false)
      }

      // Save to localStorage
      const piWalletData = {
        address: trimmedAddress,
        balance: realBalance,
        savedAt: Date.now(),
      }

      localStorage.setItem("olivia_pi_wallet", JSON.stringify(piWalletData))

      setPiAddress(trimmedAddress)
      setPiBalance(realBalance)
      setShowAddressForm(false)
      setPiAddressInput("")

      // Generate QR code
      const qr = await QRCode.toDataURL(trimmedAddress, {
        width: 256,
        margin: 2,
        color: { dark: "#9C27B0", light: "#FFFFFF" },
      })
      setQrCode(qr)

      toast({
        title: "✓ Đã lưu địa chỉ Pi!",
        description: `${trimmedAddress.slice(0, 10)}...${trimmedAddress.slice(-8)}`,
        duration: 3000,
      })

      // Navigate to deposit view to show QR
      setActiveView("deposit")
    } catch (error) {
      console.error("[v0] Error saving Pi address:", error)
      setInlineError("Không thể lưu địa chỉ. Vui lòng thử lại")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeposit = () => {
    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")

    // If no Pi wallet and no manual address saved, show warning toast
    if (!hasImportedPiWallet && !piAddress) {
      toast({
        title: "⚠️ Chưa có địa chỉ Pi",
        description: "Vui lòng nhập địa chỉ Pi thủ công hoặc import ví Pi từ header",
      })
      return
    }

    // If we have a Pi address (imported or manual), show deposit view
    setActiveView("deposit")
  }

  const handleWithdraw = () => {
    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")

    // If no Pi wallet and no manual address saved, show warning toast
    if (!hasImportedPiWallet && !piAddress) {
      toast({
        title: "⚠️ Chưa có địa chỉ Pi",
        description: "Vui lòng nhập địa chỉ Pi thủ công hoặc import ví Pi từ header",
      })
      return
    }

    // If we have a Pi address (imported or manual), show withdraw view
    setActiveView("withdraw")
  }

  const handleCrossBorder = () => {
    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")
    const currentBalance = Number.parseFloat(piBalance) || 0

    // Check if user has Pi wallet
    if (!hasImportedPiWallet && !piAddress) {
      toast({
        title: "⚠️ Chưa có địa chỉ Pi",
        description: "Vui lòng nhập địa chỉ Pi thủ công hoặc import ví Pi từ header",
      })
      return
    }

    // Check if user has balance
    if (currentBalance === 0) {
      toast({
        title: "⚠️ Cần nạp Pi để chuyển quốc tế",
        description: "Vui lòng nạp Pi vào ví trước khi thực hiện chuyển tiền quốc tế",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    // Close current modal and open cross-border dialog
    onOpenChange(false)
    setTimeout(() => {
      setShowCrossBorder(true)
    }, 300)
  }

  const handleWithdrawPi = async () => {
    const recipientAddress = withdrawAddress.trim()
    const amount = withdrawAmount.trim()

    if (!validatePiAddress(recipientAddress)) {
      toast({
        title: "Địa chỉ không hợp lệ",
        description: "Địa chỉ Pi phải có định dạng Stellar hợp lệ (bắt đầu bằng G)",
        variant: "destructive",
      })
      return
    }

    // Validate amount
    const amountNum = Number.parseFloat(amount)
    if (isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Số lượng không hợp lệ",
        description: "Vui lòng nhập số lượng lớn hơn 0",
        variant: "destructive",
      })
      return
    }

    if (amountNum > Number.parseFloat(piBalance)) {
      toast({
        title: "Số dư không đủ",
        description: `Số dư hiện tại: ${piBalance} Pi`,
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    try {
      // In production, this would call sendPiTransaction with user's private key
      await new Promise((resolve) => setTimeout(resolve, 2000))

      const txHash = `demo_${Date.now()}_${Math.random().toString(36).substring(7)}`

      // Update balance (simulate)
      const newBalance = (Number.parseFloat(piBalance) - amountNum).toFixed(2)
      setPiBalance(newBalance)

      // Update stored balance
      const piWalletData = JSON.parse(localStorage.getItem("olivia_pi_wallet") || "{}")
      piWalletData.balance = newBalance
      localStorage.setItem("olivia_pi_wallet", JSON.stringify(piWalletData))

      // Save transaction to history
      const transactions = JSON.parse(localStorage.getItem("olivia_pi_transactions") || "[]")
      transactions.unshift({
        id: txHash,
        type: "withdraw",
        amount: amountNum,
        to: recipientAddress,
        from: piAddress,
        timestamp: Date.now(),
        status: "success",
        hash: txHash,
      })
      localStorage.setItem("olivia_pi_transactions", JSON.stringify(transactions))

      toast({
        title: "✓ Rút Pi thành công!",
        description: `Đã rút ${amountNum} Pi đến ${recipientAddress.slice(0, 10)}...${recipientAddress.slice(-8)}`,
        duration: 3000,
      })

      setWithdrawAddress("")
      setWithdrawAmount("")
      setActiveView("main")
    } catch (error: any) {
      console.error("[v0] Error withdrawing Pi:", error)
      toast({
        title: "Lỗi rút Pi",
        description: error.message || "Vui lòng thử lại sau",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleCopyAddress = (address: string) => {
    if (!address) {
      toast({
        title: "Không có địa chỉ",
        description: "Chưa có địa chỉ để copy",
        variant: "destructive",
        duration: 2000,
      })
      return
    }

    navigator.clipboard
      .writeText(address)
      .then(() => {
        toast({
          title: "✓ Đã copy địa chỉ ví!",
          description: `Địa chỉ ${address.slice(0, 10)}...${address.slice(-8)} đã được copy`,
          duration: 2000,
        })
      })
      .catch(() => {
        // Fallback method for older browsers
        const textarea = document.createElement("textarea")
        textarea.value = address
        textarea.style.position = "fixed"
        textarea.style.opacity = "0"
        document.body.appendChild(textarea)
        textarea.select()
        document.execCommand("copy")
        document.body.removeChild(textarea)

        toast({
          title: "✓ Đã copy địa chỉ ví!",
          description: `Địa chỉ ${address.slice(0, 10)}...${address.slice(-8)} đã được copy`,
          duration: 2000,
        })
      })
  }

  const handleRefreshBalance = async () => {
    if (!piAddress) return

    setIsLoadingBalance(true)
    try {
      const realBalance = await getPiBalance(piAddress)
      setPiBalance(realBalance)

      const piWalletData = JSON.parse(localStorage.getItem("olivia_pi_wallet") || "{}")
      piWalletData.balance = realBalance
      localStorage.setItem("olivia_pi_wallet", JSON.stringify(piWalletData))
    } catch (error) {
      console.error("[v0] Error refreshing balance:", error)
    } finally {
      setIsLoadingBalance(false)
    }
  }

  const renderMainView = () => {
    if (activeWalletType === "olivia") {
      return (
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-purple-900 dark:text-white mb-2">Giao dịch nhanh</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">Nhập địa chỉ Pi để giao dịch</p>
          </div>

          {!showAddressForm && piAddress && piAddress.startsWith("G") ? (
            // Display saved Pi address with QR
            <div className="space-y-4">
              {qrCode && (
                <div className="flex justify-center">
                  <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-xl border-2 border-purple-200 dark:border-purple-700">
                    <img src={qrCode || "/placeholder.svg"} alt="QR Code" className="w-64 h-64 rounded-xl" />
                  </div>
                </div>
              )}

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30 rounded-2xl p-5 border-2 border-purple-300 dark:border-purple-700 shadow-lg">
                <p className="text-xs text-purple-700 dark:text-purple-300 mb-3 font-semibold text-center uppercase tracking-wide">
                  Địa chỉ nhận Pi (Stellar format)
                </p>
                <button
                  onClick={() => handleCopyAddress(piAddress)}
                  className="w-full flex items-center justify-between gap-3 p-4 bg-white dark:bg-gray-800 rounded-xl hover:bg-purple-50 dark:hover:bg-purple-900/30 transition-all hover:shadow-md group"
                >
                  <span className="text-xs font-mono text-gray-900 dark:text-white break-all leading-relaxed">
                    {piAddress}
                  </span>
                  <Copy className="w-5 h-5 text-purple-600 dark:text-purple-400 flex-shrink-0 group-hover:scale-110 transition-transform" />
                </button>

                {isLoadingBalance ? (
                  <div className="mt-4 pt-4 border-t border-purple-200 dark:border-purple-700 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 text-purple-600 animate-spin" />
                    <p className="text-sm text-purple-600">Đang tải số dư...</p>
                  </div>
                ) : (
                  <div className="mt-4 pt-4 border-t border-purple-200 dark:border-purple-700 text-center">
                    <p className="text-xs text-purple-700 dark:text-purple-300 mb-2">Số dư Pi</p>
                    <p className="text-3xl font-bold text-purple-900 dark:text-white">
                      {piBalance} <span className="text-base font-normal text-purple-600 dark:text-purple-400">π</span>
                    </p>
                  </div>
                )}
              </div>

              <Button
                onClick={() => {
                  setShowAddressForm(true)
                  setPiAddressInput("")
                }}
                variant="outline"
                className="w-full"
              >
                Thay đổi địa chỉ Pi
              </Button>
            </div>
          ) : (
            // Manual address entry form
            <div className="space-y-4">
              <div className="text-center py-4 px-3 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/30 dark:to-orange-900/30 rounded-xl border border-dashed border-amber-300 dark:border-amber-600">
                <AlertCircle className="w-8 h-8 text-amber-500 dark:text-amber-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-amber-900 dark:text-amber-100 mb-1">Chưa có địa chỉ Pi</p>
                <p className="text-xs text-amber-600 dark:text-amber-400">
                  Nhập địa chỉ Pi để xem QR và thực hiện giao dịch
                </p>
              </div>

              <div>
                <label
                  htmlFor="pi-address-manual"
                  className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block"
                >
                  Nhập địa chỉ ví Pi thủ công
                </label>
                <Input
                  id="pi-address-manual"
                  type="text"
                  placeholder="GBXUFADINJ3GBPSRW4EBYYTVORR3DB4TWQDXCQ6J7052NEQLBE6TTGBS"
                  value={piAddressInput}
                  onChange={(e) => {
                    setPiAddressInput(e.target.value)
                    if (inlineError) setInlineError("")
                  }}
                  className="mt-1.5 font-mono text-xs h-11"
                  disabled={isSaving}
                  autoFocus={false}
                />
                {inlineError && (
                  <p className="text-xs text-amber-600 dark:text-amber-500 mt-1.5 animate-in fade-in duration-200">
                    {inlineError}
                  </p>
                )}
              </div>

              <Button
                onClick={handleSavePiAddress}
                disabled={isSaving || !piAddressInput.trim()}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Đang lưu...
                  </>
                ) : (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Xác nhận địa chỉ
                  </>
                )}
              </Button>
            </div>
          )}

          <div className="text-center px-4">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Đang ở mode ví Olivia (EVM). Nhập địa chỉ Pi để nhận/gửi Pi từ ví EVM này.
            </p>
          </div>
        </div>
      )
    }

    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")

    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-purple-900 dark:text-white mb-2">Giao dịch nhanh</h2>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 border border-purple-200 dark:border-purple-700">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <p className="text-xs font-semibold text-purple-900 dark:text-purple-100">Ví Pi đã kết nối</p>
          </div>
        </div>

        {hasImportedPiWallet ? (
          <div className="bg-purple-50 dark:bg-purple-900/20 rounded-2xl p-4 border border-purple-200 dark:border-purple-700">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-purple-700 dark:text-purple-300 font-semibold">Số dư khả dụng</p>
              <Button
                size="icon"
                variant="ghost"
                onClick={handleRefreshBalance}
                disabled={isLoadingBalance}
                className="h-6 w-6"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingBalance ? "animate-spin" : ""}`} />
              </Button>
            </div>
            <p className="text-3xl font-bold text-purple-900 dark:text-white">
              {piBalance} <span className="text-sm font-normal text-purple-600 dark:text-purple-400">π</span>
            </p>
            <p className="text-xs text-purple-600 dark:text-purple-400 mt-1 font-mono break-all">
              {piAddress?.slice(0, 10)}...{piAddress?.slice(-8)}
            </p>
          </div>
        ) : (
          <div className="text-center py-6 px-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-dashed border-amber-300 dark:border-amber-600">
            <AlertCircle className="w-10 h-10 text-amber-500 dark:text-amber-400 mx-auto mb-3" />
            <p className="text-sm font-semibold text-amber-900 dark:text-amber-100 mb-2">Chưa import ví Pi</p>
            <p className="text-xs text-amber-600 dark:text-amber-400">
              Vui lòng import ví Pi từ header để thực hiện giao dịch
            </p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-3">
          <Button
            variant="outline"
            size="lg"
            className="flex flex-col items-center gap-2 h-auto py-4 border-2 hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all bg-transparent"
            onClick={handleDeposit}
          >
            <ArrowDown className="w-6 h-6 text-green-600 dark:text-green-400" />
            <span className="text-xs font-semibold">Nạp Pi</span>
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="flex flex-col items-center gap-2 h-auto py-4 border-2 hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all bg-transparent"
            onClick={handleWithdraw}
          >
            <ArrowUp className="w-6 h-6 text-red-600 dark:text-red-400" />
            <span className="text-xs font-semibold">Rút Pi</span>
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="flex flex-col items-center gap-2 h-auto py-4 border-2 border-blue-300 dark:border-blue-700 hover:border-blue-500 hover:bg-gradient-to-br hover:from-blue-50 hover:to-cyan-50 dark:hover:from-blue-900/30 dark:hover:to-cyan-900/30 transition-all bg-transparent"
            onClick={handleCrossBorder}
          >
            <Globe className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span className="text-xs font-semibold text-blue-900 dark:text-blue-100">Chuyển QT</span>
          </Button>
        </div>

        <Button
          variant="outline"
          size="lg"
          className="w-full flex items-center justify-center gap-3 h-auto py-3 border-2 border-purple-300 dark:border-purple-700 hover:border-purple-500 hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50 dark:hover:from-purple-900/30 dark:hover:to-pink-900/30 transition-all bg-transparent"
          onClick={() => setActiveView("history")}
        >
          <History className="w-5 h-5 text-purple-600 dark:text-purple-400" />
          <span className="text-sm font-semibold text-purple-900 dark:text-purple-100">Lịch sử giao dịch</span>
        </Button>

        <div className="text-center px-4">
          <p className="text-xs text-gray-500 dark:text-gray-400">Giao dịch an toàn với Pi Network Mainnet 2026</p>
        </div>
      </div>
    )
  }

  const renderDepositView = () => {
    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")
    // Always show manual form if no Pi wallet exists
    const shouldShowManualForm = showAddressForm || !hasImportedPiWallet

    return (
      <div className="space-y-4">
        {shouldShowManualForm ? (
          <>
            <div className="text-center">
              <h2 className="text-xl font-bold text-purple-900 dark:text-white mb-1">Nhập địa chỉ ví Pi</h2>
              <p className="text-xs text-gray-600 dark:text-gray-400">Nhập thủ công địa chỉ ví Pi Network của bạn</p>
            </div>

            {!hasImportedPiWallet && (
              <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl p-3">
                <div className="flex gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-800 dark:text-amber-200">
                    Bạn chưa import ví Pi. Vui lòng nhập địa chỉ Pi thủ công để nhận Pi.
                  </p>
                </div>
              </div>
            )}

            <div className="space-y-3 animate-in fade-in duration-300">
              <div>
                <label htmlFor="pi-address-input" className="text-xs font-medium text-foreground/80">
                  Địa chỉ ví Pi Network (G...)
                </label>
                <Input
                  id="pi-address-input"
                  type="text"
                  placeholder="GBXUFADINJ3..."
                  value={piAddressInput}
                  onChange={(e) => {
                    setPiAddressInput(e.target.value)
                    if (inlineError) setInlineError("")
                  }}
                  className="mt-1.5 font-mono text-xs h-10"
                  disabled={isSaving}
                  autoFocus={false}
                />
                {inlineError && (
                  <p className="text-xs text-amber-600 dark:text-amber-500 mt-1.5 animate-in fade-in duration-200">
                    {inlineError}
                  </p>
                )}
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleSavePiAddress}
                  disabled={isSaving || !piAddressInput.trim()}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 h-10"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Đang lưu...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Xác nhận
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (hasImportedPiWallet) {
                      setShowAddressForm(false)
                      setPiAddressInput("")
                      setInlineError("")
                    } else {
                      // Return to main view when no Pi wallet is imported
                      setActiveView("main")
                      setPiAddressInput("")
                      setInlineError("")
                    }
                  }}
                  disabled={isSaving}
                  className="h-10"
                >
                  Hủy
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="space-y-4 animate-in fade-in duration-300">
            {qrCode && (
              <div className="flex justify-center">
                <div className="bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-lg">
                  <img src={qrCode || "/placeholder.svg"} alt="QR Code" className="w-[200px] h-[200px] rounded-xl" />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <p className="text-xs text-center text-gray-600 dark:text-gray-400">Địa chỉ ví Pi của bạn</p>
              <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 p-2.5 rounded-lg">
                <code className="flex-1 text-xs font-mono break-all text-purple-900 dark:text-purple-300">
                  {piAddress}
                </code>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCopyAddress(piAddress)}
                  className="shrink-0 h-8 w-8 p-0"
                >
                  <Copy className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            {isLoadingBalance ? (
              <div className="flex items-center justify-center gap-2 text-sm text-gray-600 dark:text-gray-400 py-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Đang tải số dư...
              </div>
            ) : (
              <div className="text-center bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 p-3 rounded-xl">
                <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">Số dư Pi</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-300">{piBalance} π</p>
              </div>
            )}

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowAddressForm(true)} className="flex-1 h-10">
                <Edit2 className="mr-2 h-4 w-4" />
                Đổi địa chỉ
              </Button>
              <Button
                onClick={handleRefreshBalance}
                disabled={isLoadingBalance}
                variant="outline"
                className="flex-1 h-10 bg-transparent"
              >
                <RefreshCw className={`mr-2 h-4 w-4 ${isLoadingBalance ? "animate-spin" : ""}`} />
                Làm mới
              </Button>
            </div>
            <Button variant="outline" onClick={() => setActiveView("main")} className="w-full h-10">
              <ArrowUp className="mr-2 h-4 w-4 rotate-180" />
              Quay lại
            </Button>
          </div>
        )}
      </div>
    )
  }

  const renderWithdrawView = () => {
    const hasImportedPiWallet = piAddress && piAddress.startsWith("G")

    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-purple-900 dark:text-white mb-2">Gửi Pi</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400">Gửi Pi đến địa chỉ khác</p>
        </div>

        {piAddress ? (
          <>
            <div className="bg-purple-50 dark:bg-purple-900/20 rounded-2xl p-4 border border-purple-200 dark:border-purple-700">
              <p className="text-xs text-purple-700 dark:text-purple-300 mb-1">Số dư khả dụng</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-300">
                  {piBalance} <span className="text-sm font-normal text-purple-600 dark:text-purple-400">Pi</span>
                </p>
                {isLoadingBalance && <Loader2 className="w-4 h-4 text-purple-600 animate-spin" />}
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  Địa chỉ nhận (G...)
                </label>
                <Input
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  placeholder="GXXX...XXX"
                  className="font-mono"
                  disabled={isProcessing}
                  autoFocus={false}
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">Số lượng Pi</label>
                <Input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder="0.00"
                  step="0.01"
                  min="0"
                  disabled={isProcessing}
                  autoFocus={false}
                />
                <button
                  onClick={() => setWithdrawAmount(piBalance)}
                  className="text-xs text-purple-600 dark:text-purple-400 hover:underline mt-1"
                  disabled={isProcessing}
                >
                  Gửi tối đa
                </button>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={() => setActiveView("main")}
                  variant="outline"
                  className="flex-1"
                  disabled={isProcessing}
                >
                  Hủy
                </Button>
                <Button
                  onClick={handleWithdrawPi}
                  disabled={isProcessing}
                  className="flex-1 bg-gradient-to-r from-orange-600 to-red-600"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Đang xử lý...
                    </>
                  ) : (
                    "Gửi Pi"
                  )}
                </Button>
              </div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl p-3">
              <div className="flex gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-800 dark:text-amber-200">
                  Bạn đang ở chế độ ví Pi Mainnet. Để gửi token EVM, vui lòng chuyển sang ví Olivia bằng nút chuyển ở
                  header.
                </p>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-8 px-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/30 dark:to-pink-900/30 rounded-xl border border-dashed border-purple-300 dark:border-purple-600">
            <AlertCircle className="w-12 h-12 text-purple-500 dark:text-purple-400 mx-auto mb-3" />
            <p className="text-base font-semibold text-purple-900 dark:text-purple-100 mb-2">Chưa import ví Pi</p>
            <p className="text-sm text-purple-600 dark:text-purple-400 mb-4">
              Bạn cần import ví Pi để thực hiện giao dịch Pi native
            </p>
            <Button
              onClick={() => {
                onOpenChange(false)
                toast({
                  title: "Import ví Pi",
                  description: "Vui lòng bấm nút Import ở header để thêm ví Pi",
                })
              }}
              className="bg-gradient-to-r from-purple-600 to-pink-600"
            >
              Đóng
            </Button>
          </div>
        )}
      </div>
    )
  }

  const renderHistoryView = () => {
    const transactions = JSON.parse(localStorage.getItem("olivia_pi_transactions") || "[]")

    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-purple-900 dark:text-white mb-2">Lịch sử giao dịch</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400">Danh sách giao dịch Pi</p>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {transactions.length > 0 ? (
            transactions.map((tx: any) => (
              <div
                key={tx.id}
                className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {tx.type === "withdraw" ? (
                      <div className="w-8 h-8 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                        <ArrowUp className="w-4 h-4 text-red-600 dark:text-red-400" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                        <ArrowDown className="w-4 h-4 text-green-600 dark:text-green-400" />
                      </div>
                    )}
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {tx.type === "withdraw" ? "Rút Pi" : "Nạp Pi"}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {new Date(tx.timestamp).toLocaleString("vi-VN")}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-bold ${
                        tx.type === "withdraw" ? "text-red-600 dark:text-red-400" : "text-green-600 dark:text-green-400"
                      }`}
                    >
                      {tx.type === "withdraw" ? "-" : "+"}
                      {tx.amount} Pi
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{tx.status}</p>
                  </div>
                </div>
                <div className="text-xs text-gray-600 dark:text-gray-400 font-mono">
                  {tx.type === "withdraw" ? "Đến: " : "Từ: "}
                  {(tx.to || tx.from || "").slice(0, 10)}...{(tx.to || tx.from || "").slice(-8)}
                </div>
                {tx.hash && (
                  <div className="text-xs text-purple-600 dark:text-purple-400 font-mono mt-1">
                    TX: {tx.hash.slice(0, 10)}...{tx.hash.slice(-8)}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <History className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500 dark:text-gray-400">Chưa có giao dịch nào</p>
            </div>
          )}
        </div>

        <Button onClick={() => setActiveView("main")} variant="outline" className="w-full">
          ← Quay lại
        </Button>
      </div>
    )
  }

  const handleSheetOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      // If trying to close the sheet while in a sub-view, navigate to main instead
      if (activeView !== "main") {
        setActiveView("main")
        // Don't call onOpenChange, keep the sheet open
        return
      }
    }
    // If on main view or opening the sheet, proceed with normal open/close behavior
    onOpenChange(newOpen)
  }

  return (
    <>
      <Sheet open={open} onOpenChange={handleSheetOpenChange}>
        <SheetContent
          side="bottom"
          className="h-[85vh] rounded-t-3xl p-0 border-t-2 border-purple-200 dark:border-purple-700"
          onOpenAutoFocus={(e) => {
            e.preventDefault()
          }}
        >
          <div className="h-full overflow-y-auto pb-6 px-6 pt-8">
            {activeView === "main" && renderMainView()}
            {activeView === "deposit" && renderDepositView()}
            {activeView === "withdraw" && renderWithdrawView()}
            {activeView === "history" && renderHistoryView()}
          </div>
        </SheetContent>
      </Sheet>

      <CrossBorderTransferDialog open={showCrossBorder} onOpenChange={setShowCrossBorder} />
    </>
  )
}

async function getPiBalance(address: string): Promise<string> {
  try {
    // Use the official Pi Network API endpoints for mainnet and testnet
    const horizonUrl = address.startsWith("G")
      ? "https://api.mainnet.minepi.com" // Mainnet API endpoint
      : "https://api.testnet.minepi.com" // Testnet API endpoint (if needed for development)

    const response = await fetch(`${horizonUrl}/accounts/${address}`)

    if (!response.ok) {
      // Handle API errors
      console.error(
        `[getPiBalance] Error fetching balance from ${horizonUrl}: ${response.status} ${response.statusText}`,
      )
      throw new Error(`Failed to fetch balance: ${response.statusText}`)
    }

    const data = await response.json()

    // Find the balance for the native asset (Pi)
    const piBalance = data.balances?.find((b: any) => b.asset_type === "native")?.balance || "0"
    return piBalance
  } catch (error) {
    console.error("[v0] Error fetching Pi balance from Horizon:", error)
    // Return "0" in case of any error during fetching
    return "0"
  }
}

function validatePiAddress(address: string): boolean {
  // Stellar addresses start with 'G' and are exactly 56 characters long.
  // This regex checks for that pattern.
  return /^G[A-Z2-7]{55}$/.test(address)
}
