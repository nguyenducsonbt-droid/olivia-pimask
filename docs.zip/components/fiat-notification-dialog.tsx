"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { Bell, Mail, MessageCircle } from "lucide-react"

interface FiatNotificationDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function FiatNotificationDialog({ open, onOpenChange }: FiatNotificationDialogProps) {
  const [method, setMethod] = useState<"email" | "pi">("email")
  const [email, setEmail] = useState("")
  const [piUsername, setPiUsername] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async () => {
    if (method === "email" && !email) {
      toast.error("Vui lòng nhập email")
      return
    }
    if (method === "pi" && !piUsername) {
      toast.error("Vui lòng nhập Pi username")
      return
    }

    setIsSubmitting(true)

    // Simulate API call to save notification preference
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Save to localStorage
    const notificationData = {
      method,
      contact: method === "email" ? email : piUsername,
      timestamp: Date.now(),
    }
    localStorage.setItem("fiat_notification_registered", JSON.stringify(notificationData))

    setIsSubmitting(false)
    toast.success("Đã đăng ký! Chúng tôi sẽ thông báo khi tính năng sẵn sàng")
    onOpenChange(false)

    // Reset form
    setEmail("")
    setPiUsername("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
        <DialogHeader>
          <DialogTitle className="text-purple-900 dark:text-purple-100 flex items-center gap-2">
            <Bell className="w-5 h-5 text-purple-600" />
            Nhận thông báo khi ra mắt
          </DialogTitle>
          <DialogDescription className="text-purple-700 dark:text-purple-300">
            Đăng ký để nhận thông báo khi tính năng Nạp/Rút VND/USD chính thức hoạt động
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Method Selection */}
          <div className="space-y-2">
            <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">
              Phương thức nhận thông báo
            </label>
            <div className="flex gap-2">
              <Button
                onClick={() => setMethod("email")}
                variant={method === "email" ? "default" : "outline"}
                className={
                  method === "email"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                <Mail className="w-4 h-4 mr-2" />
                Email
              </Button>
              <Button
                onClick={() => setMethod("pi")}
                variant={method === "pi" ? "default" : "outline"}
                className={
                  method === "pi"
                    ? "flex-1 bg-gradient-to-r from-[#9C27B0] to-[#7B1FA2] text-white"
                    : "flex-1 border-purple-300 text-purple-700"
                }
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Pi Chat
              </Button>
            </div>
          </div>

          {/* Email Input */}
          {method === "email" && (
            <div className="space-y-2">
              <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Email của bạn</label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-purple-300 focus:border-purple-500"
              />
            </div>
          )}

          {/* Pi Username Input */}
          {method === "pi" && (
            <div className="space-y-2">
              <label className="text-sm font-semibold text-purple-900 dark:text-purple-100">Pi Username</label>
              <Input
                type="text"
                placeholder="@yourpiusername"
                value={piUsername}
                onChange={(e) => setPiUsername(e.target.value)}
                className="border-purple-300 focus:border-purple-500"
              />
            </div>
          )}

          {/* Info Box */}
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 border border-blue-200 dark:border-blue-700">
            <p className="text-xs text-blue-800 dark:text-blue-200">
              Chúng tôi sẽ gửi thông báo ngay khi Pi Network mở full on/off-ramp và tính năng Nạp/Rút VND/USD sẵn sàng
              sử dụng.
            </p>
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-[#9C27B0] to-[#E1BEE7] hover:from-[#8E24AA] hover:to-[#6A1B9A] text-white font-semibold"
          >
            {isSubmitting ? "Đang đăng ký..." : "Đăng ký nhận thông báo"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
