"use client"

import { useState, useEffect } from "react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, CheckCircle2, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useWallet } from "@/hooks/use-wallet"
import { DEFAULT_NETWORKS } from "@/lib/wallet"

export function NetworkSwitcher() {
  const [isMainnet, setIsMainnet] = useState(true)
  const [isSwitching, setIsSwitching] = useState(false)
  const { toast } = useToast()
  const { setCurrentNetwork, syncPiBalance, refreshTokenBalances } = useWallet()

  useEffect(() => {
    // Load saved network preference, default to Mainnet
    const savedNetwork = localStorage.getItem("olivia_network")
    if (savedNetwork === "testnet") {
      setIsMainnet(false)
    } else {
      // Default to Mainnet since Pi Network has opened mainnet
      setIsMainnet(true)
      localStorage.setItem("olivia_network", "mainnet")
    }
  }, [])

  const handleNetworkSwitch = async (checked: boolean) => {
    if (isSwitching) return
    setIsSwitching(true)

    const newNetwork = checked ? "mainnet" : "testnet"
    setIsMainnet(checked)
    localStorage.setItem("olivia_network", newNetwork)

    const targetNetwork = DEFAULT_NETWORKS.find((n) => (checked ? n.id === "pi-mainnet" : n.id === "pi-testnet"))
    if (targetNetwork) {
      setCurrentNetwork(targetNetwork)
    }

    // Update Pi SDK initialization
    if (typeof window !== "undefined" && (window as any).Pi) {
      const Pi = (window as any).Pi
      try {
        // Re-initialize Pi SDK with new sandbox setting
        Pi.init({
          version: "2.0",
          sandbox: !checked, // false for mainnet, true for testnet
        })
      } catch (error) {
        console.error("[v0] Error reinitializing Pi SDK:", error)
      }
    }

    toast({
      title: checked ? "Đã chuyển sang Mainnet" : "Đã chuyển sang Testnet",
      description: checked ? "Mạng chính thức - Giao dịch Pi thật" : "Mạng thử nghiệm - Dành cho phát triển",
      className: checked
        ? "border-green-400/50 bg-green-500/10 text-green-900 dark:text-green-100"
        : "border-orange-400/50 bg-orange-500/10 text-orange-900 dark:text-orange-100",
      duration: 3000,
    })

    try {
      await Promise.all([
        syncPiBalance(), // Sync Pi balance for new network
        refreshTokenBalances(), // Refresh token balances
      ])
    } catch (error) {
      console.error("[v0] Error syncing data after network switch:", error)
    }

    setIsSwitching(false)
  }

  return (
    <Card className="border-purple-200 dark:border-purple-500 bg-white/80 dark:bg-[#33004D]/80 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2 text-purple-900 dark:text-purple-200">
          <Globe className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          Network
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Network Switch */}
        <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-700">
          <div className="flex items-center gap-3">
            <div
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                isMainnet
                  ? "bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"
                  : "bg-orange-500 shadow-[0_0_10px_rgba(251,146,60,0.5)]"
              }`}
            />
            <div>
              <Label className="text-purple-900 dark:text-purple-200 font-bold text-base cursor-pointer">
                {isMainnet ? "Mainnet" : "Testnet"}
              </Label>
              <p className="text-xs text-purple-600 dark:text-purple-400">
                {isMainnet ? "🟢 Mạng chính thức" : "🟠 Mạng thử nghiệm"}
              </p>
            </div>
          </div>
          <Switch
            checked={isMainnet}
            onCheckedChange={handleNetworkSwitch}
            disabled={isSwitching}
            className="data-[state=checked]:bg-green-500 data-[state=unchecked]:bg-orange-500"
          />
        </div>

        {/* Status Text */}
        <div
          className={`p-4 rounded-xl transition-colors duration-300 ${
            isMainnet
              ? "bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700"
              : "bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700"
          }`}
        >
          <div className="flex items-start gap-3">
            {isMainnet ? (
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-0.5" />
            )}
            <div>
              <p
                className={`text-sm font-medium ${
                  isMainnet ? "text-green-900 dark:text-green-200" : "text-orange-900 dark:text-orange-200"
                }`}
              >
                {isMainnet
                  ? "Đã chuyển sang Mainnet (Mạng mở) - Kết nối ví thật"
                  : "Đã chuyển sang Testnet - Dành cho phát triển và thử nghiệm"}
              </p>
              <p
                className={`text-xs mt-1 ${
                  isMainnet ? "text-green-700 dark:text-green-400" : "text-orange-700 dark:text-orange-400"
                }`}
              >
                {isMainnet
                  ? "Pi Network đã mở Mainnet chính thức. Giao dịch thật với Pi thật."
                  : "Sử dụng Pi testnet để thử nghiệm mà không ảnh hưởng đến Pi thật."}
              </p>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="text-xs text-purple-600 dark:text-purple-400 space-y-1">
          <p>• Mainnet: Sử dụng Pi thật từ ví chính thức</p>
          <p>• Testnet: Sử dụng Pi test cho phát triển</p>
          <p>• Chuyển mạng mượt mà, không cần khởi động lại</p>
        </div>
      </CardContent>
    </Card>
  )
}
