"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { getContacts, saveContact, deleteContact, type Contact } from "@/lib/address-book"
import { UserPlus, Trash2, Search, Users } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { triggerHaptic } from "@/lib/haptic"

interface AddressBookDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSelectContact?: (address: string) => void
}

export function AddressBookDialog({ open, onOpenChange, onSelectContact }: AddressBookDialogProps) {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [isAdding, setIsAdding] = useState(false)
  const [newName, setNewName] = useState("")
  const [newAddress, setNewAddress] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  useEffect(() => {
    if (open) {
      loadContacts()
    }
  }, [open])

  const loadContacts = () => {
    const data = getContacts()
    setContacts(data)
  }

  const handleAddContact = () => {
    if (!newName.trim() || !newAddress.trim()) {
      toast({
        title: "Lỗi",
        description: "Vui lòng điền đầy đủ tên và địa chỉ",
        variant: "destructive",
      })
      return
    }

    // Basic address validation
    if (newAddress.length < 10) {
      toast({
        title: "Địa chỉ không hợp lệ",
        description: "Địa chỉ ví phải có ít nhất 10 ký tự",
        variant: "destructive",
      })
      return
    }

    saveContact(newName, newAddress)
    triggerHaptic("medium")

    toast({
      title: "✓ Đã thêm liên hệ",
      description: `${newName} đã được lưu vào sổ địa chỉ`,
    })

    setNewName("")
    setNewAddress("")
    setIsAdding(false)
    loadContacts()
  }

  const handleDeleteContact = (id: string, name: string) => {
    deleteContact(id)
    triggerHaptic("light")

    toast({
      title: "Đã xóa liên hệ",
      description: `${name} đã được xóa khỏi sổ địa chỉ`,
    })

    loadContacts()
  }

  const handleSelectContact = (address: string) => {
    if (onSelectContact) {
      triggerHaptic("light")
      onSelectContact(address)
      onOpenChange(false)
    }
  }

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.address.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-purple-900">
            <Users className="w-5 h-5" />
            Sổ địa chỉ
          </DialogTitle>
          <DialogDescription className="text-purple-600">Quản lý danh bạ địa chỉ ví của bạn</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!isAdding && (
            <>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
                <Input
                  placeholder="Tìm kiếm liên hệ..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 border-purple-200 focus:border-purple-500"
                />
              </div>

              <Button onClick={() => setIsAdding(true)} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                <UserPlus className="w-4 h-4 mr-2" />
                Thêm liên hệ mới
              </Button>

              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {filteredContacts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">{searchQuery ? "Không tìm thấy liên hệ" : "Chưa có liên hệ nào"}</p>
                  </div>
                ) : (
                  filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-purple-200 bg-purple-50/50 hover:bg-purple-100/50 transition-colors"
                    >
                      <button onClick={() => handleSelectContact(contact.address)} className="flex-1 text-left">
                        <p className="font-medium text-purple-900">{contact.name}</p>
                        <p className="text-xs text-purple-600 truncate">
                          {contact.address.slice(0, 10)}...{contact.address.slice(-8)}
                        </p>
                      </button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteContact(contact.id, contact.name)}
                        className="ml-2 hover:bg-red-100 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </>
          )}

          {isAdding && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contact-name" className="text-purple-900">
                  Tên liên hệ
                </Label>
                <Input
                  id="contact-name"
                  placeholder="VD: Anh Tuấn, Chị Lan..."
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="border-purple-200 focus:border-purple-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact-address" className="text-purple-900">
                  Địa chỉ ví
                </Label>
                <Input
                  id="contact-address"
                  placeholder="0x..."
                  value={newAddress}
                  onChange={(e) => setNewAddress(e.target.value)}
                  className="border-purple-200 focus:border-purple-500"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAdding(false)
                    setNewName("")
                    setNewAddress("")
                  }}
                  className="flex-1 border-purple-300 text-purple-700 hover:bg-purple-50"
                >
                  Hủy
                </Button>
                <Button onClick={handleAddContact} className="flex-1 bg-purple-600 hover:bg-purple-700 text-white">
                  Lưu
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
