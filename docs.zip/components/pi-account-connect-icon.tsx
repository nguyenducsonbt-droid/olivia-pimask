"use client"

import { useState, useEffect } from "react"
import { loadPiSession, savePiSession } from "@/lib/persistent-storage"
import { useToast } from "@/hooks/use-toast"
import { playSound } from "@/lib/sounds"
import { triggerHaptic } from "@/lib/haptics"

/**
 * Pi Account Connect Icon Component
 * Displays a Pi Ecosystem icon that connects to the user's Pi account
 */
export function PiAccountConnectIcon() {
  const [isConnected, setIsConnected] = useState(false)
  const [connectedUser, setConnectedUser] = useState<{ username: string; uid: string } | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const loadSavedSession = async () => {
      const session = await loadPiSession()
      if (session && session.user) {
        setConnectedUser(session.user)
        setIsConnected(true)
      }
    }

    loadSavedSession()

    // Listen for session changes
    const handleSessionChange = (event: CustomEvent) => {
      if (event.detail?.user) {
        setConnectedUser(event.detail.user)
        setIsConnected(true)
      }
    }

    window.addEventListener("olivia-pi-session-changed", handleSessionChange as EventListener)

    return () => {
      window.removeEventListener("olivia-pi-session-changed", handleSessionChange as EventListener)
    }
  }, [])

  const handleConnect = async () => {
    if (isConnecting) return

    setIsConnecting(true)
    playSound("click")
    triggerHaptic("light")

    // Check if in Pi Browser
    const isPiBrowser =
      typeof window !== "undefined" &&
      // @ts-ignore
      (window.navigator.userAgent.includes("PiBrowser") || window.Pi !== undefined)

    if (!isPiBrowser) {
      toast({
        title: "Cần Pi Browser",
        description: "Mở Olivia trong Pi Browser để kết nối tài khoản Pi chính chủ",
        duration: 3000,
      })
      setIsConnecting(false)
      return
    }

    try {
      // @ts-ignore
      if (!window.Pi) {
        throw new Error("Pi SDK không khả dụng")
      }

      // @ts-ignore
      const authResult = await window.Pi.authenticate(["username", "payments", "wallet_address"], (payment: any) => {
        console.log("[v0] Incomplete payment:", payment)
      })

      console.log("[v0] Pi authentication successful:", authResult?.user?.username)

      // Save session
      await savePiSession(authResult)
      setConnectedUser(authResult.user)
      setIsConnected(true)

      // Fetch balance if available
      try {
        // @ts-ignore
        const balanceResult = await window.Pi.getBalance()
        const balance = typeof balanceResult === "number" ? balanceResult : (balanceResult?.balance ?? null)
        console.log("[v0] Pi balance fetched:", balance)
      } catch (balanceError) {
        console.warn("[v0] Could not fetch balance:", balanceError)
      }

      // Show success toast
      toast({
        title: "Kết nối thành công!",
        description: `Tài khoản Pi @${authResult.user.username} đã được kết nối`,
        duration: 3000,
      })

      // Dispatch event
      window.dispatchEvent(
        new CustomEvent("olivia-pi-session-changed", {
          detail: { user: authResult.user },
        }),
      )

      playSound("success")
      triggerHaptic("success")
    } catch (error) {
      console.error("[v0] Pi authentication error:", error)
      toast({
        title: "Kết nối thất bại",
        description: "Không thể kết nối với tài khoản Pi. Vui lòng thử lại.",
        variant: "destructive",
        duration: 3000,
      })
    } finally {
      setIsConnecting(false)
    }
  }

  return (
    <button
      onClick={handleConnect}
      disabled={isConnecting}
      className="w-full h-16 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white transition-all active:scale-95 rounded-3xl flex items-center justify-center gap-3 disabled:opacity-70 shadow-lg relative"
      title={isConnected ? `Đã kết nối với @${connectedUser?.username}` : "Kết nối tài khoản Pi"}
    >
      <svg
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-6 h-6"
      >
        <circle cx="12" cy="12" r="10" fill="white" opacity="0.9" />
        <path
          d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"
          fill="currentColor"
        />
      </svg>
      {isConnected && connectedUser && (
        <>
          <span className="text-sm font-medium">@{connectedUser.username}</span>
          <div className="absolute top-2 right-2 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
        </>
      )}
      {isConnecting && <span className="text-sm">Đang kết nối...</span>}
    </button>
  )
}
