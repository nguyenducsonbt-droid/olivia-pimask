"use client"

import { useState, useEffect, useRef } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Camera, X, Zap } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import jsQR from "jsqr"

interface QRScannerDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onScan: (address: string) => void
}

export function QRScannerDialog({ open, onOpenChange, onScan }: QRScannerDialogProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (open) {
      requestCameraPermission()
    } else {
      stopCamera()
    }

    return () => {
      stopCamera()
    }
  }, [open])

  const requestCameraPermission = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      setStream(mediaStream)
      setHasPermission(true)
      setIsScanning(true)

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        videoRef.current.play()
        startScanning()
      }
    } catch (error) {
      console.error("[v0] Camera permission denied:", error)
      setHasPermission(false)
      toast({
        title: "Không thể truy cập camera",
        description: "Vui lòng cấp quyền camera trong cài đặt trình duyệt",
        variant: "destructive",
      })
    }
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setIsScanning(false)
  }

  const startScanning = () => {
    const scan = () => {
      if (!isScanning || !videoRef.current || !canvasRef.current) return

      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (video.readyState === video.HAVE_ENOUGH_DATA && context) {
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
        const code = jsQR(imageData.data, imageData.width, imageData.height)

        if (code) {
          const qrData = code.data
          console.log("[v0] QR Code detected:", qrData)

          // Extract wallet address from QR code
          let address = qrData
          if (qrData.startsWith("pi://") || qrData.startsWith("ethereum:")) {
            address = qrData.split(":")[1]?.split("?")[0] || qrData
          }

          // Validate address format
          if (address.match(/^(0x)?[0-9a-fA-F]{40}$/)) {
            toast({
              title: "Quét thành công!",
              description: "Đã tìm thấy địa chỉ ví",
            })
            onScan(address)
            onOpenChange(false)
            stopCamera()
            return
          } else {
            toast({
              title: "Mã QR không hợp lệ",
              description: "Vui lòng quét mã QR chứa địa chỉ ví",
              variant: "destructive",
            })
          }
        }
      }

      requestAnimationFrame(scan)
    }

    scan()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" />
              <DialogTitle>Quét mã QR</DialogTitle>
            </div>
            <Button size="icon" variant="ghost" onClick={() => onOpenChange(false)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <DialogDescription>
            {hasPermission === false ? "Cần quyền truy cập camera để quét mã QR" : "Đưa mã QR vào khung hình để quét"}
          </DialogDescription>
        </DialogHeader>

        <div className="relative bg-black aspect-square">
          {hasPermission && (
            <>
              <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
              <canvas ref={canvasRef} className="hidden" />

              {/* Scanning overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-64 h-64 border-4 border-primary rounded-2xl">
                  <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-2xl" />
                  <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-2xl" />
                  <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-2xl" />
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-2xl" />

                  {/* Scanning line animation */}
                  <div className="absolute inset-0 overflow-hidden rounded-2xl">
                    <div className="w-full h-1 bg-primary shadow-[0_0_20px_rgba(147,51,234,0.8)] animate-scan" />
                  </div>
                </div>
              </div>

              <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                <div className="bg-background/80 backdrop-blur-sm px-4 py-2 rounded-full flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary animate-pulse" />
                  <span className="text-sm font-medium">Đang quét...</span>
                </div>
              </div>
            </>
          )}

          {hasPermission === false && (
            <div className="absolute inset-0 flex items-center justify-center p-6">
              <div className="text-center">
                <Camera className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">Cần quyền truy cập camera để quét mã QR</p>
                <Button onClick={requestCameraPermission}>Cho phép truy cập camera</Button>
              </div>
            </div>
          )}
        </div>

        <style jsx global>{`
          @keyframes scan {
            0% { transform: translateY(0); }
            100% { transform: translateY(256px); }
          }
          .animate-scan {
            animation: scan 2s linear infinite;
          }
        `}</style>
      </DialogContent>
    </Dialog>
  )
}
