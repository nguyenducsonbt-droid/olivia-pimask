"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Shield, Copy, CheckCircle, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  generateTwoFactorSecret,
  generateBackupCodes,
  saveTwoFactorData,
  getTwoFactorQRCodeURL,
  verifyTOTP,
} from "@/lib/two-factor"
import { useWallet } from "@/hooks/use-wallet"

interface TwoFactorSetupDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSetupComplete: () => void
}

export function TwoFactorSetupDialog({ open, onOpenChange, onSetupComplete }: TwoFactorSetupDialogProps) {
  const [step, setStep] = useState<"intro" | "qr" | "verify" | "backup">("intro")
  const [secret, setSecret] = useState("")
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [verifyCode, setVerifyCode] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const { address } = useWallet()
  const { toast } = useToast()

  const handleStart = () => {
    const newSecret = generateTwoFactorSecret()
    const newBackupCodes = generateBackupCodes()
    setSecret(newSecret)
    setBackupCodes(newBackupCodes)
    setStep("qr")
  }

  const handleCopySecret = () => {
    navigator.clipboard.writeText(secret)
    toast({
      title: "Đã sao chép",
      description: "Đã sao chép mã bí mật vào clipboard",
    })
  }

  const handleVerify = async () => {
    if (verifyCode.length !== 6) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ 6 số",
        variant: "destructive",
      })
      return
    }

    setIsVerifying(true)

    try {
      const isValid = await verifyTOTP(verifyCode, secret)

      if (isValid) {
        saveTwoFactorData(secret, true, backupCodes)
        setStep("backup")
        toast({
          title: "Xác minh thành công",
          description: "2FA đã được kích hoạt",
        })
      } else {
        toast({
          title: "Mã không đúng",
          description: "Vui lòng kiểm tra lại mã từ Authenticator",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Lỗi xác minh",
        description: "Không thể xác minh mã. Vui lòng thử lại.",
        variant: "destructive",
      })
    } finally {
      setIsVerifying(false)
    }
  }

  const handleComplete = () => {
    onSetupComplete()
    onOpenChange(false)
    // Reset state
    setStep("intro")
    setSecret("")
    setBackupCodes([])
    setVerifyCode("")
  }

  const handleCopyBackupCodes = () => {
    navigator.clipboard.writeText(backupCodes.join("\n"))
    toast({
      title: "Đã sao chép",
      description: "Đã sao chép mã dự phòng vào clipboard",
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-purple-900">
            <Shield className="w-5 h-5 text-purple-600" />
            Thiết lập 2FA
          </DialogTitle>
          <DialogDescription>Bảo vệ giao dịch lớn với Google Authenticator</DialogDescription>
        </DialogHeader>

        {step === "intro" && (
          <div className="space-y-4">
            <Card className="bg-purple-50 border-purple-200 p-4">
              <h3 className="font-semibold text-purple-900 mb-2">2FA sẽ bảo vệ:</h3>
              <ul className="text-sm text-purple-800 space-y-1">
                <li>• Giao dịch gửi/swap &gt; 50 Pi</li>
                <li>• Xuất seed phrase</li>
                <li>• Xuất private key</li>
              </ul>
            </Card>

            <Card className="bg-blue-50 border-blue-200 p-4">
              <h3 className="font-semibold text-blue-900 mb-2">Bạn cần:</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• App Google Authenticator (iOS/Android)</li>
                <li>• Hoặc bất kỳ TOTP app nào khác</li>
              </ul>
            </Card>

            <div className="flex flex-col gap-2">
              <Button
                onClick={handleStart}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
              >
                Bắt đầu thiết lập
              </Button>
              <Button onClick={() => onOpenChange(false)} variant="outline" className="w-full">
                Hủy
              </Button>
            </div>
          </div>
        )}

        {step === "qr" && (
          <div className="space-y-4">
            <Card className="bg-white p-4 flex flex-col items-center">
              <p className="text-sm text-gray-600 mb-3 text-center">Quét mã QR này bằng Google Authenticator</p>
              <img src={getTwoFactorQRCodeURL(secret, address || "user")} alt="QR Code" className="w-64 h-64 mb-3" />
              <div className="w-full">
                <p className="text-xs text-gray-500 mb-1 text-center">Hoặc nhập thủ công:</p>
                <div className="flex items-center gap-2">
                  <Input value={secret} readOnly className="font-mono text-sm" />
                  <Button onClick={handleCopySecret} size="icon" variant="outline">
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>

            <Card className="bg-amber-50 border-amber-200 p-3">
              <div className="flex gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-amber-800">
                  Lưu mã bí mật ở nơi an toàn. Nếu mất điện thoại, bạn cần mã này để khôi phục 2FA.
                </p>
              </div>
            </Card>

            <Button
              onClick={() => setStep("verify")}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
            >
              Tiếp tục
            </Button>
          </div>
        )}

        {step === "verify" && (
          <div className="space-y-4">
            <Card className="bg-purple-50 border-purple-200 p-4">
              <p className="text-sm text-purple-900 font-medium text-center">
                Nhập mã 6 số từ Google Authenticator để xác nhận
              </p>
            </Card>

            <div className="space-y-3">
              <Input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={verifyCode}
                onChange={(e) => setVerifyCode(e.target.value.replace(/\D/g, ""))}
                placeholder="000000"
                className="text-center text-2xl tracking-widest font-mono"
                autoFocus
              />

              <div className="text-center">
                <p className="text-xs text-gray-500">Mã mới mỗi 30 giây</p>
              </div>

              <Button
                onClick={handleVerify}
                disabled={verifyCode.length !== 6 || isVerifying}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
              >
                {isVerifying ? "Đang xác minh..." : "Xác nhận"}
              </Button>

              <Button onClick={() => setStep("qr")} variant="outline" className="w-full">
                Quay lại
              </Button>
            </div>
          </div>
        )}

        {step === "backup" && (
          <div className="space-y-4">
            <Card className="bg-green-50 border-green-200 p-4">
              <div className="flex items-center gap-2 justify-center text-green-700">
                <CheckCircle className="w-5 h-5" />
                <p className="font-semibold">2FA đã được kích hoạt!</p>
              </div>
            </Card>

            <Card className="bg-red-50 border-red-200 p-4">
              <div className="flex gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-red-800">
                  <p className="font-semibold mb-1">Mã dự phòng quan trọng:</p>
                  <p className="text-xs">
                    Lưu các mã này ở nơi an toàn. Mỗi mã chỉ dùng được 1 lần khi bạn mất thiết bị Authenticator.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-white p-4">
              <div className="grid grid-cols-2 gap-2 mb-3">
                {backupCodes.map((code, index) => (
                  <div key={index} className="font-mono text-sm text-center p-2 bg-gray-100 rounded">
                    {code}
                  </div>
                ))}
              </div>
              <Button onClick={handleCopyBackupCodes} variant="outline" className="w-full bg-transparent" size="sm">
                <Copy className="w-4 h-4 mr-2" />
                Sao chép tất cả
              </Button>
            </Card>

            <Button
              onClick={handleComplete}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-500 hover:from-purple-700 hover:to-pink-600"
            >
              Hoàn tất
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
