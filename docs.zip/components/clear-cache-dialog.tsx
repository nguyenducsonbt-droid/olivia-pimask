"use client"

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useLanguage } from "@/hooks/use-language"
import { useToast } from "@/hooks/use-toast"

interface ClearCacheDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ClearCacheDialog({ open, onOpenChange }: ClearCacheDialogProps) {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [isClearing, setIsClearing] = useState(false)

  const handleClearCache = () => {
    setIsClearing(true)

    const walletData = localStorage.getItem("olivia_wallet")
    const seedPhrase = localStorage.getItem("olivia_seed_encrypted")
    const pinHash = localStorage.getItem("olivia_pin_hash")
    const language = localStorage.getItem("language")
    const biometricEnabled = localStorage.getItem("olivia_biometric_enabled")
    const walletName = localStorage.getItem("@Olivia_walletName")
    const avatar = localStorage.getItem("@Olivia_avatar")

    // Clear all localStorage
    localStorage.clear()

    // Restore critical data
    if (walletData) localStorage.setItem("olivia_wallet", walletData)
    if (seedPhrase) localStorage.setItem("olivia_seed_encrypted", seedPhrase)
    if (pinHash) localStorage.setItem("olivia_pin_hash", pinHash)
    if (language) localStorage.setItem("language", language)
    if (biometricEnabled) localStorage.setItem("olivia_biometric_enabled", biometricEnabled)
    if (walletName) localStorage.setItem("@Olivia_walletName", walletName)
    if (avatar) localStorage.setItem("@Olivia_avatar", avatar)

    // Show success toast
    toast({
      title: t.settings.clearCacheSuccess,
      description: t.settings.clearCacheSuccessDesc,
    })

    // Reload after short delay
    setTimeout(() => {
      window.location.reload()
    }, 1500)
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{t.settings.clearCacheConfirmTitle}</AlertDialogTitle>
          <AlertDialogDescription>{t.settings.clearCacheConfirmDesc}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isClearing}>{t.common.cancel}</AlertDialogCancel>
          <AlertDialogAction onClick={handleClearCache} disabled={isClearing}>
            {isClearing ? t.common.loading || "Loading..." : t.common.confirm || "Confirm"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
