"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Lock, Eye, EyeOff } from "lucide-react"
import { savePinHash, getPinHash, getWalletData } from "@/lib/storage"

interface PinManagementDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  hasExistingPin: boolean
  onPinChanged: () => void
}

// Hash function for PIN (simple SHA-256 equivalent using Web Crypto API)
async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(pin)
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

export function PinManagementDialog({ open, onOpenChange, hasExistingPin, onPinChanged }: PinManagementDialogProps) {
  const [currentPin, setCurrentPin] = useState("")
  const [newPin, setNewPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const [showCurrentPin, setShowCurrentPin] = useState(false)
  const [showNewPin, setShowNewPin] = useState(false)
  const [showConfirmPin, setShowConfirmPin] = useState(false)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const resetForm = () => {
    setCurrentPin("")
    setNewPin("")
    setConfirmPin("")
    setShowCurrentPin(false)
    setShowNewPin(false)
    setShowConfirmPin(false)
  }

  const handleClose = () => {
    resetForm()
    onOpenChange(false)
  }

  const handleSubmit = async () => {
    // Validate PIN format (6 digits)
    const pinRegex = /^\d{6}$/

    if (hasExistingPin && !currentPin) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập mã PIN hiện tại",
        variant: "destructive",
      })
      return
    }

    if (!newPin || !confirmPin) {
      toast({
        title: "Lỗi",
        description: "Vui lòng nhập đầy đủ thông tin",
        variant: "destructive",
      })
      return
    }

    if (!pinRegex.test(newPin)) {
      toast({
        title: "Lỗi",
        description: "Mã PIN phải là 6 chữ số",
        variant: "destructive",
      })
      return
    }

    if (newPin !== confirmPin) {
      toast({
        title: "Lỗi",
        description: "Mã PIN xác nhận không khớp",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      if (hasExistingPin) {
        const existingPinData = await getPinHash()
        if (!existingPinData) {
          throw new Error("Không tìm thấy mã PIN hiện tại trong hệ thống")
        }

        const currentPinHash = await hashPin(currentPin)

        console.log("[v0] ====================================")
        console.log("[v0] VERIFYING CURRENT PIN BEFORE CHANGE")
        console.log("[v0] Current PIN entered hash:", currentPinHash.substring(0, 10) + "...")
        console.log("[v0] Stored PIN hash:", existingPinData.pinHash.substring(0, 10) + "...")
        console.log("[v0] PIN version:", existingPinData.version)
        console.log("[v0] Match:", currentPinHash === existingPinData.pinHash)
        console.log("[v0] ====================================")

        if (currentPinHash !== existingPinData.pinHash) {
          console.error("[v0] ✗ Current PIN verification FAILED")
          toast({
            title: "Lỗi",
            description: "Mã PIN hiện tại KHÔNG ĐÚNG. Vui lòng nhập lại.",
            variant: "destructive",
            duration: 5000,
          })
          setLoading(false)
          return
        }

        console.log("[v0] ✓ Current PIN verified - proceeding with PIN change")
      }

      // Get wallet data
      const walletData = getWalletData()
      if (!walletData) {
        throw new Error("Không tìm thấy dữ liệu ví")
      }

      const newPinHash = await hashPin(newPin)

      console.log("[v0] ====================================")
      console.log("[v0] CHANGING PIN - CRITICAL SECURITY OPERATION")
      console.log("[v0] Old PIN existed:", !!hasExistingPin)
      console.log("[v0] New PIN hash:", newPinHash.substring(0, 10) + "...")
      console.log("[v0] Wallet address:", walletData.address.substring(0, 10) + "...")
      console.log("[v0] ====================================")

      await savePinHash(newPinHash, walletData.address, walletData.encryptedMnemonic)

      console.log("[v0] VERIFYING NEW PIN - Reading back from storage...")

      await new Promise((resolve) => setTimeout(resolve, 200))

      const verifyPin = await getPinHash()
      if (!verifyPin) {
        console.error("[v0] ✗✗✗ CRITICAL: PIN not found after save!")
        throw new Error("PIN không được lưu thành công - vui lòng thử lại")
      }

      if (verifyPin.pinHash !== newPinHash) {
        console.error("[v0] ✗✗✗ CRITICAL: PIN hash mismatch after save!")
        console.error("[v0] Expected:", newPinHash.substring(0, 10) + "...")
        console.error("[v0] Got:", verifyPin.pinHash.substring(0, 10) + "...")
        throw new Error("PIN hash không khớp - vui lòng thử lại")
      }

      console.log("[v0] ====================================")
      console.log("[v0] ✓✓✓ PIN CHANGE COMPLETED SUCCESSFULLY")
      console.log("[v0] ✓ New PIN hash:", verifyPin.pinHash.substring(0, 10) + "...")
      console.log("[v0] ✓ PIN version:", verifyPin.version)
      console.log("[v0] ✓ PIN nonce:", verifyPin.nonce)
      console.log("[v0] ✓ ONLY NEW PIN WILL WORK NOW")
      console.log("[v0] ✓ OLD PIN IS COMPLETELY INVALID")
      console.log("[v0] ✓ Saved at:", new Date().toLocaleString())
      console.log("[v0] ====================================")

      toast({
        title: "✓ Thành công",
        description: hasExistingPin
          ? "Đã đổi PIN thành công! CHỈ PIN MỚI mở được ví. PIN cũ đã vô hiệu hóa hoàn toàn."
          : "Đã thiết lập PIN thành công! Chỉ PIN này mới mở được ví.",
        duration: 6000,
      })

      resetForm()
      await new Promise((resolve) => setTimeout(resolve, 1500))

      onPinChanged()
      onOpenChange(false)
    } catch (error) {
      console.error("[v0] ✗✗✗ PIN management error:", error)
      toast({
        title: "Lỗi nghiêm trọng",
        description:
          error instanceof Error ? error.message : "Không thể thay đổi PIN. Vui lòng thử lại hoặc liên hệ hỗ trợ.",
        variant: "destructive",
        duration: 8000,
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-black">
            <Lock className="w-5 h-5 text-purple-600" />
            {hasExistingPin ? "Đổi mã PIN" : "Thiết lập mã PIN"}
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            {hasExistingPin ? "Nhập mã PIN hiện tại và mã PIN mới (6 chữ số)" : "Tạo mã PIN 6 chữ số làm khóa dự phòng"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {hasExistingPin && (
            <div className="space-y-2">
              <Label htmlFor="current-pin" className="text-black">
                Mã PIN hiện tại
              </Label>
              <div className="relative">
                <Input
                  id="current-pin"
                  type={showCurrentPin ? "text" : "password"}
                  placeholder="Nhập 6 chữ số"
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  maxLength={6}
                  className="pr-10 bg-white border-gray-200 text-black"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPin(!showCurrentPin)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                >
                  {showCurrentPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="new-pin" className="text-black">
              {hasExistingPin ? "Mã PIN mới" : "Mã PIN"}
            </Label>
            <div className="relative">
              <Input
                id="new-pin"
                type={showNewPin ? "text" : "password"}
                placeholder="Nhập 6 chữ số"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="pr-10 bg-white border-gray-200 text-black"
              />
              <button
                type="button"
                onClick={() => setShowNewPin(!showNewPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showNewPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-pin" className="text-black">
              Xác nhận mã PIN
            </Label>
            <div className="relative">
              <Input
                id="confirm-pin"
                type={showConfirmPin ? "text" : "password"}
                placeholder="Nhập lại 6 chữ số"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                className="pr-10 bg-white border-gray-200 text-black"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPin(!showConfirmPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showConfirmPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm text-purple-900">
            <p className="font-medium">Lưu ý:</p>
            <ul className="list-disc list-inside text-xs mt-1 space-y-1">
              <li>Mã PIN gồm 6 chữ số</li>
              <li>Dùng làm khóa dự phòng khi Face ID lỗi</li>
              <li>Không chia sẻ mã PIN với bất kỳ ai</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={loading} className="border-gray-200 bg-transparent">
            Hủy
          </Button>
          <Button onClick={handleSubmit} disabled={loading} className="bg-purple-600 hover:bg-purple-700 text-white">
            {loading ? "Đang xử lý..." : hasExistingPin ? "Đổi PIN" : "Thiết lập"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
