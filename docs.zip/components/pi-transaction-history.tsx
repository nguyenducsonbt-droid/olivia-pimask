"use client"

import { useState, useEffect, memo, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  Clock,
  XCircle,
  Loader2,
  Zap,
  TrendingUp,
} from "lucide-react"
import { piAppConnector } from "@/lib/pi-app-connector"
import { playSound } from "@/lib/sounds"

const DAppCard = memo(({ dapp }: { dapp: any }) => (
  <div className="flex items-center justify-between p-2 bg-purple-50 rounded-lg">
    <div className="flex-1">
      <p className="text-sm font-medium text-purple-900">{dapp.dappName}</p>
      <p className="text-xs text-purple-600 truncate">{dapp.dappUrl}</p>
    </div>
    <Badge variant="outline" className="text-green-600 border-green-600">
      Connected
    </Badge>
  </div>
))

DAppCard.displayName = "DAppCard"

const PiTransactionCard = memo(
  ({
    tx,
    formatDate,
    formatAddress,
    onOpenExplorer,
  }: {
    tx: any
    formatDate: (timestamp: number) => string
    formatAddress: (addr: string) => string
    onOpenExplorer: (hash: string) => void
  }) => {
    const getStatusIcon = (status: string) => {
      switch (status) {
        case "confirmed":
          return <CheckCircle2 className="w-4 h-4 text-green-600" />
        case "pending":
          return <Loader2 className="w-4 h-4 text-yellow-600 animate-spin" />
        case "failed":
          return <XCircle className="w-4 h-4 text-red-600" />
        default:
          return <Clock className="w-4 h-4 text-gray-600" />
      }
    }

    return (
      <div className="flex items-center gap-3 p-3 rounded-lg bg-purple-50 hover:bg-purple-100 transition-colors">
        <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br from-purple-100 to-pink-100 border border-purple-200">
          {tx.type === "send" ? (
            <ArrowUpRight className="w-5 h-5 text-pink-600" />
          ) : tx.type === "stake" ? (
            <TrendingUp className="w-5 h-5 text-purple-600" />
          ) : (
            <ArrowDownLeft className="w-5 h-5 text-purple-600" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-medium text-sm text-purple-900">
              {tx.type === "payment"
                ? "Pi Payment"
                : tx.type === "stake"
                  ? "Stake"
                  : tx.type === "send"
                    ? "Send"
                    : "Receive"}
            </p>
            {getStatusIcon(tx.status)}
          </div>
          {tx.dappName && <p className="text-xs text-purple-600">via {tx.dappName}</p>}
          <p className="text-xs text-purple-500">{formatAddress(tx.hash)}</p>
        </div>
        <div className="text-right">
          <p className="font-semibold text-sm text-purple-900">{tx.value} π</p>
          <p className="text-xs text-purple-500">{formatDate(tx.timestamp)}</p>
          <Button variant="ghost" size="sm" className="h-6 px-2 text-xs mt-1" onClick={() => onOpenExplorer(tx.hash)}>
            <ExternalLink className="w-3 h-3" />
          </Button>
        </div>
      </div>
    )
  },
)

PiTransactionCard.displayName = "PiTransactionCard"

export function PiTransactionHistory() {
  const [transactions, setTransactions] = useState<any[]>([])
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [connectedDApps, setConnectedDApps] = useState<any[]>([])

  useEffect(() => {
    loadTransactions()
    loadConnectedDApps()

    const handleNewTx = (event: any) => {
      const tx = event.detail
      if (tx && (tx.type === "receive" || tx.type === "payment")) {
        playSound("receive")
      }
      loadTransactions()
    }

    const handleDAppConnected = () => {
      loadConnectedDApps()
    }

    window.addEventListener("olivia-pi-transaction", handleNewTx)
    window.addEventListener("olivia-pi-transaction-updated", handleNewTx)
    window.addEventListener("olivia-dapp-connected", handleDAppConnected)
    window.addEventListener("olivia-dapp-disconnected", handleDAppConnected)

    return () => {
      window.removeEventListener("olivia-pi-transaction", handleNewTx)
      window.removeEventListener("olivia-pi-transaction-updated", handleNewTx)
      window.removeEventListener("olivia-dapp-connected", handleDAppConnected)
      window.removeEventListener("olivia-dapp-disconnected", handleDAppConnected)
    }
  }, [])

  const loadTransactions = () => {
    const txs = piAppConnector.getPiTransactions()
    setTransactions(txs)
  }

  const loadConnectedDApps = () => {
    const dapps = piAppConnector.getConnectedDApps()
    setConnectedDApps(dapps)
  }

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    loadTransactions()
    loadConnectedDApps()
    setIsRefreshing(false)
  }, [])

  const formatDate = useCallback((timestamp: number) => {
    const date = new Date(timestamp)
    return date.toLocaleDateString("vi-VN", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }, [])

  const formatAddress = useCallback((addr: string) => {
    if (addr.length < 10) return addr
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }, [])

  const openInExplorer = useCallback((hash: string) => {
    window.open(`https://blockexplorer.minepi.com/tx/${hash}`, "_blank")
  }, [])

  return (
    <div className="space-y-4">
      {connectedDApps.length > 0 && (
        <Card className="border-purple-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-purple-900 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              DApps Đã Kết Nối ({connectedDApps.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {connectedDApps.map((dapp) => (
                <DAppCard key={dapp.dappUrl} dapp={dapp} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-purple-200">
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-sm text-purple-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Giao Dịch Pi Network
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8 text-purple-600">
              <TrendingUp className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Chưa có giao dịch Pi</p>
              <p className="text-xs mt-1">Giao dịch từ Pi dApps sẽ hiện ở đây</p>
            </div>
          ) : (
            <div className="space-y-2">
              {transactions.map((tx) => (
                <PiTransactionCard
                  key={tx.hash}
                  tx={tx}
                  formatDate={formatDate}
                  formatAddress={formatAddress}
                  onOpenExplorer={openInExplorer}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
