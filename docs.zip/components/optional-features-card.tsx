"use client"

import { useState } from "react"
import { Sparkles, Palette, Database, Bell, Crown } from "lucide-react"
import { PiPaymentModal } from "./pi-payment-modal"
import { playSound } from "@/lib/sounds"
import { triggerHaptic } from "@/lib/haptics"

export function OptionalFeaturesCard() {
  const [selectedFeature, setSelectedFeature] = useState<{
    feature: string
    featureId: string
    description: string
    amount: number
    benefits: string[]
  } | null>(null)

  const optionalFeatures = [
    {
      icon: Palette,
      feature: "Bộ lọc AI Custom",
      featureId: "custom_ai_filters",
      description: "Tạo bộ lọc AI Olivia riêng theo phong cách của bạn",
      amount: 0.3,
      benefits: [
        "Tạo không giới hạn bộ lọc AI tùy chỉnh",
        "Lưu trữ và quản lý bộ lọc của bạn",
        "Chia sẻ bộ lọc với cộng đồng",
        "Truy cập thư viện bộ lọc premium",
      ],
      color: "from-purple-600 to-pink-600",
    },
    {
      icon: Database,
      feature: "Lưu trữ Extra",
      featureId: "extra_storage",
      description: "Tăng gấp 10 lần dung lượng lưu trữ giao dịch và backup",
      amount: 0.2,
      benefits: [
        "Lưu trữ 10,000+ giao dịch (từ 1,000)",
        "Backup tự động mỗi ngày",
        "Lịch sử giao dịch không giới hạn thời gian",
        "Export dữ liệu định dạng CSV/JSON",
      ],
      color: "from-blue-600 to-cyan-600",
    },
    {
      icon: Crown,
      feature: "Theme Cá Nhân Hóa",
      featureId: "custom_themes",
      description: "Thiết kế giao diện Olivia theo phong cách riêng của bạn",
      amount: 0.25,
      benefits: [
        "Tạo theme riêng với màu sắc tùy chỉnh",
        "10+ theme premium có sẵn",
        "Tùy chỉnh font chữ và hiệu ứng",
        "Preview theme trước khi áp dụng",
      ],
      color: "from-pink-600 to-rose-600",
    },
    {
      icon: Bell,
      feature: "Thông báo Nâng cao",
      featureId: "advanced_notifications",
      description: "Nhận thông báo realtime cho mọi hoạt động quan trọng",
      amount: 0.15,
      benefits: [
        "Thông báo giao dịch realtime",
        "Cảnh báo giá Pi tùy chỉnh",
        "Nhắc nhở staking và rewards",
        "Báo cáo hàng tuần qua email",
      ],
      color: "from-green-600 to-emerald-600",
    },
  ]

  const handleFeatureClick = (feature: (typeof optionalFeatures)[0]) => {
    playSound("click")
    triggerHaptic("light")
    setSelectedFeature(feature)
  }

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">Tính năng nâng cao (Tùy chọn)</h3>
        </div>

        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          Tất cả tính năng cơ bản hoàn toàn miễn phí. Nâng cấp với Pi để mở khóa thêm tiện ích.
        </p>

        <div className="grid grid-cols-1 gap-3">
          {optionalFeatures.map((feature, index) => {
            const Icon = feature.icon
            return (
              <button
                key={index}
                onClick={() => handleFeatureClick(feature)}
                className="w-full p-4 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600 transition-all group text-left"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-lg bg-gradient-to-br ${feature.color} group-hover:scale-110 transition-transform`}
                  >
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                      {feature.feature}
                    </h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{feature.description}</p>
                  </div>
                  <div className="flex items-center gap-1 bg-purple-100 dark:bg-purple-900/30 px-3 py-1 rounded-full">
                    <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
                      <path
                        d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
                        fill="white"
                      />
                      <path d="M11 8h2v8h-2V8z" fill="white" />
                      <path d="M8 11h8v2H8v-2z" fill="white" />
                    </svg>
                    <span className="text-sm font-bold text-purple-700 dark:text-purple-300">{feature.amount}</span>
                  </div>
                </div>
              </button>
            )
          })}
        </div>

        {/* Info footer */}
        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl">
          <div className="flex items-start gap-3">
            <svg viewBox="0 0 24 24" className="w-5 h-5 mt-0.5" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="12" cy="12" r="10" fill="#7B3FF2" />
              <path
                d="M12 4C7.58 4 4 7.58 4 12s3.58 8 8 8 8-3.58 8-8-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"
                fill="white"
              />
              <path d="M11 8h2v8h-2V8z" fill="white" />
              <path d="M8 11h8v2H8v-2z" fill="white" />
            </svg>
            <div>
              <p className="text-sm font-semibold text-purple-700 dark:text-purple-300 mb-1">
                Thanh toán an toàn với Pi Network
              </p>
              <p className="text-xs text-gray-600 dark:text-gray-400">
                Tất cả thanh toán được xử lý trực tiếp qua Pi Network Mainnet. Test miễn phí trên Testnet trước khi mua.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {selectedFeature && (
        <PiPaymentModal
          open={!!selectedFeature}
          onClose={() => setSelectedFeature(null)}
          feature={selectedFeature.feature}
          featureId={selectedFeature.featureId}
          description={selectedFeature.description}
          amount={selectedFeature.amount}
          benefits={selectedFeature.benefits}
        />
      )}
    </>
  )
}
