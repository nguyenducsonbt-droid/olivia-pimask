export interface CrossBorderTransfer {
  id: string
  from: string
  to: string
  amount: string
  currency: "PI" | "USD" | "VND"
  recipientCountry: string
  recipientAddress: string
  recipientType: "wallet" | "bank" | "phone"
  exchangeRate: number
  fees: {
    network: string
    service: string
    total: string
  }
  status: "pending" | "processing" | "completed" | "failed"
  timestamp: number
  txHash?: string
  estimatedArrival?: number
}

export interface Country {
  code: string
  name: string
  flag: string
  currency: string
  supported: boolean
  paymentMethods: string[]
  piEnabled: boolean
}

export interface ExchangeRate {
  from: string
  to: string
  rate: number
  lastUpdated: number
  provider: string
}
