# Hướng Dẫn Setup App Wallet - Olivia PiMask

## Lỗi: "The developer has not set up the app wallet"

Error này xảy ra khi bạn gọi `Pi.createPayment()` nhưng app chưa được setup app wallet trong Pi Developer Portal.

## Tại sao cần App Wallet?

App Wallet là ví Pi dành riêng cho app của bạn, dùng để:
- Nhận thanh toán từ users (User-to-App payments)
- Quản lý revenue từ app
- Tự động xử lý payment callbacks
- Security và compliance với Pi Network

## Setup App Wallet - Chi Tiết

### Bước 1: Truy cập Pi Developer Portal

1. Mở Pi Browser hoặc trình duyệt thường
2. Truy cập: **https://develop.pi** hoặc **https://developers.minepi.com**
3. Đăng nhập bằng tài khoản Pi đã KYC (required)

### Bước 2: Chọn App của bạn

1. Trong dashboard, tìm app **"Olivia PiMask"**
2. Click vào app để mở chi tiết
3. Bạn sẽ thấy các tabs: Overview, App Config, **App Wallet**, etc.

### Bước 3: Enable App Wallet

1. Click vào tab **"App Wallet"** ở menu bên trái
2. Nếu chưa có wallet, sẽ thấy button **"Enable App Wallet"** hoặc **"Set Up Wallet"**
3. Click button đó để bắt đầu setup

### Bước 4: Generate Wallet Address

Pi Platform sẽ generate một wallet address riêng cho app:

\`\`\`
App Wallet Address: GDX7...ABC (ví dụ)
\`\`\`

**QUAN TRỌNG:**
- Lưu private key/seed phrase vào backend server an toàn
- KHÔNG BAO GIỜ lưu private key trong client code
- KHÔNG share private key với ai
- Backup private key vào nơi an toàn (vault, encrypted storage)

### Bước 5: Config Payment Settings

Trong App Wallet settings:

1. **Payment Method**: Chọn "User-to-App" (default)
2. **Auto Approval**: Enable nếu muốn tự động approve payments < 5 Pi
3. **Webhook URL**: Add backend endpoint để receive payment notifications
   - Ví dụ: `https://yourbackend.com/api/pi/webhook`
   - Verify webhook signature để security

4. **Completion Logic**: Config server-side logic
   - onReadyForServerApproval: Verify payment trước khi approve
   - onReadyForServerCompletion: Unlock feature sau khi completed

### Bước 6: Activate Wallet

1. Review tất cả settings
2. Click **"Activate"** để kích hoạt app wallet
3. Status sẽ chuyển thành **"Active"** hoặc **"Live"**

### Bước 7: Backend Implementation (Required)

Setup backend để handle payment callbacks:

\`\`\`javascript
// Example Express.js backend
app.post('/api/pi/webhook', async (req, res) => {
  const { payment } = req.body
  
  // Verify payment signature
  const isValid = verifyPiSignature(req.headers, req.body)
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid signature' })
  }
  
  // Approve payment
  if (payment.status === 'waiting_for_approval') {
    await approvePiPayment(payment.identifier)
    // Unlock premium feature for user
    await unlockFeature(payment.metadata.userId, payment.metadata.featureId)
  }
  
  // Complete payment
  if (payment.status === 'waiting_for_completion') {
    await completePiPayment(payment.identifier, payment.txid)
  }
  
  res.json({ success: true })
})
\`\`\`

### Bước 8: Test Payment

1. Mở app trong Pi Browser Testnet
2. Click "Mua ngay" ở premium feature
3. Verify payment popup hiện ra
4. Complete payment với Pi test
5. Check backend logs để verify callbacks

## Testnet vs Mainnet

### Testnet (Development)
- Dùng Pi test (miễn phí, không giá trị thật)
- App wallet address khác với mainnet
- Transactions không ảnh hưởng Pi thật
- **Không cần setup app wallet** cho basic testing (dùng Demo Mode)

### Mainnet (Production)
- Dùng Pi thật sau KYC
- App wallet nhận Pi thật
- Transactions có giá trị thật
- **BẮT BUỘC phải setup app wallet** trước khi deploy

## Checklist Setup

- [ ] Truy cập Pi Developer Portal (develop.pi)
- [ ] Chọn app "Olivia PiMask"
- [ ] Enable App Wallet trong tab "App Wallet"
- [ ] Generate và lưu private key an toàn
- [ ] Config payment settings (Auto approval, webhook, etc.)
- [ ] Activate app wallet
- [ ] Implement backend webhook endpoint
- [ ] Verify webhook signature security
- [ ] Test payment flow trong testnet
- [ ] Monitor logs và errors
- [ ] Deploy backend production
- [ ] Activate mainnet wallet
- [ ] Test real payment với Pi thật

## Workaround cho Testing (Không cần App Wallet)

Nếu chưa sẵn sàng setup app wallet, dùng **Demo Mode** để test UI:

1. Trong app, click nút **"Demo"** thay vì "Mua ngay"
2. Demo Mode simulate payment flow hoàn chỉnh
3. Không cần Pi SDK, không cần app wallet
4. Features vẫn được unlock như bình thường
5. Good cho testing UI/UX trước khi integrate backend

## Troubleshooting

### Error: "App wallet not found"
- Verify app đã được approve trong Pi Developer Portal
- Check app wallet status = "Active"
- Restart Pi Browser sau khi activate wallet

### Error: "Unauthorized app"
- App chưa được approve bởi Pi team
- Submit app cho review trong Developer Portal
- Chờ 1-3 ngày để được approve

### Error: "Payment failed"
- Check backend webhook có response 200 OK
- Verify webhook signature đúng
- Check Pi balance user đủ để thanh toán

### Error: "Network error"
- Pi SDK chưa init đúng cách
- Check internet connection
- Verify Pi Browser version mới nhất

## Resources

- [Pi Platform API - Payments](https://developers.minepi.com/doc/platform-api/payments)
- [Pi JavaScript SDK - Payments](https://developers.minepi.com/doc/javascript-sdk#payments)
- [Pi Developer Portal](https://develop.pi)
- [Pi Network Developers Community](https://t.me/PiDevelopers)

## Contact Support

Nếu vẫn gặp vấn đề, liên hệ:
- Pi Developer Support: developers@minepi.com
- Pi Network Discord: https://discord.gg/pinetwork
- Olivia PiMask Support: (your support contact)

---

**Lưu ý cuối:** Setup app wallet là **required** cho production app với payments. Demo Mode chỉ dùng cho testing và development.
