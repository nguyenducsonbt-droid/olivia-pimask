"use client"

// Pi App Auto-Connection System
// Automatically detects and connects Olivia PiMask when Pi dApps are accessed

interface PiAppConnection {
  dappUrl: string
  dappName: string
  connectedAt: number
  permissions: string[]
  lastActivity: number
}

interface PiTransaction {
  hash: string
  from: string
  to: string
  value: string
  fee?: string
  timestamp: number
  status: "confirmed" | "pending" | "failed"
  type: "send" | "receive" | "payment" | "stake"
  dappName?: string
  dappUrl?: string
  network: "mainnet" | "testnet"
  blockNumber?: number
}

const PI_CONNECTIONS_KEY = "olivia_pi_app_connections"
const PI_TRANSACTIONS_KEY = "olivia_pi_transactions"

import { playSound } from "@/lib/sounds"

export class PiAppConnector {
  private static instance: PiAppConnector
  private connections: Map<string, PiAppConnection> = new Map()
  private transactions: PiTransaction[] = []
  private autoConnectEnabled = true

  private constructor() {
    this.loadConnections()
    this.loadTransactions()
    this.initializeAutoConnect()
  }

  static getInstance(): PiAppConnector {
    if (!PiAppConnector.instance) {
      PiAppConnector.instance = new PiAppConnector()
    }
    return PiAppConnector.instance
  }

  private initializeAutoConnect() {
    if (typeof window === "undefined") return
    ;(window as any).oliviaPiMask = {
      isOlivia: true,
      version: "1.0.0",
      autoConnect: true,
      connected: false,

      // Auto-connect when dApp requests wallet connection
      connect: async (options?: { dappName?: string; dappUrl?: string }) => {
        console.log("[v0] Pi dApp requesting connection:", options)
        return await this.connectDApp(options?.dappName, options?.dappUrl)
      },

      // Send Pi payment
      sendPayment: async (to: string, amount: string) => {
        console.log("[v0] dApp requesting Pi payment:", { to, amount })
        return await this.handlePaymentRequest(to, amount)
      },

      // Get connection status
      isConnected: () => {
        return this.connections.size > 0
      },

      // Get user info
      getUserInfo: async () => {
        const piSession = this.loadPiSession()
        if (!piSession) return null
        return {
          username: piSession.username,
          uid: piSession.userId,
        }
      },
    }

    // Listen for iframe messages from Pi dApps
    window.addEventListener("message", (event) => {
      this.handleDAppMessage(event)
    })

    console.log("[v0] Pi App auto-connector initialized")
  }

  private handleDAppMessage(event: MessageEvent) {
    const { type, data } = event.data

    switch (type) {
      case "pi_wallet_connect_request":
        this.connectDApp(data.dappName, data.dappUrl)
        break
      case "pi_payment_request":
        this.handlePaymentRequest(data.to, data.amount, data.memo)
        break
      case "pi_transaction_status":
        this.updateTransactionStatus(data.hash, data.status)
        break
    }
  }

  async connectDApp(dappName?: string, dappUrl?: string): Promise<{ connected: boolean; address: string }> {
    try {
      const url = dappUrl || window.location.href
      const name = dappName || new URL(url).hostname

      // Check if Pi Browser session exists
      const piSession = this.loadPiSession()
      if (!piSession) {
        // Trigger Pi authentication
        if ((window as any).Pi) {
          const auth = await (window as any).Pi.authenticate(["username", "payments"], () => {})
          this.savePiSession({
            username: auth.user.username,
            userId: auth.user.uid,
            accessToken: auth.accessToken,
          })
        } else {
          throw new Error("Pi SDK not available")
        }
      }

      const connection: PiAppConnection = {
        dappUrl: url,
        dappName: name,
        connectedAt: Date.now(),
        permissions: ["payments", "username"],
        lastActivity: Date.now(),
      }

      this.connections.set(url, connection)
      this.saveConnections()

      // Notify dApp of successful connection
      ;(window as any).oliviaPiMask.connected = true

      // Dispatch connection event
      window.dispatchEvent(
        new CustomEvent("olivia-dapp-connected", {
          detail: { dappName: name, dappUrl: url },
        }),
      )

      console.log("[v0] Auto-connected to Pi dApp:", name)

      return {
        connected: true,
        address: piSession?.username || "connected",
      }
    } catch (error) {
      console.error("[v0] Failed to auto-connect dApp:", error)
      throw error
    }
  }

  async handlePaymentRequest(to: string, amount: string, memo?: string): Promise<string> {
    try {
      // Use Pi SDK to create payment
      if (!(window as any).Pi) {
        throw new Error("Pi SDK not available")
      }

      const payment = await (window as any).Pi.createPayment(
        {
          amount: Number.parseFloat(amount),
          memo: memo || "Payment from Olivia PiMask",
          metadata: {
            source: "olivia_pimask",
            timestamp: Date.now(),
          },
        },
        {
          onReadyForServerApproval: (paymentId: string) => {
            console.log("[v0] Payment ready for approval:", paymentId)
          },
          onReadyForServerCompletion: (paymentId: string, txid: string) => {
            console.log("[v0] Payment completed:", { paymentId, txid })
            // Save transaction to history
            this.addTransaction({
              hash: txid,
              from: "user",
              to: to,
              value: amount,
              timestamp: Date.now(),
              status: "confirmed",
              type: "payment",
              network: "mainnet",
            })
          },
          onCancel: (paymentId: string) => {
            console.log("[v0] Payment cancelled:", paymentId)
          },
          onError: (error: any, payment: any) => {
            console.error("[v0] Payment error:", error)
            throw error
          },
        },
      )

      return payment.identifier
    } catch (error) {
      console.error("[v0] Payment request failed:", error)
      throw error
    }
  }

  addTransaction(tx: PiTransaction) {
    this.transactions.unshift(tx)
    // Keep last 100 transactions
    if (this.transactions.length > 100) {
      this.transactions = this.transactions.slice(0, 100)
    }
    this.saveTransactions()

    if (tx.type === "receive" || tx.type === "payment") {
      playSound("receive")
    }

    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent("olivia-pi-transaction", { detail: tx }))
  }

  updateTransactionStatus(hash: string, status: "confirmed" | "pending" | "failed") {
    const tx = this.transactions.find((t) => t.hash === hash)
    if (tx) {
      tx.status = status
      this.saveTransactions()
      window.dispatchEvent(new CustomEvent("olivia-pi-transaction-updated", { detail: tx }))
    }
  }

  getPiTransactions(): PiTransaction[] {
    return this.transactions
  }

  getConnectedDApps(): PiAppConnection[] {
    return Array.from(this.connections.values())
  }

  disconnectDApp(dappUrl: string) {
    this.connections.delete(dappUrl)
    this.saveConnections()
    window.dispatchEvent(new CustomEvent("olivia-dapp-disconnected", { detail: { dappUrl } }))
  }

  private loadConnections() {
    if (typeof window === "undefined") return
    const data = localStorage.getItem(PI_CONNECTIONS_KEY)
    if (data) {
      const parsed = JSON.parse(data)
      this.connections = new Map(Object.entries(parsed))
    }
  }

  private saveConnections() {
    if (typeof window === "undefined") return
    const obj = Object.fromEntries(this.connections)
    localStorage.setItem(PI_CONNECTIONS_KEY, JSON.stringify(obj))
  }

  private loadTransactions() {
    if (typeof window === "undefined") return
    const data = localStorage.getItem(PI_TRANSACTIONS_KEY)
    if (data) {
      this.transactions = JSON.parse(data)
    }
  }

  private saveTransactions() {
    if (typeof window === "undefined") return
    localStorage.setItem(PI_TRANSACTIONS_KEY, JSON.stringify(this.transactions))
  }

  private loadPiSession() {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem("olivia_wallet_pi_session")
    return data ? JSON.parse(data) : null
  }

  private savePiSession(session: any) {
    if (typeof window === "undefined") return
    localStorage.setItem("olivia_wallet_pi_session", JSON.stringify(session))
  }
}

// Export singleton instance
export const piAppConnector = PiAppConnector.getInstance()

// Auto-initialize on import
if (typeof window !== "undefined") {
  PiAppConnector.getInstance()
}
