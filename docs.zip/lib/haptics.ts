// Haptic feedback utility for Olivia PiMask

export type HapticType = "light" | "medium" | "heavy" | "success" | "warning" | "error"

const hapticEnabled = () => {
  try {
    return localStorage.getItem("olivia_haptic_enabled") !== "false"
  } catch {
    return true
  }
}

export const hapticFeedback = (type: HapticType = "light") => {
  if (!hapticEnabled()) return

  try {
    if (!navigator.vibrate) return

    switch (type) {
      case "light":
        navigator.vibrate(10)
        break

      case "medium":
        navigator.vibrate(20)
        break

      case "heavy":
        navigator.vibrate(30)
        break

      case "success":
        navigator.vibrate([10, 50, 10])
        break

      case "warning":
        navigator.vibrate([20, 100, 20])
        break

      case "error":
        navigator.vibrate([30, 50, 30, 50, 30])
        break

      default:
        navigator.vibrate(10)
    }
  } catch (error) {
    // Silent fail - haptic not critical
    console.log("[v0] Haptic feedback failed:", error)
  }
}

export const toggleHaptic = () => {
  try {
    const current = hapticEnabled()
    localStorage.setItem("olivia_haptic_enabled", String(!current))
    return !current
  } catch {
    return true
  }
}

export const triggerHaptic = hapticFeedback
