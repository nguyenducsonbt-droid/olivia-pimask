/**
 * Pi Network Deep Links & Integration Utilities for Olivia PiMask
 */

export interface PiDeepLinkConfig {
  app: string
  redirectUri: string
  username?: string
}

/**
 * Generate Pi Wallet connection deep link
 * Works on Android and iOS with Pi app installed
 */
export function generatePiWalletConnectLink(config: PiDeepLinkConfig): string {
  const params = new URLSearchParams({
    app: config.app,
    redirect_uri: config.redirectUri,
  })

  return `pi://wallet/connect?${params.toString()}`
}

/**
 * Generate Pi Wallet open deep link
 * Opens wallet for authenticated users
 */
export function generatePiWalletOpenLink(config: PiDeepLinkConfig): string {
  const params = new URLSearchParams({
    app: config.app,
    redirect_uri: config.redirectUri,
  })

  if (config.username) {
    params.append("username", config.username)
  }

  return `pi://wallet/open?${params.toString()}`
}

/**
 * Attempt to open Pi Wallet with multiple fallback methods
 */
export async function openPiWallet(username?: string): Promise<boolean> {
  const config: PiDeepLinkConfig = {
    app: "oliviapimask",
    redirectUri: typeof window !== "undefined" ? window.location.href : "",
    username,
  }

  // Method 1: Try Pi SDK's built-in wallet opener
  if (typeof window !== "undefined" && (window as any).Pi) {
    try {
      if (typeof (window as any).Pi.openWallet === "function") {
        await (window as any).Pi.openWallet()
        return true
      }
    } catch (error) {
      console.error("Pi SDK openWallet failed:", error)
    }
  }

  // Method 2: Try deep link (mobile apps)
  try {
    const deepLinkUrl = username ? generatePiWalletOpenLink(config) : generatePiWalletConnectLink(config)

    // Create hidden iframe to trigger deep link
    const iframe = document.createElement("iframe")
    iframe.style.display = "none"
    iframe.src = deepLinkUrl
    document.body.appendChild(iframe)

    // Clean up after 1 second
    setTimeout(() => {
      if (document.body.contains(iframe)) {
        document.body.removeChild(iframe)
      }
    }, 1000)

    return true
  } catch (error) {
    console.error("Deep link failed:", error)
    return false
  }
}

/**
 * Android Intent for opening Pi Wallet
 * Use this format in Android WebView
 */
export function getAndroidIntent(config: PiDeepLinkConfig): string {
  return `intent://wallet/connect?app=${config.app}&redirect_uri=${encodeURIComponent(
    config.redirectUri,
  )}#Intent;scheme=pi;package=com.blockchainvault;end;`
}

/**
 * iOS URL Scheme for opening Pi Wallet
 * Use this format in iOS WebView
 */
export function getIOSUrlScheme(config: PiDeepLinkConfig): string {
  return generatePiWalletConnectLink(config)
}

/**
 * Check if Pi SDK is available and initialized
 */
export function isPiSdkAvailable(): boolean {
  return typeof window !== "undefined" && typeof (window as any).Pi !== "undefined"
}

/**
 * Check if running in Pi Browser
 */
export function isPiBrowser(): boolean {
  if (typeof window === "undefined") return false

  const userAgent = window.navigator.userAgent.toLowerCase()
  return userAgent.includes("pi browser") || isPiSdkAvailable()
}

/**
 * Initialize Pi SDK with error handling
 */
export async function initializePiSdk(): Promise<boolean> {
  if (!isPiSdkAvailable()) {
    console.error("Pi SDK not available")
    return false
  }

  try {
    const Pi = (window as any).Pi
    if (!Pi.initialized) {
      await Pi.init({ version: "2.0", sandbox: false })
      console.log("Pi SDK initialized successfully")
    }
    return true
  } catch (error) {
    console.error("Failed to initialize Pi SDK:", error)
    return false
  }
}
