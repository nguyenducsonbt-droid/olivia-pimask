export interface TransactionData {
  hash: string
  from: string
  to: string
  amount: string
  token: string
  status: "pending" | "confirmed" | "failed"
}

export interface Notification {
  id: string
  title: string
  message: string
  timestamp: number
  read: boolean
  type:
    | "transaction_send"
    | "transaction_receive"
    | "staking_reward"
    | "fiat_deposit"
    | "fiat_withdraw"
    | "system_update"
    | "dapp"
    | "success"
    | "info"
    | "warning"
    | "error"
  data?: TransactionData | Record<string, any>
}

export function addNotification(
  title: string,
  message: string,
  type: Notification["type"] = "info",
  data?: TransactionData | Record<string, any>,
) {
  try {
    const notifications = getNotifications()
    const newNotification: Notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      title,
      message,
      timestamp: Date.now(),
      read: false,
      type,
      data,
    }
    notifications.unshift(newNotification)
    localStorage.setItem("olivia_notifications", JSON.stringify(notifications))

    // Request push notification permission and send push
    requestPushPermissionAndNotify(title, message)

    return newNotification
  } catch (error) {
    console.error("[v0] Failed to add notification:", error)
    return null
  }
}

export async function requestPushPermissionAndNotify(title: string, message: string) {
  try {
    if (!("Notification" in window)) {
      console.log("[v0] This browser does not support notifications")
      return
    }

    if (Notification.permission === "granted") {
      new Notification(title, {
        body: message,
        icon: "/placeholder-logo.png",
        badge: "/placeholder-logo.png",
        tag: "olivia-pimask",
      })
    } else if (Notification.permission !== "denied") {
      const permission = await Notification.requestPermission()
      if (permission === "granted") {
        new Notification(title, {
          body: message,
          icon: "/placeholder-logo.png",
          badge: "/placeholder-logo.png",
          tag: "olivia-pimask",
        })
      }
    }
  } catch (error) {
    console.error("[v0] Failed to send push notification:", error)
  }
}

export function getNotifications(): Notification[] {
  try {
    const stored = localStorage.getItem("olivia_notifications")
    return stored ? JSON.parse(stored) : []
  } catch (error) {
    console.error("[v0] Failed to get notifications:", error)
    return []
  }
}

export function markNotificationAsRead(id: string) {
  try {
    const notifications = getNotifications()
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    localStorage.setItem("olivia_notifications", JSON.stringify(updated))
  } catch (error) {
    console.error("[v0] Failed to mark notification as read:", error)
  }
}

export function deleteNotification(id: string) {
  try {
    const notifications = getNotifications()
    const updated = notifications.filter((n) => n.id !== id)
    localStorage.setItem("olivia_notifications", JSON.stringify(updated))
  } catch (error) {
    console.error("[v0] Failed to delete notification:", error)
  }
}

export function clearAllNotifications() {
  try {
    localStorage.setItem("olivia_notifications", JSON.stringify([]))
  } catch (error) {
    console.error("[v0] Failed to clear notifications:", error)
  }
}
