// Sound effects utility for Olivia PiMask

export type SoundType = "click" | "success" | "error" | "notification" | "send" | "receive"

const soundEnabled = () => {
  try {
    return localStorage.getItem("olivia_sound_enabled") !== "false"
  } catch {
    return true
  }
}

export const playSound = (type: SoundType) => {
  if (!soundEnabled()) return

  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    switch (type) {
      case "click":
        oscillator.frequency.value = 800
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.05)
        break

      case "success":
        oscillator.frequency.value = 1200
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.15)
        break

      case "error":
        oscillator.frequency.value = 400
        oscillator.type = "square"
        gainNode.gain.setValueAtTime(0.15, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.2)
        break

      case "notification":
        oscillator.frequency.value = 1000
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.15, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.1)
        break

      case "send":
        oscillator.frequency.value = 900
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.12)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.12)
        break

      case "receive":
        oscillator.frequency.value = 1100
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.12)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.12)
        break

      default:
        oscillator.frequency.value = 800
        oscillator.type = "sine"
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05)
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.05)
    }
  } catch (error) {
    // Silent fail - sound not critical
    console.log("[v0] Sound playback failed:", error)
  }
}

export const toggleSound = () => {
  try {
    const current = soundEnabled()
    localStorage.setItem("olivia_sound_enabled", String(!current))
    return !current
  } catch {
    return true
  }
}
