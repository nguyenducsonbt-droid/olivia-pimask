// Auto-lock functionality for wallet security
// Stores timeout settings in localStorage with multi-layer persistence

const AUTO_LOCK_KEY = "olivia_autolock_time"
const AUTO_LOCK_BACKUP = "olivia_autolock_backup"

/**
 * Get the saved auto-lock timeout setting
 * @returns The timeout value ("1", "5", "15", "30", "60", "never") or null if not set
 */
export function getAutoLockTime(): string | null {
  try {
    // Try primary storage
    const value = localStorage.getItem(AUTO_LOCK_KEY)
    if (value) return value

    // Try backup storage
    const backup = sessionStorage.getItem(AUTO_LOCK_BACKUP)
    if (backup) {
      // Restore to primary
      localStorage.setItem(AUTO_LOCK_KEY, backup)
      return backup
    }

    return null
  } catch (error) {
    console.error("[Auto-lock] Failed to get auto-lock time:", error)
    return null
  }
}

/**
 * Save the auto-lock timeout setting
 * @param value - The timeout value in minutes ("1", "5", "15", "30", "60") or "never"
 */
export function saveAutoLockTime(value: string): void {
  try {
    // Save to primary storage
    localStorage.setItem(AUTO_LOCK_KEY, value)

    // Save to backup storage
    sessionStorage.setItem(AUTO_LOCK_BACKUP, value)

    console.log("[Auto-lock] Saved auto-lock time:", value)
  } catch (error) {
    console.error("[Auto-lock] Failed to save auto-lock time:", error)
  }
}

/**
 * Clear auto-lock settings (used on logout)
 */
export function clearAutoLockTime(): void {
  try {
    localStorage.removeItem(AUTO_LOCK_KEY)
    sessionStorage.removeItem(AUTO_LOCK_BACKUP)
    console.log("[Auto-lock] Cleared auto-lock settings")
  } catch (error) {
    console.error("[Auto-lock] Failed to clear auto-lock time:", error)
  }
}

/**
 * Get auto-lock timeout in milliseconds
 * @returns Timeout in milliseconds or null if "never" or not set
 */
export function getAutoLockTimeoutMs(): number | null {
  const value = getAutoLockTime()

  if (!value || value === "never") {
    return null
  }

  const minutes = Number.parseInt(value, 10)
  if (isNaN(minutes)) {
    return null
  }

  return minutes * 60 * 1000 // Convert minutes to milliseconds
}
