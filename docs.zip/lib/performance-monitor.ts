interface PerformanceMetrics {
  fcp: number // First Contentful Paint
  lcp: number // Largest Contentful Paint
  fid: number // First Input Delay
  cls: number // Cumulative Layout Shift
  ttfb: number // Time to First Byte
}

/**
 * Monitor and log performance metrics
 */
export function initPerformanceMonitoring() {
  if (typeof window === "undefined") return

  // Monitor page load performance
  if ("PerformanceObserver" in window) {
    // First Contentful Paint
    const fcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries()
      entries.forEach((entry) => {
        if (entry.name === "first-contentful-paint") {
          console.log("[Performance] FCP:", entry.startTime.toFixed(2), "ms")
        }
      })
    })

    try {
      fcpObserver.observe({ entryTypes: ["paint"] })
    } catch (e) {
      // Silent fail
    }

    // Largest Contentful Paint
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries()
      const lastEntry = entries[entries.length - 1]
      console.log("[Performance] LCP:", lastEntry.startTime.toFixed(2), "ms")
    })

    try {
      lcpObserver.observe({ entryTypes: ["largest-contentful-paint"] })
    } catch (e) {
      // Silent fail
    }

    // Cumulative Layout Shift
    let clsValue = 0
    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!(entry as any).hadRecentInput) {
          clsValue += (entry as any).value
        }
      }
      console.log("[Performance] CLS:", clsValue.toFixed(4))
    })

    try {
      clsObserver.observe({ entryTypes: ["layout-shift"] })
    } catch (e) {
      // Silent fail
    }
  }

  // Monitor memory usage (if available)
  if ("memory" in performance) {
    const checkMemory = () => {
      const memory = (performance as any).memory
      console.log("[Performance] Memory Usage:", {
        used: (memory.usedJSHeapSize / 1048576).toFixed(2) + " MB",
        total: (memory.totalJSHeapSize / 1048576).toFixed(2) + " MB",
        limit: (memory.jsHeapSizeLimit / 1048576).toFixed(2) + " MB",
      })
    }

    // Check memory every 30 seconds in development
    if (process.env.NODE_ENV === "development") {
      setInterval(checkMemory, 30000)
    }
  }

  if (typeof document !== "undefined") {
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        intervalManager.pause()
      } else {
        intervalManager.resume()
      }
    })
  }
}

/**
 * Enhanced debounce with immediate execution option
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number,
  immediate = false,
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null

  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null
      if (!immediate) func(...args)
    }

    const callNow = immediate && !timeout
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(later, wait)

    if (callNow) func(...args)
  }
}

/**
 * Throttle function for performance
 */
export function throttle<T extends (...args: any[]) => any>(func: T, limit: number): (...args: Parameters<T>) => void {
  let inThrottle = false

  return function executedFunction(...args: Parameters<T>) {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

/**
 * RequestIdleCallback polyfill
 */
export const requestIdleCallback =
  typeof window !== "undefined" && "requestIdleCallback" in window
    ? window.requestIdleCallback
    : (cb: IdleRequestCallback) => setTimeout(cb, 1)

/**
 * Run task during idle time
 */
export function runWhenIdle(task: () => void) {
  requestIdleCallback(() => {
    task()
  })
}

/**
 * Safe render function with visibility check
 */
export function safeRender(callback: () => void, delay = 100) {
  if (document.hidden) {
    console.log("[v0] Skipping render - document hidden")
    return
  }

  const debouncedCallback = debounce(callback, delay)
  requestIdleCallback(() => {
    if (!document.hidden) {
      debouncedCallback()
    }
  })
}

/**
 * Interval manager for automatic cleanup
 */
export class IntervalManager {
  private intervals: Set<NodeJS.Timeout> = new Set()
  private isPaused = false

  setInterval(callback: () => void, ms: number): NodeJS.Timeout {
    const wrappedCallback = () => {
      if (!this.isPaused && !document.hidden) {
        callback()
      }
    }

    const id = setInterval(wrappedCallback, ms)
    this.intervals.add(id)
    return id
  }

  clearInterval(id: NodeJS.Timeout) {
    clearInterval(id)
    this.intervals.delete(id)
  }

  pause() {
    this.isPaused = true
    console.log("[v0] Intervals paused - saving battery")
  }

  resume() {
    this.isPaused = false
    console.log("[v0] Intervals resumed")
  }

  clearAll() {
    this.intervals.forEach((id) => clearInterval(id))
    this.intervals.clear()
    console.log("[v0] All intervals cleared")
  }
}

/**
 * Global interval manager instance
 */
export const intervalManager = new IntervalManager()

/**
 * Optimize images for faster loading
 */
export function preloadCriticalAssets() {
  if (typeof window === "undefined") return

  const criticalImages = ["/placeholder-logo.png"]

  criticalImages.forEach((src) => {
    const link = document.createElement("link")
    link.rel = "preload"
    link.as = "image"
    link.href = src
    document.head.appendChild(link)
  })
}

/**
 * Check if page is loaded from cache (bfcache)
 */
export function detectBFCache(callback: () => void) {
  if (typeof window === "undefined") return

  window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
      console.log("[v0] Page loaded from bfcache - refreshing")
      callback()
    }
  })
}

/**
 * FPS monitor for debugging
 */
export function monitorFPS(callback?: (fps: number) => void) {
  if (typeof window === "undefined") return

  let lastTime = performance.now()
  let frames = 0

  function measureFPS() {
    frames++
    const currentTime = performance.now()

    if (currentTime >= lastTime + 1000) {
      const fps = Math.round((frames * 1000) / (currentTime - lastTime))
      if (callback) callback(fps)
      console.log("[v0] FPS:", fps)

      frames = 0
      lastTime = currentTime
    }

    requestAnimationFrame(measureFPS)
  }

  requestAnimationFrame(measureFPS)
}
