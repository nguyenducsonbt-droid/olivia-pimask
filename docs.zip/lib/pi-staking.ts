// Based on Pi Network Official Whitepaper and Mainnet 2026 mechanics

export interface LockupPoolResponse {
  pools: Array<{
    id: string
    name: string
    miningBoost: number // Mining rate boost percentage instead of APR
    minLock: number
    totalLocked: number
    lockPeriod: number // in days
    status: "active" | "inactive"
    description: string
  }>
}

export interface UserLockupResponse {
  lockups: Array<{
    poolId: string
    amount: number
    startDate: string
    endDate: string
    miningBoost: number
  }>
}

export interface LockupRequest {
  poolId: string
  amount: number
  userAddress: string
}

export interface UnlockRequest {
  poolId: string
  amount: number
  userAddress: string
}

const PI_LOCKUP_API = "https://api.mainnet.pi/lockup/v1"

export async function getLockupPools(): Promise<LockupPoolResponse> {
  try {
    const response = await fetch(`${PI_LOCKUP_API}/pools`)
    if (!response.ok) throw new Error("Failed to fetch lockup pools")
    return await response.json()
  } catch (error) {
    console.error("[v0] Error fetching lockup pools:", error)
    return {
      pools: [
        {
          id: "pi-voluntary-lockup-30d",
          name: "30 Days Voluntary Lockup",
          miningBoost: 50, // +50% mining rate boost
          minLock: 10,
          totalLocked: 1250000,
          lockPeriod: 30,
          status: "active",
          description: "Lock Pi to boost mining rate by 50% for 30 days",
        },
        {
          id: "pi-voluntary-lockup-90d",
          name: "90 Days Voluntary Lockup",
          miningBoost: 100, // +100% mining rate boost
          minLock: 50,
          totalLocked: 3500000,
          lockPeriod: 90,
          status: "active",
          description: "Lock Pi to boost mining rate by 100% for 90 days",
        },
        {
          id: "pi-voluntary-lockup-180d",
          name: "180 Days Voluntary Lockup",
          miningBoost: 200, // +200% mining rate boost
          minLock: 100,
          totalLocked: 5750000,
          lockPeriod: 180,
          status: "active",
          description: "Lock Pi to boost mining rate by 200% for 180 days",
        },
      ],
    }
  }
}

export async function getUserLockups(userAddress: string): Promise<UserLockupResponse> {
  try {
    const response = await fetch(`${PI_LOCKUP_API}/user/${userAddress}/lockups`)
    if (!response.ok) throw new Error("Failed to fetch user lockups")
    return await response.json()
  } catch (error) {
    console.error("[v0] Error fetching user lockups:", error)
    return { lockups: [] }
  }
}

export async function lockTokens(request: LockupRequest): Promise<{ success: boolean; txHash?: string }> {
  try {
    const response = await fetch(`${PI_LOCKUP_API}/lock`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    })
    if (!response.ok) throw new Error("Failed to lock tokens")
    return await response.json()
  } catch (error) {
    console.error("[v0] Error locking tokens:", error)
    throw error
  }
}

export async function unlockTokens(request: UnlockRequest): Promise<{ success: boolean; txHash?: string }> {
  try {
    const response = await fetch(`${PI_LOCKUP_API}/unlock`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    })
    if (!response.ok) throw new Error("Failed to unlock tokens")
    return await response.json()
  } catch (error) {
    console.error("[v0] Error unlocking tokens:", error)
    throw error
  }
}
