export interface LiquidityPool {
  id: string
  name: string
  tokenA: string
  tokenB: string
  tvl: number // Total Value Locked in USD
  apy: number // Annual Percentage Yield
  fee: number // Pool fee percentage
  volume24h: number
}

export interface SwapRoute {
  dex: string
  path: string[]
  expectedOutput: number
  priceImpact: number
  fee: number
  gasEstimate: number
}

export interface SwapQuote {
  fromToken: string
  toToken: string
  fromAmount: number
  toAmount: number
  bestRoute: SwapRoute
  alternativeRoutes: SwapRoute[]
  executionTime: number
}

// Mock liquidity pools for Pi Network ecosystem
const PI_LIQUIDITY_POOLS: LiquidityPool[] = [
  {
    id: "pi-usdt-1",
    name: "Pi/USDT Pool",
    tokenA: "PI",
    tokenB: "USDT",
    tvl: 5000000,
    apy: 12.5,
    fee: 0.25,
    volume24h: 250000,
  },
  {
    id: "pi-usdc-1",
    name: "Pi/USDC Pool",
    tokenA: "PI",
    tokenB: "USDC",
    tvl: 3500000,
    apy: 10.8,
    fee: 0.25,
    volume24h: 180000,
  },
  {
    id: "pi-dai-1",
    name: "Pi/DAI Pool",
    tokenA: "PI",
    tokenB: "DAI",
    tvl: 2000000,
    apy: 8.5,
    fee: 0.3,
    volume24h: 120000,
  },
  {
    id: "usdt-usdc-1",
    name: "USDT/USDC Pool",
    tokenA: "USDT",
    tokenB: "USDC",
    tvl: 8000000,
    apy: 5.2,
    fee: 0.05,
    volume24h: 400000,
  },
]

interface CoinGeckoPriceResponse {
  "pi-network": {
    usd: number
  }
}

// Fetch real Pi price from CoinGecko
async function fetchRealPiPrice(): Promise<number> {
  try {
    const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd", {
      cache: "no-store",
      next: { revalidate: 30 }, // Refresh every 30 seconds
    })

    if (!response.ok) {
      throw new Error(`CoinGecko API error: ${response.status}`)
    }

    const data: CoinGeckoPriceResponse = await response.json()
    const piPrice = data["pi-network"]?.usd

    if (!piPrice || piPrice <= 0) {
      throw new Error("Invalid Pi price received")
    }

    return piPrice
  } catch (error) {
    console.error("Failed to fetch Pi price from CoinGecko:", error)
    return 0.21
  }
}

// DEX aggregator to find best swap routes
export class PiSwapAggregator {
  private pools: LiquidityPool[]
  private currentPiPrice = 0.2 // Default fallback price

  constructor() {
    this.pools = PI_LIQUIDITY_POOLS
    // Fetch real price on initialization
    this.updatePiPrice()
  }

  async updatePiPrice(): Promise<number> {
    this.currentPiPrice = await fetchRealPiPrice()
    return this.currentPiPrice
  }

  getCurrentPiPrice(): number {
    return this.currentPiPrice
  }

  // Get all available pools
  getPools(): LiquidityPool[] {
    return this.pools
  }

  // Find best swap route using DEX aggregator algorithm
  async findBestRoute(fromToken: string, toToken: string, amount: number): Promise<SwapQuote> {
    const startTime = Date.now()

    // Direct swap routes
    const directRoutes = this.findDirectRoutes(fromToken, toToken, amount)

    // Multi-hop routes (through intermediate tokens)
    const multiHopRoutes = this.findMultiHopRoutes(fromToken, toToken, amount)

    const allRoutes = [...directRoutes, ...multiHopRoutes]

    // Sort by expected output (best rate)
    allRoutes.sort((a, b) => b.expectedOutput - a.expectedOutput)

    const bestRoute = allRoutes[0]
    const alternativeRoutes = allRoutes.slice(1, 4)

    const executionTime = Date.now() - startTime

    return {
      fromToken,
      toToken,
      fromAmount: amount,
      toAmount: bestRoute.expectedOutput,
      bestRoute,
      alternativeRoutes,
      executionTime,
    }
  }

  // Find direct swap routes (single pool)
  private findDirectRoutes(fromToken: string, toToken: string, amount: number): SwapRoute[] {
    const routes: SwapRoute[] = []

    // Find pools that contain both tokens
    const directPools = this.pools.filter(
      (pool) =>
        (pool.tokenA === fromToken && pool.tokenB === toToken) ||
        (pool.tokenA === toToken && pool.tokenB === fromToken),
    )

    for (const pool of directPools) {
      const rate = this.getPoolRate(pool, fromToken, toToken)
      const fee = pool.fee / 100
      const outputBeforeFee = amount * rate
      const feeAmount = outputBeforeFee * fee
      const expectedOutput = outputBeforeFee - feeAmount

      // Calculate price impact based on TVL
      const priceImpact = (amount / pool.tvl) * 100

      routes.push({
        dex: pool.name,
        path: [fromToken, toToken],
        expectedOutput,
        priceImpact,
        fee: pool.fee,
        gasEstimate: 0.005, // ~0.005 Pi gas
      })
    }

    return routes
  }

  // Find multi-hop routes (through intermediate tokens)
  private findMultiHopRoutes(fromToken: string, toToken: string, amount: number): SwapRoute[] {
    const routes: SwapRoute[] = []

    // Common intermediate tokens for routing
    const intermediateTokens = ["USDT", "USDC", "DAI"]

    for (const intermediate of intermediateTokens) {
      if (intermediate === fromToken || intermediate === toToken) continue

      // Find first hop: fromToken -> intermediate
      const firstHopPools = this.pools.filter(
        (pool) =>
          (pool.tokenA === fromToken && pool.tokenB === intermediate) ||
          (pool.tokenA === intermediate && pool.tokenB === fromToken),
      )

      // Find second hop: intermediate -> toToken
      const secondHopPools = this.pools.filter(
        (pool) =>
          (pool.tokenA === intermediate && pool.tokenB === toToken) ||
          (pool.tokenA === toToken && pool.tokenB === intermediate),
      )

      for (const pool1 of firstHopPools) {
        for (const pool2 of secondHopPools) {
          // Calculate first hop
          const rate1 = this.getPoolRate(pool1, fromToken, intermediate)
          const fee1 = pool1.fee / 100
          const outputHop1 = amount * rate1 * (1 - fee1)

          // Calculate second hop
          const rate2 = this.getPoolRate(pool2, intermediate, toToken)
          const fee2 = pool2.fee / 100
          const expectedOutput = outputHop1 * rate2 * (1 - fee2)

          // Combined price impact
          const priceImpact = (amount / pool1.tvl + outputHop1 / pool2.tvl) * 100

          // Combined fees
          const totalFee = pool1.fee + pool2.fee

          routes.push({
            dex: `${pool1.name} → ${pool2.name}`,
            path: [fromToken, intermediate, toToken],
            expectedOutput,
            priceImpact,
            fee: totalFee,
            gasEstimate: 0.01, // Higher gas for multi-hop
          })
        }
      }
    }

    return routes
  }

  private getPoolRate(pool: LiquidityPool, fromToken: string, toToken: string): number {
    const piPrice = this.currentPiPrice

    const rates: Record<string, number> = {
      "PI-USDT": piPrice,
      "USDT-PI": 1 / piPrice,
      "PI-USDC": piPrice,
      "USDC-PI": 1 / piPrice,
      "PI-DAI": piPrice,
      "DAI-PI": 1 / piPrice,
      "USDT-USDC": 1.0,
      "USDC-USDT": 1.0,
      "USDT-DAI": 1.0,
      "DAI-USDT": 1.0,
      "USDC-DAI": 1.0,
      "DAI-USDC": 1.0,
    }

    const key = `${fromToken}-${toToken}`
    return rates[key] || 1.0
  }

  // Calculate optimal slippage based on pool liquidity
  calculateOptimalSlippage(pool: LiquidityPool, amount: number): number {
    const priceImpact = (amount / pool.tvl) * 100

    if (priceImpact < 0.1) return 0.5 // Very low impact
    if (priceImpact < 0.5) return 1.0 // Low impact
    if (priceImpact < 1.0) return 2.0 // Medium impact
    return 3.0 // High impact
  }
}

// Singleton instance
export const piSwapAggregator = new PiSwapAggregator()
