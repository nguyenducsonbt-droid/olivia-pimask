// Secure local storage utilities
// Note: In production, consider using encryption for sensitive data

const WALLET_KEY = "olivia_wallet_encrypted"
const NETWORKS_KEY = "olivia_networks"
const TOKENS_KEY = "olivia_tokens"
const TRANSACTIONS_KEY = "olivia_transactions"
const CUSTOM_TOKENS_KEY = "olivia_custom_tokens"
const CUSTOM_NETWORKS_KEY = "olivia_custom_networks"
const PI_CONNECTION_KEY = "olivia_pi_connection"
const PIN_HASH_KEY = "olivia_pin_hash"
const BIOMETRIC_ENABLED_KEY = "olivia_biometric_enabled"
const PIN_MEMORY_ENABLED_KEY = "olivia_pin_memory_enabled"
const AVATAR_KEY = "olivia_avatar"
const AUTOLOCK_TIME_KEY = "olivia_autolock_time"

export function testStorageIntegrity(): boolean {
  if (typeof window === "undefined") return false

  const testKey = "olivia_storage_test"
  const testValue = "test_data_" + Date.now()

  try {
    // Test write
    localStorage.setItem(testKey, testValue)

    // Test read
    const readValue = localStorage.getItem(testKey)

    // Test delete
    localStorage.removeItem(testKey)

    const success = readValue === testValue
    console.log("[v0] Storage integrity test:", success ? "PASS" : "FAIL")
    return success
  } catch (err) {
    console.error("[v0] Storage integrity test FAILED:", err)
    return false
  }
}

export function saveWalletData(address: string, encryptedMnemonic: string) {
  if (typeof window !== "undefined") {
    const data = { address, encryptedMnemonic }
    console.log("[v0] ====================================")
    console.log("[v0] SAVING WALLET TO PERSISTENT STORAGE")
    console.log("[v0] Address:", address)
    console.log("[v0] Key:", WALLET_KEY)
    console.log("[v0] ====================================")

    try {
      localStorage.setItem(WALLET_KEY, JSON.stringify(data))

      const verifyRead = localStorage.getItem(WALLET_KEY)
      if (!verifyRead) {
        throw new Error("localStorage save failed - data not readable")
      }

      const parsed = JSON.parse(verifyRead)
      if (parsed.address !== address) {
        throw new Error("localStorage save failed - address mismatch")
      }

      console.log("[v0] ✓ WALLET SAVED & VERIFIED")
      console.log("[v0] ✓ Address:", parsed.address)
      console.log("[v0] ✓ Encrypted length:", parsed.encryptedMnemonic.length)
      console.log("[v0] ✓ Data persists across reloads")
      console.log("[v0] ====================================")

      return true
    } catch (err) {
      console.error("[v0] ✗ SAVE FAILED:", err)
      console.log("[v0] ====================================")
      alert("CRITICAL: Failed to save wallet to storage. Please try again.")
      return false
    }
  }
  return false
}

export function getWalletData(): { address: string; encryptedMnemonic: string } | null {
  if (typeof window !== "undefined") {
    console.log("[v0] ====================================")
    console.log("[v0] RETRIEVING WALLET FROM LOCALSTORAGE")
    console.log("[v0] Key:", WALLET_KEY)

    const data = localStorage.getItem(WALLET_KEY)

    if (data) {
      const parsed = JSON.parse(data)
      console.log("[v0] ✓ WALLET FOUND IN STORAGE")
      console.log("[v0] ✓ Address:", parsed.address)
      console.log("[v0] ====================================")
      return parsed
    } else {
      console.log("[v0] ✗ NO WALLET IN STORAGE")
      console.log("[v0] ====================================")
      return null
    }
  }
  return null
}

export function forceResetAllWalletData() {
  if (typeof window !== "undefined") {
    console.log("[v0] ====================================")
    console.log("[v0] FORCE RESET ALL WALLET DATA")
    console.log("[v0] ====================================")

    // Remove all wallet-related keys
    localStorage.removeItem(WALLET_KEY)
    localStorage.removeItem(BIOMETRIC_ENABLED_KEY)
    localStorage.removeItem(PI_CONNECTION_KEY)
    localStorage.removeItem(PIN_HASH_KEY)
    localStorage.removeItem(NETWORKS_KEY)
    localStorage.removeItem(TOKENS_KEY)
    localStorage.removeItem(TRANSACTIONS_KEY)
    localStorage.removeItem(CUSTOM_TOKENS_KEY)
    localStorage.removeItem(CUSTOM_NETWORKS_KEY)
    localStorage.removeItem(AUTOLOCK_TIME_KEY) // Added Auto-lock time key from reset

    console.log("[v0] ✓ All wallet data cleared")
    console.log("[v0] ====================================")

    return true
  }
  return false
}

export function clearWalletData() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(WALLET_KEY)
    localStorage.removeItem(BIOMETRIC_ENABLED_KEY)
    localStorage.removeItem(PI_CONNECTION_KEY)
    // Note: Keep PIN hash so user can set it again after re-creating wallet
    // If you want to clear PIN too, uncomment the line below:
    // localStorage.removeItem(PIN_HASH_KEY)
    localStorage.removeItem(AUTOLOCK_TIME_KEY) // Added Auto-lock time key from clear
  }
}

export function deleteWalletCompletely() {
  if (typeof window !== "undefined") {
    console.log("[v0] ====================================")
    console.log("[v0] DELETING WALLET COMPLETELY")
    console.log("[v0] ====================================")

    // Remove ALL wallet-related keys including PIN
    localStorage.removeItem(WALLET_KEY)
    localStorage.removeItem(BIOMETRIC_ENABLED_KEY)
    localStorage.removeItem(PI_CONNECTION_KEY)
    localStorage.removeItem(PIN_HASH_KEY)
    localStorage.removeItem(NETWORKS_KEY)
    localStorage.removeItem(TOKENS_KEY)
    localStorage.removeItem(TRANSACTIONS_KEY)
    localStorage.removeItem(CUSTOM_TOKENS_KEY)
    localStorage.removeItem(CUSTOM_NETWORKS_KEY)
    localStorage.removeItem(AUTOLOCK_TIME_KEY)
    localStorage.removeItem("olivia_currency")
    localStorage.removeItem("olivia_language")
    localStorage.removeItem("olivia_theme")

    // Try to clear Pi SDK storage as well
    try {
      if ((window as any).Pi) {
        ;(window as any).Pi.storage.removeSecure("userPinHash")
        ;(window as any).Pi.storage.sync()
      }
    } catch (err) {
      console.log("[v0] Pi SDK storage not available:", err)
    }

    console.log("[v0] ✓ Wallet deleted completely")
    console.log("[v0] ====================================")

    return true
  }
  return false
}

export function saveNetworks(networks: any[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(NETWORKS_KEY, JSON.stringify(networks))
  }
}

export function getNetworks(): any[] {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(NETWORKS_KEY)
    return data ? JSON.parse(data) : []
  }
  return []
}

export function saveTokens(tokens: any[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(TOKENS_KEY, JSON.stringify(tokens))
  }
}

export function getTokens(): any[] {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(TOKENS_KEY)
    return data ? JSON.parse(data) : []
  }
  return []
}

export function saveTransactions(transactions: any[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(transactions))
  }
}

export function getTransactions(): any[] {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(TRANSACTIONS_KEY)
    return data ? JSON.parse(data) : []
  }
  return []
}

export function saveCustomTokens(tokens: any[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(CUSTOM_TOKENS_KEY, JSON.stringify(tokens))
  }
}

export function getCustomTokens(): any[] {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(CUSTOM_TOKENS_KEY)
    return data ? JSON.parse(data) : []
  }
  return []
}

export function saveCustomNetworks(networks: any[]) {
  if (typeof window !== "undefined") {
    localStorage.setItem(CUSTOM_NETWORKS_KEY, JSON.stringify(networks))
  }
}

export function getCustomNetworks(): any[] {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(CUSTOM_NETWORKS_KEY)
    return data ? JSON.parse(data) : []
  }
  return []
}

// Pi connection storage
export function savePiConnection(data: {
  accessToken: string
  userId: string
  username: string
  balance: string
  kycStatus: string
  mainnetMigrated: boolean
}) {
  if (typeof window !== "undefined") {
    localStorage.setItem(PI_CONNECTION_KEY, JSON.stringify(data))
  }
}

export function getPiConnection(): {
  accessToken: string
  userId: string
  username: string
  balance: string
  kycStatus: string
  mainnetMigrated: boolean
} | null {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(PI_CONNECTION_KEY)
    return data ? JSON.parse(data) : null
  }
  return null
}

export function clearPiConnection() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(PI_CONNECTION_KEY)
  }
}

export async function savePinHash(pinHash: string, address: string, encryptedMnemonic: string) {
  if (typeof window !== "undefined") {
    const pinVersion = Date.now()
    const pinNonce = Math.random().toString(36).substring(7)

    const pinData = {
      pinHash,
      address,
      encryptedMnemonic,
      version: pinVersion,
      nonce: pinNonce,
      createdAt: Date.now(),
    }

    console.log("[v0] ====================================")
    console.log("[v0] SAVING NEW PIN WITH VERSION")
    console.log("[v0] PIN Hash:", pinHash.substring(0, 10) + "...")
    console.log("[v0] Version:", pinVersion)
    console.log("[v0] Nonce:", pinNonce)
    console.log("[v0] ====================================")

    try {
      localStorage.removeItem(PIN_HASH_KEY)
      localStorage.removeItem("olivia_pin") // Old key
      localStorage.removeItem("pin_hash") // Old key
      sessionStorage.removeItem(PIN_HASH_KEY)
      sessionStorage.removeItem("olivia_pin")
      sessionStorage.removeItem("pin_hash")
      console.log("[v0] ✓ Cleared all old PIN storage locations")
    } catch (err) {
      console.warn("[v0] Error clearing old storage:", err)
    }

    // Layer 1: localStorage (primary, most reliable)
    localStorage.setItem(PIN_HASH_KEY, JSON.stringify(pinData))
    console.log("[v0] ✓ PIN saved to localStorage (Layer 1)")

    // Layer 2: sessionStorage (backup for same session)
    sessionStorage.setItem(PIN_HASH_KEY, JSON.stringify(pinData))
    console.log("[v0] ✓ PIN saved to sessionStorage (Layer 2)")

    // Layer 3: IndexedDB (backup for cross-session persistence)
    try {
      const db = await openPinDatabase()
      const transaction1 = db.transaction(["pins"], "readwrite")
      const store1 = transaction1.objectStore("pins")
      await new Promise((resolve, reject) => {
        const clearReq = store1.clear()
        clearReq.onsuccess = () => resolve(undefined)
        clearReq.onerror = () => reject(clearReq.error)
      })
      console.log("[v0] ✓ Cleared old IndexedDB entries")

      await savePinToIndexedDB(db, pinData)
      console.log("[v0] ✓ PIN saved to IndexedDB (Layer 3)")
    } catch (err) {
      console.warn("[v0] IndexedDB save failed:", err)
    }

    // Layer 4: Pi SDK secure storage (if available)
    try {
      if (typeof window !== "undefined" && (window as any).Pi) {
        await (window as any).Pi.storage.setSecure("userPinHash", JSON.stringify(pinData), {
          persistent: true,
          clearOnClose: false,
        })
        await (window as any).Pi.storage.sync()
        console.log("[v0] ✓ PIN saved to Pi SDK (Layer 4)")
      }
    } catch (err) {
      console.warn("[v0] Pi SDK storage failed:", err)
    }

    await new Promise((resolve) => setTimeout(resolve, 50))

    const verifyLocal = localStorage.getItem(PIN_HASH_KEY)
    const verifySession = sessionStorage.getItem(PIN_HASH_KEY)

    if (!verifyLocal || !verifySession) {
      console.error("[v0] ✗✗✗ CRITICAL: PIN verification FAILED - not in storage")
      throw new Error("PIN không được lưu - vui lòng thử lại")
    }

    const parsedLocal = JSON.parse(verifyLocal)
    const parsedSession = JSON.parse(verifySession)

    if (parsedLocal.pinHash !== pinHash || parsedSession.pinHash !== pinHash) {
      console.error("[v0] ✗✗✗ CRITICAL: PIN hash mismatch")
      console.error("[v0] Expected:", pinHash.substring(0, 10) + "...")
      console.error("[v0] Got localStorage:", parsedLocal.pinHash.substring(0, 10) + "...")
      console.error("[v0] Got sessionStorage:", parsedSession.pinHash.substring(0, 10) + "...")
      throw new Error("PIN hash không khớp - vui lòng thử lại")
    }

    if (parsedLocal.version !== pinVersion || parsedSession.version !== pinVersion) {
      console.error("[v0] ✗✗✗ CRITICAL: PIN version mismatch")
      throw new Error("PIN version không khớp - vui lòng thử lại")
    }

    console.log("[v0] ====================================")
    console.log("[v0] ✓✓✓ PIN SAVED & VERIFIED SUCCESSFULLY")
    console.log("[v0] ✓ Hash:", pinHash.substring(0, 10) + "...")
    console.log("[v0] ✓ Version:", pinVersion)
    console.log("[v0] ✓ Nonce:", pinNonce)
    console.log("[v0] ✓ ONLY THIS PIN WILL WORK FROM NOW ON")
    console.log("[v0] ✓ ALL OLD PINS ARE INVALID")
    console.log("[v0] ====================================")
  }
}

export async function getPinHash(): Promise<{
  pinHash: string
  address: string
  encryptedMnemonic: string
  version: number
  nonce: string
  createdAt: number
} | null> {
  if (typeof window !== "undefined") {
    console.log("[v0] ====================================")
    console.log("[v0] RETRIEVING PIN FROM STORAGE")

    let localData: string | null = null
    try {
      localData = localStorage.getItem(PIN_HASH_KEY)
    } catch (err) {
      console.error("[v0] localStorage read error:", err)
    }

    if (localData) {
      try {
        const parsed = JSON.parse(localData)
        console.log("[v0] ✓ PIN retrieved from localStorage")
        console.log("[v0] ✓ Hash:", parsed.pinHash.substring(0, 10) + "...")
        console.log("[v0] ✓ Version:", parsed.version)
        console.log("[v0] ✓ Nonce:", parsed.nonce)
        console.log("[v0] ✓ Saved at:", new Date(parsed.createdAt).toLocaleString())
        console.log("[v0] ====================================")
        return parsed
      } catch (err) {
        console.error("[v0] localStorage parse error:", err)
      }
    }

    // Layer 2: sessionStorage (backup)
    const sessionData = sessionStorage.getItem(PIN_HASH_KEY)
    if (sessionData) {
      try {
        const parsed = JSON.parse(sessionData)
        console.log("[v0] ⚠ PIN retrieved from sessionStorage - restoring to localStorage")
        localStorage.setItem(PIN_HASH_KEY, sessionData)
        console.log("[v0] ====================================")
        return parsed
      } catch (err) {
        console.error("[v0] sessionStorage parse error:", err)
      }
    }

    // Layer 3: IndexedDB (backup)
    try {
      const db = await openPinDatabase()
      const pinData = await getPinFromIndexedDB(db)
      if (pinData) {
        console.log("[v0] ⚠ PIN retrieved from IndexedDB - restoring to primary storage")
        const dataStr = JSON.stringify(pinData)
        localStorage.setItem(PIN_HASH_KEY, dataStr)
        sessionStorage.setItem(PIN_HASH_KEY, dataStr)
        console.log("[v0] ====================================")
        return pinData
      }
    } catch (err) {
      console.warn("[v0] IndexedDB retrieval failed:", err)
    }

    // Layer 4: Pi SDK secure storage (backup)
    try {
      if ((window as any).Pi) {
        const piData = await (window as any).Pi.storage.getSecure("userPinHash")
        if (piData) {
          const parsed = JSON.parse(piData)
          console.log("[v0] ⚠ PIN retrieved from Pi SDK - restoring to primary storage")
          localStorage.setItem(PIN_HASH_KEY, piData)
          sessionStorage.setItem(PIN_HASH_KEY, piData)
          console.log("[v0] ====================================")
          return parsed
        }
      }
    } catch (err) {
      console.warn("[v0] Pi SDK retrieval failed:", err)
    }

    console.error("[v0] ✗✗✗ NO PIN FOUND IN ANY STORAGE LAYER")
    console.log("[v0] ====================================")
  }
  return null
}

function openPinDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("OliviaPiMaskDB", 1)

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result
      if (!db.objectStoreNames.contains("pins")) {
        db.createObjectStore("pins", { keyPath: "id" })
      }
    }
  })
}

function savePinToIndexedDB(
  db: IDBDatabase,
  pinData: {
    pinHash: string
    address: string
    encryptedMnemonic: string
    version: number
    nonce: string
    createdAt: number
  },
): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["pins"], "readwrite")
    const store = transaction.objectStore("pins")
    const request = store.put({ id: "currentPin", ...pinData })

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}

function getPinFromIndexedDB(db: IDBDatabase): Promise<{
  pinHash: string
  address: string
  encryptedMnemonic: string
  version: number
  nonce: string
  createdAt: number
} | null> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["pins"], "readonly")
    const store = transaction.objectStore("pins")
    const request = store.get("currentPin")

    request.onerror = () => reject(request.error)
    request.onsuccess = () => {
      const result = request.result
      if (result) {
        const { id, ...pinData } = result
        resolve(pinData)
      } else {
        resolve(null)
      }
    }
  })
}

export async function resetPinHash() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(PIN_HASH_KEY)
    sessionStorage.removeItem(PIN_HASH_KEY)

    try {
      const db = await openPinDatabase()
      const transaction = db.transaction(["pins"], "readwrite")
      const store = transaction.objectStore("pins")
      store.delete("currentPin")
      console.log("[v0] PIN cleared from IndexedDB")
    } catch (err) {
      console.warn("[v0] IndexedDB clear failed:", err)
    }

    try {
      if ((window as any).Pi) {
        await (window as any).Pi.storage.removeSecure("userPinHash")
        await (window as any).Pi.storage.sync()
        console.log("[v0] PIN cleared from Pi SDK")
      }
    } catch (err) {
      console.warn("[v0] Pi SDK clear failed:", err)
    }

    console.log("[v0] PIN cleared from all storage layers")
  }
}

export function clearPinHash() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(PIN_HASH_KEY)
  }
}

export function saveBiometricEnabled(enabled: boolean) {
  if (typeof window !== "undefined") {
    console.log("[v0] Saving biometric enabled:", enabled)

    // Save to localStorage (primary)
    localStorage.setItem(BIOMETRIC_ENABLED_KEY, JSON.stringify(enabled))

    // Save to sessionStorage (backup 1)
    sessionStorage.setItem(BIOMETRIC_ENABLED_KEY, JSON.stringify(enabled))

    // Save to Pi SDK secure storage (backup 2)
    if ((window as any).Pi && (window as any).Pi.storage) {
      try {
        ;(window as any).Pi.storage.set(BIOMETRIC_ENABLED_KEY, JSON.stringify(enabled), {
          persistent: true,
          clearOnClose: false,
        })
      } catch (error) {
        console.warn("[v0] Pi SDK storage not available for biometric", error)
      }
    }

    // Verify save
    const saved = localStorage.getItem(BIOMETRIC_ENABLED_KEY)
    console.log("[v0] Biometric saved and verified:", saved === JSON.stringify(enabled))

    // Force storage sync
    try {
      window.dispatchEvent(new CustomEvent("biometric-changed", { detail: { enabled } }))
    } catch (e) {
      console.warn("[v0] Could not dispatch biometric event", e)
    }
  }
}

export const setBiometricEnabled = saveBiometricEnabled

export function getBiometricEnabled(): boolean {
  if (typeof window !== "undefined") {
    // Try localStorage first (primary)
    let data = localStorage.getItem(BIOMETRIC_ENABLED_KEY)
    if (data !== null) {
      console.log("[v0] Biometric from localStorage:", data)
      return JSON.parse(data)
    }

    // Try sessionStorage (backup 1)
    data = sessionStorage.getItem(BIOMETRIC_ENABLED_KEY)
    if (data !== null) {
      console.log("[v0] Biometric from sessionStorage, restoring to localStorage:", data)
      localStorage.setItem(BIOMETRIC_ENABLED_KEY, data)
      return JSON.parse(data)
    }

    // Try Pi SDK storage (backup 2)
    if ((window as any).Pi && (window as any).Pi.storage) {
      try {
        const piData = (window as any).Pi.storage.get(BIOMETRIC_ENABLED_KEY)
        if (piData !== null && piData !== undefined) {
          console.log("[v0] Biometric from Pi SDK, restoring to localStorage:", piData)
          const enabled = JSON.parse(piData)
          localStorage.setItem(BIOMETRIC_ENABLED_KEY, JSON.stringify(enabled))
          sessionStorage.setItem(BIOMETRIC_ENABLED_KEY, JSON.stringify(enabled))
          return enabled
        }
      } catch (error) {
        console.warn("[v0] Could not read from Pi SDK storage", error)
      }
    }

    console.log("[v0] No biometric setting found, defaulting to false")
    return false
  }
  return false
}

export function isBiometricEnabled(): boolean {
  return getBiometricEnabled()
}

export function getWalletAddress(): string | null {
  const walletData = getWalletData()
  return walletData ? walletData.address : null
}

export function savePinMemoryEnabled(enabled: boolean) {
  if (typeof window !== "undefined") {
    console.log("[v0] Saving PIN memory enabled:", enabled)
    localStorage.setItem(PIN_MEMORY_ENABLED_KEY, JSON.stringify(enabled))
  }
}

export function getPinMemoryEnabled(): boolean {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(PIN_MEMORY_ENABLED_KEY)
    // Default to true if biometric is available
    if (data === null) {
      return isBiometricAvailable()
    }
    return data ? JSON.parse(data) : false
  }
  return false
}

export function isBiometricAvailable(): boolean {
  if (typeof window !== "undefined") {
    // Check if Pi SDK biometric is available
    if ((window as any).Pi && (window as any).Pi.biometric) {
      return true
    }
    // Check for WebAuthn as fallback
    if ((window as any).PublicKeyCredential) {
      return true
    }
  }
  return false
}

// Simple XOR encryption (for demo purposes - use proper encryption in production)
export function simpleEncrypt(text: string, password: string): string {
  let result = ""
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ password.charCodeAt(i % password.length))
  }
  return btoa(result)
}

export function simpleDecrypt(encrypted: string, password: string): string {
  const text = atob(encrypted)
  let result = ""
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ password.charCodeAt(i % password.length))
  }
  return result
}

// Auto-lock time storage functions
export function saveAutoLockTime(minutes: string) {
  if (typeof window !== "undefined") {
    console.log("[v0] Saving Auto-lock time:", minutes)

    // Save to localStorage
    localStorage.setItem(AUTOLOCK_TIME_KEY, minutes)

    // Save to sessionStorage for backup
    sessionStorage.setItem(AUTOLOCK_TIME_KEY, minutes)

    // Try Pi SDK storage
    try {
      if ((window as any).Pi) {
        ;(window as any).Pi.createStorage("olivia_autolock", {
          persistent: true,
          clearOnClose: false,
        })
          .setItem("autolock_time", minutes)
          .then(() => console.log("[v0] Auto-lock time saved to Pi SDK"))
      }
    } catch (err) {
      console.log("[v0] Pi SDK storage not available for auto-lock:", err)
    }

    // Verify save
    const saved = localStorage.getItem(AUTOLOCK_TIME_KEY)
    console.log("[v0] Auto-lock time verified:", saved)

    return saved === minutes
  }
  return false
}

export function getAutoLockTime(): string | null {
  if (typeof window !== "undefined") {
    // Try localStorage first
    const time = localStorage.getItem(AUTOLOCK_TIME_KEY)

    if (time) {
      console.log("[v0] Auto-lock time loaded from localStorage:", time)
      return time
    }

    // Try sessionStorage backup
    const sessionTime = sessionStorage.getItem(AUTOLOCK_TIME_KEY)
    if (sessionTime) {
      console.log("[v0] Auto-lock time loaded from sessionStorage:", sessionTime)
      // Restore to localStorage
      localStorage.setItem(AUTOLOCK_TIME_KEY, sessionTime)
      return sessionTime
    }

    console.log("[v0] No Auto-lock time found (user hasn't set)")
    return null
  }
  return null
}
