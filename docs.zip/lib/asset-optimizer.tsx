/**
 * Asset optimization utilities for lightweight Olivia PiMask
 */

// Emoji alternatives for common icons
export const EMOJI_ICONS = {
  wallet: "👛",
  money: "💰",
  send: "📤",
  receive: "📥",
  scan: "📷",
  settings: "⚙️",
  security: "🔒",
  history: "📜",
  success: "✅",
  error: "❌",
  warning: "⚠️",
  info: "ℹ️",
  star: "⭐",
  fire: "🔥",
  rocket: "🚀",
  heart: "❤️",
  check: "✓",
  arrow_up: "↑",
  arrow_down: "↓",
  arrow_right: "→",
  arrow_left: "←",
}

// SVG icon templates (lightweight alternatives to PNG)
export const SVG_ICONS = {
  wallet: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/>
    <path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/>
    <path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>
  </svg>`,

  send: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="22" y1="2" x2="11" y2="13"/>
    <polygon points="22 2 15 22 11 13 2 9 22 2"/>
  </svg>`,

  receive: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <polyline points="9 11 12 14 22 4"/>
    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
  </svg>`,
}

// CSS gradients (alternatives to background images)
export const CSS_GRADIENTS = {
  purple_pink: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
  red_pink: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
  blue_purple: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
  orange_pink: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
  green_blue: "linear-gradient(135deg, #30cfd0 0%, #330867 100%)",
  pi_official: "linear-gradient(135deg, #9C27B0 0%, #E91E63 100%)",
}

/**
 * Check if data URL exceeds size limit
 */
export function checkDataUrlSize(dataUrl: string, maxSizeKB = 200): boolean {
  const sizeInBytes = dataUrl.length
  const sizeInKB = sizeInBytes / 1024
  return sizeInKB <= maxSizeKB
}

/**
 * Get size of data URL in KB
 */
export function getDataUrlSizeKB(dataUrl: string): number {
  return dataUrl.length / 1024
}

/**
 * Suggest lighter alternatives for heavy assets
 */
export function suggestLighterAlternative(fileSizeKB: number): string {
  if (fileSizeKB > 500) {
    return "💡 Tip: Ảnh rất nặng! Dùng ảnh nhỏ hơn hoặc icon emoji cho ví mượt hơn ❤️"
  } else if (fileSizeKB > 200) {
    return "💡 Tip: Ảnh hơi nặng! Nén xuống dưới 200KB sẽ tải nhanh hơn ❤️"
  }
  return "✓ Kích thước ảnh tốt! Ví sẽ chạy mượt mà ❤️"
}

/**
 * Remove unused animations to improve performance
 */
export function optimizeAnimations() {
  if (typeof document === "undefined") return

  // Check if user prefers reduced motion
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches

  if (prefersReducedMotion) {
    document.documentElement.style.setProperty("--animation-duration", "0s")
    console.log("[v0] Animations disabled - respecting user preference")
  }
}

/**
 * Preload critical CSS gradients (no image loading needed)
 */
export function preloadCriticalGradients() {
  // CSS gradients don't need preloading - they're instant!
  console.log("[v0] Using CSS gradients - no image loading needed ❤️")
}

/**
 * Convert PNG icon to emoji suggestion
 */
export function suggestEmojiForIcon(iconName: string): string {
  const normalized = iconName.toLowerCase().replace(/[-_]/g, "")

  const mapping: Record<string, string> = {
    wallet: "👛",
    money: "💰",
    coin: "🪙",
    send: "📤",
    receive: "📥",
    scan: "📷",
    qr: "📱",
    settings: "⚙️",
    gear: "⚙️",
    security: "🔒",
    lock: "🔒",
    unlock: "🔓",
    key: "🔑",
    history: "📜",
    list: "📋",
    success: "✅",
    check: "✓",
    error: "❌",
    warning: "⚠️",
    info: "ℹ️",
    star: "⭐",
    fire: "🔥",
    rocket: "🚀",
    heart: "❤️",
    user: "👤",
    profile: "👤",
    avatar: "👤",
  }

  return mapping[normalized] || "💎"
}

/**
 * Calculate optimal image dimensions for avatar
 */
export function getOptimalAvatarSize(originalWidth: number, originalHeight: number): { width: number; height: number } {
  const maxSize = 400 // Max 400x400 for avatars

  if (originalWidth <= maxSize && originalHeight <= maxSize) {
    return { width: originalWidth, height: originalHeight }
  }

  const scale = Math.min(maxSize / originalWidth, maxSize / originalHeight)
  return {
    width: Math.round(originalWidth * scale),
    height: Math.round(originalHeight * scale),
  }
}
