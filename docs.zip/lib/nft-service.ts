"use client"

export interface NFTAttribute {
  trait_type: string
  value: string
}

export interface NFT {
  id: string
  name: string
  collection: string
  image: string
  rarity: "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"
  tokenId: string
  description?: string
  attributes?: NFTAttribute[]
  contractAddress?: string
  owner?: string
  metadata?: any
}

class NFTService {
  private cache: Map<string, { data: NFT[]; timestamp: number }> = new Map()
  private readonly CACHE_TTL = 30000 // 30 seconds

  async fetchUserNFTs(walletAddress: string): Promise<NFT[]> {
    if (!walletAddress) return []

    // Check cache first
    const cached = this.cache.get(walletAddress)
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.data
    }

    try {
      // Try to use Pi SDK if available in Pi Browser
      if (typeof window !== "undefined" && (window as any).Pi) {
        const Pi = (window as any).Pi
        try {
          await Pi.init({ version: "2.0" })

          // Fetch NFTs using Pi SDK enumeration
          const nftData = await this.fetchFromPiMainnet(walletAddress)

          // Cache the result
          this.cache.set(walletAddress, { data: nftData, timestamp: Date.now() })
          return nftData
        } catch (piError) {
          console.error("[v0] Pi SDK error:", piError)
        }
      }

      // Fallback: Try Pi Network API endpoints
      const nfts = await this.fetchFromPiAPI(walletAddress)

      // Cache the result
      this.cache.set(walletAddress, { data: nfts, timestamp: Date.now() })
      return nfts
    } catch (error) {
      console.error("[v0] Failed to fetch NFTs:", error)
      return []
    }
  }

  private async fetchFromPiAPI(walletAddress: string): Promise<NFT[]> {
    try {
      // Pi Network Mainnet NFT API endpoint
      const response = await fetch(`https://api.minepi.com/v2/nft/owned/${walletAddress}`, {
        headers: {
          Accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }

      const data = await response.json()

      // Transform API response to NFT format
      return this.transformNFTData(data)
    } catch (error) {
      console.error("[v0] Pi API fetch error:", error)
      return []
    }
  }

  private async fetchFromPiMainnet(walletAddress: string): Promise<NFT[]> {
    try {
      const Pi = (window as any).Pi

      // Use Pi SDK to enumerate NFTs
      const nftContracts = await Pi.blockchain.getNFTsByAddress(walletAddress)

      const nfts: NFT[] = []

      for (const contract of nftContracts) {
        const metadata = await this.fetchNFTMetadata(contract.tokenURI)

        nfts.push({
          id: `${contract.contractAddress}-${contract.tokenId}`,
          name: metadata.name || `NFT #${contract.tokenId}`,
          collection: metadata.collection || "Unknown Collection",
          image: this.resolveIPFSUrl(metadata.image),
          rarity: this.determineRarity(metadata.attributes),
          tokenId: contract.tokenId,
          description: metadata.description,
          attributes: metadata.attributes,
          contractAddress: contract.contractAddress,
          owner: walletAddress,
          metadata: metadata,
        })
      }

      return nfts
    } catch (error) {
      console.error("[v0] Pi mainnet fetch error:", error)
      return []
    }
  }

  private transformNFTData(data: any): NFT[] {
    if (!data || !Array.isArray(data.nfts)) return []

    return data.nfts.map((item: any) => ({
      id: `${item.contract_address}-${item.token_id}`,
      name: item.name || `NFT #${item.token_id}`,
      collection: item.collection_name || "Unknown Collection",
      image: this.resolveIPFSUrl(item.image_url || item.metadata?.image),
      rarity: this.determineRarity(item.metadata?.attributes),
      tokenId: item.token_id,
      description: item.description || item.metadata?.description,
      attributes: item.metadata?.attributes || [],
      contractAddress: item.contract_address,
      owner: item.owner,
      metadata: item.metadata,
    }))
  }

  private async fetchNFTMetadata(tokenURI: string): Promise<any> {
    try {
      const url = this.resolveIPFSUrl(tokenURI)
      const response = await fetch(url)
      return await response.json()
    } catch (error) {
      console.error("[v0] Metadata fetch error:", error)
      return {}
    }
  }

  private resolveIPFSUrl(url: string): string {
    if (!url) return "/placeholder.svg?height=400&width=400"

    if (url.startsWith("ipfs://")) {
      return url.replace("ipfs://", "https://ipfs.io/ipfs/")
    }

    return url
  }

  private determineRarity(attributes?: NFTAttribute[]): NFT["rarity"] {
    if (!attributes || attributes.length === 0) return "Common"

    // Calculate rarity score based on attribute count and special traits
    const rarityKeywords = ["legendary", "epic", "rare", "uncommon", "common"]

    for (const attr of attributes) {
      const value = attr.value.toLowerCase()
      if (value.includes("legendary")) return "Legendary"
      if (value.includes("epic")) return "Epic"
      if (value.includes("rare")) return "Rare"
      if (value.includes("uncommon")) return "Uncommon"
    }

    // Fallback: more attributes = more rare
    if (attributes.length >= 8) return "Legendary"
    if (attributes.length >= 6) return "Epic"
    if (attributes.length >= 4) return "Rare"
    if (attributes.length >= 2) return "Uncommon"

    return "Common"
  }

  async refreshNFTs(walletAddress: string): Promise<NFT[]> {
    // Clear cache for this address
    this.cache.delete(walletAddress)
    return this.fetchUserNFTs(walletAddress)
  }

  clearCache() {
    this.cache.clear()
  }

  getCollections(nfts: NFT[]): string[] {
    const collections = new Set<string>()
    nfts.forEach((nft) => collections.add(nft.collection))
    return ["All", ...Array.from(collections)]
  }
}

export const nftService = new NFTService()
