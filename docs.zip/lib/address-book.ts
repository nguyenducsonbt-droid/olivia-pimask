interface Contact {
  id: string
  name: string
  address: string
  addedAt: number
  lastUsed?: number
}

interface RecentRecipient {
  address: string
  timestamp: number
  count: number
}

const STORAGE_KEY = "olivia_address_book"
const RECENT_KEY = "olivia_recent_recipients"

export function getContacts(): Contact[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY)
    return data ? JSON.parse(data) : []
  } catch {
    return []
  }
}

export function saveContact(name: string, address: string): Contact {
  const contacts = getContacts()
  const id = `contact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

  const newContact: Contact = {
    id,
    name,
    address,
    addedAt: Date.now(),
  }

  contacts.push(newContact)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(contacts))

  return newContact
}

export function deleteContact(id: string): void {
  const contacts = getContacts()
  const filtered = contacts.filter((c) => c.id !== id)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered))
}

export function updateContact(id: string, name: string, address: string): void {
  const contacts = getContacts()
  const index = contacts.findIndex((c) => c.id === id)

  if (index !== -1) {
    contacts[index] = {
      ...contacts[index],
      name,
      address,
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(contacts))
  }
}

export function getRecentRecipients(limit = 10): RecentRecipient[] {
  try {
    const data = localStorage.getItem(RECENT_KEY)
    const recent: RecentRecipient[] = data ? JSON.parse(data) : []
    return recent.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit)
  } catch {
    return []
  }
}

export function addRecentRecipient(address: string): void {
  try {
    const recent = getRecentRecipients(50) // Keep more in storage
    const existing = recent.find((r) => r.address === address)

    if (existing) {
      existing.timestamp = Date.now()
      existing.count += 1
    } else {
      recent.push({
        address,
        timestamp: Date.now(),
        count: 1,
      })
    }

    // Sort by most recent and keep top 50
    const sorted = recent.sort((a, b) => b.timestamp - a.timestamp).slice(0, 50)
    localStorage.setItem(RECENT_KEY, JSON.stringify(sorted))
  } catch (error) {
    console.error("Failed to save recent recipient:", error)
  }
}

export function findContactByAddress(address: string): Contact | undefined {
  const contacts = getContacts()
  return contacts.find((c) => c.address.toLowerCase() === address.toLowerCase())
}
