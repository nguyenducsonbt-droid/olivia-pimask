interface PiPrice {
  usd: number
  vnd: number
  change24h: number
  lastUpdated: number
}

const CACHE_KEY = "olivia_pi_price_cache"
const CACHE_DURATION = 2 * 60 * 1000 // 2 minutes

export async function fetchPiPrice(): Promise<PiPrice> {
  try {
    // Check cache first
    const cached = getCachedPrice()
    if (cached && Date.now() - cached.lastUpdated < CACHE_DURATION) {
      return cached
    }

    // Fetch from CoinGecko API
    const response = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd&include_24hr_change=true",
      {
        headers: {
          Accept: "application/json",
        },
      },
    )

    if (!response.ok) {
      throw new Error("Failed to fetch Pi price")
    }

    const data = await response.json()
    const usd = data["pi-network"]?.usd || 0
    const change24h = data["pi-network"]?.usd_24h_change || 0

    // Convert USD to VND (approximate rate: 1 USD = 24,000 VND)
    const vnd = usd * 24000

    const priceData: PiPrice = {
      usd,
      vnd,
      change24h,
      lastUpdated: Date.now(),
    }

    // Cache the result
    localStorage.setItem(CACHE_KEY, JSON.stringify(priceData))

    return priceData
  } catch (error) {
    console.error("Failed to fetch Pi price:", error)

    // Return cached data if available, otherwise return defaults
    const cached = getCachedPrice()
    if (cached) {
      return cached
    }

    return {
      usd: 0,
      vnd: 0,
      change24h: 0,
      lastUpdated: Date.now(),
    }
  }
}

function getCachedPrice(): PiPrice | null {
  try {
    const cached = localStorage.getItem(CACHE_KEY)
    return cached ? JSON.parse(cached) : null
  } catch {
    return null
  }
}

export function subscribeToPriceUpdates(callback: (price: PiPrice) => void): () => void {
  let intervalId: NodeJS.Timeout

  const update = async () => {
    const price = await fetchPiPrice()
    callback(price)
  }

  // Initial fetch
  update()

  // Update every 2 minutes
  intervalId = setInterval(update, CACHE_DURATION)

  // Return cleanup function
  return () => {
    clearInterval(intervalId)
  }
}
