// Email OTP utilities for Two-Factor Authentication

interface EmailOTPData {
  email: string
  enabled: boolean
  createdAt: number
}

const EMAIL_OTP_KEY = "olivia_email_otp_data"
const OTP_STORAGE_KEY = "olivia_otp_temp"

// Save email OTP data
export function saveEmailOTPData(email: string, enabled: boolean) {
  if (typeof window !== "undefined") {
    const data: EmailOTPData = {
      email,
      enabled,
      createdAt: Date.now(),
    }
    localStorage.setItem(EMAIL_OTP_KEY, JSON.stringify(data))
  }
}

// Get email OTP data
export function getEmailOTPData(): EmailOTPData | null {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(EMAIL_OTP_KEY)
    return data ? JSON.parse(data) : null
  }
  return null
}

// Check if email OTP is enabled
export function isEmailOTPEnabled(): boolean {
  const data = getEmailOTPData()
  return data?.enabled || false
}

// Disable email OTP
export function disableEmailOTP() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(EMAIL_OTP_KEY)
    localStorage.removeItem(OTP_STORAGE_KEY)
  }
}

// Generate 6-digit OTP
export function generateOTP(): string {
  const otp = Math.floor(100000 + Math.random() * 900000)
  return otp.toString()
}

// Send OTP via email (demo version - simulated)
export async function sendEmailOTP(email: string): Promise<{ success: boolean; otp?: string; error?: string }> {
  try {
    // In production, this would call a backend API to send the email
    // For demo purposes, we'll generate and store the OTP locally
    const otp = generateOTP()

    // Store OTP with expiration (5 minutes)
    const otpData = {
      otp,
      email,
      expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
      attempts: 0,
    }

    if (typeof window !== "undefined") {
      localStorage.setItem(OTP_STORAGE_KEY, JSON.stringify(otpData))
    }

    // Simulate email sending delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // In demo, we'll show the OTP in console for testing
    console.log(`[v0] Email OTP sent to ${email}: ${otp}`)

    return { success: true, otp } // In production, don't return OTP
  } catch (error) {
    console.error("[v0] Error sending email OTP:", error)
    return { success: false, error: "Không thể gửi mã OTP" }
  }
}

// Verify email OTP
export function verifyEmailOTP(otp: string): { success: boolean; error?: string } {
  if (typeof window === "undefined") {
    return { success: false, error: "Invalid environment" }
  }

  const data = localStorage.getItem(OTP_STORAGE_KEY)
  if (!data) {
    return { success: false, error: "Không tìm thấy mã OTP" }
  }

  const otpData = JSON.parse(data)

  // Check expiration
  if (Date.now() > otpData.expiresAt) {
    localStorage.removeItem(OTP_STORAGE_KEY)
    return { success: false, error: "Mã OTP đã hết hạn" }
  }

  // Check attempts
  if (otpData.attempts >= 3) {
    localStorage.removeItem(OTP_STORAGE_KEY)
    return { success: false, error: "Quá số lần thử" }
  }

  // Verify OTP
  if (otp === otpData.otp) {
    localStorage.removeItem(OTP_STORAGE_KEY)
    return { success: true }
  }

  // Increment attempts
  otpData.attempts += 1
  localStorage.setItem(OTP_STORAGE_KEY, JSON.stringify(otpData))

  return { success: false, error: "Mã OTP không đúng" }
}

// Get remaining OTP time
export function getOTPExpirationTime(): number | null {
  if (typeof window === "undefined") return null

  const data = localStorage.getItem(OTP_STORAGE_KEY)
  if (!data) return null

  const otpData = JSON.parse(data)
  const remaining = Math.max(0, otpData.expiresAt - Date.now())

  return remaining
}
