// Two-Factor Authentication utilities using TOTP (Time-based One-Time Password)

interface TwoFactorData {
  secret: string
  enabled: boolean
  backupCodes: string[]
  createdAt: number
}

const TWO_FACTOR_KEY = "olivia_2fa_data"

// Generate a random base32 secret for Google Authenticator
export function generateTwoFactorSecret(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
  let secret = ""
  const array = new Uint8Array(20)
  crypto.getRandomValues(array)

  for (let i = 0; i < array.length; i++) {
    secret += chars[array[i] % chars.length]
  }

  return secret
}

// Generate backup codes (8 codes, 8 characters each)
export function generateBackupCodes(): string[] {
  const codes: string[] = []
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

  for (let i = 0; i < 8; i++) {
    let code = ""
    const array = new Uint8Array(8)
    crypto.getRandomValues(array)

    for (let j = 0; j < array.length; j++) {
      code += chars[array[j] % chars.length]
    }

    codes.push(code)
  }

  return codes
}

// Save 2FA data
export function saveTwoFactorData(secret: string, enabled: boolean, backupCodes: string[]) {
  if (typeof window !== "undefined") {
    const data: TwoFactorData = {
      secret,
      enabled,
      backupCodes,
      createdAt: Date.now(),
    }
    localStorage.setItem(TWO_FACTOR_KEY, JSON.stringify(data))
  }
}

// Get 2FA data
export function getTwoFactorData(): TwoFactorData | null {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(TWO_FACTOR_KEY)
    return data ? JSON.parse(data) : null
  }
  return null
}

// Check if 2FA is enabled
export function isTwoFactorEnabled(): boolean {
  const data = getTwoFactorData()
  return data?.enabled || false
}

// Disable 2FA
export function disableTwoFactor() {
  if (typeof window !== "undefined") {
    localStorage.removeItem(TWO_FACTOR_KEY)
  }
}

// Verify TOTP token
export async function verifyTOTP(token: string, secret: string): Promise<boolean> {
  try {
    // Get current time step (30 second intervals)
    const timeStep = Math.floor(Date.now() / 30000)

    // Check current time window and adjacent windows (±1 for clock drift)
    for (let window = -1; window <= 1; window++) {
      const expectedToken = await generateTOTP(secret, timeStep + window)
      if (token === expectedToken) {
        return true
      }
    }

    return false
  } catch (error) {
    console.error("[v0] TOTP verification error:", error)
    return false
  }
}

// Generate TOTP token for a given time step
async function generateTOTP(secret: string, timeStep: number): Promise<string> {
  // Convert base32 secret to bytes
  const secretBytes = base32Decode(secret)

  // Convert time step to 8-byte array
  const timeBytes = new ArrayBuffer(8)
  const timeView = new DataView(timeBytes)
  timeView.setUint32(4, timeStep, false)

  // Import secret as HMAC key
  const key = await crypto.subtle.importKey("raw", secretBytes, { name: "HMAC", hash: "SHA-1" }, false, ["sign"])

  // Generate HMAC
  const signature = await crypto.subtle.sign("HMAC", key, timeBytes)
  const signatureArray = new Uint8Array(signature)

  // Dynamic truncation
  const offset = signatureArray[19] & 0xf
  const binary =
    ((signatureArray[offset] & 0x7f) << 24) |
    ((signatureArray[offset + 1] & 0xff) << 16) |
    ((signatureArray[offset + 2] & 0xff) << 8) |
    (signatureArray[offset + 3] & 0xff)

  // Generate 6-digit code
  const otp = binary % 1000000
  return otp.toString().padStart(6, "0")
}

// Base32 decode
function base32Decode(base32: string): Uint8Array {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
  const cleanedInput = base32.toUpperCase().replace(/=+$/, "")

  let bits = 0
  let value = 0
  const output: number[] = []

  for (let i = 0; i < cleanedInput.length; i++) {
    const idx = alphabet.indexOf(cleanedInput[i])
    if (idx === -1) throw new Error("Invalid base32 character")

    value = (value << 5) | idx
    bits += 5

    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 0xff)
      bits -= 8
    }
  }

  return new Uint8Array(output)
}

// Verify backup code
export function verifyBackupCode(code: string): boolean {
  const data = getTwoFactorData()
  if (!data) return false

  const codeIndex = data.backupCodes.indexOf(code.toUpperCase())
  if (codeIndex === -1) return false

  // Remove used backup code
  data.backupCodes.splice(codeIndex, 1)
  saveTwoFactorData(data.secret, data.enabled, data.backupCodes)

  return true
}

// Get QR code URL for Google Authenticator
export function getTwoFactorQRCodeURL(secret: string, username: string): string {
  const issuer = "Olivia PiMask"
  const label = `${issuer}:${username}`
  const otpauthURL = `otpauth://totp/${encodeURIComponent(label)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}`

  // Use QR code generation service
  return `https://api.qrserver.com/v1/create-qr-code/?size=256x256&data=${encodeURIComponent(otpauthURL)}`
}

export function isAny2FAEnabled(): boolean {
  const googleAuth = isTwoFactorEnabled()

  // Check email OTP
  if (typeof window !== "undefined") {
    const emailData = localStorage.getItem("olivia_email_otp_data")
    if (emailData) {
      const data = JSON.parse(emailData)
      if (data.enabled) return true
    }
  }

  return googleAuth
}
