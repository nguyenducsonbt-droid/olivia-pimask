import { ethers } from "ethers"
import * as StellarSdk from "stellar-sdk"
import * as bip39 from "bip39"

export interface Network {
  id: string
  name: string
  rpcUrl: string
  chainId: number
  symbol: string
  explorerUrl?: string
}

export interface Token {
  address: string
  name: string
  symbol: string
  decimals: number
  balance?: string
  network: string
  isPIMask?: boolean
  privacyMode?: boolean
  theme?: "default" | "white"
}

export interface Transaction {
  hash: string
  from: string
  to: string
  value: string
  timestamp: number
  status: "pending" | "confirmed" | "failed"
  network: string
}

export const DEFAULT_NETWORKS: Network[] = [
  {
    id: "ethereum",
    name: "Ethereum",
    rpcUrl: "https://eth.llamarpc.com",
    chainId: 1,
    symbol: "ETH",
    explorerUrl: "https://etherscan.io",
  },
  {
    id: "pi-mainnet",
    name: "Pi Mainnet",
    rpcUrl: "https://api.mainnet.pi.network",
    chainId: 314159,
    symbol: "PI",
    explorerUrl: "https://blockexplorer.pi.network",
  },
  {
    id: "pi-testnet",
    name: "Pi Testnet",
    rpcUrl: "https://api.testnet.pi.network",
    chainId: 314,
    symbol: "PI",
    explorerUrl: "https://blockexplorer.testnet.pi.network",
  },
  {
    id: "bsc-testnet",
    name: "BSC Testnet",
    rpcUrl: "https://data-seed-prebsc-1-s1.binance.org:8545",
    chainId: 97,
    symbol: "BNB",
    explorerUrl: "https://testnet.bscscan.com",
  },
  {
    id: "polygon",
    name: "Polygon",
    rpcUrl: "https://polygon-rpc.com",
    chainId: 137,
    symbol: "MATIC",
    explorerUrl: "https://polygonscan.com",
  },
  {
    id: "solana",
    name: "Solana",
    rpcUrl: "https://api.mainnet-beta.solana.com",
    chainId: 1399811149, // Solana doesn't use EVM chain IDs, using a placeholder
    symbol: "SOL",
    explorerUrl: "https://explorer.solana.com",
  },
  {
    id: "bitcoin",
    name: "Bitcoin",
    rpcUrl: "https://bitcoin.llamarpc.com", // Placeholder, Bitcoin doesn't have traditional RPC
    chainId: 0, // Bitcoin doesn't use chain IDs
    symbol: "BTC",
    explorerUrl: "https://blockchair.com/bitcoin",
  },
  {
    id: "arbitrum",
    name: "Arbitrum",
    rpcUrl: "https://arb1.arbitrum.io/rpc",
    chainId: 42161,
    symbol: "ETH",
    explorerUrl: "https://arbiscan.io",
  },
  {
    id: "optimism",
    name: "Optimism",
    rpcUrl: "https://mainnet.optimism.io",
    chainId: 10,
    symbol: "ETH",
    explorerUrl: "https://optimistic.etherscan.io",
  },
  {
    id: "base",
    name: "Base",
    rpcUrl: "https://mainnet.base.org",
    chainId: 8453,
    symbol: "ETH",
    explorerUrl: "https://basescan.org",
  },
  {
    id: "linea",
    name: "Linea",
    rpcUrl: "https://rpc.linea.build",
    chainId: 59144,
    symbol: "ETH",
    explorerUrl: "https://lineascan.build",
  },
]

export function validateMnemonic(mnemonic: string): boolean {
  try {
    // Step 1: Trim whitespace and convert to lowercase
    const trimmed = mnemonic.trim()
    const words = trimmed.split(/\s+/).map((word) => word.toLowerCase())

    // Step 2: Check word count (must be exactly 24 words)
    if (words.length !== 24 && words.length !== 12) {
      console.error("[v0] Invalid word count:", words.length)
      return false
    }

    // Step 3: Get BIP39 English wordlist (2048 words)
    const wordlist = bip39.wordlists.EN

    // Step 4: Validate each word is in BIP39 wordlist
    for (let i = 0; i < words.length; i++) {
      if (!wordlist.includes(words[i])) {
        console.error(`[v0] Invalid word at position ${i + 1}: "${words[i]}"`)
        return false
      }
    }

    // Step 5: Validate checksum using bip39 library (includes full BIP39 spec validation)
    const normalizedMnemonic = words.join(" ")
    const isValidChecksum = bip39.validateMnemonic(normalizedMnemonic)

    if (!isValidChecksum) {
      console.error("[v0] Invalid BIP39 checksum")
      return false
    }

    return true
  } catch (error) {
    console.error("[v0] Mnemonic validation error:", error)
    return false
  }
}

export function validateMnemonicDetailed(mnemonic: string): {
  isValid: boolean
  error?: string
  wordCount?: number
  invalidWords?: string[]
} {
  try {
    // Step 1: Trim and split
    const trimmed = mnemonic.trim()
    const words = trimmed.split(/\s+/).map((word) => word.toLowerCase())

    // Step 2: Check word count
    if (words.length !== 12 && words.length !== 24) {
      return {
        isValid: false,
        error: `Cần đúng 12 hoặc 24 từ. Bạn đã nhập ${words.length} từ.`,
        wordCount: words.length,
      }
    }

    // Step 3: Get BIP39 wordlist
    const wordlist = bip39.wordlists.EN
    const invalidWords: string[] = []

    // Step 4: Check each word
    for (let i = 0; i < words.length; i++) {
      if (!wordlist.includes(words[i])) {
        invalidWords.push(`Từ ${i + 1}: "${words[i]}"`)
      }
    }

    if (invalidWords.length > 0) {
      return {
        isValid: false,
        error: `Từ không hợp lệ: ${invalidWords.join(", ")}`,
        invalidWords: invalidWords,
      }
    }

    // Step 5: Validate checksum
    const normalizedMnemonic = words.join(" ")
    const isValidChecksum = bip39.validateMnemonic(normalizedMnemonic)

    if (!isValidChecksum) {
      return {
        isValid: false,
        error: "Seed phrase không hợp lệ! Kiểm tra chính tả, từ sai hoặc checksum.",
        wordCount: words.length,
      }
    }

    return {
      isValid: true,
      wordCount: words.length,
    }
  } catch (error) {
    console.error("[v0] Detailed validation error:", error)
    return {
      isValid: false,
      error: "Lỗi khi kiểm tra seed phrase. Vui lòng thử lại.",
    }
  }
}

export function generateMnemonic(): string {
  return ethers.Wallet.createRandom().mnemonic?.phrase || ""
}

export function getWalletFromMnemonic(mnemonic: string): ethers.HDNodeWallet {
  return ethers.Wallet.fromPhrase(mnemonic)
}

export function getPiAddressFromMnemonic(mnemonic: string): string {
  try {
    // Pi Network uses Stellar blockchain with BIP39/BIP44 derivation
    // Derivation path: m/44'/314159'/0' (314159 is Pi's coin type)

    // Convert mnemonic to seed
    const seed = bip39.mnemonicToSeedSync(mnemonic.trim())

    // Derive key using Pi Network's derivation path
    // For simplicity, we'll use first 32 bytes of derived seed
    const privateKeyBytes = seed.slice(0, 32)

    // Generate Stellar keypair from private key
    const keypair = StellarSdk.Keypair.fromRawEd25519Seed(privateKeyBytes)

    // Return public key (G... address)
    return keypair.publicKey()
  } catch (error) {
    console.error("[v0] Error generating Pi address:", error)
    throw new Error("Không thể tạo địa chỉ Pi từ seed phrase")
  }
}

export function validatePiAddress(address: string): boolean {
  try {
    // Trim whitespace
    const trimmedAddress = address?.trim()

    // Basic checks
    if (!trimmedAddress || typeof trimmedAddress !== "string") {
      return false
    }

    // Must start with G (Stellar public key prefix)
    if (!trimmedAddress.startsWith("G")) {
      return false
    }

    // Stellar addresses are typically 56 characters, but allow some flexibility (54-58 chars)
    const length = trimmedAddress.length
    if (length < 54 || length > 58) {
      return false
    }

    // Check that it only contains valid Base32 characters (A-Z, 2-7)
    // Stellar uses Base32 encoding for public keys
    const base32Regex = /^[A-Z2-7]+$/
    if (!base32Regex.test(trimmedAddress)) {
      return false
    }

    // If all basic checks pass, accept the address
    // We don't use strict Stellar SDK validation to be more lenient
    return true
  } catch (error) {
    console.error("[v0] Pi address validation error:", error)
    return false
  }
}

export function getProvider(rpcUrl: string): ethers.JsonRpcProvider {
  return new ethers.JsonRpcProvider(rpcUrl)
}

export async function getBalance(address: string, rpcUrl: string): Promise<string> {
  try {
    const provider = getProvider(rpcUrl)
    const balance = await provider.getBalance(address)
    return ethers.formatEther(balance)
  } catch (error) {
    console.error("[v0] Error getting balance:", error)
    return "0"
  }
}

export async function getTokenBalance(walletAddress: string, tokenAddress: string, rpcUrl: string): Promise<string> {
  try {
    const provider = getProvider(rpcUrl)
    const contract = new ethers.Contract(tokenAddress, ["function balanceOf(address) view returns (uint256)"], provider)
    const balance = await contract.balanceOf(walletAddress)
    return balance.toString()
  } catch (error) {
    console.error("[v0] Error getting token balance:", error)
    return "0"
  }
}

export async function getTokenInfo(
  tokenAddress: string,
  rpcUrl: string,
): Promise<{ name: string; symbol: string; decimals: number } | null> {
  try {
    const provider = getProvider(rpcUrl)
    const contract = new ethers.Contract(
      tokenAddress,
      [
        "function name() view returns (string)",
        "function symbol() view returns (string)",
        "function decimals() view returns (uint8)",
      ],
      provider,
    )
    const [name, symbol, decimals] = await Promise.all([contract.name(), contract.symbol(), contract.decimals()])
    return { name, symbol, decimals: Number(decimals) }
  } catch (error) {
    console.error("[v0] Error getting token info:", error)
    return null
  }
}

export async function sendTransaction(
  wallet: ethers.HDNodeWallet,
  to: string,
  amount: string,
  rpcUrl: string,
): Promise<string> {
  const provider = getProvider(rpcUrl)
  const connectedWallet = wallet.connect(provider)
  const tx = await connectedWallet.sendTransaction({
    to,
    value: ethers.parseEther(amount),
  })
  return tx.hash
}

export async function sendTokenTransaction(
  wallet: ethers.HDNodeWallet,
  tokenAddress: string,
  to: string,
  amount: string,
  decimals: number,
  rpcUrl: string,
): Promise<string> {
  const provider = getProvider(rpcUrl)
  const connectedWallet = wallet.connect(provider)
  const contract = new ethers.Contract(
    tokenAddress,
    ["function transfer(address to, uint256 amount) returns (bool)"],
    connectedWallet,
  )
  const tx = await contract.transfer(to, ethers.parseUnits(amount, decimals))
  return tx.hash
}

export async function getTransactionHistory(address: string, network: Network): Promise<Transaction[]> {
  try {
    const provider = getProvider(network.rpcUrl)

    // Try to get transaction history from Pi Chain API/Explorer
    // Since Pi Chain might not have a public API yet, we'll use ethers to get recent transactions
    const currentBlock = await provider.getBlockNumber()
    const transactions: Transaction[] = []

    // Check last 1000 blocks for transactions involving this address
    const blocksToCheck = Math.min(1000, currentBlock)
    const startBlock = Math.max(0, currentBlock - blocksToCheck)

    console.log(`[v0] Fetching transactions for ${address} from block ${startBlock} to ${currentBlock}`)

    // In a real implementation, we would use Pi Chain's block explorer API
    // For now, we'll simulate fetching transactions from the blockchain
    for (let i = 0; i < 10; i++) {
      const blockNumber = currentBlock - i * 100
      if (blockNumber < 0) break

      try {
        const block = await provider.getBlock(blockNumber, true)
        if (block && block.transactions) {
          for (const txHash of block.transactions) {
            if (typeof txHash === "string") {
              const tx = await provider.getTransaction(txHash)
              if (
                tx &&
                (tx.from.toLowerCase() === address.toLowerCase() || tx.to?.toLowerCase() === address.toLowerCase())
              ) {
                const receipt = await provider.getTransactionReceipt(txHash)
                transactions.push({
                  hash: tx.hash,
                  from: tx.from,
                  to: tx.to || "",
                  value: ethers.formatEther(tx.value),
                  timestamp: block.timestamp * 1000,
                  status: receipt?.status === 1 ? "confirmed" : "failed",
                  network: network.id,
                })
              }
            }
          }
        }
      } catch (error) {
        console.error(`[v0] Error fetching block ${blockNumber}:`, error)
      }
    }

    return transactions.sort((a, b) => b.timestamp - a.timestamp)
  } catch (error) {
    console.error("[v0] Error fetching transaction history:", error)
    return []
  }
}

export async function getTransactionDetails(txHash: string, rpcUrl: string) {
  try {
    const provider = getProvider(rpcUrl)
    const [tx, receipt] = await Promise.all([provider.getTransaction(txHash), provider.getTransactionReceipt(txHash)])

    if (!tx) return null

    return {
      transaction: tx,
      receipt,
      confirmations: receipt ? await receipt.confirmations() : 0,
    }
  } catch (error) {
    console.error("[v0] Error fetching transaction details:", error)
    return null
  }
}

export async function validateRpcUrl(rpcUrl: string, timeout = 3000): Promise<boolean> {
  try {
    const provider = getProvider(rpcUrl)

    // Create a promise that rejects after timeout
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("RPC validation timeout")), timeout),
    )

    // Race between getting block number and timeout
    const blockNumber = await Promise.race([provider.getBlockNumber(), timeoutPromise])

    return typeof blockNumber === "number" && blockNumber >= 0
  } catch (error) {
    console.error("[v0] RPC validation error:", error)
    return false
  }
}

export async function getPiBalance(piAddress: string): Promise<string> {
  try {
    console.log("[v0] Fetching Pi balance for:", piAddress)

    // Pi Network Mainnet uses Stellar Horizon API
    const horizonUrl = "https://api.mainnet.minepi.com"

    // Fetch account from Horizon
    const response = await fetch(`${horizonUrl}/accounts/${piAddress}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      if (response.status === 404) {
        // Account not found - new account with 0 balance
        console.log("[v0] Account not found, returning 0 balance")
        return "0.00"
      }
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    // Find native Pi balance
    const piBalance = data.balances?.find((b: any) => b.asset_type === "native" || b.asset_code === "PI")

    if (piBalance) {
      const balance = Number.parseFloat(piBalance.balance)
      return balance.toFixed(2)
    }

    return "0.00"
  } catch (error) {
    console.error("[v0] Error fetching Pi balance:", error)
    // Return 0 instead of throwing to prevent UI crash
    return "0.00"
  }
}

export async function sendPiTransaction(
  mnemonic: string,
  fromAddress: string,
  toAddress: string,
  amount: string,
): Promise<string> {
  try {
    console.log("[v0] Sending Pi transaction:", { fromAddress, toAddress, amount })

    // Validate inputs
    if (!toAddress.startsWith("G")) {
      throw new Error("Địa chỉ nhận không hợp lệ")
    }

    const amountNum = Number.parseFloat(amount)
    if (isNaN(amountNum) || amountNum <= 0) {
      throw new Error("Số lượng không hợp lệ")
    }

    // Get keypair from mnemonic
    const seed = bip39.mnemonicToSeedSync(mnemonic.trim())
    const privateKeyBytes = seed.slice(0, 32)
    const sourceKeypair = StellarSdk.Keypair.fromRawEd25519Seed(privateKeyBytes)

    // Configure Stellar SDK for Pi Network
    const server = new StellarSdk.Horizon.Server("https://api.mainnet.minepi.com")
    StellarSdk.Network.use(new StellarSdk.Networks.PUBLIC())

    // Load source account
    const sourceAccount = await server.loadAccount(sourceKeypair.publicKey())

    // Build transaction
    const transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
      fee: StellarSdk.BASE_FEE,
      networkPassphrase: StellarSdk.Networks.PUBLIC,
    })
      .addOperation(
        StellarSdk.Operation.payment({
          destination: toAddress,
          asset: StellarSdk.Asset.native(), // Pi is the native asset
          amount: amount,
        }),
      )
      .setTimeout(180)
      .build()

    // Sign transaction
    transaction.sign(sourceKeypair)

    // Submit transaction
    const result = await server.submitTransaction(transaction)

    console.log("[v0] Transaction successful:", result.hash)
    return result.hash
  } catch (error) {
    console.error("[v0] Error sending Pi transaction:", error)
    throw error
  }
}

export function getPiKeypairFromMnemonic(mnemonic: string): { publicKey: string; secretKey: string } | null {
  try {
    // Use stellar-sdk.Keypair.fromMnemonic with 'pi' passphrase
    const keypair = StellarSdk.Keypair.fromMnemonic(mnemonic.trim(), undefined, 0, "pi")

    return {
      publicKey: keypair.publicKey(),
      secretKey: keypair.secret(),
    }
  } catch (error) {
    console.error("[v0] Error deriving Pi keypair from mnemonic:", error)
    return null
  }
}

export function getPiKeypairFromSecret(secretKey: string): { publicKey: string; secretKey: string } | null {
  try {
    // Use stellar-sdk.Keypair.fromSecret to derive from private key
    const keypair = StellarSdk.Keypair.fromSecret(secretKey.trim())

    return {
      publicKey: keypair.publicKey(),
      secretKey: keypair.secret(),
    }
  } catch (error) {
    console.error("[v0] Error deriving Pi keypair from secret:", error)
    return null
  }
}
