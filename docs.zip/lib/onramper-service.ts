export interface OnramperConfig {
  apiKey: string
  defaultCrypto?: string
  defaultFiat?: string
  defaultAmount?: number
  walletAddress?: string
}

export interface OnramperTransaction {
  id: string
  status: "pending" | "processing" | "completed" | "failed"
  type: "onramp" | "offramp"
  fiatAmount: number
  fiatCurrency: string
  cryptoAmount: number
  cryptoCurrency: string
  provider: string
  walletAddress: string
  timestamp: number
  txHash?: string
}

export class OnramperService {
  private static readonly WIDGET_URL = "https://widget.onramper.com"
  private static readonly API_KEY = process.env.NEXT_PUBLIC_ONRAMPER_API_KEY || "pk_prod_01JQV8XXXXXXXXX" // Replace with real API key

  // Generate Onramper widget URL
  static getWidgetUrl(config: Partial<OnramperConfig> = {}): string {
    const params = new URLSearchParams({
      apiKey: config.apiKey || this.API_KEY,
      defaultCrypto: config.defaultCrypto || "PI",
      defaultFiat: config.defaultFiat || "USD",
      defaultAmount: String(config.defaultAmount || 100),
      onlyCryptos: "PI,ETH,USDT,USDC",
      supportSell: "true",
      supportSwap: "false",
      ...(config.walletAddress ? { wallets: `PI:${config.walletAddress}` } : {}),
    })

    return `${this.WIDGET_URL}?${params.toString()}`
  }

  // Save transaction to local storage
  static saveTransaction(transaction: OnramperTransaction): void {
    const transactions = this.getTransactions()
    transactions.unshift(transaction)
    if (transactions.length > 100) {
      transactions.length = 100
    }
    localStorage.setItem("olivia_onramper_transactions", JSON.stringify(transactions))
  }

  // Get all Onramper transactions
  static getTransactions(): OnramperTransaction[] {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem("olivia_onramper_transactions")
    return data ? JSON.parse(data) : []
  }

  // Get supported providers
  static getSupportedProviders(): string[] {
    return ["Onramp.money", "Transfi", "Banxa", "MoonPay", "Ramp", "Mercuryo"]
  }

  // Calculate estimated fees (approximate)
  static estimateFees(amount: number, provider: string): { fee: number; percentage: number } {
    const feeRates: Record<string, number> = {
      "Onramp.money": 0.015, // 1.5%
      Transfi: 0.02, // 2%
      Banxa: 0.025, // 2.5%
      MoonPay: 0.045, // 4.5%
      Ramp: 0.029, // 2.9%
      Mercuryo: 0.035, // 3.5%
    }

    const percentage = feeRates[provider] || 0.03
    const fee = amount * percentage

    return { fee, percentage }
  }

  // Handle widget events
  static handleWidgetEvent(
    event: MessageEvent,
    callbacks: {
      onSuccess?: (data: any) => void
      onError?: (error: any) => void
      onClose?: () => void
    },
  ): void {
    if (event.origin !== "https://widget.onramper.com") return

    const { type, data } = event.data

    switch (type) {
      case "onramper_transaction_completed":
        console.log("[v0] Onramper transaction completed:", data)
        callbacks.onSuccess?.(data)
        break
      case "onramper_transaction_failed":
        console.error("[v0] Onramper transaction failed:", data)
        callbacks.onError?.(data)
        break
      case "onramper_widget_closed":
        console.log("[v0] Onramper widget closed")
        callbacks.onClose?.()
        break
      default:
        console.log("[v0] Onramper event:", type, data)
    }
  }

  // Check if Onramper is available
  static isAvailable(): boolean {
    return !!this.API_KEY && this.API_KEY !== "pk_prod_01JQV8XXXXXXXXX"
  }
}

export default OnramperService
