export function triggerHaptic(type: "light" | "medium" | "heavy" = "light") {
  try {
    if (typeof window !== "undefined") {
      // Try Pi SDK haptic first
      if ((window as any).Pi?.haptic) {
        ;(window as any).Pi.haptic[type]()
        return
      }

      // Fallback to Vibration API
      if (navigator.vibrate) {
        const duration = type === "light" ? 10 : type === "medium" ? 20 : 30
        navigator.vibrate(duration)
      }
    }
  } catch (error) {
    // Silent fail
  }
}

export function triggerSuccessFeedback() {
  triggerHaptic("medium")

  // Optional: play success sound
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    oscillator.frequency.value = 800
    oscillator.type = "sine"

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.15)
  } catch (error) {
    // Silent fail
  }
}
