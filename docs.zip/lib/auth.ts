import { clearWalletData } from "./storage"

export function handleLogout() {
  clearWalletData()
  // Reload to go back to welcome screen
  window.location.reload()
}
