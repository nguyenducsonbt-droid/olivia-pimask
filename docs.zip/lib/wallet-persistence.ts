const WALLET_SEED_KEY = "olivia_wallet_seed_encrypted"
const WALLET_ADDRESS_KEY = "olivia_wallet_address"
const WALLET_BALANCE_KEY = "olivia_wallet_balance"

// Simple XOR encryption for seed phrase (for demo - use stronger encryption in production)
const encryptSeed = (seed: string, key = "olivia-pi-secure-2024"): string => {
  let result = ""
  for (let i = 0; i < seed.length; i++) {
    result += String.fromCharCode(seed.charCodeAt(i) ^ key.charCodeAt(i % key.length))
  }
  return btoa(result)
}

const decryptSeed = (encrypted: string, key = "olivia-pi-secure-2024"): string => {
  try {
    const decoded = atob(encrypted)
    let result = ""
    for (let i = 0; i < decoded.length; i++) {
      result += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length))
    }
    return result
  } catch (error) {
    console.error("[v0] Failed to decrypt seed:", error)
    return ""
  }
}

export const saveWalletSeed = async (seed: string): Promise<void> => {
  try {
    const encrypted = encryptSeed(seed)
    localStorage.setItem(WALLET_SEED_KEY, encrypted)
    console.log("[v0] Wallet seed encrypted and saved securely")
  } catch (error) {
    console.error("[v0] Failed to save wallet seed:", error)
    throw new Error("Không thể lưu seed phrase")
  }
}

export const loadWalletSeed = async (): Promise<string | null> => {
  try {
    const encrypted = localStorage.getItem(WALLET_SEED_KEY)
    if (!encrypted) {
      console.log("[v0] No wallet seed found in storage")
      return null
    }

    const decrypted = decryptSeed(encrypted)
    console.log("[v0] Wallet seed loaded and decrypted")
    return decrypted
  } catch (error) {
    console.error("[v0] Failed to load wallet seed:", error)
    return null
  }
}

export const hasStoredWallet = (): boolean => {
  return !!localStorage.getItem(WALLET_SEED_KEY)
}

export const saveWalletAddress = async (address: string): Promise<void> => {
  try {
    localStorage.setItem(WALLET_ADDRESS_KEY, address)
    console.log("[v0] Wallet address saved:", address)
  } catch (error) {
    console.error("[v0] Failed to save wallet address:", error)
  }
}

export const loadWalletAddress = async (): Promise<string | null> => {
  try {
    return localStorage.getItem(WALLET_ADDRESS_KEY)
  } catch (error) {
    console.error("[v0] Failed to load wallet address:", error)
    return null
  }
}

export const clearWallet = async (): Promise<void> => {
  try {
    localStorage.removeItem(WALLET_SEED_KEY)
    localStorage.removeItem(WALLET_ADDRESS_KEY)
    localStorage.removeItem(WALLET_BALANCE_KEY)
    console.log("[v0] Wallet data cleared")
  } catch (error) {
    console.error("[v0] Failed to clear wallet:", error)
  }
}
