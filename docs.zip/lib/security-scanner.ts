import { ethers } from "ethers"

export interface TransactionSimulation {
  success: boolean
  gasUsed: string
  balanceChange: string
  warnings: string[]
  riskLevel: "low" | "medium" | "high"
  estimatedCost: string
}

export interface ScamCheckResult {
  isScam: boolean
  riskScore: number // 0-100
  warnings: string[]
  category?: "phishing" | "honeypot" | "rugpull" | "fake-token" | "suspicious"
}

// Known scam patterns and suspicious URLs
const SCAM_PATTERNS = [
  /pancak.*swap.*claim/i,
  /uniswap.*airdrop/i,
  /metamask.*verify/i,
  /wallet.*connect.*urgent/i,
  /free.*crypto/i,
  /double.*your.*btc/i,
  /_airdrop\d+/i,
  /claim.*reward.*now/i,
]

const SUSPICIOUS_DOMAINS = [
  "bit.ly",
  "tinyurl.com",
  "t.co",
  // Add more suspicious shorteners
]

const KNOWN_SCAM_CONTRACTS = [
  // Add known scam contract addresses
  "0x0000000000000000000000000000000000000000",
]

export async function simulateTransaction(
  from: string,
  to: string,
  value: string,
  data: string,
  rpcUrl: string,
): Promise<TransactionSimulation> {
  const warnings: string[] = []
  let riskLevel: "low" | "medium" | "high" = "low"

  try {
    const provider = new ethers.JsonRpcProvider(rpcUrl)

    // Get current gas price
    const feeData = await provider.getFeeData()
    const gasPrice = feeData.gasPrice || ethers.parseUnits("50", "gwei")

    // Simulate the transaction
    const tx = {
      from,
      to,
      value: ethers.parseEther(value || "0"),
      data: data || "0x",
    }

    // Estimate gas
    const gasEstimate = await provider.estimateGas(tx)
    const estimatedCost = ethers.formatEther(gasEstimate * gasPrice)

    // Get balances before simulation
    const balanceBefore = await provider.getBalance(from)

    // Check for suspicious patterns
    if (to === "0x0000000000000000000000000000000000000000") {
      warnings.push("Gửi tiền đến địa chỉ null - giao dịch sẽ thất bại")
      riskLevel = "high"
    }

    if (KNOWN_SCAM_CONTRACTS.includes(to.toLowerCase())) {
      warnings.push("Địa chỉ nhận đã được đánh dấu là lừa đảo")
      riskLevel = "high"
    }

    // Check if sending large amount
    const valueInEther = Number.parseFloat(value || "0")
    const balanceInEther = Number.parseFloat(ethers.formatEther(balanceBefore))

    if (valueInEther > balanceInEther * 0.9) {
      warnings.push("Bạn đang gửi hơn 90% số dư - hãy cẩn thận")
      riskLevel = riskLevel === "high" ? "high" : "medium"
    }

    // Check for contract interaction
    const code = await provider.getCode(to)
    if (code !== "0x") {
      warnings.push("Đang tương tác với hợp đồng thông minh")

      // Check if it's a verified contract (in real implementation, check with block explorer API)
      if (data && data.length > 10) {
        warnings.push("Giao dịch chứa dữ liệu phức tạp - kiểm tra kỹ trước khi ký")
        riskLevel = riskLevel === "high" ? "high" : "medium"
      }
    }

    return {
      success: true,
      gasUsed: gasEstimate.toString(),
      balanceChange: value || "0",
      warnings,
      riskLevel,
      estimatedCost,
    }
  } catch (error: any) {
    warnings.push(`Mô phỏng thất bại: ${error.message}`)
    return {
      success: false,
      gasUsed: "0",
      balanceChange: "0",
      warnings,
      riskLevel: "high",
      estimatedCost: "0",
    }
  }
}

export async function checkDAppSecurity(url: string): Promise<ScamCheckResult> {
  const warnings: string[] = []
  let riskScore = 0

  try {
    // Parse URL
    const parsedUrl = new URL(url)
    const domain = parsedUrl.hostname.toLowerCase()

    // Check for suspicious patterns in URL
    for (const pattern of SCAM_PATTERNS) {
      if (pattern.test(url)) {
        warnings.push(`URL chứa từ khóa nghi ngờ: ${url.match(pattern)?.[0]}`)
        riskScore += 30
      }
    }

    // Check for URL shorteners
    if (SUSPICIOUS_DOMAINS.some((d) => domain.includes(d))) {
      warnings.push("URL sử dụng dịch vụ rút gọn link - có thể nguy hiểm")
      riskScore += 20
    }

    // Check for IP address instead of domain
    if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain)) {
      warnings.push("Sử dụng địa chỉ IP thay vì tên miền - rất nghi ngờ")
      riskScore += 40
    }

    // Check for HTTP instead of HTTPS
    if (parsedUrl.protocol === "http:") {
      warnings.push("Kết nối không bảo mật (HTTP) - hãy cẩn thận")
      riskScore += 25
    }

    // Check for suspicious TLD
    const suspiciousTLDs = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz"]
    if (suspiciousTLDs.some((tld) => domain.endsWith(tld))) {
      warnings.push("Tên miền sử dụng phần mở rộng miễn phí - thường dùng cho lừa đảo")
      riskScore += 30
    }

    // Check for lookalike domains
    const legitimateDomains = ["uniswap.org", "pancakeswap.finance", "aave.com", "compound.finance", "wallet.pi"]
    for (const legitimate of legitimateDomains) {
      if (domain !== legitimate && domain.includes(legitimate.replace(".", ""))) {
        warnings.push(`Tên miền giả mạo ${legitimate} - nguy hiểm cao`)
        riskScore += 50
      }
    }

    // Determine category
    let category: ScamCheckResult["category"] = undefined
    if (riskScore >= 60) {
      if (url.match(/phish|verify|urgent/i)) category = "phishing"
      else if (url.match(/claim|airdrop|reward/i)) category = "fake-token"
      else category = "suspicious"
    }

    return {
      isScam: riskScore >= 60,
      riskScore: Math.min(riskScore, 100),
      warnings,
      category,
    }
  } catch (error) {
    return {
      isScam: false,
      riskScore: 0,
      warnings: ["Không thể kiểm tra URL"],
    }
  }
}

export async function checkContractSecurity(contractAddress: string, rpcUrl: string): Promise<ScamCheckResult> {
  const warnings: string[] = []
  let riskScore = 0

  try {
    const provider = new ethers.JsonRpcProvider(rpcUrl)

    // Check if address is valid
    if (!ethers.isAddress(contractAddress)) {
      warnings.push("Địa chỉ hợp đồng không hợp lệ")
      return { isScam: true, riskScore: 100, warnings, category: "suspicious" }
    }

    // Check if it's a known scam
    if (KNOWN_SCAM_CONTRACTS.includes(contractAddress.toLowerCase())) {
      warnings.push("Hợp đồng này đã được xác nhận là lừa đảo")
      return { isScam: true, riskScore: 100, warnings, category: "rugpull" }
    }

    // Get contract code
    const code = await provider.getCode(contractAddress)

    if (code === "0x") {
      warnings.push("Không phải hợp đồng thông minh")
      riskScore += 10
    } else {
      // Check for honeypot patterns (simplified)
      if (code.includes("selfdestruct") || code.includes("delegatecall")) {
        warnings.push("Hợp đồng chứa code nguy hiểm (selfdestruct/delegatecall)")
        riskScore += 40
      }

      // Check contract size (very small or very large might be suspicious)
      const codeSize = (code.length - 2) / 2 // Remove 0x and convert hex to bytes
      if (codeSize < 100) {
        warnings.push("Hợp đồng quá nhỏ - có thể không hợp lệ")
        riskScore += 20
      }
    }

    // Check for recent creation (less than 7 days)
    // In real implementation, would query block explorer API for creation date

    return {
      isScam: riskScore >= 60,
      riskScore: Math.min(riskScore, 100),
      warnings,
      category: riskScore >= 60 ? "honeypot" : undefined,
    }
  } catch (error) {
    warnings.push("Không thể kiểm tra hợp đồng")
    return { isScam: false, riskScore: 10, warnings }
  }
}
