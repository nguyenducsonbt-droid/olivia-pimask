// Persistent storage utilities for avatar, balance visibility, and wallet name with multi-layer redundancy
const AVATAR_KEY = "@Olivia_avatar"
const AVATAR_BACKUP_KEY = "@Olivia_avatar_backup"
const AVATAR_SESSION_KEY = "@Olivia_avatar_session"
const WALLET_NAME_KEY = "@Olivia_walletName"
const HIDE_BAL_KEY = "olivia_hide_balance"
const PI_SESSION_KEY = "olivia_pi_session"
const PI_USER_KEY = "olivia_pi_user"
const DEFAULT_WALLET_NAME = "Olivia PiMask"

// Avatar storage with triple redundancy (localStorage + sessionStorage + IndexedDB backup)
export const saveAvatar = async (base64: string | null): Promise<void> => {
  try {
    // Layer 1: Primary localStorage
    if (base64 === null) {
      localStorage.removeItem(AVATAR_KEY)
      localStorage.removeItem(AVATAR_BACKUP_KEY)
      sessionStorage.removeItem(AVATAR_SESSION_KEY)
    } else {
      localStorage.setItem(AVATAR_KEY, base64)
      localStorage.setItem(AVATAR_BACKUP_KEY, base64) // Backup copy
      sessionStorage.setItem(AVATAR_SESSION_KEY, base64) // Session backup
    }

    // Layer 2: IndexedDB for persistence across sessions
    try {
      const db = await openAvatarDB()
      if (base64 === null) {
        await deleteAvatarFromDB(db)
      } else {
        await saveAvatarToDB(db, base64)
      }
    } catch (error) {
      console.warn("IndexedDB avatar save failed (fallback to localStorage):", error)
    }

    // Dispatch event for components to update
    window.dispatchEvent(new CustomEvent("olivia-avatar-changed", { detail: { avatar: base64 } }))

    // Verify save was successful
    const verified = localStorage.getItem(AVATAR_KEY)
    if (base64 !== null && verified !== base64) {
      console.error("Avatar save verification failed! Retrying...")
      localStorage.setItem(AVATAR_KEY, base64)
    }

    console.log(`[Olivia] Avatar saved successfully: ${base64 ? "Custom avatar" : "Default logo"}`)
  } catch (error) {
    console.error("Failed to save avatar:", error)
    throw error
  }
}

export const loadAvatar = async (): Promise<string | null> => {
  try {
    // Layer 1: Primary localStorage
    let avatar = localStorage.getItem(AVATAR_KEY)

    if (avatar) {
      console.log("[Olivia] Avatar loaded from primary storage")
      return avatar
    }

    // Layer 2: Backup localStorage
    avatar = localStorage.getItem(AVATAR_BACKUP_KEY)
    if (avatar) {
      console.log("[Olivia] Avatar restored from backup storage")
      // Restore to primary
      localStorage.setItem(AVATAR_KEY, avatar)
      return avatar
    }

    // Layer 3: Session storage
    avatar = sessionStorage.getItem(AVATAR_SESSION_KEY)
    if (avatar) {
      console.log("[Olivia] Avatar restored from session storage")
      // Restore to all layers
      localStorage.setItem(AVATAR_KEY, avatar)
      localStorage.setItem(AVATAR_BACKUP_KEY, avatar)
      return avatar
    }

    // Layer 4: IndexedDB
    try {
      const db = await openAvatarDB()
      avatar = await loadAvatarFromDB(db)
      if (avatar) {
        console.log("[Olivia] Avatar restored from IndexedDB")
        // Restore to all layers
        localStorage.setItem(AVATAR_KEY, avatar)
        localStorage.setItem(AVATAR_BACKUP_KEY, avatar)
        sessionStorage.setItem(AVATAR_SESSION_KEY, avatar)
        return avatar
      }
    } catch (error) {
      console.warn("IndexedDB avatar load failed:", error)
    }

    console.log("[Olivia] No avatar found, using default")
    return null
  } catch (error) {
    console.error("Failed to load avatar:", error)
    return null
  }
}

// IndexedDB helper functions for persistent avatar storage
function openAvatarDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("OliviaWallet", 1)

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result)

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result
      if (!db.objectStoreNames.contains("avatars")) {
        db.createObjectStore("avatars")
      }
    }
  })
}

function saveAvatarToDB(db: IDBDatabase, avatar: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["avatars"], "readwrite")
    const store = transaction.objectStore("avatars")
    const request = store.put(avatar, "current")

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}

function loadAvatarFromDB(db: IDBDatabase): Promise<string | null> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["avatars"], "readonly")
    const store = transaction.objectStore("avatars")
    const request = store.get("current")

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve(request.result || null)
  })
}

function deleteAvatarFromDB(db: IDBDatabase): Promise<void> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["avatars"], "readwrite")
    const store = transaction.objectStore("avatars")
    const request = store.delete("current")

    request.onerror = () => reject(request.error)
    request.onsuccess = () => resolve()
  })
}

export const saveWalletName = (name: string): void => {
  try {
    localStorage.setItem(WALLET_NAME_KEY, name)

    // Dispatch event for components to update
    window.dispatchEvent(new CustomEvent("olivia-wallet-name-changed", { detail: { name } }))
  } catch (error) {
    console.error("Failed to save wallet name:", error)
  }
}

export const loadWalletName = (): string => {
  try {
    const name = localStorage.getItem(WALLET_NAME_KEY)
    return name || DEFAULT_WALLET_NAME
  } catch (error) {
    console.error("Failed to load wallet name:", error)
    return DEFAULT_WALLET_NAME
  }
}

export const saveHideBal = (hidden: boolean): void => {
  try {
    localStorage.setItem(HIDE_BAL_KEY, hidden.toString())
    // Dispatch event for components to update
    window.dispatchEvent(new CustomEvent("olivia-balance-visibility-changed", { detail: { hidden } }))
  } catch (error) {
    console.error("Failed to save hide balance state:", error)
  }
}

export const loadHideBal = (): boolean => {
  try {
    const val = localStorage.getItem(HIDE_BAL_KEY)
    // Default to false (show balance) if never set before
    return val === null ? false : val === "true"
  } catch (error) {
    console.error("Failed to load hide balance state:", error)
    return false
  }
}

// Pi Network session storage functions
export const savePiSession = (session: { accessToken: string; user: any; scopes?: string[] }): void => {
  try {
    const sessionStr = JSON.stringify(session)
    localStorage.setItem(PI_SESSION_KEY, sessionStr)
    localStorage.setItem(PI_USER_KEY, JSON.stringify(session.user))

    // Save scopes separately for quick access
    if (session.scopes) {
      localStorage.setItem("olivia_pi_scopes", JSON.stringify(session.scopes))
    }
  } catch (error) {
    console.error("Failed to save Pi session:", error)
  }
}

export const loadPiSession = (): { accessToken: string; user: any; scopes?: string[] } | null => {
  try {
    const sessionStr = localStorage.getItem(PI_SESSION_KEY)
    if (sessionStr) {
      const session = JSON.parse(sessionStr)

      // Add scopes if not in session but stored separately
      if (!session.scopes) {
        const scopesStr = localStorage.getItem("olivia_pi_scopes")
        if (scopesStr) {
          session.scopes = JSON.parse(scopesStr)
        }
      }

      return session
    }
    return null
  } catch (error) {
    console.error("Failed to load Pi session:", error)
    return null
  }
}

export const clearPiSession = (): void => {
  try {
    localStorage.removeItem(PI_SESSION_KEY)
    localStorage.removeItem(PI_USER_KEY)
    localStorage.removeItem("olivia_pi_scopes")
  } catch (error) {
    console.error("Failed to clear Pi session:", error)
  }
}

export const hasPaymentsScope = (): boolean => {
  try {
    const session = loadPiSession()
    if (!session || !session.scopes) {
      return false
    }
    return session.scopes.includes("payments")
  } catch (error) {
    console.error("Failed to check payments scope:", error)
    return false
  }
}

export const requestPaymentsScope = async (): Promise<boolean> => {
  try {
    if (typeof window === "undefined" || !(window as any).Pi) {
      throw new Error("Pi SDK không khả dụng")
    }

    const Pi = (window as any).Pi
    const authResult = await Pi.authenticate(["username", "payments", "wallet_address"], (payment: any) => {
      console.log("Incomplete payment found:", payment)
    })

    if (authResult && authResult.user) {
      // Save session with scopes
      savePiSession({
        accessToken: authResult.accessToken,
        user: authResult.user,
        scopes: ["username", "payments", "wallet_address"],
      })

      // Dispatch update event
      window.dispatchEvent(
        new CustomEvent("olivia-pi-session-changed", {
          detail: {
            user: authResult.user,
            accessToken: authResult.accessToken,
            scopes: ["username", "payments", "wallet_address"],
          },
        }),
      )

      return true
    }

    return false
  } catch (error: any) {
    console.error("Failed to request payments scope:", error)

    // User cancelled is not an error
    if (error.message?.includes("user_cancelled")) {
      return false
    }

    throw error
  }
}

export { getWalletData } from "./storage"
