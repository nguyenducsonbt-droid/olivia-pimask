import type { CrossBorderTransfer, ExchangeRate, Country } from "@/types/cross-border"

const CROSS_BORDER_STORAGE_KEY = "olivia_cross_border_transfers"
const EXCHANGE_RATE_CACHE_KEY = "olivia_exchange_rates"
const CACHE_DURATION = 30000 // 30 seconds

export const SUPPORTED_COUNTRIES: Country[] = [
  {
    code: "VN",
    name: "Vietnam",
    flag: "🇻🇳",
    currency: "VND",
    supported: true,
    paymentMethods: ["VNPay", "ZaloPay", "Momo", "Bank Transfer"],
    piEnabled: true,
  },
  {
    code: "US",
    name: "United States",
    flag: "🇺🇸",
    currency: "USD",
    supported: true,
    paymentMethods: ["Bank Transfer", "Wire"],
    piEnabled: true,
  },
  {
    code: "PH",
    name: "Philippines",
    flag: "🇵🇭",
    currency: "PHP",
    supported: true,
    paymentMethods: ["GCash", "PayMaya", "Bank Transfer"],
    piEnabled: true,
  },
  {
    code: "IN",
    name: "India",
    flag: "🇮🇳",
    currency: "INR",
    supported: true,
    paymentMethods: ["UPI", "Bank Transfer"],
    piEnabled: true,
  },
  {
    code: "SG",
    name: "Singapore",
    flag: "🇸🇬",
    currency: "SGD",
    supported: true,
    paymentMethods: ["PayNow", "Bank Transfer"],
    piEnabled: true,
  },
  {
    code: "MY",
    name: "Malaysia",
    flag: "🇲🇾",
    currency: "MYR",
    supported: true,
    paymentMethods: ["Bank Transfer", "Touch 'n Go"],
    piEnabled: true,
  },
  {
    code: "TH",
    name: "Thailand",
    flag: "🇹🇭",
    currency: "THB",
    supported: true,
    paymentMethods: ["PromptPay", "Bank Transfer"],
    piEnabled: true,
  },
  {
    code: "ID",
    name: "Indonesia",
    flag: "🇮🇩",
    currency: "IDR",
    supported: true,
    paymentMethods: ["GoPay", "OVO", "Bank Transfer"],
    piEnabled: true,
  },
]

export class CrossBorderService {
  private static cachedRates: Map<string, { rate: ExchangeRate; timestamp: number }> = new Map()

  // Fetch real-time exchange rate
  static async getExchangeRate(from: string, to: string): Promise<ExchangeRate> {
    const cacheKey = `${from}-${to}`
    const cached = this.cachedRates.get(cacheKey)

    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      return cached.rate
    }

    try {
      // Fetch Pi price from CoinGecko
      const piPriceResponse = await fetch(
        "https://api.coingecko.com/api/v3/simple/price?ids=pi-network&vs_currencies=usd,vnd,php,inr,sgd,myr,thb,idr",
      )
      const piPriceData = await piPriceResponse.json()

      // Fetch fiat exchange rates
      const fiatResponse = await fetch("https://api.exchangerate-api.com/v4/latest/USD")
      const fiatData = await fiatResponse.json()

      let rate = 1

      if (from === "PI" && to === "USD") {
        rate = piPriceData["pi-network"]?.usd || 0.21
      } else if (from === "PI" && to === "VND") {
        rate = piPriceData["pi-network"]?.vnd || 5250
      } else if (from === "PI") {
        const piUsd = piPriceData["pi-network"]?.usd || 0.21
        const toCurrency = to.toLowerCase()
        rate = piUsd * (fiatData.rates[to] || 1)
      } else if (from === "USD" && to === "PI") {
        rate = 1 / (piPriceData["pi-network"]?.usd || 0.21)
      } else {
        rate = fiatData.rates[to] / fiatData.rates[from]
      }

      const exchangeRate: ExchangeRate = {
        from,
        to,
        rate,
        lastUpdated: Date.now(),
        provider: "Live Market Data",
      }

      this.cachedRates.set(cacheKey, { rate: exchangeRate, timestamp: Date.now() })
      return exchangeRate
    } catch (error) {
      console.error("[v0] Error fetching exchange rate:", error)
      // Return fallback rates
      return {
        from,
        to,
        rate: from === "PI" && to === "USD" ? 0.21 : 1,
        lastUpdated: Date.now(),
        provider: "Fallback",
      }
    }
  }

  // Calculate transfer fees
  static calculateFees(amount: number, currency: string): { network: string; service: string; total: string } {
    // Network fee (blockchain gas)
    const networkFee = currency === "PI" ? 0.0001 : 0.001

    // Service fee (0.5% for cross-border)
    const serviceFee = amount * 0.005

    const total = networkFee + serviceFee

    return {
      network: networkFee.toFixed(4),
      service: serviceFee.toFixed(4),
      total: total.toFixed(4),
    }
  }

  // Validate address format
  static validateAddress(address: string, type: "wallet" | "bank" | "phone"): boolean {
    if (type === "wallet") {
      // EVM address validation
      return /^0x[a-fA-F0-9]{40}$/.test(address) || /^@[a-zA-Z0-9_]{3,20}$/.test(address)
    } else if (type === "phone") {
      // International phone format
      return /^\+?[1-9]\d{1,14}$/.test(address)
    } else if (type === "bank") {
      // Bank account (flexible format)
      return address.length >= 8 && address.length <= 30
    }
    return false
  }

  // Save transfer history
  static saveTransfer(transfer: CrossBorderTransfer): void {
    const transfers = this.getTransferHistory()
    transfers.unshift(transfer)
    // Keep last 50 transfers
    if (transfers.length > 50) {
      transfers.length = 50
    }
    localStorage.setItem(CROSS_BORDER_STORAGE_KEY, JSON.stringify(transfers))
  }

  // Get transfer history
  static getTransferHistory(): CrossBorderTransfer[] {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(CROSS_BORDER_STORAGE_KEY)
    return data ? JSON.parse(data) : []
  }

  // Check KYC status
  static async checkKYCStatus(): Promise<{
    verified: boolean
    level: "none" | "basic" | "full"
    dailyLimit: number
    monthlyLimit: number
  }> {
    // Check Pi Network KYC status
    if (typeof window !== "undefined" && (window as any).Pi) {
      try {
        const userInfo = await (window as any).Pi.User.getInfo()
        const kycStatus = userInfo.kyc_status || "pending"

        if (kycStatus === "verified") {
          return {
            verified: true,
            level: "full",
            dailyLimit: 10000,
            monthlyLimit: 100000,
          }
        }
      } catch (error) {
        console.error("[v0] KYC check error:", error)
      }
    }

    // Check local KYC status
    const localKYC = localStorage.getItem("olivia_kyc_verified")
    if (localKYC === "true") {
      return {
        verified: true,
        level: "basic",
        dailyLimit: 1000,
        monthlyLimit: 10000,
      }
    }

    return {
      verified: false,
      level: "none",
      dailyLimit: 100,
      monthlyLimit: 1000,
    }
  }

  // Estimate arrival time
  static estimateArrivalTime(country: string, paymentMethod: string): number {
    // In minutes
    const estimates: Record<string, number> = {
      wallet: 5, // 5 minutes for Pi wallet transfers
      bank: 60, // 1 hour for bank transfers
      phone: 10, // 10 minutes for mobile money
    }

    return estimates[paymentMethod] || 30
  }
}

export default CrossBorderService
