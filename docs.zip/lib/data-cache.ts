/**
 * Smart data cache with TTL and stale-while-revalidate
 * Olivia PiMask - Lightweight caching system
 */

interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
}

interface CacheConfig {
  ttl: number // Time to live in milliseconds
  staleWhileRevalidate?: boolean // Return stale data while refreshing
}

class DataCache {
  private cache: Map<string, CacheEntry<any>> = new Map()
  private pendingRequests: Map<string, Promise<any>> = new Map()

  /**
   * Get cached data or fetch fresh data
   */
  async get<T>(key: string, fetchFn: () => Promise<T>, config: CacheConfig = { ttl: 30000 }): Promise<T> {
    const cached = this.cache.get(key)
    const now = Date.now()

    // Return fresh data from cache
    if (cached && now - cached.timestamp < cached.ttl) {
      return cached.data
    }

    // Stale-while-revalidate: return stale data + refresh in background
    if (config.staleWhileRevalidate && cached) {
      this.refresh(key, fetchFn, config)
      return cached.data
    }

    // Deduplicate requests: if already fetching, return existing promise
    if (this.pendingRequests.has(key)) {
      return this.pendingRequests.get(key)!
    }

    // Fetch fresh data
    const promise = this.fetch(key, fetchFn, config)
    this.pendingRequests.set(key, promise)

    try {
      const data = await promise
      return data
    } finally {
      this.pendingRequests.delete(key)
    }
  }

  /**
   * Fetch and cache data
   */
  private async fetch<T>(key: string, fetchFn: () => Promise<T>, config: CacheConfig): Promise<T> {
    try {
      const data = await fetchFn()
      this.set(key, data, config.ttl)
      return data
    } catch (error) {
      // Return stale data on error if available
      const cached = this.cache.get(key)
      if (cached) {
        return cached.data
      }
      throw error
    }
  }

  /**
   * Refresh data in background
   */
  private async refresh<T>(key: string, fetchFn: () => Promise<T>, config: CacheConfig) {
    try {
      const data = await fetchFn()
      this.set(key, data, config.ttl)
    } catch (error) {
      // Silent fail - keep using stale data
    }
  }

  /**
   * Set data in cache
   */
  set<T>(key: string, data: T, ttl: number) {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl,
    })
  }

  /**
   * Invalidate cache entry
   */
  invalidate(key: string) {
    this.cache.delete(key)
  }

  /**
   * Clear all cache
   */
  clear() {
    this.cache.clear()
    this.pendingRequests.clear()
  }

  /**
   * Clean expired cache entries
   */
  cleanup() {
    const now = Date.now()
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key)
      }
    }
  }
}

// Global cache instance
export const dataCache = new DataCache()

// Cleanup expired entries every 5 minutes
if (typeof window !== "undefined") {
  setInterval(() => dataCache.cleanup(), 5 * 60 * 1000)
}

// Cache presets for different data types
export const CACHE_PRESETS = {
  BALANCE: { ttl: 15000, staleWhileRevalidate: true }, // 15s
  MINING: { ttl: 300000, staleWhileRevalidate: true }, // 5 min
  TOKEN_INFO: { ttl: 3600000 }, // 1 hour (rarely changes)
  TRANSACTIONS: { ttl: 30000, staleWhileRevalidate: true }, // 30s
  PRICE: { ttl: 10000, staleWhileRevalidate: true }, // 10s
}
