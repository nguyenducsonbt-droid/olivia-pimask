// Pi SDK utility functions for Olivia PiMask

import { playSound } from "@/lib/sounds"

/**
 * Callback function for handling incomplete payments
 * Called by Pi SDK during authentication if there are pending/incomplete payments
 */
export function onIncompletePaymentFound(payment: any) {
  console.log("[v0] Incomplete payment found:", payment)

  if (payment.status === "completed" || payment.status === "confirmed") {
    playSound("receive")
  }

  // You can handle incomplete payments here
  // For example: show a notification, redirect to payment completion page, etc.

  return payment
}
