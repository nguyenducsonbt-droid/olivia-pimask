export const PlatformUtils = {
  // Detect iOS
  isIOS: () => {
    if (typeof window === "undefined") return false
    return (
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
    )
  },

  // Detect Android
  isAndroid: () => {
    if (typeof window === "undefined") return false
    return /Android/.test(navigator.userAgent)
  },

  // Check if running in standalone mode (iOS PWA)
  isStandalone: () => {
    if (typeof window === "undefined") return false
    return (window.navigator as any).standalone === true || window.matchMedia("(display-mode: standalone)").matches
  },

  // Haptic feedback for iOS/Android
  vibrate: (duration = 10) => {
    if (typeof window === "undefined") return

    try {
      // iOS haptic feedback
      if (PlatformUtils.isIOS()) {
        // Light haptic feedback on iOS
        if ((navigator as any).vibrate) {
          ;(navigator as any).vibrate(duration)
        }
      }
      // Android vibration
      else if (PlatformUtils.isAndroid()) {
        if (navigator.vibrate) {
          navigator.vibrate(duration)
        }
      }
    } catch (error) {
      console.log("[v0] Vibration not supported", error)
    }
  },

  // Request camera permission
  requestCameraPermission: async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      stream.getTracks().forEach((track) => track.stop())
      return true
    } catch (error) {
      console.log("[v0] Camera permission denied", error)
      return false
    }
  },

  // Request notification permission
  requestNotificationPermission: async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      return permission === "granted"
    }
    return false
  },

  // Get safe area insets for iOS notch
  getSafeAreaInsets: () => {
    if (typeof window === "undefined") return { top: 0, bottom: 0, left: 0, right: 0 }

    const style = getComputedStyle(document.documentElement)
    return {
      top: Number.parseInt(style.getPropertyValue("env(safe-area-inset-top)") || "0"),
      bottom: Number.parseInt(style.getPropertyValue("env(safe-area-inset-bottom)") || "0"),
      left: Number.parseInt(style.getPropertyValue("env(safe-area-inset-left)") || "0"),
      right: Number.parseInt(style.getPropertyValue("env(safe-area-inset-right)") || "0"),
    }
  },
}
